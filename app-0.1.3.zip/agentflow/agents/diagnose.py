"""Lead 诊断前置（先查清现场，再决定要不要派工）。"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import func
from sqlmodel import Session, select

from agentflow.config import detect_exec_env
from agentflow.storage import models as m
from agentflow.storage import trace as tr

_VALID_VERDICTS = ("ops", "single", "complex")
_MIN_EVIDENCE = 1


class DiagnosisError(Exception):
    """诊断卡不合规（缺证据/字段非法/无 JSON 卡）——响亮失败，调用方决定重试或停机。"""


def build_diagnose_system() -> str:
    return (
        "你是团队 Lead 的现场诊断模式（只读）。任务尚未拆解，你的职责是**先查清现场再定方向**，"
        "严禁不查代码/不跑探针就下结论。\n\n"
        "可用工具：read_file / grep / glob / run_cmd（只读命令）。禁止写文件、禁止构建、禁止起停服务。\n\n"
        "规则：\n"
        "1. 证据先行：每个结论必须有至少一条你真实执行过的命令或读过的文件佐证，禁止无证据推断。\n"
        "2. 探针从简：优先秒级只读命令——HTTP 探活（curl/Invoke-WebRequest）、文件存在性（Test-Path）、"
        "git log/status、日志与配置查看。禁止任何写操作。\n"
        "3. 步数预算：尽量 8 步内完成；查不到的就明说查不到，不要编。\n"
        "4. 结束前必须输出一张「诊断卡」，用 ```json 代码块，字段固定：\n"
        '   {"verdict": "ops|single|complex", "root_cause": "根因一句话", '
        '"evidence": [{"cmd": "你执行过的命令", "output": "关键输出摘录≤300字"}], '
        '"suggestion": "建议的解决路径", '
        '"ops_cmd": "仅 verdict=ops 时必填：修复命令（一条可直接执行的运维命令）", '
        '"verify_cmd": "仅 verdict=ops 时必填：验证命令（跑它 exit 0 = 问题已解决，如 status/探活）"}\n'
        "   verdict 判定标准：ops = 运维/环境/数据问题，跑一条命令或重置即可解决，不需要改代码；"
        "single = 单功能小修（1-2 个文件能收口）；complex = 需要多功能拆解。\n"
        "5. 诊断卡输出后调用 done。"
    )


def _shell_hint(shell: str) -> str:
    """执行环境说明。"""
    if shell == "bash":
        import platform

        if platform.system().lower() == "windows":
            return (
                "执行环境: Windows（Git Bash）——命令按 bash/POSIX 方言书写"
                "（如 test -f、grep -q、command -v、curl、sed）；"
                ".ps1 脚本调用与 $env: 引用平台会自动改走 PowerShell。"
            )
        return "执行环境: Linux/macOS（命令按 bash/POSIX 方言书写）"
    if shell == "powershell":
        return "执行环境: Windows（命令按 PowerShell 或 cmd 方言书写均可，平台自动选择解释器）"
    return f"执行环境: shell={shell}"


def build_diagnose_prompt(task: m.Task, project: m.Project, history_text: str, shell: str) -> str:
    return (
        f"PROJECT_PATH: {project.repo_path}\n"
        f"{_shell_hint(shell)}\n\n"
        f"## 任务信息\n"
        f"任务标题: {task.title}\n"
        f"原始需求: {task.raw_request or '（空，以澄清历史为准）'}\n\n"
        f"## 澄清历史（用户消息逐字保留）\n{history_text or '（暂无）'}\n\n"
        "请按系统提示完成现场诊断，输出诊断卡 JSON 后调用 done。"
    )


def parse_diagnosis_card(text: str) -> dict:
    """从 agent 最终输出提取并校验诊断卡。不合规抛 DiagnosisError（带具体缺什么）。"""
    block = _last_json_block(text or "")
    if block is None:
        raise DiagnosisError("输出中没有 ```json 诊断卡代码块")
    try:
        card = json.loads(block)
    except json.JSONDecodeError as e:
        raise DiagnosisError(f"诊断卡不是合法 JSON: {e}") from e
    if not isinstance(card, dict):
        raise DiagnosisError("诊断卡必须是 JSON 对象")
    verdict = card.get("verdict")
    if verdict not in _VALID_VERDICTS:
        raise DiagnosisError(f"verdict 必须是 {'|'.join(_VALID_VERDICTS)} 之一，得到: {verdict!r}")
    ev = card.get("evidence")
    if not isinstance(ev, list) or len(ev) < _MIN_EVIDENCE:
        raise DiagnosisError(f"evidence 至少 {_MIN_EVIDENCE} 条真实探针证据（命令+输出），得到: {type(ev).__name__}")
    for i, e in enumerate(ev):
        if not isinstance(e, dict) or not (e.get("cmd") or "").strip():
            raise DiagnosisError(f"evidence[{i}] 缺少真实执行过的 cmd")
    if verdict == "ops":
        if not (card.get("ops_cmd") or "").strip():
            raise DiagnosisError("verdict=ops 时必须给出 ops_cmd（修复命令）")
        if not (card.get("verify_cmd") or "").strip():
            raise DiagnosisError("verdict=ops 时必须给出 verify_cmd（验证命令：跑它 exit 0 = 问题已解决）")
    return card


def _last_json_block(text: str) -> str | None:
    """取最后一个 ```json 围栏块；无围栏时回退首个平衡花括号块（兼容无围栏输出）。"""
    import re

    blocks = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", text, flags=re.DOTALL)
    if blocks:
        return blocks[-1]
    start = text.find("{")
    if start == -1:
        return None
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[start : i + 1]
    return None


def latest_diagnosis(session: Session, task_id: int) -> str:
    """读取本任务最新诊断卡（HandoffNote.kind=diagnosis）。无 → 空串。"""
    note = (
        session.exec(
            select(m.HandoffNote)
            .where(m.HandoffNote.task_id == task_id, m.HandoffNote.kind == "diagnosis")
            .order_by(m.HandoffNote.id.desc())
        ).first()
    )
    return note.content if note else ""


def run_pre_spec_diagnosis(engine, gateway, bus, settings, task_id: int) -> dict | None:
    """Spec 生成前跑一轮只读现场诊断。返回诊断卡 dict。"""
    with Session(engine) as s:
        prev = latest_diagnosis(s, task_id)
        if prev:
            try:
                return parse_diagnosis_card(prev)
            except DiagnosisError:
                pass
        task = s.get(m.Task, task_id)
        if task is None:
            raise DiagnosisError(f"任务#{task_id} 不存在")
        project = s.get(m.Project, task.project_id)
        repo_root = Path(project.repo_path)
        history_rows = (
            s.query(m.ClarifyMessage)
            .filter(m.ClarifyMessage.task_id == task_id, m.ClarifyMessage.role == "user")
            .order_by(m.ClarifyMessage.id.asc())
            .all()
        )
        history_text = "\n".join(f"用户: {(r.content or '')[:400]}" for r in history_rows)
        instance = m.AgentInstance(task_id=task_id, role="lead", model=_record_model(gateway, "lead"))
        s.add(instance)
        s.commit()

        node = _new_lead_node(s, settings, task, project, instance.id, "diagnose", f"现场诊断: {task.title}")
        rt = _build_runtime(engine, gateway, bus, settings, repo_root)
        feedback = ""
        last_err: DiagnosisError | None = None
        for _attempt in (1, 2):
            prompt = build_diagnose_prompt(task, project, history_text, detect_exec_env()["shell"])
            if feedback:
                prompt += f"\n\n【上一轮诊断卡被拒】{feedback}\n请补齐证据后重新输出合规诊断卡。"
            from agentflow.agents.base import Dispatch
            from agentflow.safety.command import Safety





            dispatch = Dispatch(
                task=task, role="lead", feature=None,
                system=build_diagnose_system(), prompt=prompt, node_kind="diagnose", node_id=node.id,
                max_steps=int(settings.data.get("lead", {}).get("diagnose_max_steps", 22)),
            )
            try:
                text = rt.run(dispatch, s, Safety(settings))
                card = parse_diagnosis_card(text)
            except DiagnosisError as e:
                last_err = e
                feedback = str(e)
                continue
            _finish_node(s, node, m.NodeStatus.succeeded,
                         f"诊断完成: verdict={card['verdict']} 根因={str(card.get('root_cause', ''))[:120]}")
            _persist_card(s, task_id, card)
            bus.publish_task(task_id, "log.appended", {
                "level": "lead",
                "message": f"Lead 现场诊断完成: {card['verdict']} | {str(card.get('root_cause', ''))[:200]}",
            })
            return card
        _finish_node(s, node, m.NodeStatus.failed, f"诊断卡不合规（2 轮）: {last_err}")
        raise last_err if last_err else DiagnosisError("诊断失败")


def _build_runtime(engine, gateway, bus, settings, repo_root: Path):
    from agentflow.agents.base import AgentRuntime


    return AgentRuntime(
        engine, gateway, bus, settings, repo_root,
        drop_tools={"edit_file", "write_file", "delete_file", "ask_lead"},
    )


def _record_model(gateway, role: str) -> str:
    """AgentInstance 记录用模型名（元数据）：档案未配置时留空不阻断（同 scheduler._record_model）。"""
    try:
        return gateway.model_for(role) or ""
    except Exception:
        return ""


def _new_lead_node(s: Session, settings, task: m.Task, project: m.Project, agent_id: int,
                   kind: str, summary: str) -> m.Node:
    trace_dir = tr.trace_dir_for(settings, Path(project.repo_path).name, task.id)
    row = s.exec(select(func.max(m.Node.seq)).where(m.Node.task_id == task.id)).one()
    node = m.Node(
        task_id=task.id, agent_id=agent_id, feature_id=None,
        seq=int(row or 0) + 1, kind=kind, role="lead",
        status=m.NodeStatus.running,
        started_at=_utcnow(),
        summary=summary,
        trace_uri="",
    )
    s.add(node)
    s.commit()
    node.trace_uri = tr.new_trace_file(trace_dir, node.id)
    s.add(node)
    s.commit()
    return node


def _finish_node(s: Session, node: m.Node, status: m.NodeStatus, summary: str) -> None:
    node.status = status
    node.ended_at = _utcnow()
    if node.started_at:
        node.duration_ms = int(
            (datetime.now(timezone.utc) - datetime.fromisoformat(node.started_at)).total_seconds() * 1000
        )
    node.summary = summary[:300]
    s.add(node)
    s.commit()


def _persist_card(s: Session, task_id: int, card: dict) -> None:
    s.add(m.HandoffNote(
        task_id=task_id, feature_id=None, role="lead", kind="diagnosis", seq=0,
        content=json.dumps(card, ensure_ascii=False),
    ))
    s.commit()




def build_ops_exec_system() -> str:
    return (
        "你是团队 Lead 的运维执行模式（诊断已判定：这是运维问题，不需要改代码）。"
        "现在由你自主执行修复，并验证问题是否真解决。\n\n"
        "可用工具：run_cmd（命令过安全策略：危险命令会被拒或转人工审批）、read_file / grep / glob。\n"
        "禁止写文件（运维任务不改代码；若发现必须改代码才能解决，直接 done 说明并给出证据）。\n\n"
        "规则：\n"
        "1. 命令失败不要放弃：读懂报错，换参数/换写法/换路径再试（shell 方言、路径、进程状态、"
        "权限各有各的对策）；同一条命令同一错误连续失败 2 次就换思路。\n"
        "1a. **run_cmd 是同步执行、有超时——绝不要同步等一个「前台常驻」的命令返回**。"
        "构建+起服务一体的脚本（如 kk_dash 的 `sop.ps1 prod`：静态导出后会前台常驻 8234 预览）"
        "永远不返回，同步跑必然超时，再反复查端口/读日志就把步数烧光。"
        "正确做法：**把常驻服务放后台起**（Windows 用 `Start-Process` 或 `cmd /c start /b`，输出重定向到日志文件），"
        "然后**轮询就绪**（`Get-NetTCPConnection -LocalPort <port>` 看 Listen + 请求目标 URL 看内容），"
        "最后再跑验证命令收尾。纯构建（只 build 不起服务）可以同步跑，但要给足 timeout（如 600s）。\n"
        "2. 完成前必须用验证命令证实问题已解决，验证不通过不算完成（你自证之后系统还会独立复跑一次）。\n"
        "3. 步数预算内自主推进；确实解决不了就如实 done：说清卡在哪、试过什么、还差什么。\n"
        "4. 收尾调用 done，summary 写清：执行过哪些命令、验证命令与关键输出、结论（已解决/未解决+原因）。\n"
    )


def build_ops_exec_prompt(task: m.Task, project: m.Project, card: dict, shell: str) -> str:
    ev = [e for e in (card.get("evidence") or []) if isinstance(e, dict)]
    ev_text = "\n".join(
        f"- {str(e.get('cmd', ''))[:160]} → {str(e.get('output', ''))[:200]}" for e in ev[:6]
    )
    return (
        f"PROJECT_PATH: {project.repo_path}\n"
        f"{_shell_hint(shell)}\n\n"
        f"## 任务\n标题: {task.title}\n原始需求: {task.raw_request or '（以诊断结论为准）'}\n\n"
        f"## 诊断现场（已查实，可直接采信）\n"
        f"根因: {str(card.get('root_cause', ''))[:400]}\n"
        f"建议路径: {str(card.get('suggestion', ''))[:400]}\n"
        f"修复命令（起点，可按现场调整）: `{str(card.get('ops_cmd', '')).strip()}`\n"
        f"验证命令（exit 0 = 已解决）: `{str(card.get('verify_cmd', '')).strip()}`\n\n"
        f"## 现场证据\n{ev_text or '（无）'}\n\n"
        "请执行修复并用验证命令确认，然后调用 done。"
    )


def latest_ops_exec(session: Session, task_id: int) -> dict | None:
    """读取本任务最新运维执行结论（HandoffNote.kind=ops_exec）。无/损坏 → None。"""
    note = (
        session.exec(
            select(m.HandoffNote)
            .where(m.HandoffNote.task_id == task_id, m.HandoffNote.kind == "ops_exec")
            .order_by(m.HandoffNote.id.desc())
        ).first()
    )
    if not note:
        return None
    try:
        data = json.loads(note.content)
        return data if isinstance(data, dict) else None
    except (json.JSONDecodeError, TypeError):
        return None


def _git_main_head(repo_root: Path) -> str:
    """main 的 HEAD sha（best-effort：非 git/无 main → 空串，调用方按"无变更"保守处理）。"""
    try:
        from agentflow.git_runtime.repo import RepoHandle

        return RepoHandle(str(repo_root)).repo.git.rev_parse("main").strip()
    except Exception:
        return ""


def run_ops_execution(engine, gateway, bus, settings, task_id: int, card: dict) -> dict:
    """诊断判定 ops 后的自主执行（用户拍板：去掉人工触发按钮，AI 自己分析并执行）。"""
    from agentflow.agents.base import Dispatch
    from agentflow.safety.command import Safety, run_command

    out: dict = {
        "ok": False, "summary": "", "stop_reason": "", "verify_exit": None, "verify_output": "",
        "ops_cmd": str(card.get("ops_cmd") or "").strip(),
        "verify_cmd": str(card.get("verify_cmd") or "").strip(),
        "main_before": "", "main_after": "", "code_changed": False,
    }
    try:
        verify_cmd = out["verify_cmd"]
        with Session(engine) as s:
            task = s.get(m.Task, task_id)
            if task is None:
                out["summary"] = f"任务#{task_id} 不存在"
                return out
            project = s.get(m.Project, task.project_id)
            repo_root = Path(project.repo_path)
            instance = m.AgentInstance(task_id=task_id, role="lead", model=_record_model(gateway, "lead"))
            s.add(instance)
            s.commit()
            node = _new_lead_node(s, settings, task, project, instance.id, "ops", f"运维执行: {task.title}")
            try:
                max_steps = int(settings.data.get("lead", {}).get("ops_max_steps", 15))
            except (TypeError, ValueError):
                max_steps = 15
            rt = _build_runtime(engine, gateway, bus, settings, repo_root)

            main_before = _git_main_head(repo_root)
            dispatch = Dispatch(
                task=task, role="lead", feature=None,
                system=build_ops_exec_system(),
                prompt=build_ops_exec_prompt(task, project, card, detect_exec_env()["shell"]),
                node_kind="ops", node_id=node.id, max_steps=max_steps,
            )
            err = ""
            try:
                text = rt.run(dispatch, s, Safety(settings))
            except Exception as e:
                text, err = "", f"{type(e).__name__}: {e}"
            out["stop_reason"] = dispatch.stop_reason
            out["summary"] = (text or "").strip()
            if err:
                out["summary"] = (out["summary"] + "\n" if out["summary"] else "") + f"[执行中断] {err}"
            if verify_cmd:
                try:
                    timeout_s = float(settings.data.get("lead", {}).get("ops_cmd_timeout_s", 600))
                except (TypeError, ValueError):
                    timeout_s = 600.0
                code, vout = run_command(verify_cmd, repo_root, timeout=int(timeout_s))
                out["verify_exit"] = code
                out["verify_output"] = vout[-1200:] if len(vout) > 1200 else vout
                out["ok"] = code == 0
            else:

                out["ok"] = dispatch.stop_reason == "done" and not err


            out["main_before"] = main_before
            out["main_after"] = _git_main_head(repo_root)
            out["code_changed"] = bool(main_before and out["main_after"] and main_before != out["main_after"])
            _finish_node(s, node, m.NodeStatus.succeeded if out["ok"] else m.NodeStatus.failed,
                         f"运维执行{'成功' if out['ok'] else '未通过'}: {out['summary'][:120]}")
            _persist_ops_exec(s, task_id, out)
        return out
    except Exception as e:
        out["summary"] = (out["summary"] + "\n" if out["summary"] else "") + f"[执行异常] {type(e).__name__}: {e}"
        return out


def _persist_ops_exec(s: Session, task_id: int, out: dict) -> None:
    s.add(m.HandoffNote(
        task_id=task_id, feature_id=None, role="lead", kind="ops_exec", seq=0,
        content=json.dumps({
            "ok": out["ok"],
            "ops_cmd": out.get("ops_cmd", ""),
            "verify_cmd": out.get("verify_cmd", ""),
            "verify_exit": out.get("verify_exit"),
            "stop_reason": out.get("stop_reason", ""),
            "summary": (out.get("summary") or "")[:1500],

            "main_before": out.get("main_before", ""),
            "main_after": out.get("main_after", ""),
            "code_changed": bool(out.get("code_changed")),
            "ts": _utcnow(),
        }, ensure_ascii=False),
    ))
    s.commit()


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()
