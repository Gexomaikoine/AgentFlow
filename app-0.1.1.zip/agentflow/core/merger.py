"""串行合并队列消费（P1）：每项目独立串行，协调 worktree / 冲突解 / 集成校验。"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from agentflow.core.events_bus import EventBus
from agentflow.core.scheduler import _node_payload
from agentflow.git_runtime import merge as merge_mod
from agentflow.git_runtime import worktree
from agentflow.git_runtime.repo import GitError, RepoHandle
from agentflow.storage import models as m, trace as tr
from sqlalchemy import func
from sqlmodel import Session, select



ConflictResolver = Callable[[RepoHandle, list[str], m.Task, m.Project, m.Spec, int | None], bool]
IntegrationValidator = Callable[[Session, RepoHandle, m.Task, m.Project], str | None]





class GateRework(Exception):
    """门禁判定产品缺陷并已回灌开发循环：合并中止，记 reworked，拉起开发继续修。"""

    def __init__(self, task_id: int, feature_seq: int, reason: str = ""):
        self.task_id = task_id
        self.feature_seq = feature_seq
        super().__init__(reason or f"门禁回灌开发循环（任务#{task_id} 功能[{feature_seq}]）")

    def __str__(self) -> str:
        return self.args[0] if self.args else "门禁回灌开发循环"


def replay_feature_conflicts(repo: RepoHandle, anchors: list[dict]) -> list[dict]:
    """Bors 式冲突定位（F，Gastown Refinery 同型）：把各功能的绿点 commit 逐个重放到"""
    g = repo.repo.git
    results: list[dict] = []
    for a in anchors:
        try:
            g.cherry_pick("--no-commit", a["commit"], with_exceptions=False)
            files = [l for l in (g.diff("--name-only", "--diff-filter=U") or "").splitlines() if l.strip()]
        except Exception:
            files = ["<重放异常>"]
        for undo in ("cherry_pick --abort", "reset --hard"):
            try:
                if undo == "cherry_pick --abort":
                    g.cherry_pick("--abort", with_exceptions=False)
                elif not repo.is_clean():
                    g.reset("--hard", with_exceptions=False)
            except Exception:
                pass
        if files:
            results.append({
                "feature_id": a.get("feature_id"),
                "seq": a.get("seq"),
                "title": a.get("title") or "",
                "commit": str(a.get("commit") or "")[:10],
                "files": files[:10],
            })
    return results


def task_anchors(session: Session, task_id: int) -> list[dict]:
    """任务的有效绿点（按 id 升序）→ [{commit, feature_id, seq, title}]。"""
    rows = session.exec(
        select(m.GreenAnchor).where(
            m.GreenAnchor.task_id == task_id,
            m.GreenAnchor.invalidated_at == None,
        )
    ).all()
    if not rows:
        return []
    feats = {f.id: f for f in session.exec(select(m.Feature).where(m.Feature.task_id == task_id)).all()}
    return [
        {
            "commit": a.commit_hash,
            "feature_id": a.feature_id,
            "seq": getattr(feats.get(a.feature_id), "seq", None),
            "title": getattr(feats.get(a.feature_id), "title", ""),
        }
        for a in sorted(rows, key=lambda x: x.id)
    ]


def bisect_feature_conflicts(wt_repo: RepoHandle, session: Session, task_id: int) -> list[dict]:
    """replay_feature_conflicts 的 DB 版：加载任务的有效绿点 + 功能元数据后重放。"""
    return replay_feature_conflicts(wt_repo, task_anchors(session, task_id))


def format_conflict_attribution(items: list[dict]) -> str:
    """冲突归因 → 人类可读一行（日志/失败原因用）。"""
    if not items:
        return ""
    parts = []
    for it in items:
        files = ", ".join(it.get("files") or [])
        parts.append(f"功能[{it.get('seq')}]{(it.get('title') or '')[:30]} ← {it.get('commit')} 与 main 冲突于（{files}）")
    return "；".join(parts)


@dataclass
class _OptDequeued:
    """出队轻量对象（仅含消费所需 id，避免 detached session 访问）。"""
    id: int
    task_id: int
    round_no: int = 1


class MergeConsumer:
    def __init__(
        self,
        engine,
        settings,
        bus: EventBus,
        settings_dict: dict,
        session_factory=None,
        resolver: ConflictResolver | None = None,
        validator: IntegrationValidator | None = None,
        on_merged=None,
        on_gate_rework=None,
    ):
        self.engine = engine
        self.settings = settings
        self.bus = bus
        self.settings_dict = settings_dict
        self._session_factory = session_factory or (lambda: Session(self.engine))
        self._resolver = resolver
        self._validator = validator
        self._on_merged = on_merged

        self._on_gate_rework = on_gate_rework
        self._busy: dict[int, asyncio.Lock] = {}
        self._stop = False
        self._poll_s = 2

    def _lock_for(self, project_id: int) -> asyncio.Lock:
        if project_id not in self._busy:
            self._busy[project_id] = asyncio.Lock()
        return self._busy[project_id]

    def _merge_cfg(self) -> dict:
        mcfg = self.settings_dict.get("merge", {})
        return {
            "ai_conflict_max_files": int(mcfg.get("ai_conflict_max_files", 3)),
            "max_ai_retries": int(mcfg.get("max_ai_retries", 1)),





            "max_engine_retries": int(mcfg.get("max_engine_retries", 2)),
        }

    def _dequeue(self, project_id: int) -> _OptDequeued | None:
        with self._session_factory() as s:


            held = s.exec(
                select(m.MergeQueueEntry)
                .where(m.MergeQueueEntry.project_id == project_id, m.MergeQueueEntry.hold == True)
            ).first()
            if held is not None:
                return None
            row = s.exec(
                select(m.MergeQueueEntry)
                .where(m.MergeQueueEntry.project_id == project_id, m.MergeQueueEntry.status == "queued")
                .order_by(m.MergeQueueEntry.id.asc())
            ).first()
            if row is None:
                return None
            row.status = "merging"
            row.updated_at = datetime.now(timezone.utc).isoformat()
            s.add(row)
            s.commit()

            _id = row.id
            _tid = row.task_id
            _round = row.round_no
            return _OptDequeued(id=_id, task_id=_tid, round_no=_round)

    def _set_status(
        self, entry_id: int, task_id: int, status: str, error: str | None = None, attempts: int | None = None
    ) -> None:
        with self._session_factory() as s:
            row = s.get(m.MergeQueueEntry, entry_id)
            if row is None:
                return
            row.status = status
            row.updated_at = datetime.now(timezone.utc).isoformat()
            if error is not None:
                row.error = (error or "")[:2000]
            if attempts is not None:
                row.attempts = attempts
            t = s.get(m.Task, task_id)
            status_map = {


                "merged": m.TaskStatus.human_review,
                "failed": m.TaskStatus.failed,
                "aborted": m.TaskStatus.aborted,
            }
            if t is not None and status in status_map:




                if t.status == m.TaskStatus.aborted:
                    row.status = "aborted"
                    row.error = row.error or "任务已被用户废弃：合并结果不予采纳"
                    s.add(row)
                    s.commit()
                    self.bus.publish_task(task_id, "merge.updated", {"status": "aborted", "error": row.error})
                    self._close_running_merge_nodes(s, task_id, "aborted", "任务已废弃，合并中断")
                    return


                if not (status == "merged" and t.status in m.MERGED_OK_STATUSES):
                    t.status = status_map[status]
                    if status == "merged" and not t.completed_at:
                        t.completed_at = datetime.now(timezone.utc).isoformat()
                    s.add(t)
            s.add(row)
            s.commit()
            self.bus.publish_task(task_id, "task.updated", {
                "task_id": task_id,
                "status": t.status.value if t else "",


                "branch": t.branch if t else "",
            })






            if status in ("merged", "failed", "aborted", "reworked"):
                self._evolve_after_final(task_id)
            self.bus.publish_task(task_id, "merge.updated", {"status": status, "error": row.error})

            if status in ("merged", "failed", "aborted", "reworked"):
                self._close_running_merge_nodes(s, task_id, status, error or "")

            if status == "failed":
                from agentflow.core.services import HARNESS_MARK

                err_txt = (error or "").strip()

                if HARNESS_MARK in err_txt:
                    prefix, opts = "合并被机审环境问题挡住（非代码问题）", ["查看 Report", "人工处理后恢复", "回滚"]
                elif "引擎内部异常" in err_txt or "合并消费异常" in err_txt:
                    prefix, opts = "合并因 AgentFlow 引擎内部异常中断（非项目代码问题）", ["查看 Report", "人工处理后恢复", "回滚"]
                else:


                    prefix, opts = "集成校验未过", ["查看 Report", "重规划", "人工修复后恢复", "回滚"]
                self.bus.publish_task(task_id, "human.required", {
                    "reason": f"{prefix}:{err_txt[:400]}（详见 Report 页失败明细）",
                    "options": opts,
                })

            if status == "merged":
                self.bus.publish_task(task_id, "merge.review_required", {
                    "task_id": task_id,
                    "merged_sha": row.merged_sha or "",
                    "round_no": row.round_no,
                    "attempts": row.attempts,
                    "error": row.error or "",
                })

    def _evolve_after_final(self, task_id: int) -> None:
        """合并终态补评（best-effort，不阻塞合并主链路）。"""
        try:
            from agentflow.core import evolution

            evolution.maybe_evolve(self.engine, None, self.bus, self.settings, task_id)
        except Exception:
            pass

    def _create_merge_node(self, task_id: int, project_id: int, title: str) -> int | None:
        """#6：合并队列出队即建 PM 合并节点（真实介入的 agent 必须有图块）。"""
        try:
            with self._session_factory() as s:
                t = s.get(m.Task, task_id)
                proj = s.get(m.Project, project_id)
                if not t or not proj:
                    return None
                ai = m.AgentInstance(task_id=task_id, role="pm", model="")
                s.add(ai)
                s.flush()
                trace_dir = tr.trace_dir_for(self.settings, proj.name, task_id)
                max_seq = s.exec(select(func.max(m.Node.seq)).where(m.Node.task_id == task_id)).one() or 0
                node = m.Node(
                    task_id=task_id,
                    agent_id=ai.id,
                    feature_id=None,
                    seq=int(max_seq) + 1,
                    kind="merge",
                    role="pm",
                    status=m.NodeStatus.running,
                    started_at=datetime.now(timezone.utc).isoformat(),
                    summary=f"合并: 任务#{task_id} {title}",
                    trace_uri=tr.new_trace_file(trace_dir, 0),
                )
                s.add(node)
                s.flush()
                node.trace_uri = tr.new_trace_file(trace_dir, node.id)
                s.add(node)
                s.commit()
                self.bus.publish_task(task_id, "node.updated", _node_payload(node))
                return node.id
        except Exception:
            return None

    def _close_running_merge_nodes(self, session: Session, task_id: int, status: str, error: str) -> None:
        """把本任务运行中的 merge 节点置终态并推事件（merged→succeeded，其余→failed）。"""
        try:
            nodes = session.exec(
                select(m.Node).where(
                    m.Node.task_id == task_id,
                    m.Node.kind == "merge",
                    m.Node.status == m.NodeStatus.running,
                )
            ).all()
            final = m.NodeStatus.succeeded if status == "merged" else m.NodeStatus.failed
            for node in nodes:
                node.status = final
                node.ended_at = datetime.now(timezone.utc).isoformat()
                if node.started_at:
                    try:
                        start = datetime.fromisoformat(node.started_at)
                        end = datetime.fromisoformat(node.ended_at)
                        node.duration_ms = max(0, int((end - start).total_seconds() * 1000))
                    except Exception:
                        pass
                if final == m.NodeStatus.failed and error:
                    node.summary = f"合并失败: {error[:200]}"
                session.add(node)
                self.bus.publish_task(task_id, "node.updated", _node_payload(node))
            if nodes:
                session.commit()
        except Exception:
            pass

    def async_run(self) -> asyncio.Task:
        compressed = self
        return asyncio.create_task(compressed._loop(), name="merge-consumer")

    async def _loop(self) -> None:
        while not self._stop:

            with self._session_factory() as s:
                projects = s.exec(
                    select(m.MergeQueueEntry.project_id)
                    .where(m.MergeQueueEntry.status == "queued")
                    .distinct()
                ).all()
            for pid in projects:
                async with self._lock_for(int(pid)):
                    entry = self._dequeue(int(pid))
                    if entry is None:
                        continue
                    await self._handle(int(pid), entry)
            await asyncio.sleep(self._poll_s)

    def stop(self) -> None:
        self._stop = True

    async def _handle(self, project_id: int, entry) -> None:
        """处理一个合并条目。串行由外层(每项目 _lock_for)保证。"""
        wt_repo: RepoHandle | None = None
        try:
            with self._session_factory() as s:
                task = s.get(m.Task, entry.task_id)
                spec = (
                    s.exec(select(m.Spec).where(m.Spec.task_id == task.id).order_by(m.Spec.id.desc()))
                    .first()
                ) if task else None
                proj = s.get(m.Project, project_id)

                t_branch = task.branch if task else ""
                repo_path = Path(proj.repo_path) if proj else None
                t_status = task.status if task else None

                anchors = task_anchors(s, entry.task_id) if task else []
            if not task or not proj:
                self._set_status(entry.id, entry.task_id, "failed", error="任务/项目不存在")
                return

            if t_status == m.TaskStatus.aborted:
                self._set_status(entry.id, entry.task_id, "aborted", error="任务已被用户终止，跳过合并")
                return





            with self._session_factory() as ms:
                _t = ms.get(m.Task, entry.task_id)


                if _t is not None and _t.status in (m.TaskStatus.done, m.TaskStatus.failed, m.TaskStatus.running):
                    _t.status = m.TaskStatus.merging
                    ms.add(_t)
                    ms.commit()
                    self.bus.publish_task(entry.task_id, "task.updated",
                                          {"task_id": entry.task_id, "status": "merging"})



            resolver = self._resolver
            validator = self._validator
            cfg = self._merge_cfg()

            node_id = self._create_merge_node(entry.task_id, project_id, task.title)

            wt = worktree.ensure_merge_worktree(self.settings, repo_path, project_id)




            try:
                from agentflow.projects.registry import project_dep_strategy

                with Session(self.engine) as _dep_s:
                    _strategy = project_dep_strategy(_dep_s, project_id)
                if _strategy == "junction_node_modules" and repo_path is not None:
                    worktree.link_node_deps(Path(repo_path), Path(wt))
            except Exception:
                pass



            try:
                from agentflow.projects.registry import project_runtime_data_dirs

                with Session(self.engine) as _dat_s:
                    _data_dirs = project_runtime_data_dirs(_dat_s, project_id)
                if _data_dirs and repo_path is not None:
                    worktree.link_runtime_data(Path(repo_path), Path(wt), _data_dirs)
            except Exception:
                pass
            wt_repo = RepoHandle(wt)


            conflict_attribution = ""
            try:
                with self._session_factory() as bs:
                    _attribution_items = await asyncio.to_thread(bisect_feature_conflicts, wt_repo, bs, entry.task_id)
                conflict_attribution = format_conflict_attribution(_attribution_items)
                if conflict_attribution:
                    self.bus.publish_task(entry.task_id, "log.appended", {
                        "level": "sched",
                        "message": f"冲突定位（逐功能重放 main 顶端）：{conflict_attribution[:600]}",
                    })
            except Exception:
                pass
            conflicts = merge_mod.start_merge(wt_repo, t_branch, anchors=anchors)
            if conflicts:
                if len(conflicts) > cfg["ai_conflict_max_files"]:
                    merge_mod.abort_merge(wt_repo)
                    self._set_status(entry.id, entry.task_id, "failed", error=f"冲突文件数 {len(conflicts)} 超上限（门禁②）：{conflicts[:5]}{('。' + conflict_attribution) if conflict_attribution else ''}")
                    return

                if resolver is not None:
                    ok = await asyncio.to_thread(resolver, wt_repo, conflicts, task, proj, spec, node_id)
                    if not ok:
                        merge_mod.abort_merge(wt_repo)
                        self._set_status(entry.id, entry.task_id, "failed", error=f"AI 解冲突失败，停机人工{('。' + conflict_attribution) if conflict_attribution else ''}")
                        return
                if merge_mod.conflicts_unresolved(wt_repo, conflicts):
                    merge_mod.abort_merge(wt_repo)
                    self._set_status(entry.id, entry.task_id, "failed", error="合并后仍有冲突标记残留（响亮错）")
                    return

            attempts = 0
            max_retries = cfg["max_ai_retries"]
            while True:
                err = None
                if validator is not None:
                    try:
                        with self._session_factory() as vs:



                            err = await asyncio.to_thread(validator, vs, wt_repo, task, proj)
                    except GateRework as rw:


                        merge_mod.abort_merge(wt_repo)
                        self._set_status(entry.id, entry.task_id, "reworked", error=str(rw)[:500])
                        self.bus.publish_task(entry.task_id, "log.appended", {
                            "level": "sched",
                            "message": f"门禁回灌开发循环：功能[{rw.feature_seq}]重开待修，任务回到开发阶段继续（{str(rw)[:200]}）",
                        })
                        if self._on_gate_rework is not None:
                            try:
                                self._on_gate_rework(entry.task_id)
                            except Exception:
                                pass
                        return
                if not err:
                    break
                merge_mod.abort_merge(wt_repo)
                attempts += 1
                with self._session_factory() as us:
                    q = us.get(m.MergeQueueEntry, entry.id)
                    q.attempts = attempts
                    us.add(q)
                    us.commit()
                if attempts > max_retries:
                    self._set_status(entry.id, entry.task_id, "failed", error=f"集成校验失败，AI 重试后仍败（门禁③）：{err}")
                    return



                conflicts = merge_mod.start_merge(wt_repo, t_branch, anchors=anchors)
                if conflicts:
                    if len(conflicts) > cfg["ai_conflict_max_files"]:
                        merge_mod.abort_merge(wt_repo)
                        self._set_status(entry.id, entry.task_id, "failed",
                                         error=f"重试路径冲突文件数 {len(conflicts)} 超上限（门禁②）：{conflicts[:5]}")
                        return
                    if resolver is not None:
                        ok = await asyncio.to_thread(resolver, wt_repo, conflicts, task, proj, spec, node_id)
                        if not ok:
                            merge_mod.abort_merge(wt_repo)
                            self._set_status(entry.id, entry.task_id, "failed",
                                             error="重试路径 AI 解冲突失败，停机人工")
                            return
                    if merge_mod.conflicts_unresolved(wt_repo, conflicts):
                        merge_mod.abort_merge(wt_repo)
                        self._set_status(entry.id, entry.task_id, "failed",
                                         error="重试路径仍有冲突标记残留（响亮错）")
                        return



            with self._session_factory() as cs:
                fresh = cs.get(m.Task, entry.task_id)
                if fresh is not None and fresh.status == m.TaskStatus.aborted:
                    merge_mod.abort_merge(wt_repo)
                    self._set_status(entry.id, entry.task_id, "aborted", error="合并提交前任务已被废弃，已停手")
                    return
                try:
                    committed = merge_mod.commit_resolved_merge(cs, wt_repo, fresh, conflicts)
                except merge_mod.TaskNotMergeable as e:
                    merge_mod.abort_merge(wt_repo)
                    self._set_status(entry.id, entry.task_id, "aborted", error=str(e))
                    return
            if not committed:
                self.bus.publish_task(
                    entry.task_id, "log.appended",
                    {"level": "sched", "message": "合并跳过：任务分支无内容差异（空合并守卫），不产出空提交"},
                )



            with self._session_factory() as vs2:
                t2 = vs2.get(m.Task, entry.task_id)
                if t2 is not None and t2.status == m.TaskStatus.aborted:
                    merge_mod.abort_merge(wt_repo)
                    self._set_status(entry.id, entry.task_id, "aborted", error="main 前移前任务已被废弃，已停手")
                    return
            merge_mod.advance_main(RepoHandle(repo_path), wt_repo)

            try:
                merged_sha = wt_repo.repo.git.rev_parse("HEAD").strip()
                with self._session_factory() as ms:
                    q2 = ms.get(m.MergeQueueEntry, entry.id)
                    q2.merged_sha = merged_sha
                    ms.add(q2)
                    ms.commit()
            except Exception:
                pass
            self._set_status(entry.id, entry.task_id, "merged")


            if self._on_merged is not None:
                try:
                    self._on_merged(entry.task_id)
                except Exception:
                    pass
        except GitError as e:





            if self._retry_engine_fault(entry, f"{e}"):
                return
            self._set_status(entry.id, entry.task_id, "failed", error=str(e))
        except Exception as e:
            import traceback

            tb = traceback.format_exc()



            if self._retry_engine_fault(entry, f"{e}"):
                return
            self._set_status(
                entry.id, entry.task_id, "failed",
                error=f"合并消费异常（引擎内部异常，非项目代码问题）: {e}\n{tb[-1500:]}",
            )
        finally:

            if wt_repo is not None:
                wt_repo.release()

    def _retry_engine_fault(self, entry, reason: str) -> bool:
        """引擎瞬时故障重排队（返回 True = 已重试，调用方勿再判死）。"""
        cfg = self._merge_cfg()
        max_engine = cfg.get("max_engine_retries", 2)
        with self._session_factory() as s:
            row = s.get(m.MergeQueueEntry, entry.id)
            if row is None:
                return False

            prior = 0
            if row.error and row.error.startswith("[engine-retry:"):
                try:
                    prior = int(row.error.split("]", 1)[0].split(":")[1])
                except Exception:
                    prior = 0
            if prior >= max_engine:
                return False
            row.status = "queued"
            row.error = f"[engine-retry:{prior + 1}] {reason[:1500]}"
            row.updated_at = datetime.now(timezone.utc).isoformat()
            s.add(row)
            s.commit()
        self.bus.publish_task(entry.task_id, "log.appended", {
            "level": "sched",
            "message": (
                f"合并遇引擎瞬时故障，第 {prior + 1}/{max_engine} 次自动重试"
                f"（非项目代码问题）：{reason[:200]}"
            ),
        })
        return True