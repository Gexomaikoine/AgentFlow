"""SOS 求助通道（自愈系统 P1）：熔断判定 + Lead 决策校验 + 配额闸。判定权全在代码。"""

from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path

from agentflow.storage import models as m
from sqlmodel import Session, select


TRIGGER_CB = ("CB-1", "CB-2", "CB-3", "CB-4")
TRIGGER_AGENT_ASK = "agent_ask"


DECISIONS = ("restrategy", "research", "split", "escalate")



_FREETEXT_LIMITS = {"new_hint": 500, "focus": 500, "question": 500}


def _sos_cfg() -> dict:
    """读 sos 配置段（读全局 ~/.agentflow/config.toml 与默认值合并）。"""
    try:
        from agentflow.config import Settings

        return Settings().data.get("sos", {})
    except Exception:
        return {}




def check_breaker(
    fault: str,
    fingerprints: list[str],
    has_fix_report: bool,
    worktree_diff_empty: bool,
    developer_report: str,
    retry_count: int,
    max_retries: int,
    budget_pressure: bool = False,
) -> str | None:
    """熔断判定（纯代码）。优先级 CB-4 > CB-1 > CB-3 > CB-2，返回触发标识或 None。"""

    if developer_report and worktree_diff_empty:
        return "CB-4"

    if has_fix_report and len(fingerprints) >= 2 and len(set(fingerprints[-2:])) == 1:
        return "CB-1"

    if len(fingerprints) >= 3:
        tail3 = fingerprints[-3:]
        if tail3[0] == tail3[2] and tail3[0] != tail3[1]:
            return "CB-3"
    if len(fingerprints) >= 4:
        tail4 = fingerprints[-4:]
        if tail4[0] == tail4[2] and tail4[1] == tail4[3] and tail4[0] != tail4[1]:
            return "CB-3"

    if fault in ("env", "semantic") and budget_pressure:
        return "CB-2"
    return None




def build_sos_packet(
    session: Session,
    task: m.Task,
    feature: m.Feature,
    trigger: str,
    fault: str,
    fingerprints: list[str],
    runs: list[m.VerifierRun],
    fix_report: str,
    retry_count: int,
    max_retries: int,
    sos_used: int,
    sos_quota: int,
) -> m.SosPacket:
    """代码组装 SOS 包并落库（不让 LLM 自由发挥，防幻觉）。"""
    symptom = {
        "fault": fault,
        "fingerprints_tail": fingerprints[-5:],
        "retry_count": retry_count,
        "max_retries": max_retries,
        "trigger_detail": trigger,
    }
    tried = []
    if fix_report:
        tried.append(f"fixer 上轮报告: {fix_report[:500]}")
    if fingerprints:
        tried.append(f"历轮失败指纹: {fingerprints[-8:]}")

    try:
        from agentflow.core import evolution as _evo

        run_fps = [r.fingerprint for r in runs if r.fingerprint]
        hist = _evo.match_history(session, int(task.project_id), run_fps)
        if hist:
            tried.append("历史同指纹证据（跨任务）:\n" + _evo.format_history_evidence(hist))
    except Exception:
        pass
    evidence = [
        {"cmd": r.cmd[:200], "exit_code": r.exit_code, "output": (r.output_uri or "")[:500]}
        for r in runs
        if r.exit_code != 0
    ][:2]
    budget_left = {
        "retries_left": max(0, max_retries - retry_count),
        "sos_used": sos_used,
        "sos_quota": sos_quota,
    }
    packet = m.SosPacket(
        task_id=task.id,
        feature_id=feature.id,
        trigger=trigger,
        symptom=json.dumps(symptom, ensure_ascii=False),
        tried=json.dumps(tried, ensure_ascii=False),
        evidence=json.dumps(evidence, ensure_ascii=False),
        budget_left=json.dumps(budget_left, ensure_ascii=False),
    )
    session.add(packet)
    session.commit()
    return packet




def sos_task_used(session: Session, task_id: int) -> int:
    """任务已用熔断决策次数（只计 CB 触发的包，agent_ask 不占配额）。"""
    return len(
        session.exec(
            select(m.SosPacket).where(
                m.SosPacket.task_id == task_id,
                m.SosPacket.trigger.in_(TRIGGER_CB),
            )
        ).all()
    )


def breaker_count(session: Session, feature_id: int) -> int:
    """同一 feature 已熔断次数（≥1 时再熔断直接 escalate，不再问 Lead）。"""
    return len(
        session.exec(
            select(m.SosPacket).where(
                m.SosPacket.feature_id == feature_id,
                m.SosPacket.trigger.in_(TRIGGER_CB),
            )
        ).all()
    )


def agent_ask_count(session: Session, feature_id: int) -> int:
    """agent 主动求助次数（每 feature 上限，超限工具直接拒绝）。"""
    return len(
        session.exec(
            select(m.SosPacket).where(
                m.SosPacket.feature_id == feature_id,
                m.SosPacket.trigger == TRIGGER_AGENT_ASK,
            )
        ).all()
    )


def decision_count(session: Session, feature_id: int, decision: str) -> int:
    """同一 feature 某分支已决策次数（restrategy/research 计数上限用）。"""
    return len(
        session.exec(
            select(m.SosPacket).where(
                m.SosPacket.feature_id == feature_id,
                m.SosPacket.decision == decision,
                m.SosPacket.decision_valid.is_(True),
            )
        ).all()
    )


def research_in_progress(session: Session, task_id: int) -> bool:
    """是否有进行中的 research 节点（防并发起两个 researcher）。"""
    node = session.exec(
        select(m.Node).where(
            m.Node.task_id == task_id,
            m.Node.kind == "research",
            m.Node.status == m.NodeStatus.running,
        )
    ).first()
    return node is not None




def _payload_hash(payload: dict) -> str:
    return hashlib.sha1(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def normalize_decision(decision: dict) -> list[str]:
    """把决策里的自由文本字段截断到契约上限，返回被截断字段说明（供响亮留痕）。"""
    notes: list[str] = []
    payload = decision.get("payload")
    if not isinstance(payload, dict):
        return notes
    for key, limit in _FREETEXT_LIMITS.items():
        v = payload.get(key)
        if isinstance(v, str) and len(v) > limit:
            payload[key] = v[:limit]
            notes.append(f"{key} {len(v)}→{limit} 字")
    return notes


def validate_decision(
    decision: dict,
    session: Session,
    task: m.Task,
    feature: m.Feature,
    repo_root: Path,
) -> tuple[bool, str]:
    """Lead 四选一决策的代码校验。返回 (ok, error)。"""
    if not isinstance(decision, dict):
        return False, "决策输出不是 JSON 对象"
    d = decision.get("decision")
    if d not in DECISIONS:
        return False, f"decision 非法（{d}），只允许 {'|'.join(DECISIONS)}"
    if not (decision.get("reason") or "").strip():
        return False, "reason 不能为空（供人类审查）"
    payload = decision.get("payload")
    if not isinstance(payload, dict):
        return False, "payload 必须是对象"


    ph = _payload_hash(payload)
    dup = session.exec(
        select(m.SosPacket).where(
            m.SosPacket.feature_id == feature.id,
            m.SosPacket.decision == d,
            m.SosPacket.decision_valid.is_(True),
        )
    ).all()
    for p in dup:
        try:
            if _payload_hash(json.loads(p.decision_payload or "{}")) == ph:
                return False, f"决策去重命中：该 feature 已执行过完全相同的 {d} 决策，禁止重复"
        except Exception:
            continue

    if d == "restrategy":
        hint = (payload.get("new_hint") or "").strip()
        if not hint:
            return False, "restrategy.new_hint 不能为空"
        if len(hint) > 500:
            return False, "restrategy.new_hint 超过 500 字"

        limit = _sos_cfg().get("restrategy_max", 2)
        if decision_count(session, feature.id, "restrategy") >= limit:
            return False, f"restrategy 已达上限 {limit} 次"
        for p in dup:
            try:
                hist = (json.loads(p.decision_payload or "{}").get("new_hint") or "")
            except Exception:
                hist = ""
            if hist and difflib.SequenceMatcher(None, hint, hist).ratio() > 0.8:
                return False, "new_hint 与历史 hint 相似度过高（>0.8），换汤不换药"
        return True, ""

    if d == "research":
        focus = (payload.get("focus") or "").strip()
        if not focus:
            return False, "research.focus 不能为空"
        limit = int(_sos_cfg().get("research_max", 2))
        task_research = len(
            session.exec(
                select(m.SosPacket).where(
                    m.SosPacket.task_id == task.id,
                    m.SosPacket.decision == "research",
                    m.SosPacket.decision_valid.is_(True),
                )
            ).all()
        )
        if task_research >= limit:
            return False, f"research 已达任务上限 {limit} 次"
        if research_in_progress(session, task.id):
            return False, "已有进行中的 research，禁止并发再起"
        return True, ""

    if d == "split":
        subs = payload.get("subtasks")
        if not isinstance(subs, list) or not (1 <= len(subs) <= 3):
            return False, "split.subtasks 必须是 1-3 条"
        from agentflow.core.partition import feature_write_set, expand_glob

        parent_set = feature_write_set(feature, repo_root)
        union: set[str] = set()
        for sub in subs:
            if not isinstance(sub, dict) or not (sub.get("title") or "").strip():
                return False, "split.subtasks[].title 不能为空"
            scope = sub.get("file_scope")
            if not isinstance(scope, list) or not scope:
                return False, "split.subtasks[].file_scope 不能为空"
            for pat in scope:
                if not isinstance(pat, str) or not pat.strip():
                    return False, "split.subtasks[].file_scope 含空 glob"

                expanded = set(expand_glob(repo_root, pat))
                if expanded:
                    leaked = expanded - parent_set
                    if leaked:
                        return False, f"file_scope「{pat}」越出父写集: {sorted(leaked)[:3]}"
                    union |= expanded
                else:

                    import fnmatch

                    if not any(fnmatch.fnmatch(f, pat.replace("\\", "/")) for f in parent_set):
                        return False, f"file_scope「{pat}」未命中父写集任何文件（新建文件也不在父范围内）"
                    union.add(pat)
        if not (payload.get("deferred_scope") or "").strip() and union < parent_set:
            missing = sorted(parent_set - union)[:5]
            return False, f"子任务并集未覆盖父写集（缺 {missing}），需补 deferred_scope 说明剩余归属"
        return True, ""


    question = (payload.get("question") or "").strip()
    if len(question) < 20:
        return False, "escalate.question 至少 20 字（须说明卡在哪/需要人定什么）"
    return True, ""




def create_split_subtask(
    session: Session,
    parent_task: m.Task,
    parent_feature: m.Feature,
    sub: dict,
) -> m.Task:
    """代码组装 SOS 拆分子任务（不走 LLM）："""
    title = (sub.get("title") or "").strip()
    scope = sub.get("file_scope") or []
    desc = sub.get("description") or ""
    task = m.Task(
        project_id=parent_task.project_id,
        title=title,
        raw_request=desc or f"（SOS 拆分自任务 #{parent_task.id} 功能「{parent_feature.title}」）{title}",
        parent_task_id=parent_task.id,
        origin="sos_split",
        status=m.TaskStatus.spec_pending,
        branch=f"task/sos-{parent_task.id}",
    )
    session.add(task)
    session.flush()

    import yaml

    yaml_raw = yaml.safe_dump(
        {
            "title": title,
            "complexity": "simple",
            "features": [
                {
                    "seq": 1,
                    "title": title,
                    "file_scope": scope,
                    "verify_commands": json.loads(parent_feature.verify_commands or "[]"),
                    "depends_on": [],
                    "related_files": json.loads(parent_feature.related_files or "[]"),
                }
            ],
            "invariants": [],
            "budget": {},
        },
        allow_unicode=True,
    )
    spec = m.Spec(task_id=task.id, version=1, yaml_raw=yaml_raw, confirmed_at=parent_task.created_at, complexity="simple")
    session.add(spec)
    session.flush()
    feat = m.Feature(
        task_id=task.id,
        spec_id=spec.id,
        seq=1,
        title=title,
        file_scope=json.dumps(scope, ensure_ascii=False),
        verify_commands=parent_feature.verify_commands,
        depends_on="[]",
        related_files=parent_feature.related_files,
        status=m.FeatureStatus.pending,
    )
    session.add(feat)
    session.commit()
    return task
