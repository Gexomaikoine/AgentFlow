"""修复队列（FR5）：FIFO + K 上限。"""

from __future__ import annotations

from agentflow.storage import models as m
from sqlmodel import Session


def push(session: Session, entry: m.FailureQueueEntry) -> None:
    session.add(entry)
    session.commit()


def pop_oldest_open(session: Session, task_id: int) -> m.FailureQueueEntry | None:
    row = (
        session.query(m.FailureQueueEntry)
        .filter(m.FailureQueueEntry.task_id == task_id, m.FailureQueueEntry.status == "open")
        .order_by(m.FailureQueueEntry.id.asc())
        .first()
    )
    if row:
        row.status = "fixing"
        session.add(row)
        session.commit()
    return row


def resolve(session: Session, entry: m.FailureQueueEntry) -> None:
    entry.status = "resolved"
    session.add(entry)
    session.commit()
