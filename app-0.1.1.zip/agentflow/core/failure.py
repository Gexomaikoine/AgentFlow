"""失败分类器（FR5）：阻断/隔离 + 债务上限 + stale 重验 + 故障类型识别（B-1）。"""

from __future__ import annotations

import json

from agentflow.storage import models as m
from agentflow.verifiers.probe import SPEC_DEFECT_MARK
from sqlmodel import Session






_COMMAND_ERR = (
    SPEC_DEFECT_MARK.lower(),
    "commandnotfoundexception",
    "is not recognized",
    "was unexpected at this time",
    "not recognized as an internal or external command",
    "not recognized as the name of a cmdlet",
    "command not found",
    "项识别为 cmdlet",
    "不是内部或外部命令",
    "未找到命令",
)
_TRANSIENT = (
    "[timeout after", "[run error]",
    "connection error", "connection reset", "connection refused",
    "timed out", "read timed out",
    "连接被拒绝", "连接被重置", "连接超时", "操作超时", "请求已中止",
)
_ENV_ERR = (
    "cannot find the path specified",
    "no such file or directory",
    "module not found",
    "cannot find module",
    "are you sure the module name is correct",
    "找不到指定的路径", "系统找不到指定的文件", "没有那个文件或目录",
    "找不到模块", "没有名为", "模块导入失败",
)




_HARNESS_ERR = (
    "[机审环境]",
    "ui 机审依赖未安装",
    "无法起机审服务",
    "机审服务启动即退出",
    "机审服务",
)


def classify_failure(feature: m.Feature, runs: list[m.VerifierRun]) -> str:
    """判定失败类型。blocking 当且仅当："""
    verify_cmds = json.loads(feature.verify_commands) if feature.verify_commands else []
    hint_by_cmd = {v.get("cmd"): v.get("classification_hint", "blocking") for v in verify_cmds}
    depends = json.loads(feature.depends_on) if feature.depends_on else []

    for r in runs:
        if r.exit_code != 0:
            hint = hint_by_cmd.get(r.cmd, "blocking")
            if hint == "blocking":
                return "blocking"
    if depends:
        return "blocking"
    return "isolated"


def classify_fault(runs: list[m.VerifierRun]) -> str:
    """故障类型识别（B-1）：harness | transient | command | env | semantic。"""
    for r in runs:
        if r.exit_code == 0:
            continue
        out = (r.output_uri or "").lower()
        if any(p in out for p in _HARNESS_ERR):
            return "harness"
        if r.exit_code == 124 or any(p in out for p in _TRANSIENT):
            return "transient"
        if any(p in out for p in _COMMAND_ERR):
            return "command"
        if any(p in out for p in _ENV_ERR):
            return "env"
    return "semantic"


def debt_count(session: Session, task_id: int) -> int:
    """当前失败队列债务（未 resolved 的 open/fixing 条目）。"""
    q = (
        session.query(m.FailureQueueEntry)
        .filter(
            m.FailureQueueEntry.task_id == task_id,
            m.FailureQueueEntry.status.in_(["open", "fixing"]),
        )
        .count()
    )
    return q


def mark_stale_if_overlap(session: Session, task_id: int, new_feature_id: int, repo_root) -> list:
    """已绿功能写集与新绿点写集相交 → 标 stale（FR4 重验）。"""
    from agentflow.core.partition import feature_write_set

    new_feat = session.get(m.Feature, new_feature_id)
    if new_feat is None:
        return []
    new_set = feature_write_set(new_feat, repo_root)
    passed = (
        session.query(m.Feature)
        .filter(
            m.Feature.task_id == task_id,
            m.Feature.id != new_feature_id,
            m.Feature.status.in_([m.FeatureStatus.passed]),
        )
        .all()
    )
    staled = []
    for f in passed:
        if feature_write_set(f, repo_root) & new_set:
            f.status = m.FeatureStatus.stale
            session.add(f)
            staled.append(f)
    if staled:
        session.commit()
    return staled
