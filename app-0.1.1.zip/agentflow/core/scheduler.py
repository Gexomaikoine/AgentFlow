"""调度器。"""

from __future__ import annotations

import asyncio
import json
import re
import threading
from datetime import datetime, timezone
from pathlib import Path

from agentflow.agents import context as _ctx
from agentflow.agents import developer as dev, fixer as fx, lead, qa as qa, verifier_agent as va
from agentflow.agents.base import AgentRuntime, Dispatch
from agentflow.core import budget as budget_mod, failure as failure_mod, leases, queue as queue_mod, sos as sos_mod
from agentflow.core.events_bus import EventBus
from agentflow.core.partition import ParallelGroup, cluster_features
from agentflow.git_runtime import anchors, branch, merge as merge_mod
from agentflow.git_runtime.repo import GitError, RepoHandle
from agentflow.llm.gateway import LLMGateway
from agentflow.safety.command import Safety
from agentflow.storage import models as m, trace as tr
from sqlalchemy import func
from sqlmodel import Session, select


class TaskRunner:
    def __init__(self, engine, gateway: LLMGateway, bus: EventBus, settings, task_id: int,
                 project_lock: threading.Lock | None = None, spawn_runner=None):
        self.engine = engine
        self.gateway = gateway
        self.bus = bus
        self.settings = settings
        self.task_id = task_id
        self._lock = project_lock or threading.Lock()
        self._db_lock = threading.Lock()
        self._dev_root: Path | None = None
        self._research_report: str | None = None
        self._fast_path: bool = False
        self._fix_reports: dict[int, str] = {}
        self._fault_fingerprints: dict[int, list[str]] = {}
        self._dev_reports: dict[int, str] = {}
        self._sos_hints: dict[int, str] = {}
        self._sos_research_reports: dict[int, str] = {}
        self._harness_retries: dict[int, int] = {}
        self._env_drift_notes: dict[int, list[str]] = {}
        self._spawn_runner = spawn_runner
        self._seq = 0

        from agentflow.llm import gateway as _gw

        self._adversarial_roles = _gw.apply_adversarial_review(settings)
        if self._adversarial_roles:
            detail = "，".join(f"{role}→档案「{name}」" for role, name in self._adversarial_roles.items())
            try:
                self.bus.publish_task(self.task_id, "log.appended", {
                    "level": "sched",
                    "message": f"跨模型对抗评审已生效（写者≠评审者）：{detail}",
                })
            except Exception:
                pass
        elif self.settings.data["llm"].get("cross_review") is not False:
            try:
                rv_fam = _gw.model_family(_gw.profile_for(settings, "reviewer"))
                dev_fam = _gw.model_family(_gw.profile_for(settings, "developer"))
                if rv_fam == dev_fam and self.settings.data["llm"].get("provider") != "mock":
                    self.bus.publish_task(self.task_id, "log.appended", {
                        "level": "sched",
                        "message": (
                            f"跨模型对抗评审未生效：reviewer 与 developer 同为 {dev_fam} 家族且无第二家族档案可换。"
                            "建议在 设置→模型 添加一个不同家族的模型档案（如 deepseek/gpt/claude），否则互审会漏掉同家族模型的共性盲区。"
                        ),
                    })
            except Exception:
                pass


    def _ev(self, task_id: int, event: str, payload: dict):
        self.bus.publish_task(task_id, event, payload)

    def _next_seq(self) -> int:
        self._seq += 1
        return self._seq


    def _new_node(
        self, session: Session, task: m.Task, feature: m.Feature | None, agent_id: int | None,
        kind: str, summary: str = "", role: str = "",
    ) -> m.Node:
        trace_dir = tr.trace_dir_for(self.settings, _project_name(session, task.project_id), task.id)

        if not role and agent_id:
            ai = session.get(m.AgentInstance, agent_id)
            role = ai.role if ai else ""
        with self._db_lock:

            if self._seq == 0:
                row = session.exec(select(func.max(m.Node.seq)).where(m.Node.task_id == task.id)).one()
                self._seq = int(row or 0)
            seq = self._next_seq()
            node = m.Node(
                task_id=task.id,
                agent_id=agent_id,
                feature_id=feature.id if feature else None,
                seq=seq,
                kind=kind,
                role=role,
                status=m.NodeStatus.running,
                started_at=datetime.now(timezone.utc).isoformat(),
                summary=summary,
                trace_uri=tr.new_trace_file(trace_dir, 0),
            )
            session.add(node)
            session.flush()
            node.trace_uri = tr.new_trace_file(trace_dir, node.id)
            session.add(node)
            session.commit()
        self._ev(task.id, "node.updated", _node_payload(node))
        return node

    def _finish_node(self, session: Session, node: m.Node, status: m.NodeStatus, summary: str = ""):
        node.status = status
        node.ended_at = datetime.now(timezone.utc).isoformat()

        if node.started_at:
            try:
                start = datetime.fromisoformat(node.started_at)
                end = datetime.fromisoformat(node.ended_at)
                node.duration_ms = max(0, int((end - start).total_seconds() * 1000))
            except Exception:
                pass
        node.summary = summary[:400] or node.summary
        with self._db_lock:
            session.add(node)
            session.commit()
        self._ev(node.task_id, "node.updated", _node_payload(node))

        _persist_explore_footprint(session, node)


    async def run(self) -> None:
        session = Session(self.engine)
        task = session.get(m.Task, self.task_id)
        if task is None:
            return
        try:
            await self._run_inner(session, task)
        except Exception as e:
            task.status = m.TaskStatus.paused_human
            session.add(task)
            session.commit()
            self._ev(task.id, "human.required", {"reason": f"调度异常: {e}", "options": ["重试", "回滚"]})
        finally:
            session.close()

    async def _run_inner(self, session: Session, task: m.Task) -> None:
        if task.status != m.TaskStatus.running:
            return
        project = session.get(m.Project, task.project_id)
        main_repo_root = Path(project.repo_path)
        main_repo = RepoHandle(main_repo_root)



        use_wt = bool(self.settings.data["scheduler"].get("per_task_worktree", False))
        if use_wt:
            from agentflow.git_runtime import worktree as wt_mod


            with self._lock:
                if not main_repo.is_clean():
                    raise RuntimeError("主 checkout 有未提交改动，拒绝启动（FR6）")
            wt_path = wt_mod.ensure_dev_worktree(self.settings, main_repo_root, task.id)
            repo_root = wt_path
            repo = RepoHandle(wt_path)




            from agentflow.projects.registry import project_dep_strategy

            if project_dep_strategy(session, project.id) == "junction_node_modules":
                linked = wt_mod.link_node_deps(main_repo_root, wt_path)
                if linked:
                    self._ev(
                        task.id,
                        "log.appended",
                        {
                            "role": "system",
                            "kind": "exec",
                            "content": f"依赖策略 junction_node_modules：已复用主 checkout 的 node_modules，"
                            f"免重装（链接 {len(linked)} 处）。",
                        },
                    )






            try:
                from agentflow.projects.registry import project_runtime_data_dirs

                data_dirs = project_runtime_data_dirs(session, project.id)
                if data_dirs:
                    linked_data, failed_data = wt_mod.link_runtime_data(main_repo_root, wt_path, data_dirs)
                    if linked_data:
                        self._ev(task.id, "log.appended", {
                            "level": "sched",
                            "message": (
                                f"已链接主 checkout 运行时数据目录 {len(linked_data)} 处"
                                f"（{', '.join(str(p.relative_to(wt_path)).replace(chr(92), '/') for p, _ in linked_data)}），"
                                "开发期即可读到数据"
                            ),
                        })
                    if failed_data:
                        self._ev(task.id, "log.appended", {
                            "level": "sched",
                            "message": (
                                f"运行时数据链接失败 {len(failed_data)} 处: "
                                + "；".join(f"{d}（{why}）" for d, why in failed_data[:3])
                                + "。前端类任务的 UI 自测可能因缺数据而假失败，请人工检查。"
                            ),
                        })
            except Exception as e:
                self._ev(task.id, "log.appended", {
                    "level": "sched",
                    "message": f"运行时数据链接异常: {type(e).__name__}: {e}（不阻塞主链路，但 UI 自测可能缺数据）",
                })
        else:
            repo_root = main_repo_root
            repo = main_repo
        self._dev_root = repo_root


        try:
            from agentflow.core import env_fingerprint as _envfp

            _envfp.save_baseline(self.settings, project.name, task.id, main_repo_root)
            self._project_name = project.name
        except Exception:
            self._project_name = project.name


        with self._lock:
            task.branch = branch.create_task_branch(repo, task.id)
        session.add(task)
        session.commit()



        self._ev(task.id, "task.updated", {"task_id": task.id, "status": task.status.value, "branch": task.branch})

        spec = session.query(m.Spec).filter(m.Spec.task_id == task.id).order_by(m.Spec.id.desc()).first()
        features = (
            session.query(m.Feature)
            .filter(m.Feature.spec_id == spec.id)
            .order_by(m.Feature.seq.asc())
            .all()
        )
        if not features:
            raise RuntimeError("Spec 无功能，拒绝启动")


        safety = Safety(self.settings)
        agent_instance = m.AgentInstance(task_id=task.id, role="developer", model=_record_model(self.gateway, "developer"))
        session.add(agent_instance)
        session.flush()
        agent_id = agent_instance.id
        session.commit()
        runtime = AgentRuntime(
            self.engine, self.gateway, self.bus, self.settings, repo_root,
            project_invariants=_project_invariants(session, project.id),
        )


        group_size = int(self.settings.data["scheduler"]["group_size"])
        groups = self._resolve_groups(spec, features, repo_root, group_size)



        _lead_cfg = self.settings.data.get("lead", {}) or {}
        fast_path = bool(_lead_cfg.get("force_direct", False)) or (
            (getattr(spec, "complexity", "standard") or "standard") == "simple"
            and len(features) == 1
        )
        if fast_path:
            self._fast_path = True
            self._ev(task.id, "log.appended", {
                "level": "sched",
                "message": ("快手模式（force_direct 强制）：跳过 researcher 调研" if _lead_cfg.get("force_direct")
                            else "快路径：简单任务，跳过 researcher 调研"),
            })
        else:

            self._research_report = await self._lead_maybe_research(session, task, project, spec, features, repo_root)
            _persist_research_report(self.engine, task.id, None, self._research_report, sos=False)

        for g in groups:
            stop = await self._run_group(session, task, project, repo, runtime, spec, g, agent_id, safety)
            if stop:
                return


        task.status = m.TaskStatus.done
        if not task.completed_at:
            task.completed_at = datetime.now(timezone.utc).isoformat()
        session.add(task)
        session.commit()
        self._ev(task.id, "task.updated", {"task_id": task.id, "status": task.status.value})

        self._evolve_async(task.id)




        await self._enqueue_merge(session, task, project, repo, spec)



        try:
            swept = sweep_agent_temp_files(repo, main_repo_root)
            if swept:
                self._ev(task.id, "log.appended", {"level": "sched", "message": f"已清扫 agent 临时文件（主仓）: {', '.join(swept[:5])}"})
        except Exception:
            pass

        self._cleanup_dev_worktree_best_effort(repo_root, task.id, repo=repo)


    def _evolve(self, task_id: int) -> None:
        """入账评分 + 首次失败痕迹触发反思提案流（全自动，不问人）。best-effort。"""
        from agentflow.core import evolution

        evolution.maybe_evolve(self.engine, self.gateway, self.bus, self.settings, task_id)

    def _evolve_async(self, task_id: int) -> None:
        """后台线程触发（不阻塞调度循环/终态返回）。"""
        import threading

        threading.Thread(target=self._evolve, args=(task_id,), daemon=True, name=f"evolve-{task_id}").start()

    def _cleanup_dev_worktree_best_effort(self, repo_root: Path, task_id: int, repo=None) -> None:
        """任务终态释放 dev worktree。"""
        if repo is not None:
            try:
                repo.release()
            except Exception:
                pass


        try:
            from agentflow.core.services import release_services

            dev_root = getattr(self, "_dev_root", None)
            n = release_services(dev_root) if dev_root else 0
            if n:
                self._ev(task_id, "log.appended", {
                    "level": "sched", "message": f"已收口开发期暖服务 {n} 个（{dev_root}）",
                })
        except Exception:
            pass
        try:
            from agentflow.git_runtime import worktree as wt_mod

            if wt_mod.remove_dev_worktree(self.settings, repo_root, task_id):
                self._ev(task_id, "log.appended", {"level": "sched", "message": f"已清理任务 worktree: dev-{task_id}"})
        except Exception:
            pass

    def _noop_mode(self) -> str:
        """no-op 0 diff 裁决档：0 diff 不再想当然。"""
        v = str(self.settings.data.get("scheduler", {}).get("noop_short_circuit", "confirm")).strip().lower()
        return v if v in ("confirm", "trust", "off") else "confirm"


    async def _lead_maybe_research(
        self, session: Session, task: m.Task, project: m.Project, spec: m.Spec,
        features: list[m.Feature], repo_root: Path,
    ) -> str | None:
        """P4 Lead：判定任务体量，体大（feature 数 ≥ 阈值）并行调度 researcher，产物返回给 developer。"""
        threshold = int(self.settings.data.get("lead", {}).get("researcher_min_features", 3))
        if len(features) < threshold:
            return None


        if (getattr(spec, "complexity", "standard") or "standard") == "simple":
            self._ev(task.id, "log.appended", {"level": "sched", "message": "Lead: 简单任务（complexity=simple）跳过 researcher 调研"})
            return None



        prev, prev_ts = _latest_task_research(session, task.id)
        spec_ts = (spec.confirmed_at or "") if spec is not None else ""
        if prev and len(prev.strip()) >= 50 and (not spec_ts or prev_ts >= spec_ts):
            self._ev(task.id, "log.appended", {
                "level": "lead", "message": "Lead: 复用本轮已落库的调研报告（重启续跑不重复调研）",
            })
            return prev
        from agentflow.agents.base import Dispatch
        from agentflow.agents import researcher as rs

        feats_summary = "\n".join(
            f"- F{f.seq} {f.title}（写集: {f.file_scope}）" for f in features
        )


        _diag_for_research = _latest_lead_diagnosis(session, task.id) or ""

        def _worker() -> str:
            ws = Session(self.engine)
            node = None
            try:
                instance = m.AgentInstance(task_id=task.id, role="researcher", model=_record_model(self.gateway, "researcher"))
                ws.add(instance)
                ws.commit()
                t = ws.get(m.Task, task.id)


                node = self._new_node(ws, t, None, instance.id, "research", summary=f"调研: {t.title}")
                dispatch = Dispatch(
                    task=t, role="researcher", feature=None,
                    system=rs.build_researcher_system(),
                    prompt=rs.build_researcher_prompt(t, project, feats_summary, _diag_for_research),
                    node_kind="research",
                    node_id=node.id,
                )
                rt = AgentRuntime(self.engine, self.gateway, self.bus, self.settings, repo_root,
                                  _project_invariants(ws, project.id), intervention_fetch=self._pending_interventions,
                                  project_root=Path(project.repo_path))
                result = rt.run(dispatch, ws, Safety(self.settings))


                if len((result or "").strip()) < 50:
                    self._finish_node(ws, node, m.NodeStatus.failed, summary="调研产物为空/过短，响亮失败（防 token 白烧）")
                    return ""
                self._finish_node(ws, node, m.NodeStatus.succeeded, summary=f"调研完成: {(result or '').strip()[:300]}")
                return result
            except Exception:
                if node is not None:
                    self._finish_node(ws, node, m.NodeStatus.failed, summary=f"调研异常: {task.title}")
                raise
            finally:
                ws.close()

        report = await asyncio.to_thread(_worker)
        if not report or len(report.strip()) < 50:
            self._ev(task.id, "log.appended", {
                "level": "lead",
                "message": "Lead: researcher 产物为空/过短，不计入 developer 上下文（响亮留痕，防 token 白烧）",
            })
            return None
        self._ev(task.id, "log.appended", {"level": "lead", "message": f"Lead: 任务体量大，已启用 researcher 调研"})
        return report or None

    async def _enqueue_merge(
        self, session: Session, task: m.Task, project: m.Project, repo: RepoHandle, spec: m.Spec
    ) -> None:
        """任务 done 后入合并队列（每项目串行）。合并前先经独立 reviewer 审查（P4）。"""


        mode = self._noop_mode()
        if mode != "off" and _has_no_content_diff(repo, task):
            if mode == "trust":
                self._ev(task.id, "log.appended", {
                    "level": "sched",
                    "message": "no-op 短路（trust）：任务分支无代码改动（git diff 为空），跳过合并前审查与合并队列，直接完成",
                })
                return

            task.status = m.TaskStatus.paused_human
            session.add(task)
            session.commit()
            self._ev(task.id, "log.appended", {
                "level": "sched",
                "message": "no-op 裁决：任务分支无代码改动（git diff 为空），停机等待人工确认（可能验证空转或 agent 未产出）",
            })
            self._ev(task.id, "human.required", {
                "reason": "任务分支相对 main 无任何代码改动（0 diff）。若验证命令未实际执行或 agent 未产出实现，建议退回修复；确认确实无事可做才直接完成。",
                "options": ["确认无产出，直接完成", "退回修复"],
            })
            return





        stale_feats = (
            session.query(m.Feature)
            .filter(m.Feature.task_id == task.id, m.Feature.status == m.FeatureStatus.stale)
            .order_by(m.Feature.seq.asc())
            .all()
        )
        if stale_feats:
            seqs = ", ".join(f"F{f.seq}" for f in stale_feats)
            self._ev(task.id, "log.appended", {
                "level": "sched",
                "message": f"门禁④：检测到待重验功能 {seqs}（改动波及已绿功能），合并前现场重验",
            })
            repo_root = Path(repo.repo_path)
            for f in stale_feats:
                passed, runs, blocking = await asyncio.to_thread(self._verify_feature, session, task, f, repo_root)
                if passed:
                    await asyncio.to_thread(self._green, session, task, f, repo, repo_root)
                    continue
                task.status = m.TaskStatus.paused_human
                session.add(task)
                session.commit()
                self._ev(task.id, "human.required", {
                    "reason": f"功能[{f.seq}]「{f.title}」合并前重验失败（{blocking}），已停机不入队",
                    "options": ["人工修复后恢复", "回滚", "放弃该功能"],
                })
                return

        if self._fast_path:
            self._ev(task.id, "log.appended", {"level": "sched", "message": "快路径：简单任务，跳过合并前 reviewer 审查"})
        else:
            stop = await self._review_before_merge_guarded(session, task, project, repo)
            if stop:
                return
        prev = session.exec(
            select(m.MergeQueueEntry)
            .where(m.MergeQueueEntry.task_id == task.id)
            .order_by(m.MergeQueueEntry.id.desc())
        ).first()
        q = m.MergeQueueEntry(
            project_id=project.id,
            task_id=task.id,
            status="queued",


            round_no=(prev.round_no + 1) if prev is not None else 1,
            redo_of=(prev.id if prev is not None else None),
        )

        if prev is not None and prev.hold:
            prev.hold = False
            session.add(prev)
        session.add(q)
        session.commit()
        self._ev(task.id, "merge.updated", {"status": "queued", "round_no": q.round_no})
        self._ev(task.id, "log.appended", {"level": "pm", "message": f"已入合并队列: {task.branch}"})

    async def _review_before_merge_guarded(self, session: Session, task: m.Task, project: m.Project, repo: RepoHandle) -> bool:
        """reviewer 合并前审查（原逻辑，异常不阻塞合入）。审查不通过 → 停机人工，返回 True（停止入队）。"""

        if self.settings.data.get("lead", {}).get("review_before_merge", True):
            try:
                ok, report = await self._review_before_merge(session, task, project, repo)
                self._ev(task.id, "log.appended", {"level": "lead", "message": f"Lead 审查{'通过' if ok else '未通过'}：{(report or '')[:200]}"})
            except Exception as _e:

                self._ev(task.id, "log.appended", {"level": "lead", "message": f"Lead 审查跳过（异常）: {_e}"})
                ok, report = True, ""
            if not ok:
                task.status = m.TaskStatus.paused_human
                session.add(task)
                session.commit()
                self._ev(task.id, "human.required", {
                    "reason": f"合并前审查发现阻塞风险（占位残留/空实现）: {report}",
                    "options": ["修复后重新合并", "强制合并"],
                })
                return True
        return False

    async def _review_before_merge(
        self, session: Session, task: m.Task, project: m.Project, repo: RepoHandle,
    ) -> tuple[bool, str]:
        """P4 reviewer：合并前独立只读审查。返回 (是否通过, 报告)。"""
        from agentflow.agents.base import Dispatch
        from agentflow.agents import reviewer as rv

        def _check_blockers(repo: RepoHandle, branch: str) -> str:
            """代码判定：分支相对 main 新增的改动里有无明确的未完成占位（忽略被删的行）。"""
            try:
                diff = repo.repo.git.diff("main", branch, with_exceptions=False)
            except Exception:
                return ""
            hits = []
            for line in (diff or "").splitlines():
                if not line.startswith("+") or line.startswith("+++"):
                    continue
                for marker in ("NotImplementedError", "TODO: unimplemented", "todo pass"):
                    if marker in line:
                        hits.append(marker)
                        break
            return "；".join(hits)

        def _worker() -> str:
            ws = Session(self.engine)
            node = None
            try:
                t = ws.get(m.Task, task.id)
                try:
                    stat = repo.repo.git.diff("--stat", f"main...{task.branch}")
                except Exception:
                    stat = ""

                try:
                    diff_hunks = repo.repo.git.diff("-U0", f"main...{task.branch}")[:4000]
                except Exception:
                    diff_hunks = ""
                handoff_ctx = _ctx.build_handoff_block(ws, task.id, kinds=("note", "report", "attribution"))
                instance = m.AgentInstance(task_id=task.id, role="reviewer", model=_record_model(self.gateway, "reviewer"))
                ws.add(instance)
                ws.commit()

                node = self._new_node(ws, t, None, instance.id, "review", summary=f"合并前审查: {t.title}")
                dispatch = Dispatch(
                    task=t, role="reviewer", feature=None, system=rv.build_reviewer_system(),
                    prompt=rv.build_reviewer_prompt(t, project, task.branch, stat or "", diff_hunks=diff_hunks, handoff_ctx=handoff_ctx),
                    node_kind="review",
                    node_id=node.id,
                )
                rt = AgentRuntime(self.engine, self.gateway, self.bus, self.settings, self._dev_root or Path(project.repo_path),
                                  _project_invariants(ws, project.id), intervention_fetch=self._pending_interventions,
                                  drop_tools={"ask_lead"})
                result = rt.run(dispatch, ws, Safety(self.settings))
                self._finish_node(ws, node, m.NodeStatus.succeeded, summary=f"审查完成: {(result or '').strip()[:300]}")
                return result
            except Exception:
                if node is not None:
                    self._finish_node(ws, node, m.NodeStatus.failed, summary=f"审查异常: {task.title}")
                raise
            finally:
                ws.close()


        blockers = await asyncio.to_thread(_check_blockers, repo, task.branch)
        report = await asyncio.to_thread(_worker)
        return (not blockers), (blockers or report or "")[:1500]

    def _resolve_groups(self, spec: m.Spec, features: list[m.Feature], repo_root: Path, group_size: int) -> list[ParallelGroup]:
        """分组裁决（Planner 不再产出 grouping 建议 → 纯代码确定性聚类）。"""
        return cluster_features(features, repo_root, group_size)

    async def _run_group(
        self, session: Session, task: m.Task, project: m.Project, repo: RepoHandle,
        runtime: AgentRuntime, spec: m.Spec, group: ParallelGroup, agent_id: int, safety: Safety,
    ) -> bool:
        """运行一个并行组。返回 True 表示任务应停止（停机）。"""
        if self._stopped(task):
            return True
        feats = [session.get(m.Feature, fid) for fid in group.feature_ids]
        self._ev(task.id, "group.updated", {"group_id": f"g{feats[0].seq}", "member_feature_ids": group.feature_ids, "phase": "writing"})


        dev_root = self._dev_root or Path(project.repo_path)
        for f in feats:
            if f.status == m.FeatureStatus.pending:
                leases.grant_feature_leases(session, f, dev_root)



        todo = [f for f in feats if f.status == m.FeatureStatus.pending]
        await self._dispatch_group_developers(task, project.id, spec.id, todo, agent_id)


        self._ev(task.id, "group.updated", {"group_id": f"g{feats[0].seq}", "member_feature_ids": group.feature_ids, "phase": "verifying"})


        repo_root = self._dev_root or Path(project.repo_path)
        for f in sorted(feats, key=lambda x: x.seq):
            while True:
                if self._stopped(task):
                    return True
                if f.status in (m.FeatureStatus.passed, m.FeatureStatus.skipped):
                    break

                passed, runs, blocking = await asyncio.to_thread(self._verify_feature, session, task, f, repo_root)
                if passed:
                    await asyncio.to_thread(self._green, session, task, f, repo, repo_root)
                    break

                fault = failure_mod.classify_fault(runs)

                env_drift = self._env_drift(repo_root)
                if env_drift:
                    self._env_drift_notes[f.id] = env_drift
                    self._ev(task.id, "log.appended", {
                        "level": "sched",
                        "message": f"功能[{f.seq}]环境漂移告警（任务启动后环境变化，失败疑似非纯代码原因）: {'；'.join(env_drift)}",
                    })
                self._ev(task.id, "log.appended", {"level": "sched", "message": f"功能[{f.seq}]校验失败，故障类型: {fault}"})








                if fault in ("env", "semantic", "transient"):
                    fp_early = _failure_fingerprint(runs)
                    hist = self._fault_fingerprints.get(f.id, [])
                    if fp_early and fp_early in hist:
                        zero_diff = self._feature_diff_empty(repo_root, f)
                        repeats = hist.count(fp_early)
                        if zero_diff or repeats >= 2:
                            why = "写集零改动" if zero_diff else f"有改动但同指纹已出现 {repeats} 次"
                            self._ev(task.id, "log.appended", {
                                "level": "sched",
                                "message": (
                                    f"功能[{f.seq}]同指纹重复失败（{why}）："
                                    "判定为 Spec/验收命令缺陷，转 Lead 重规划（不派 fixer 空转）"
                                ),
                            })
                            fault = "command"


                            self._fault_fingerprints[f.id] = [fp_early]



                if fault == "harness":
                    evidence = ""
                    for r in runs:
                        if r.exit_code != 0 and (r.output_uri or "").strip():
                            evidence = (r.output_uri or "").strip().splitlines()[0][:200]
                            break
                    if self._harness_retries.get(f.id, 0) < 1:
                        self._harness_retries[f.id] = self._harness_retries.get(f.id, 0) + 1
                        self._ev(task.id, "log.appended", {
                            "level": "sched",
                            "message": f"功能[{f.seq}]机审环境问题（可自愈）：AgentFlow 换空闲端口自动重试 1 次… 证据: {evidence}",
                        })
                        continue
                    task.status = m.TaskStatus.paused_human
                    session.add(task)
                    session.commit()
                    self._ev(task.id, "task.updated", {"task_id": task.id, "status": "paused_human"})
                    self._ev(task.id, "human.required", {
                        "reason": (
                            f"功能[{f.seq}]机审环境问题（非代码问题）：{evidence}。"
                            "已自动换端口重试 1 次仍未通过，请人工处理（释放端口/安装依赖/确认本机浏览器）后恢复。"
                        ),
                        "options": ["人工处理后恢复", "回滚", "放弃该功能"],
                    })
                    self._evolve_async(task.id)
                    return True
                f.retry_count += 1
                session.add(f)
                session.commit()
                max_retries = int(json.loads(spec.parsed).get("budget", {}).get("max_retries", self.settings.data["budget"]["max_retries"]))


                from agentflow.core import evolution as _evo

                for _r in runs:
                    if _r.exit_code != 0 and not _r.fingerprint:
                        _r.fingerprint = _evo.run_fingerprint(_r.cmd, _r.exit_code, _r.output_uri)
                        session.add(_r)
                session.commit()
                fp = _failure_fingerprint(runs)
                _fps = self._fault_fingerprints.setdefault(f.id, [])
                repeat_fp = fp in _fps
                _fps.append(fp)

                hard_hit, hard_reason = budget_mod.budget_exceeded(session, task, self.settings)
                if hard_hit:
                    task.status = m.TaskStatus.paused_human
                    session.add(task)
                    session.commit()
                    self._ev(task.id, "task.updated", {"task_id": task.id, "status": "paused_human"})
                    self._ev(task.id, "human.required", {
                        "reason": f"功能[{f.seq}]预算硬顶已达（{hard_reason}），停止继续重试。费用看板见 CI 页签；可确认后恢复（提高上限）或回滚。",
                        "options": ["恢复运行", "回滚", "放弃该功能"],
                    })
                    self._evolve_async(task.id)
                    return True

                sos_action = await self._maybe_sos(session, task, project, repo, spec, f, runs, fault, max_retries)
                if sos_action == "stop":
                    return True
                if sos_action == "fixer":
                    await self._dispatch_fixer(task, project.id, spec.id, f.id, agent_id, runs)
                    continue


                if f.retry_count > max_retries and repeat_fp:
                    task.status = m.TaskStatus.paused_human
                    session.add(task)
                    session.commit()
                    self._ev(task.id, "human.required", {"reason": f"功能[{f.seq}]重试超限且失败指纹重复无进展（{fault}）", "options": ["人工修复后恢复", "回滚", "放弃该功能"]})

                    self._evolve_async(task.id)
                    return True
                if fault == "command":

                    if repeat_fp and self._fault_fingerprints[f.id].count(fp) >= 3:
                        task.status = m.TaskStatus.paused_human
                        session.add(task)
                        session.commit()
                        self._ev(task.id, "human.required", {"reason": f"功能[{f.seq}]验证命令重规划后同指纹失败 3 次，重规划无效", "options": ["人工修复后恢复", "回滚", "放弃该功能"]})
                        self._evolve_async(task.id)
                        return True

                    err = await asyncio.to_thread(lead.replan_verify_commands, self.gateway, session, task, f, _failure_context_with_history(session, project.id, runs), self.bus)
                    if err:
                        task.status = m.TaskStatus.paused_human
                        session.add(task)
                        session.commit()
                        self._ev(task.id, "human.required", {"reason": f"功能[{f.seq}]验证命令重规划失败: {err}", "options": ["人工修复后恢复", "回滚"]})
                        return True
                    self._ev(task.id, "log.appended", {"level": "lead", "message": f"功能[{f.seq}]验证命令已由 Lead 重规划"})
                    continue
                if fault == "transient":

                    if repeat_fp and self._fault_fingerprints[f.id].count(fp) >= 3:
                        task.status = m.TaskStatus.paused_human
                        session.add(task)
                        session.commit()
                        self._ev(task.id, "human.required", {"reason": f"功能[{f.seq}]瞬时故障同指纹连续 3 次，疑似环境/稳定性问题而非瞬时", "options": ["人工处理后恢复", "回滚", "放弃该功能"]})
                        self._evolve_async(task.id)
                        return True

                    self._ev(task.id, "log.appended", {"level": "sched", "message": f"功能[{f.seq}]瞬时故障，直接重试"})
                    continue


                async def _qa_report_async() -> None:
                    try:
                        report = await asyncio.to_thread(qa.qa_attribute_failure, self.gateway, f, runs, "light", self.engine)
                        if report:

                            try:
                                with Session(self.engine) as _s:
                                    _tt = _s.get(m.Task, task.id)
                                    _s.add(
                                        m.HandoffNote(
                                            task_id=task.id,
                                            feature_id=f.id,
                                            parent_task_id=_tt.parent_task_id if _tt else None,
                                            role="qa",
                                            kind="attribution",
                                            content=report[:4000],
                                        )
                                    )
                                    _s.commit()
                            except Exception:
                                pass
                            self._ev(task.id, "log.appended", {"level": "qa", "message": f"QA 归因: {report[:500]}"})
                    except Exception:
                        pass

                asyncio.create_task(_qa_report_async())


                if len(self._fault_fingerprints[f.id]) >= 3 and len(set(self._fault_fingerprints[f.id][-3:])) == 1:
                    self._ev(task.id, "log.appended", {"level": "sched", "message": f"功能[{f.seq}]连续 3 次失败指纹相同，判定空转 → Lead 重规划"})
                    self._fault_fingerprints[f.id] = []
                    err = await asyncio.to_thread(lead.replan_verify_commands, self.gateway, session, task, f, _failure_context_with_history(session, project.id, runs), self.bus)
                    if err:
                        task.status = m.TaskStatus.paused_human
                        session.add(task)
                        session.commit()
                        self._ev(task.id, "human.required", {"reason": f"功能[{f.seq}]修复空转后重规划失败: {err}", "options": ["人工修复后恢复", "回滚"]})
                        return True
                    continue

                await self._dispatch_fixer(task, project.id, spec.id, f.id, agent_id, runs)
        return False


    async def _dispatch_developer(
        self, task: m.Task, project_id: int, spec_id: int, feature_id: int, agent_id: int):
        """并发写：复制 id 到 worker，worker 内自建 session 取 model，避免跨线程共享主 session。"""
        def _worker() -> None:
            s = Session(self.engine)
            node = None
            try:
                f = s.get(m.Feature, feature_id)
                tt = s.get(m.Task, task.id)
                proj = s.get(m.Project, project_id)
                sp = s.get(m.Spec, spec_id)
                target = dev.compute_target_file(f, self._dev_root or Path(proj.repo_path))
                failure_ctx = _developer_failure_context(s, f.id)
                prompt = dev.build_developer_prompt(tt, f, sp.yaml_raw if sp else "", proj, target, failure_context=failure_ctx, repo_root=self._dev_root)
                if failure_ctx:
                    self._ev(tt.id, "log.appended", {"level": "sched", "message": f"功能[{f.seq}]developer 重派：已注入历次失败上下文（{len(failure_ctx)} 字）"})

                rework = latest_rework_instruction(s, tt.id)
                if rework:
                    prompt += "\n\n## 用户重做指令（最高优先级，必须据此修改；不要照抄上一轮实现）\n" + rework[:2000]
                research = self._research_report
                if not research:
                    research = _latest_research_note(s, tt.id, feature_id=None)
                if research:





                    clipped = "" if len(research) <= 2000 else "（本报告已截断，缺失部分**按未知处理**：以本功能 Spec 为准自行定名/定锚点，**不要去 `~/.agentflow/` 下的 DB/trace/日志里翻找**——那是平台内部文件，不是你的工作区）"
                    prompt += "\n\n## Lead 调研参考（researcher 产物）\n" + research[:2000] + ("\n" + clipped if clipped else "")



                diag = _latest_lead_diagnosis(s, tt.id)
                if diag:
                    prompt += (
                        "\n\n## 现场诊断结论（diagnose 节点产物，已查证；**直接采信，勿重复探索**）\n"
                        + diag[:3000]
                    )
                pf = _ui_preflight_hint(self.settings, tt.id)
                if pf:
                    prompt += "\n\n" + pf
                rm = _repo_map_hint(self.settings, self._dev_root or Path(proj.repo_path))
                if rm:
                    prompt += rm
                overview = _ctx.build_tree_overview(s, tt, mode="brief")
                if overview:
                    prompt += "\n\n" + overview + _ctx.BRIEF_APPENDIX
                node = self._new_node(s, tt, f, agent_id, "edit", summary=f"开发: {f.title}")
                dispatch = Dispatch(task=tt, role="developer", feature=f, system=_developer_system(f), prompt=prompt,
                                    node_id=node.id, requires_done=True,
                                    images=lead.requirement_images(self.settings, s, tt.id))
                runtime = AgentRuntime(self.engine, self.gateway, self.bus, self.settings, self._dev_root or Path(proj.repo_path), _project_invariants(s, proj.id), intervention_fetch=self._pending_interventions, project_root=Path(proj.repo_path))
                runtime.run(dispatch, s, Safety(self.settings))
                if self._stopped(tt):
                    self._finish_node(s, node, m.NodeStatus.failed, summary=self._halt_summary(node, f.title))
                    return
                f.status = m.FeatureStatus.verifying
                s.add(f)
                s.commit()

                dev_summary = f"开发完成: {f.title}" + (f"\n{dispatch.report[:400]}" if dispatch.report else "")
                self._finish_node(s, node, m.NodeStatus.succeeded, summary=dev_summary)
                self._ev(tid := tt.id, "feature.updated", _feature_payload(f))
            except Exception as e:
                if node is not None:
                    self._finish_node(s, node, m.NodeStatus.failed, summary=f"开发异常: {e}")
                else:
                    import traceback as _tb
                    _tb.print_exc()
            finally:
                s.close()

        await asyncio.to_thread(_worker)

    async def _dispatch_group_developers(
        self, task: m.Task, project_id: int, spec_id: int, todo: list[m.Feature], agent_id: int):
        """组内开发派工：快手路径资格命中 → Lead 直做；否则 developer 派工（组内 gather 并发）。"""




        if not todo:
            return
        if self._lead_direct_eligible(todo):
            self._ev(task.id, "log.appended", {
                "level": "lead",
                "message": f"Lead 直做（快手路径）：功能[{todo[0].seq}]「{todo[0].title}」简单小改，跳过派工直接执行",
            })



            await asyncio.gather(*(self._dispatch_lead_direct(
                task, project_id, spec_id, f.id, agent_id) for f in todo))
        else:
            await asyncio.gather(*(self._dispatch_developer(
                task, project_id, spec_id, f.id, agent_id) for f in todo))

    def _lead_direct_eligible(self, todo: list[m.Feature]) -> bool:
        """快手路径资格：简单快路径 + 单功能 + 写集 ≤2 个**字面路径** + 开关未关。"""
        if not todo:
            return False
        cfg = self.settings.data.get("lead", {}) or {}
        if bool(cfg.get("force_direct", False)):
            return True
        if not bool(cfg.get("direct_simple", True)):
            return False
        if not self._fast_path or len(todo) != 1:
            return False
        try:
            scope = json.loads(todo[0].file_scope or "[]")
        except (json.JSONDecodeError, TypeError):
            return False
        if not 0 < len(scope) <= 2:
            return False
        return all(not any(ch in str(p) for ch in "*?[") for p in scope)

    async def _dispatch_lead_direct(
        self, task: m.Task, project_id: int, spec_id: int, feature_id: int, agent_id: int):
        """ 快手路径：Lead 以执行模式直做简单小改（单功能/小写集）。"""
        def _worker() -> None:
            s = Session(self.engine)
            node = None
            try:
                f = s.get(m.Feature, feature_id)
                tt = s.get(m.Task, task.id)
                proj = s.get(m.Project, project_id)
                sp = s.get(m.Spec, spec_id)
                target = dev.compute_target_file(f, self._dev_root or Path(proj.repo_path))
                prompt = dev.build_developer_prompt(
                    tt, f, sp.yaml_raw if sp else "", proj, target,
                    failure_context=_developer_failure_context(s, f.id), repo_root=self._dev_root,
                )




                rework = latest_rework_instruction(s, tt.id)
                if rework:
                    prompt += (
                        "\n\n## 用户重做指令（最高优先级，必须据此修改；不要照抄上一轮实现）\n"
                        + rework[:2000]
                    )
                overview = _ctx.build_tree_overview(s, tt, mode="brief")
                if overview:
                    prompt += "\n\n" + overview + _ctx.BRIEF_APPENDIX




                diag = _latest_lead_diagnosis(s, tt.id)
                if diag:
                    prompt += (
                        "\n\n## 现场诊断结论（diagnose 节点产物，已查证；**直接采信，勿重复探索**）\n"
                        + diag[:3000]
                    )
                pf = _ui_preflight_hint(self.settings, tt.id)
                if pf:
                    prompt += "\n\n" + pf
                rm = _repo_map_hint(self.settings, self._dev_root or Path(proj.repo_path))
                if rm:
                    prompt += rm
                node = self._new_node(s, tt, f, agent_id, "edit", summary=f"Lead 直做: {f.title}")
                dispatch = Dispatch(
                    task=tt, role="lead", feature=f,
                    system=_lead_direct_system(), prompt=prompt, node_id=node.id,
                    requires_done=True,

                    images=lead.requirement_images(self.settings, s, tt.id),


                    max_steps=int(self.settings.data.get("lead", {}).get("direct_max_steps", 80)),
                )
                runtime = AgentRuntime(
                    self.engine, self.gateway, self.bus, self.settings,
                    self._dev_root or Path(proj.repo_path), _project_invariants(s, proj.id),
                    intervention_fetch=self._pending_interventions, project_root=Path(proj.repo_path),
                )
                final = runtime.run(dispatch, s, Safety(self.settings))
                if self._stopped(tt):
                    self._finish_node(s, node, m.NodeStatus.failed, summary=self._halt_summary(node, f.title))
                    return
                f.status = m.FeatureStatus.verifying
                s.add(f)
                s.commit()
                tail = (dispatch.report or (final or "").strip())[:400]
                self._finish_node(
                    s, node, m.NodeStatus.succeeded,
                    summary=f"Lead 直做完成: {f.title}" + (f"\n{tail}" if tail and tail != "done" else ""),
                )
                self._ev(tt.id, "feature.updated", _feature_payload(f))
            except Exception as e:
                if node is not None:
                    self._finish_node(s, node, m.NodeStatus.failed, summary=f"Lead 直做异常: {e}")
                else:
                    import traceback as _tb
                    _tb.print_exc()
            finally:
                s.close()

        await asyncio.to_thread(_worker)


    async def _dispatch_fixer(
        self, task: m.Task, project_id: int, spec_id: int, feature_id: int, agent_id: int, runs: list[m.VerifierRun]):
        def _worker() -> None:
            s = Session(self.engine)
            node = None
            try:
                f = s.get(m.Feature, feature_id)
                tt = s.get(m.Task, task.id)
                proj = s.get(m.Project, project_id)
                sp = s.get(m.Spec, spec_id)
                failure_ctx = _failure_context(runs)

                drift = self._env_drift_notes.get(feature_id)
                if drift:
                    failure_ctx += (
                        "\n\n## 环境漂移告警（任务启动后环境已变化）\n"
                        + "；".join(drift)
                        + "\n先判断失败是否由环境/依赖引起（缺依赖先补装、缓存先清理），确认非环境问题再修改代码。"
                    )

                handoff = _ctx.build_handoff_block(
                    s, tt.id, feature_id=feature_id, kinds=("report", "attribution", "summary")
                )
                if handoff:
                    failure_ctx += "\n\n## 历轮修复记录（已试过，勿重复）\n" + handoff.split("\n\n", 1)[-1]

                foot = _latest_explore_note(s, feature_id)
                if foot:
                    failure_ctx += "\n\n## 上一轮探索足迹（文件/命令/结论已探明，直接从这里继续，勿从头探索）\n" + foot.content[:2500]

                hist = _history_evidence_block(s, proj.id, runs)
                if hist:
                    failure_ctx += "\n\n## 历史同指纹证据（跨任务，代码聚类）\n" + hist
                    self._ev(tt.id, "log.appended", {"level": "sched", "message": f"功能[{f.seq}]命中 {len(hist.splitlines())} 条跨任务同指纹历史证据，已注入修复上下文"})

                hint = self._sos_hints.get(feature_id, "")
                sos_research = self._sos_research_reports.get(feature_id, "")
                if not sos_research:
                    sos_research = _latest_research_note(s, tt.id, feature_id=feature_id)
                prompt = fx.build_fixer_prompt(tt, f, sp.yaml_raw if sp else "", proj, failure_ctx, lead_hint=hint, research_report=sos_research)

                rework = latest_rework_instruction(s, tt.id)
                if rework:
                    prompt += "\n\n## 用户重做指令（最高优先级，必须据此修改）\n" + rework[:2000]
                overview = _ctx.build_tree_overview(s, tt, mode="brief")
                if overview:
                    prompt += "\n\n" + overview[:1200] + _ctx.BRIEF_APPENDIX
                node = self._new_node(s, tt, f, agent_id, "fix", summary=f"修复: {f.title}")
                dispatch = Dispatch(task=tt, role="fixer", feature=f, system=fx.build_fixer_system(f), prompt=prompt,
                                    node_id=node.id, requires_done=True,
                                    images=lead.requirement_images(self.settings, s, tt.id))
                runtime = AgentRuntime(self.engine, self.gateway, self.bus, self.settings, self._dev_root or Path(proj.repo_path), _project_invariants(s, proj.id), intervention_fetch=self._pending_interventions, project_root=Path(proj.repo_path))
                runtime.run(dispatch, s, Safety(self.settings))
                if self._stopped(tt):
                    self._finish_node(s, node, m.NodeStatus.failed, summary=self._halt_summary(node, f.title))
                    return
                f.status = m.FeatureStatus.verifying
                s.add(f)
                s.commit()

                if dispatch.report:
                    seq = (
                        len(
                            s.exec(_select_note_reports(feature_id)).all()
                        )
                        + 1
                    )
                    s.add(
                        m.HandoffNote(
                            task_id=tt.id,
                            feature_id=feature_id,
                            parent_task_id=tt.parent_task_id,
                            role="fixer",
                            kind="report",
                            seq=seq,
                            content=dispatch.report,
                            files=_report_files(dispatch.report),
                        )
                    )
                    s.commit()
                fix_summary = f"修复完成: {f.title}" + (f"\n{dispatch.report[:400]}" if dispatch.report else "")
                self._finish_node(s, node, m.NodeStatus.succeeded, summary=fix_summary)
            except Exception as e:
                if node is not None:
                    self._finish_node(s, node, m.NodeStatus.failed, summary=f"修复异常: {e}")
                else:
                    import traceback as _tb
                    _tb.print_exc()
            finally:
                s.close()


        await asyncio.to_thread(_worker)


    def _env_drift(self, repo_root: Path) -> list[str]:
        """E 环境指纹对账：重算当前环境与任务启动基线的差异。失败静默（指纹是增强证据）。"""
        try:
            from agentflow.core import env_fingerprint as _envfp

            return _envfp.check_drift(self.settings, getattr(self, "_project_name", ""), self.task_id, repo_root)
        except Exception:
            return []

    def _feature_diff_empty(self, repo_root: Path, feature: m.Feature) -> bool:
        """该 feature 写集内是否有未提交改动（CB-4 假完成判定：自称完成+写集空）。"""
        from agentflow.core.partition import feature_write_set

        try:
            write_set = feature_write_set(feature, repo_root)
            if not write_set:
                return True
            status_out = ""
            try:
                status_out = RepoHandle(repo_root).repo.git.status("--porcelain", "--", *write_set) or ""
            except Exception:
                status_out = ""
            return not status_out.strip()
        except Exception:
            return False

    async def _maybe_sos(
        self, session: Session, task: m.Task, project: m.Project, repo: RepoHandle,
        spec: m.Spec, feature: m.Feature, runs, fault: str, max_retries: int,
    ) -> str:
        '''SOS 熔断检查 + Lead 决策 + 分支执行。返回 "none"（走原路径）/"fixer"/"stop"。'''
        repo_root = self._dev_root or Path(project.repo_path)
        fps = self._fault_fingerprints.get(feature.id, [])

        soft_hit, soft_reason = budget_mod.budget_soft_exceeded(session, task, self.settings)
        trigger = sos_mod.check_breaker(
            fault=fault,
            fingerprints=fps,
            has_fix_report=feature.id in self._fix_reports,
            worktree_diff_empty=self._feature_diff_empty(repo_root, feature),
            developer_report=self._dev_reports.get(feature.id, ""),
            retry_count=feature.retry_count,
            max_retries=max_retries,
            budget_pressure=soft_hit,
        )
        if trigger is None:
            return "none"
        self._ev(task.id, "log.appended", {"level": "sos", "message": f"功能[{feature.seq}]触发熔断 {trigger}（{fault}）→ 进入 SOS 决策"})


        quota = int(self.settings.data.get("sos", {}).get("task_quota", 2))
        redecide_max = int(self.settings.data.get("sos", {}).get("redecide_max", 1))
        used = sos_mod.sos_task_used(session, task.id)
        direct_escalate = False
        if used >= quota:
            self._ev(task.id, "log.appended", {"level": "sos", "message": f"SOS 配额已用尽（{used}/{quota}）→ 直接升级人工"})
            direct_escalate = True
        elif sos_mod.breaker_count(session, feature.id) >= 1:
            self._ev(task.id, "log.appended", {"level": "sos", "message": "该功能已熔断过一次仍未解决 → 直接升级人工"})
            direct_escalate = True


        packet = sos_mod.build_sos_packet(
            session, task, feature, trigger, fault, fps, runs,
            fix_report=self._fix_reports.get(feature.id, ""),
            retry_count=feature.retry_count, max_retries=max_retries,
            sos_used=used, sos_quota=quota,
        )

        if direct_escalate:
            packet.decision = "escalate"
            packet.decision_payload = json.dumps({"question": f"SOS 配额限制直接升级（触发 {trigger}，故障 {fault}）"}, ensure_ascii=False)
            packet.decision_valid = True
            session.add(packet)
            session.commit()
            return await self._sos_escalate(session, task, feature, packet)


        decision: dict | None = None
        retry_error = ""
        for _ in range(redecide_max + 1):
            decision = await asyncio.to_thread(lead.sos_decide, self.gateway, session, task, feature, packet, retry_error, self.bus)
            if decision is None:
                retry_error = "决策输出无法解析为 JSON"
                decision = None
                continue
            clamped = sos_mod.normalize_decision(decision)
            if clamped:
                self._ev(task.id, "log.appended", {
                    "level": "sos",
                    "message": "SOS 决策自由文本超限已截断（非致命，保留下一步可执行内容）: " + "、".join(clamped),
                })
            ok, err = sos_mod.validate_decision(decision, session, task, feature, repo_root)
            if ok:
                break
            retry_error = err
            decision = None
        if decision is None:
            self._ev(task.id, "log.appended", {"level": "sos", "message": f"Lead 决策非法（{retry_error}）→ 升级人工"})
            packet.decision = "escalate"
            packet.decision_payload = json.dumps({"question": f"Lead 决策输出非法（{retry_error}），需人工介入。触发: {trigger}"}, ensure_ascii=False)
            packet.decision_valid = True
            session.add(packet)
            session.commit()
            return await self._sos_escalate(session, task, feature, packet)


        packet.decision = decision.get("decision")
        packet.decision_payload = json.dumps(decision.get("payload") or {}, ensure_ascii=False)
        packet.decision_valid = True
        session.add(packet)
        session.commit()
        d = decision.get("decision")
        payload = decision.get("payload") or {}
        reason = (decision.get("reason") or "")[:200]
        self._ev(task.id, "log.appended", {"level": "sos", "message": f"SOS 决策: {d}（{reason}）"})

        if d == "restrategy":
            self._sos_hints[feature.id] = str(payload.get("new_hint") or "")

            feature.retry_count = max(0, feature.retry_count // 2)
            session.add(feature)
            session.commit()
            return "fixer"

        if d == "research":
            report = await self._sos_dispatch_research(session, task, project, feature, str(payload.get("focus") or ""))
            self._sos_research_reports[feature.id] = report or ""
            _persist_research_report(self.engine, task.id, feature.id, report or "", sos=True)
            return "fixer"

        if d == "split":
            subs = payload.get("subtasks") or []
            fids = []
            for sub in subs:
                sub_task = await asyncio.to_thread(sos_mod.create_split_subtask, session, task, feature, sub)
                fids.append(sub_task.id)
                self._ev(task.id, "log.appended", {"level": "sos", "message": f"SOS 拆分子任务 #{sub_task.id}「{sub_task.title}」"})
            feature.status = m.FeatureStatus.blocked
            session.add(feature)
            task.status = m.TaskStatus.waiting_subtasks
            session.add(task)
            session.commit()
            self._ev(task.id, "feature.updated", _feature_payload(feature, status="blocked"))
            self._ev(task.id, "task.updated", {"task_id": task.id, "status": "waiting_subtasks"})
            self._ev(task.id, "human.required", {
                "reason": f"功能[{feature.seq}]已拆为 {len(fids)} 个子任务（{', '.join(f'#{i}' for i in fids)}），父任务等待子任务完成后自动恢复",
                "options": ["查看子任务进度"],
            })

            self._spawn_subtask_runners(task, fids)
            return "stop"

        return await self._sos_escalate(session, task, feature, packet)

    def _spawn_subtask_runners(self, parent_task: m.Task, sub_ids: list[int]) -> None:
        """派发子任务 runner（spawn_runner 回调优先，None 时本地 asyncio 兜底）。"""
        for sid in sub_ids:
            try:
                if self._spawn_runner is not None:
                    self._spawn_runner(sid)
                else:
                    from agentflow.core.scheduler import TaskRunner as _TR

                    asyncio.get_event_loop().create_task(_TR(self.engine, self.gateway, self.bus, self.settings, sid).run())
            except Exception as e:
                self._ev(parent_task.id, "log.appended", {"level": "sos", "message": f"子任务 #{sid} 启动失败: {e}"})

    async def _sos_escalate(self, session: Session, task: m.Task, feature: m.Feature, packet: "m.SosPacket") -> str:
        """escalate 分支：停机人工 + human.required（带 SOS 摘要）。"""
        try:
            q = json.loads(packet.decision_payload or "{}").get("question", "")
        except Exception:
            q = ""
        task.status = m.TaskStatus.paused_human
        session.add(task)
        session.commit()
        self._ev(task.id, "task.updated", {"task_id": task.id, "status": "paused_human"})
        self._ev(task.id, "human.required", {
            "reason": f"功能[{feature.seq}]SOS 升级人工（触发 {packet.trigger}）: {q}",
            "options": ["人工修复后恢复", "回滚", "放弃该功能"],
        })
        return "stop"

    async def _sos_dispatch_research(
        self, session: Session, task: m.Task, project: m.Project, feature: m.Feature, focus: str,
    ) -> str | None:
        """SOS research 分支：按需派 researcher（复用 _lead_maybe_research 的线程模式），"""
        from agentflow.agents import researcher as rs

        def _worker() -> str:
            ws = Session(self.engine)
            node = None
            try:
                instance = m.AgentInstance(task_id=task.id, role="researcher", model=_record_model(self.gateway, "researcher"))
                ws.add(instance)
                ws.commit()
                t = ws.get(m.Task, task.id)
                node = self._new_node(ws, t, feature, instance.id, "research", summary=f"SOS 调研: {feature.title}")
                dispatch = Dispatch(
                    task=t, role="researcher", feature=feature,
                    system=rs.build_researcher_system(),
                    prompt=(
                        f"功能 F{feature.seq}「{feature.title}」修复多次失败，Lead 决策派你只读调研。\n"
                        f"PROJECT_PATH: {project.repo_path}\n\n"
                        f"## 调研聚焦点（Lead 指定）\n{focus[:1000]}\n\n"
                        f"## 当前失败上下文\n写集: {feature.file_scope}\n\n"
                        "请只读排查（read_file/grep/glob/run_cmd 只读命令），定位真正的根因与可行修复路径，"
                        "输出简洁报告后调用 done。"
                    ),
                    node_kind="research",
                    node_id=node.id,
                )
                rt = AgentRuntime(self.engine, self.gateway, self.bus, self.settings,
                                  self._dev_root or Path(project.repo_path),
                                  _project_invariants(ws, project.id), intervention_fetch=self._pending_interventions,
                                  drop_tools={"ask_lead"})
                result = rt.run(dispatch, ws, Safety(self.settings))
                self._finish_node(ws, node, m.NodeStatus.succeeded, summary=f"SOS 调研完成: {(result or '').strip()[:300]}")
                return result or ""
            except Exception:
                if node is not None:
                    self._finish_node(ws, node, m.NodeStatus.failed, summary=f"SOS 调研异常: {feature.title}")
                return ""
            finally:
                ws.close()

        return await asyncio.to_thread(_worker)


    def _pending_interventions(self) -> list[str]:
        """拉取用户插队消息（供 AgentRuntime 循环头注入）。_db_lock 防并发双读，逻辑在模块级函数。"""
        with self._db_lock:
            return _drain_user_interventions(self.engine, self.task_id)


    def _stopped(self, task: m.Task) -> bool:
        """人工干预/熔断检查：任务脱离可运行态后，当前 dispatch 结束即停。"""
        with Session(self.engine) as fresh:
            t = fresh.get(m.Task, task.id)
            return t is None or t.status not in (m.TaskStatus.running, m.TaskStatus.merging)

    def _halt_summary(self, node: m.Node | None, title: str) -> str:
        """停机节点摘要：从 trace 取确切停机原因（预算熔断 ≠ 人工中断，别让 UI 说谎）。"""
        reason = ""
        try:
            if node is not None and node.trace_uri:
                for ev in reversed(tr.read_trace(node.trace_uri, limit=2000)):
                    if ev.get("kind") == "interrupt":
                        reason = str(ev.get("content") or "").strip()
                        break
        except Exception:
            reason = ""
        return f"已停机: {title}（{reason or '任务脱离可运行态，agent 已停止'}）"

    def _verify_feature(self, session: Session, task: m.Task, feature: m.Feature, repo_root: Path):



        try:
            from agentflow.core.strays import sweep_strays



            try:
                _sibs = list(session.exec(
                    select(m.Feature).where(m.Feature.task_id == task.id)
                ).all())
                _sibs = [x for x in _sibs if x.id != feature.id]
            except Exception:
                _sibs = []
            sweep_strays(session, feature, repo_root, bus=self.bus, siblings=_sibs)
        except Exception as e:
            self._ev(task.id, "log.appended", {
                "level": "sched",
                "message": f"校验前卫生收口异常（跳过，不阻断校验）: {type(e).__name__}: {e}",
            })
        verify_node = self._new_node(session, task, feature, None, "verify", summary=f"校验: {feature.title}")
        passed, runs, blocking = va.run_feature_verifiers(
            session, self.settings, task, feature, repo_root, node_id=verify_node.id, bus=self.bus, stage="light"
        )

        summary = f"校验通过: {feature.title}" if passed else f"校验失败({blocking}): {feature.title}"
        self._finish_node(session, verify_node, m.NodeStatus.succeeded if passed else m.NodeStatus.failed, summary)
        if not passed:
            for r in runs:
                if r.exit_code != 0:
                    queue_mod.push(session, m.FailureQueueEntry(task_id=task.id, feature_id=feature.id, verifier_run_id=r.id, classification=r.classification or "blocking"))
        self._ev(task.id, "feature.updated", _feature_payload(feature, status=m.FeatureStatus.verifying.value))
        return passed, runs, blocking

    def _green_commit_message(self, task: m.Task, feature: m.Feature, files: list[str]) -> str:
        """#11：绿点 commit 中文标题（Lead LLM 拟定，≤30 字；失败回退模板，响亮降级不阻塞）。"""
        fallback = f"功能 F{feature.seq}：{feature.title}"
        try:
            prompt = (
                "为下面的功能改动拟定一条 git commit 标题：简体中文，不超过 30 个字，"
                "概括做了什么（动词开头），只输出标题本身，不要引号/前后缀/解释。\n"
                f"功能标题：{feature.title}\n"
                f"改动文件：{', '.join(files[:10]) or '（无文件改动）'}"
            )
            result = self.gateway.generate("lead", prompt)
            from agentflow.core.llm_usage import record_extra

            record_extra(self.engine, task.id, "lead", "merge", "green_commit_title", result)
            text = (result.text or "").strip()
            if text:
                text = text.splitlines()[0].strip().strip('"\'「」').strip()
            return text[:60] or fallback
        except Exception:
            return fallback

    def _green(self, session: Session, task: m.Task, feature: m.Feature, repo: RepoHandle, repo_root: Path):
        files = leases.applied_files(session, feature.id)



        try:
            scope = {p.replace("\\", "/") for p in json.loads(feature.file_scope or "[]")}
            changed = parse_porcelain_paths(repo.repo.git.status("--porcelain") or "")
            files, extra, out_of_scope = merge_green_file_set(files, scope, changed)
            if extra:
                self._ev(task.id, "log.appended", {
                    "level": "sched",
                    "message": f"绿点锚纳入工作区未提交改动 {len(extra)} 个（租约外补录）: {', '.join(extra[:5])}",
                })
            if out_of_scope:




                sibling: set[str] = set()
                try:
                    for ff in session.query(m.Feature).filter(m.Feature.task_id == task.id).all():
                        if ff.id != feature.id:
                            sibling |= {p.replace("\\", "/") for p in json.loads(ff.file_scope or "[]")}
                except Exception:
                    sibling = set()
                claimed = [p for p in out_of_scope if p in sibling]
                orphan = [p for p in out_of_scope if p not in sibling]
                if claimed:
                    self._ev(task.id, "log.appended", {
                        "level": "sched",
                        "message": f"绿点未纳 {len(claimed)} 个兄弟 feature 写集内的在途文件（由其各自绿点提交，非漏纳）: {', '.join(claimed[:5])}",
                    })
                if orphan:
                    self._ev(task.id, "log.appended", {
                        "level": "sched",
                        "message": f"警告: 工作区有 {len(orphan)} 个不属于任何 feature 写集的未提交文件未纳入绿点: {', '.join(orphan[:5])}",
                    })
        except Exception as e:
            self._ev(task.id, "log.appended", {"level": "sched", "message": f"绿点锚文件集探测失败（按租约原集提交）: {e}"})
        commit_msg = self._green_commit_message(task, feature, files)
        commit_hash = anchors.create_green_commit(repo, feature, files, message=commit_msg)
        anchor = m.GreenAnchor(task_id=task.id, feature_id=feature.id, commit_hash=commit_hash)
        session.add(anchor)
        feature.status = m.FeatureStatus.passed
        session.add(feature)

        for q in (
            session.query(m.FailureQueueEntry)
            .filter(m.FailureQueueEntry.task_id == task.id, m.FailureQueueEntry.feature_id == feature.id)
            .all()
        ):
            if q.status != "resolved":
                q.status = "resolved"
                session.add(q)
        session.commit()
        self._ev(task.id, "anchor.created", {"anchor_id": anchor.id, "commit": commit_hash, "feature_id": feature.id})
        self._ev(task.id, "feature.updated", _feature_payload(feature, status=m.FeatureStatus.passed.value))
        for sf in failure_mod.mark_stale_if_overlap(session, task.id, feature.id, repo_root):
            self._ev(task.id, "feature.updated", _feature_payload(sf))


        try:
            swept = sweep_agent_temp_files(repo, repo_root)
            if swept:
                self._ev(task.id, "log.appended", {"level": "sched", "message": f"已清扫 agent 临时文件: {', '.join(swept[:5])}"})
        except Exception:
            pass





_AGENT_TEMP_NAME_RE = re.compile(
    r"(?:^|/)(?:check_tmp[^/]*|tmp_[^/]*|temp_[^/]*|scratch_[^/]*|[^/]*_tmp\.(?:py|sh|ps1|js|ts|json|txt|log))$",
    re.I,
)


def sweep_agent_temp_files(repo: RepoHandle, repo_root: Path) -> list[str]:
    """清扫工作区未跟踪的 agent 临时文件（验证脚本写完即弃的残留）。"""
    deleted: list[str] = []
    try:
        out = repo.repo.git.status("--porcelain", "--untracked-files=all") or ""
    except Exception:
        return deleted
    for line in out.splitlines():
        if not line.startswith("??"):
            continue
        p = line[3:].strip().replace("\\", "/")
        if not p or not _AGENT_TEMP_NAME_RE.search(p):
            continue
        fp = repo_root / p
        try:
            if fp.is_file():
                fp.unlink()
                deleted.append(p)
        except Exception:
            pass
    return deleted


def parse_porcelain_paths(text: str) -> set[str]:
    """解析 git status --porcelain 输出为路径集合（归一化 / 分隔、处理 rename 箭头）。"""
    out: set[str] = set()
    for line in (text or "").splitlines():
        p = line[3:].strip()
        if not p:
            continue
        if "->" in p:
            p = p.split("->")[-1].strip()
        out.add(p.replace("\\", "/"))
    return out


def merge_green_file_set(
    files: list[str], scope: set[str], changed: set[str]
) -> tuple[list[str], list[str], list[str]]:
    """绿点锚文件集 = 租约文件集 ∪ 工作区内属 file_scope 的未提交改动。"""
    norm_files = {p.replace("\\", "/") for p in files}
    extra = sorted((changed & scope) - norm_files)
    out_of_scope = sorted(changed - scope - norm_files)
    merged = list(files) + extra if extra else list(files)
    return merged, extra, out_of_scope


def _drain_user_interventions(engine, task_id: int) -> list[str]:
    """模块级插队拉取：TaskRunner 与 PM 合并 resolver 共用。"""
    try:
        with Session(engine) as s:
            rows = s.exec(
                select(m.ClarifyMessage)
                .where(
                    m.ClarifyMessage.task_id == task_id,
                    m.ClarifyMessage.role == "user",
                    m.ClarifyMessage.consumed_at == "",
                )
                .order_by(m.ClarifyMessage.id.asc())
            ).all()
            if not rows:
                return []
            now = datetime.now(timezone.utc).isoformat()
            texts: list[str] = []
            for r in rows:
                text = (r.content or "").strip()
                if r.images and r.images != "[]":
                    text = (text + "\n[附图片]") if text else "[附图片]"
                if text:
                    texts.append(text[-500:])
                r.consumed_at = now
                s.add(r)
            s.commit()
            return texts[-8:]
    except Exception:
        return []


def _project_name(session: Session, project_id: int) -> str:
    p = session.get(m.Project, project_id)
    return p.name if p else str(project_id)


def _project_invariants(session: Session, project_id: int) -> list[str]:
    rows = session.query(m.Invariant).filter(m.Invariant.project_id == project_id).all()
    return [r.text for r in rows]


def _developer_system(feature: m.Feature) -> str:
    from agentflow.spec.schema import render_spec_prompt
    from agentflow.spec.schema import parse_spec

    return (
        "你是开发 agent（ReAct）。用工具读写文件完成任务后调用 done。"
        "写文件必须遵守：只写自己的写集文件；通过工具完成，禁止臆造。"
        "若经核实功能目标状态已被历史提交满足（无需任何代码改动），在完成报告中如实声明"
        "「无需改动」并给出核实证据（如目标文件/控件现状），不要为证明项目没坏而跑构建级"
        "重验证（build 等）——平台会按 git diff 事实判定无改动并短路后续审查与合并；"
        "但请务必先真核实（读目标文件/运行只读检查），核实是声明的前提。"
        "调用 done 前，先输出结构化完成报告（供系统解析归档，格式严格如下）：\n"
        "[DEV_REPORT]\n"
        "做了什么: <一句话>\n"
        "改动文件: <文件路径列表>\n"
        "测试: <自检命令与结果>\n"
        "[/DEV_REPORT]\n"
        "你可以用 ask_lead 工具向 Lead 求助（每功能最多 2 次），仅当确实无法推进时；"
        "求助后请继续尽力尝试，不要停下等待。\n"
        "你的所有自然语言输出（思考过程、分析说明、完成总结）必须使用简体中文；"
        "代码、命令、文件路径、标识符保持原文。"
    )


def _lead_direct_system() -> str:
    """快手路径 system：Lead 直做简单小改，不派 developer。"""
    return (
        "你是团队 Lead 的执行模式（快手路径）：本功能已判定为**简单小改**（单功能、少文件），"
        "由你直接动手完成，不再派 developer。\n"
        "可用工具：read_file / write_file / edit_file / delete_file / grep / glob / run_cmd / ui_check。\n\n"
        "规则：\n"
        "1. 先读清再改：项目结构摘要已给出相关文件内容，不够再 read_file；不要凭猜测改。\n"
        "1a. **一步多做**（省的是往返步数，墙钟 = 步数 × 单步时延）：互不依赖的多个读取/搜索"
        "（read_file / grep / glob）请在**同一次响应里并行调用**，别一步一个来回；"
        "跨文件的多处改动用一个 `edit_file` 的 `edits` 数组一次提交（原子：任一处不合法则整体不写）。\n"
        "2. 改动只能落本功能写集（file_scope）内，越区写会被租约拒绝（工具提示会告诉你怎么办）。\n"
        "3. 临时脚本一律写 .agentflow_tmp/；不要复制进真实源码目录——残留在 repo 里的临时文件会"
        "污染 typecheck/build 的全目录扫描，让校验误判。\n"
        "3a. 验收命令若是**关键词存在性/缺席性**检查，代码、注释、文档字符串里都**不要保留被移除的"
        "那个关键词字面量**——缺席断言会命中注释里的字面量而假失败（：flex-wrap 已从 "
        "className 移除，注释里却写着「不再 flex-wrap 折行」→ 被判残留 → 空转）。注释换同义描述。\n"
        "4. 改完**必须自己跑一遍本功能的验证命令**（见任务信息的 verify_commands），确认通过再 done；"
        "跑不过就继续改，不要谎报完成。\n"
        "5. 本功能若含 ui 机审（verify_commands 里 verifier=ui 那条）：**直接调 `ui_check` 跑它**——"
        "那是与合并门禁完全同一套管线（起服务 → Playwright 执行声明），开发期就能告诉你声明打不打中控件。"
        "不要自己用 run_cmd 手搓 Playwright 脚本（找解释器、装依赖、试端口会烧掉大半步数预算）。"
        "报「选择器不可见」时先分清是**声明缺陷**还是**实现缺陷**：目标控件常只在某个 tab / 筛选档位下才渲染，"
        "（数据为空时组件也可能整体不渲染）——这时该改的是**声明**，在 actions 里补上前置 click 动作"
        "（切到承载该控件的 tab、把数据筛到有内容的档位）再断言；只有确认选择器在页面上真实存在才去改实现。\n"
        "6. 调用 done 前先输出结构化完成报告（格式严格如下）：\n"
        "[DEV_REPORT]\n"
        "做了什么: <一句话>\n"
        "改动文件: <文件路径列表>\n"
        "测试: <自检命令与结果>\n"
        "[/DEV_REPORT]\n"
        "你的所有自然语言输出必须使用简体中文；代码、命令、路径保持原文。"
    )


def _has_no_content_diff(repo: RepoHandle, task: m.Task) -> bool:
    """任务分支相对 main 是否无内容差异（代码级判定，no-op 短路依据，）。"""
    if not task.branch:
        return False
    try:
        diff = repo.repo.git.diff("main", task.branch, "--numstat") or ""
        return not diff.strip()
    except Exception:
        return False


_PM_SYSTEM = (
    "你是 PM agent，负责合并冲突解决。"
    "标出的冲突文件含 <<<<<<< / ======= / >>>>>>> 标记，两侧分别是：上=当前分支(main)，下=待合并分支的改动。"
    "用 read_file 读取冲突文件、理解两侧意图，然后用 write_file/edit_file 写出合并后的正确内容（消除冲突标记）。"
    "保留两侧都有意义的改动，删除过时部分，不要臆造。冲突全部解决后调用 done。"

    "环境与手法（务必遵守，省步数）：操作系统是 Windows cmd——**没有 sed/grep/tail/head**；"
    "查看文件一律用 read_file，改写一律用 write_file/edit_file，**不要用 run_cmd 拼管道，也不要写临时文件**。"
    "read_file 只能读当前合并 worktree 内的路径；若要看任务分支或历史版本，用 run_cmd 执行 "
    "`git show <ref>:<path>`（输出直接进对话，**不要重定向到文件**）。"
    "若 main 侧是 revert 提交（撤销了本任务此前的合并），冲突的正确解法通常是以**待合并分支的意图**为准重建该文件。"
    "你的所有自然语言输出使用简体中文；代码、命令、文件路径保持原文。"
)


def _record_model(gateway: LLMGateway, role: str) -> str:
    """AgentInstance 记录用模型名（元数据，非 LLM 调用路径）：档案未配置时留空不阻断任务；"""
    from agentflow.llm.gateway import LLMError

    try:
        return gateway.model_for(role)
    except LLMError:
        return ""


_QA_CATEGORY_RE = re.compile(r"类别\s*[:：]\s*([A-Za-z]+)")
_GATE_REPLAN_KIND = "gate_replan"
_GATE_REWORK_KIND = "gate_rework"


_GATE_REWORK_BUDGET = 1


def _is_product_defect(qa_report: str) -> bool:
    """QA 归因是否把根因判为产品/实现侧缺陷（`类别: semantic`）→ 值得回灌开发循环。"""
    m = _QA_CATEGORY_RE.search(qa_report or "")
    return bool(m) and m.group(1).strip().lower() == "semantic"


def _is_command_defect(qa_report: str) -> bool:
    """QA 归因是否把根因判为 command 类（命令/检查声明侧缺陷，改代码救不了）。"""
    m = _QA_CATEGORY_RE.search(qa_report or "")
    return bool(m) and m.group(1).strip().lower() == "command"


def _ui_preflight_hint(settings, task_id: int) -> str:
    """Spec 期 ui 实测预检报告 → 开发节点提示词的「环境事实」块（P0，2026-09-27）。"""
    try:
        from agentflow.verifiers.ui_preflight import dev_hint

        return dev_hint(settings.home, task_id)
    except Exception:
        return ""


def _repo_map_hint(settings, root) -> str:
    """仓库符号索引（P4，2026-09-27）→ 开发节点提示词块；关掉配置即返回空串。"""
    try:
        if not bool(settings.data.get("context", {}).get("repo_map", True)):
            return ""
        from agentflow.core.repomap import build_repo_map

        mp = build_repo_map(root)
        if not mp:
            return ""
        return "\n\n## 仓库索引（repo map，Spec 期生成）\n" + mp
    except Exception:
        return ""


def ui_declaration_defect(runs: list) -> str:
    """失败命令里是否存在**可证明**的检查声明结构缺陷（空串=没有）。"""
    import json as _json

    from agentflow.verifiers.ui_dsl import declaration_problems

    for r in runs or []:
        if getattr(r, "exit_code", 0) == 0 or (getattr(r, "verifier", "") or "").lower() != "ui":
            continue
        cmd = getattr(r, "cmd", "") or ""
        try:
            obj = _json.loads(cmd) if cmd.strip().startswith("{") else None
        except Exception:
            obj = None
        if obj is None:
            continue
        problems = declaration_problems(obj)
        if problems:
            return "；".join(problems[:2])
    return ""


def _integration_failure_ctx(runs: list, qa_report: str) -> str:
    """集成失败上下文（供 B-2 重规划）：失败命令输出 + 结构化逐步详情 + QA 归因。"""
    parts: list[str] = []
    for r in runs or []:
        if getattr(r, "exit_code", 0) == 0:
            continue
        parts.append(_fmt_failed_run(r, limit=2000))
        d = (getattr(r, "detail", "") or "").strip()
        if d:
            parts.append(f"结构化失败详情（含页面 DOM 证据）:\n{d[:2500]}")
    if qa_report:
        parts.append("QA 归因:\n" + qa_report[:1500])
    return "\n\n".join(parts) or "（无失败输出记录）"


def _gate_replanned(session: Session, feature: m.Feature) -> int:
    """本功能的门禁自动重规划已用次数（HandoffNote 留档，server 重启后仍生效）。"""
    rows = session.exec(
        select(m.HandoffNote).where(
            m.HandoffNote.task_id == feature.task_id,
            m.HandoffNote.feature_id == feature.id,
            m.HandoffNote.kind == _GATE_REPLAN_KIND,
        )
    ).all()
    return len(rows)





_GATE_REPLAN_BUDGET = 2


def _mark_gate_replanned(session: Session, task: m.Task, feature: m.Feature, runs: list, qa_report: str) -> None:
    """留档门禁自动重规划（审计：原命令 + 新命令 + QA 归因摘录），并防同一功能重复自动重规划。"""
    try:
        old = [getattr(r, "cmd", "") for r in runs or [] if getattr(r, "verifier", "") == "ui"]
        note = m.HandoffNote(
            task_id=task.id,
            feature_id=feature.id,
            role="lead",
            kind=_GATE_REPLAN_KIND,
            content=(
                "门禁③ 自动重规划（QA 归因 command 类缺陷）\n"
                f"新 verify_commands: {feature.verify_commands[:1500]}\n\n"
                f"原 ui 命令: {(old[0] if old else '')[:800]}\n\n"
                f"QA 归因摘录: {qa_report[:600]}"
            ),
        )
        session.add(note)
        session.commit()
    except Exception:
        pass


def _note_gate_failure(session: Session, task: m.Task, feature: m.Feature, runs: list, qa_report: str) -> None:
    """把门禁失败现场落成 HandoffNote：后续修复者（重派开发者/fixer/人工）可注入。"""
    try:
        session.add(
            m.HandoffNote(
                task_id=task.id,
                feature_id=feature.id,
                role="qa",
                kind="attribution",
                content=("门禁③ 集成机审失败现场（heavy）\n" + _integration_failure_ctx(runs, qa_report))[:6000],
                verify_evidence="; ".join(
                    f"{getattr(r, 'verifier', '')} exit={r.exit_code}" for r in runs or [] if getattr(r, "exit_code", 0) != 0
                )[:1000],
            )
        )
        session.commit()
    except Exception:
        pass


def _gate_rework_count(session: Session, feature: m.Feature) -> int:
    """本功能门禁回灌开发循环已用次数（HandoffNote 留档，server 重启后仍生效）。"""
    rows = session.exec(
        select(m.HandoffNote).where(
            m.HandoffNote.task_id == feature.task_id,
            m.HandoffNote.feature_id == feature.id,
            m.HandoffNote.kind == _GATE_REWORK_KIND,
        )
    ).all()
    return len(rows)


def _mark_gate_rework(session: Session, task: m.Task, feature: m.Feature, runs: list, qa_report: str) -> None:
    """门禁回灌状态迁移 + 留档（单一入口，全部走代码）："""
    feature.status = m.FeatureStatus.pending
    feature.retry_count = 0
    session.add(feature)
    task.status = m.TaskStatus.running
    session.add(task)
    session.add(
        m.HandoffNote(
            task_id=task.id,
            feature_id=feature.id,
            role="lead",
            kind=_GATE_REWORK_KIND,
            content=("门禁回灌开发循环（QA 归因产品缺陷，功能重开待修）\n" + _integration_failure_ctx(runs, qa_report))[:6000],
            verify_evidence="; ".join(
                f"{getattr(r, 'verifier', '')} exit={r.exit_code}" for r in runs or [] if getattr(r, "exit_code", 0) != 0
            )[:1000],
        )
    )
    session.commit()


def build_merge_handlers(engine, gateway, bus, settings):
    """构造合并队列的 resolver/validator 回调（供 AppState 注入 MergeConsumer）。"""
    from agentflow.agents.base import AgentRuntime, Dispatch
    from agentflow.core.events_bus import EventBus

    def resolver(repo: "RepoHandle", conflicts: list[str], task: m.Task, project: m.Project, spec: m.Spec, node_id: int | None = None) -> bool:
        details = merge_mod.merge_conflict_details(repo, conflicts)
        s = Session(engine)
        try:
            t = s.get(m.Task, task.id)
            path = repo.repo_path
            detail_md = (
                f"以下任务#{t.id}「{t.title}」合并 main 与 {t.branch} 时冲突，请解决以下冲突文件：\n\n"
                f"{details}\n\n"
                "请读取每个冲突文件，用 write_file/edit_file 写出合并后的正确内容（消除全部冲突标记）。完成调用 done。"
            )
            dispatch = Dispatch(task=t, role="pm", feature=None, system=_PM_SYSTEM, prompt=detail_md,
                                node_kind="merge", node_id=node_id, max_steps=45)
            runtime = AgentRuntime(
                engine, gateway, bus, settings, path,
                project_invariants=_project_invariants(s, project.id),
                intervention_fetch=lambda: _drain_user_interventions(engine, task.id),
            )
            runtime.run(dispatch, s, Safety(settings))
            return not merge_mod.conflicts_unresolved(repo, conflicts)
        finally:
            s.close()

    def validator(session: Session, repo: "RepoHandle", task: m.Task, project: m.Project) -> str | None:
        """集成校验：对 worktree 当前 Spec 轮次的 feature 跑 stage=heavy，失败时由 QA 归因，返回首个失败错误文本或 None。"""
        from agentflow.agents import qa as qa, verifier_agent as va
        from agentflow.spec.scope import current_features




        feats = current_features(session, task.id)
        if not feats:
            return f"集成校验取不到任务#{task.id} 当前 Spec 轮次的功能（Spec 缺失或轮次错乱）"
        repo_root = repo.repo_path
        for f in feats:
            passed, runs, blocking = va.run_feature_verifiers(
                session, settings, task, f, repo_root, stage="heavy"
            )
            if not passed:
                failed = [r for r in runs if r.exit_code != 0]
                detail = failed[0].output_uri[:2000] if failed else ""

                try:
                    qa_report = qa.qa_attribute_failure(
                        gateway, f, runs, "heavy", session, want_fix_declaration=True
                    )
                except Exception:
                    qa_report = ""
                if qa_report:
                    try:
                        bus.publish_task(task.id, "log.appended", {"level": "qa", "message": f"QA 集成归因: {qa_report[:500]}"})
                    except Exception:
                        pass






                decl_defect = ui_declaration_defect(runs)
                if (
                    gateway is not None
                    and (decl_defect or _is_command_defect(qa_report))
                    and _gate_replanned(session, f) < _GATE_REPLAN_BUDGET
                ):
                    if decl_defect:
                        try:
                            bus.publish_task(task.id, "log.appended", {
                                "level": "sched",
                                "message": f"门禁③ 检出检查声明结构缺陷（{decl_defect[:160]}）→ 自动修复",
                            })
                        except Exception:
                            pass




                    fixed_ok, fixed_note = False, ""
                    fixed_decl = qa.parse_fixed_declaration(qa_report)
                    if fixed_decl is not None:
                        err_apply = qa.apply_fixed_declaration(session, f, fixed_decl)
                        if err_apply is None:
                            fixed_ok = True
                            try:
                                bus.publish_task(task.id, "log.appended", {
                                    "level": "lead",
                                    "message": "门禁③ QA 现场直修：检查声明缺陷由其修正声明直接修复（免转手重写），立即复跑",
                                })
                            except Exception:
                                pass
                        else:
                            fixed_note = err_apply
                    if not fixed_ok and fixed_note:
                        try:
                            bus.publish_task(task.id, "log.appended", {
                                "level": "sched",
                                "message": f"门禁③ QA 修正声明未采用（{fixed_note[:200]}）→ 回退 Lead 重规划",
                            })
                        except Exception:
                            pass
                    if not fixed_ok:

                        ctx = _integration_failure_ctx(runs, qa_report)
                        try:
                            err_r = lead.replan_verify_commands(gateway, session, task, f, ctx, bus=bus)
                        except Exception as e:
                            err_r = f"{type(e).__name__}: {e}"
                        if err_r:
                            try:
                                bus.publish_task(task.id, "log.appended", {
                                    "level": "sched",
                                    "message": f"门禁③ 自动重规划失败（{err_r[:200]}），按原路停机人工",
                                })
                            except Exception:
                                pass
                        else:
                            fixed_ok = True
                            try:
                                bus.publish_task(task.id, "log.appended", {
                                    "level": "lead",
                                    "message": f"门禁③ 自动重规划：功能[{f.seq}]的检查声明缺陷（{decl_defect or 'QA 归因 command 类'}）已由 Lead 重写，立即复跑该轮机审",
                                })
                            except Exception:
                                pass
                    if fixed_ok:
                        _mark_gate_replanned(session, task, f, runs, qa_report)
                        passed, runs, blocking = va.run_feature_verifiers(
                            session, settings, task, f, repo_root, stage="heavy"
                        )
                        if passed:
                            continue
                        failed = [r for r in runs if r.exit_code != 0]
                        detail = failed[0].output_uri[:2000] if failed else ""

                _note_gate_failure(session, task, f, runs, qa_report)




                product_defect = _is_product_defect(qa_report) and not decl_defect
                if product_defect and gateway is not None and _gate_rework_count(session, f) < _GATE_REWORK_BUDGET:
                    _mark_gate_rework(session, task, f, runs, qa_report)
                    try:
                        bus.publish_task(task.id, "log.appended", {
                            "level": "sched",
                            "message": (
                                f"门禁回灌开发循环：功能[{f.seq}]经 QA 归因为产品缺陷（{qa_report[:160]}），"
                                "已重开该功能并回到开发阶段继续修（预算内自动重做一次）"
                            ),
                        })
                    except Exception:
                        pass
                    from agentflow.core.merger import GateRework

                    raise GateRework(task.id, f.seq, f"QA 归因: {qa_report[:200]}")
                return f"集成校验失败[{f.title}]({blocking}): {detail}"


            try:
                ok_n = sum(1 for r in runs if r.exit_code == 0)
                heavy_names = "、".join(sorted({r.verifier for r in runs if r.exit_code == 0})) or "—"
                bus.publish_task(task.id, "log.appended", {
                    "level": "sched",
                    "message": f"集成校验通过：功能[{f.seq}] heavy 校验 {ok_n} 条全 exit=0（{heavy_names}）· 合并门禁③",
                })
            except Exception:
                pass



        from agentflow.core import services as services_mod

        try:
            _ui_on = services_mod.parse_ui_review(project.config) is not None
        except Exception:
            _ui_on = False
        err = services_mod.run_project_ui_review(session, settings, bus, task, project, repo_root)
        if err:
            return err
        if _ui_on:
            try:
                bus.publish_task(task.id, "log.appended", {
                    "level": "sched",
                    "message": "集成校验通过：UI 机审回归门 exit=0（合并 worktree 上真跑浏览器检查）",
                })
            except Exception:
                pass

        try:
            from agentflow.verifiers.probe import ui_coverage_summary

            cov = ui_coverage_summary(feats)
            if cov:
                bus.publish_task(task.id, "log.appended", {"level": "sched", "message": cov})
        except Exception:
            pass
        return None

    return resolver, validator


def resume_parent_after_subtasks(engine, gateway, bus, settings, parent_id: int, spawn_runner=None) -> None:
    """P1 SOS：子任务全部终态后恢复父任务（merger.on_merged 回调触发）。"""
    from agentflow.core.leases import grant_feature_leases

    with Session(engine) as s:
        parent = s.get(m.Task, parent_id)
        if parent is None or parent.status != m.TaskStatus.waiting_subtasks:
            return
        subs = s.exec(select(m.Task).where(m.Task.parent_task_id == parent_id)).all()
        if not subs:
            return


        pending = [
            t for t in subs
            if t.status not in m.MERGED_OK_STATUSES and t.status != m.TaskStatus.aborted
        ]
        if pending:
            bus.publish_task(parent_id, "log.appended", {
                "level": "sos",
                "message": f"子任务 #{pending[0].id} 等尚未终态（{pending[0].status.value}），父任务继续等待",
            })
            return

        proj = s.get(m.Project, parent.project_id)

        _ensure_subtask_notes(engine, gateway, bus, s, parent)

        try:
            repo = RepoHandle(proj.repo_path)

            base = settings.data.get("merge", {}).get("worktree_base_dir", "")
            from pathlib import Path as _P
            wt_root = _P(base) if base else (settings.home / "merge_worktrees")
            dev_wt = wt_root / f"dev-{parent_id}"
            wt_repo = repo.repo
            if dev_wt.exists():
                from git import Repo as _Repo

                wt_repo = _Repo(str(dev_wt))
            wt_repo.git.checkout(parent.branch)
            merge_out = wt_repo.git.merge("main", "--no-edit")
            bus.publish_task(parent_id, "log.appended", {"level": "sos", "message": f"父任务已合入 main（子任务产出）: {str(merge_out)[:200]}"})
        except Exception as e:
            parent.status = m.TaskStatus.paused_human
            s.add(parent)
            s.commit()
            bus.publish_task(parent_id, "task.updated", {"task_id": parent_id, "status": "paused_human"})
            bus.publish_task(parent_id, "human.required", {
                "reason": f"父任务恢复时合并 main 失败（子任务产出与父任务冲突？）: {e}",
                "options": ["人工修复后恢复", "回滚"],
            })
            return


        feats = s.exec(select(m.Feature).where(m.Feature.task_id == parent_id)).all()
        repo_root = _dev_root_for_task(settings, proj, parent_id)
        for f in feats:
            if f.status == m.FeatureStatus.blocked:
                f.status = m.FeatureStatus.verifying
                s.add(f)
                try:
                    grant_feature_leases(s, f, repo_root)
                except Exception:
                    pass
                bus.publish_task(parent_id, "feature.updated", _feature_payload(f, status="verifying"))
        parent.status = m.TaskStatus.running
        s.add(parent)
        s.commit()
        bus.publish_task(parent_id, "task.updated", {"task_id": parent_id, "status": "running"})
        bus.publish_task(parent_id, "log.appended", {"level": "sos", "message": "子任务全部终态，父任务恢复运行（重验拆分功能）"})


    if spawn_runner is not None:
        spawn_runner(parent_id)
    else:
        import asyncio as _a

        _TR = TaskRunner
        try:
            _a.get_event_loop().create_task(_TR(engine, gateway, bus, settings, parent_id).run())
        except RuntimeError:
            pass


def _ensure_subtask_notes(engine, gateway, bus, session, parent: m.Task) -> None:
    """上下文系统：为已终态子任务生成交接笔记（幂等，仅缺笔记时生成）。"""
    subs = session.exec(_select_subtasks(parent.id)).all()
    for sub in subs:

        if sub.status not in m.MERGED_OK_STATUSES and sub.status != m.TaskStatus.aborted:
            continue
        try:
            existing = session.exec(
                _select_note_kinds(sub.id, kind="note")
            ).all()
            if existing:
                continue
            work, files, verify_ev = _subtask_evidence(session, sub)
            content = _generate_note_text(gateway, sub, work, session)
            note = m.HandoffNote(
                task_id=sub.id,
                parent_task_id=parent.id,
                role="lead",
                kind="note",
                content=content,
                files=files,
                verify_evidence=verify_ev,
            )
            session.add(note)
            session.commit()
            bus.publish_task(parent.id, "log.appended", {
                "level": "ctx",
                "message": f"已生成交接笔记: 子任务 #{sub.id}「{sub.title}」（{content[:80]}…）",
            })
        except Exception:
            pass


def _select_subtasks(parent_id: int):
    from sqlmodel import select

    return select(m.Task).where(m.Task.parent_task_id == parent_id).order_by(m.Task.id)


def _select_note_kinds(task_id: int, kind: str):
    from sqlmodel import select

    return (
        select(m.HandoffNote)
        .where(m.HandoffNote.task_id == task_id, m.HandoffNote.kind == kind)
        .order_by(m.HandoffNote.id.desc())
    )


def _subtask_evidence(session, sub: m.Task) -> tuple[str, str, str]:
    """（工作摘要, files, verify_evidence）——全部来自 SQLite 事实源。"""
    nodes = session.exec(
        _select_sub_nodes(sub.id)
    ).all()
    work_parts = [f"[{n.kind}] {(n.summary or '')[:200]}" for n in nodes]
    feats = session.exec(
        _select_sub_feats(sub.id)
    ).all()
    globs: list[str] = []
    for f in feats:
        for g in (f.file_scope or "").split(","):
            g = g.strip()
            if g and g not in globs:
                globs.append(g)
    run = session.exec(
        _select_sub_verify(sub.id)
    ).first()
    verify_ev = f"`{(run.cmd or '')[:120]}` exit={run.exit_code}" if run else ""
    work = "\n".join(work_parts[:10]) or f"功能「{feats[0].title if feats else sub.title}」状态 {sub.status.value}"
    files = ",".join(globs)[:500]
    return work, files, verify_ev


def _select_sub_nodes(task_id: int):
    from sqlmodel import select

    return (
        select(m.Node)
        .where(m.Node.task_id == task_id, m.Node.status == m.NodeStatus.succeeded, m.Node.kind.in_(["edit", "fix", "think"]))
        .order_by(m.Node.id.desc())
    )


def _select_sub_feats(task_id: int):
    from sqlmodel import select

    return select(m.Feature).where(m.Feature.task_id == task_id).order_by(m.Feature.seq)


def _select_sub_verify(task_id: int):
    from sqlmodel import select

    return (
        select(m.VerifierRun)
        .where(m.VerifierRun.task_id == task_id, m.VerifierRun.exit_code == 0)
        .order_by(m.VerifierRun.id.desc())
    )


def _select_note_reports(feature_id: int):
    from sqlmodel import select

    return (
        select(m.HandoffNote)
        .where(m.HandoffNote.feature_id == feature_id, m.HandoffNote.kind == "report")
        .order_by(m.HandoffNote.id.desc())
    )


def _developer_failure_context(session: Session, feature_id: int) -> str:
    """developer 重派上下文（DB 取证，防重启丢内存态）：历次失败 VerifierRun + QA 归因。"""
    runs = session.exec(
        select(m.VerifierRun)
        .where(m.VerifierRun.feature_id == feature_id, m.VerifierRun.exit_code != 0)
        .order_by(m.VerifierRun.id.desc())
    ).all()[:3]
    parts = [_fmt_failed_run(r) for r in reversed(runs)]
    notes = session.exec(
        select(m.HandoffNote)
        .where(m.HandoffNote.feature_id == feature_id, m.HandoffNote.kind == "attribution")
        .order_by(m.HandoffNote.id.desc())
    ).all()[:2]
    parts += [f"--- QA 归因（历轮） ---\n{n.content[:1500]}" for n in reversed(notes)]
    foot = _latest_explore_note(session, feature_id)
    if foot:
        parts.append(f"--- 上一轮探索足迹（文件/命令/结论已探明，直接从这里继续，勿从头探索） ---\n{foot.content[:2500]}")
    return "\n\n".join(parts)


def _latest_explore_note(session: Session, feature_id: int) -> m.HandoffNote | None:
    """本功能最近一次探索足迹（HandoffNote.kind=explore，_persist_explore_footprint 落库）。"""
    return session.exec(
        select(m.HandoffNote)
        .where(m.HandoffNote.feature_id == feature_id, m.HandoffNote.kind == "explore")
        .order_by(m.HandoffNote.id.desc())
    ).first()


def _persist_explore_footprint(session: Session, node: m.Node) -> None:
    """developer/fixer 节点收尾：从 trace 提取探索足迹（读过/改过/跑过 + 末轮结论）落"""
    if node.role not in ("developer", "fixer") or not node.feature_id or not node.trace_uri:
        return
    try:
        rows = tr.read_trace(node.trace_uri)
    except Exception:
        return
    reads: list[str] = []
    edits: list[str] = []
    cmds: list[str] = []
    last_text = ""
    for r in rows:
        kind = r.get("kind")
        if kind == "tool_call":
            name, args = r.get("content"), r.get("args") or {}
            path = str(args.get("path") or "").strip()
            if name == "read_file" and path:
                reads.append(path)
            elif name in ("edit_file", "write_file") and path:
                edits.append(path)
            elif name == "run_cmd":
                cmds.append(str(args.get("cmd") or "")[:120])
        elif kind == "response" and (r.get("content") or "").strip():
            last_text = r["content"]

    def _dedupe(items: list[str]) -> list[str]:
        out: list[str] = []
        for x in items:
            if x not in out:
                out.append(x)
        return out

    reads, edits, cmds = _dedupe(reads), _dedupe(edits), _dedupe(cmds)
    if not (reads or edits or cmds):
        return
    turns = sum(1 for r in rows if r.get("kind") == "response")
    lines = [f"[探索足迹 · {node.role} · {turns} 轮]"]
    if reads:
        lines.append("已读文件: " + ", ".join(reads[:15]))
    if edits:
        lines.append("已改文件: " + ", ".join(edits[:15]))
    if cmds:
        lines.append("已跑命令: " + " | ".join(cmds[:8]))
    if last_text:
        lines.append("末轮结论: " + last_text[:400])
    try:
        session.add(
            m.HandoffNote(
                task_id=node.task_id,
                feature_id=node.feature_id,
                role=node.role,
                kind="explore",
                seq=0,
                content="\n".join(lines)[:3000],
            )
        )
        session.commit()
    except Exception:
        pass


def _persist_research_report(engine, task_id: int, feature_id: int | None, report: str, sos: bool) -> None:
    """上下文系统 ：researcher 报告落库（防重启丢失；重启续跑回读 HandoffNote）。"""
    text = (report or "").strip()
    if not text:
        return
    try:
        with Session(engine) as _s:
            _tt = _s.get(m.Task, task_id)
            _s.add(
                m.HandoffNote(
                    task_id=task_id,
                    feature_id=feature_id,
                    parent_task_id=_tt.parent_task_id if _tt else None,
                    role="researcher",
                    kind="research",
                    content=text[:6000],
                )
            )
            _s.commit()
    except Exception:
        pass


def latest_rework_instruction(session, task_id: int) -> str:
    """人审「重做」时用户填写的修复指令。"""
    from sqlmodel import select

    try:
        rows = session.exec(
            select(m.HandoffNote)
            .where(m.HandoffNote.task_id == task_id)
            .order_by(m.HandoffNote.id.desc())
        ).all()
    except Exception:
        return ""
    for r in rows:
        text = (r.content or "").strip()
        if not text:
            continue
        if (r.kind or "") == "rework" or "[用户重做指令]" in text:
            return text
    return ""


def _latest_task_research(session, task_id: int) -> tuple[str, str]:
    """任务级（feature_id 为空）最新 research 笔记 → (content, created_at)。无 → ("", "")。"""
    from sqlmodel import select

    try:
        rows = session.exec(
            select(m.HandoffNote)
            .where(
                m.HandoffNote.task_id == task_id,
                m.HandoffNote.kind == "research",
                m.HandoffNote.feature_id == None,
            )
            .order_by(m.HandoffNote.id.desc())
        ).all()
        if not rows:
            return "", ""
        return (rows[0].content or ""), (rows[0].created_at or "")
    except Exception:
        return "", ""


def _latest_research_note(session, task_id: int, feature_id: int | None = None) -> str:
    """重启续跑兜底：内存 research 报告丢失时回读 HandoffNote（优先本 feature，否则任务级最新）。"""
    from sqlmodel import select

    try:
        stmt = (
            select(m.HandoffNote)
            .where(m.HandoffNote.task_id == task_id, m.HandoffNote.kind == "research")
            .order_by(m.HandoffNote.id.desc())
        )
        rows = session.exec(stmt).all()
        if feature_id is not None:
            for r in rows:
                if r.feature_id == feature_id:
                    return r.content or ""
        return (rows[0].content or "") if rows else ""
    except Exception:
        return ""


def _latest_lead_diagnosis(session, task_id: int) -> str:
    """回读 diagnose 节点落的根因结论（handoffnote: role=lead, kind=diagnosis）。"""
    from sqlmodel import select

    try:
        stmt = (
            select(m.HandoffNote)
            .where(m.HandoffNote.task_id == task_id, m.HandoffNote.kind == "diagnosis")
            .order_by(m.HandoffNote.id.desc())
        )
        rows = session.exec(stmt).all()
        return (rows[0].content or "") if rows else ""
    except Exception:
        return ""


def _report_files(report: str) -> str:
    """从修复报告文本里抓文件路径（启发式：出现 ≥1 次 `/` 的 token）。"""
    files: list[str] = []
    for tok in re.findall(r"[\w./\\-]+/[\w./\\-]+", report or ""):
        tok = tok.strip().rstrip("。,;")
        if tok and tok not in files:
            files.append(tok)
        if len(files) >= 20:
            break
    return ",".join(files)[:500]


def _generate_note_text(gateway, sub: m.Task, work: str, session: Session | None = None) -> str:
    _merged = sub.status in m.MERGED_OK_STATUSES
    action = "已完成并合入" if _merged else "已中止（缺口未完成）"
    prompt = (
        f"## 子任务 #{sub.id}「{sub.title}」{action}\n\n"
        f"## 过程证据（代码收集）\n{work[:2500]}\n\n"
        "请写一段≤400字的交接笔记，供后续同族子任务/父任务参考。格式：\n"
        "做了什么（一句话）\n改了哪些方面/有什么结论\n风险与注意事项（若有）\n"
        "只依据上面证据，不要编造；禁止输出代码块。"
    )
    system = "你是交接笔记生成器：把证据压缩为给后续 agent 看的简明笔记，不新增事实判断。"
    try:
        result = gateway.generate("lead", prompt, system)
        if session is not None:
            from agentflow.core.llm_usage import record_extra

            record_extra(session, sub.id, "lead", "think", "handoff_note", result)
        text = (result.text or "").strip()
        if text:
            return text[:600]
    except Exception:
        pass
    action_text = "已完成并合入" if _merged else "已中止（存在完成缺口）"
    return f"子任务 {action_text}。过程摘要:\n{work[:400]}"


def _dev_root_for_task(settings, project: m.Project, task_id: int) -> Path:
    """P1 SOS：任务的开发根路径（worktree 或主路径；与 TaskRunner 内部规则一致）。"""
    use_wt = bool(settings.data.get("scheduler", {}).get("per_task_worktree", False))
    if not use_wt:
        return Path(project.repo_path)
    base = settings.data.get("merge", {}).get("worktree_base_dir", "")
    wt_root = Path(base) if base else (settings.home / "merge_worktrees")
    dev_wt = wt_root / f"dev-{task_id}"
    return dev_wt if dev_wt.exists() else Path(project.repo_path)


def _fmt_failed_run(r, limit: int = 1200) -> str:
    """失败运行的可读摘要——**必须带命令原文**。"""
    cmd = (getattr(r, "cmd", "") or "").strip()
    out = (getattr(r, "output_uri", "") or "").strip()
    body = f"命令: {cmd[:600]}\n" if cmd else ""
    body += f"输出: {out[:limit]}" if out else "输出: （空——该命令不打印内容，判定依据就是退出码）"
    return f"--- {getattr(r, 'verifier', '')} (exit {getattr(r, 'exit_code', '')}) ---\n{body}"


def _failure_context(runs: list[m.VerifierRun]) -> str:
    parts = []
    for r in runs[:3]:
        if r.exit_code != 0:
            parts.append(_fmt_failed_run(r))
    return "\n\n".join(parts)


def _history_evidence_block(session: Session, project_id: int, runs: list[m.VerifierRun]) -> str:
    """跨任务同指纹历史证据：有证据才返回文本块，无则空串。"""
    fps = [r.fingerprint for r in runs if r.fingerprint]
    if not fps:
        return ""
    from agentflow.core import evolution as _evo

    hist = _evo.match_history(session, project_id, fps)
    if not hist:
        return ""
    return _evo.format_history_evidence(hist)


def _failure_context_with_history(session: Session, project_id: int, runs: list[m.VerifierRun]) -> str:
    ctx = _failure_context(runs)
    hist = _history_evidence_block(session, project_id, runs)
    if hist:
        ctx += "\n\n## 历史同指纹证据（跨任务，代码聚类）\n" + hist
    return ctx


def _failure_fingerprint(runs: list[m.VerifierRun]) -> str:
    """B-3 白试指纹：失败命令 + 退出码 + 输出片段。相同指纹 = 失败条件没变（fixer 空转）。"""
    import hashlib

    parts = []
    for r in runs[:3]:
        if r.exit_code != 0:
            parts.append(f"{r.cmd}|{r.exit_code}|{(r.output_uri or '')[:200]}")
    if not parts:
        return ""
    return hashlib.sha1("\n".join(parts).encode("utf-8", "replace")).hexdigest()


def _feature_payload(f: m.Feature, status: str | None = None) -> dict:
    """feature.updated 事件负载：带 seq/title（前端事件卡/泳道头在运行中新功能也有标题可显示）。"""
    if status is not None:
        st = status
    elif isinstance(f.status, m.FeatureStatus):
        st = f.status.value
    else:
        st = str(f.status)
    return {"feature_id": f.id, "status": st, "seq": f.seq, "title": f.title}


def _node_payload(node: m.Node) -> dict:
    return {
        "node_id": node.id,
        "feature_id": node.feature_id,
        "status": node.status.value,
        "retries": node.retries,
        "duration_ms": node.duration_ms,
        "token_in": node.token_in,
        "token_out": node.token_out,
        "summary": node.summary,
        "kind": node.kind,
        "role": node.role or "",
        "seq": node.seq,
    }
