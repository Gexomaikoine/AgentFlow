"""demo 闭环：初始化 demo 项目 + 跑通 澄清→Spec→写→校验→绿点 全闭环（M1 出口标准）。"""

from __future__ import annotations

import asyncio
import json
import subprocess
import sys
from pathlib import Path

from agentflow.config import Settings
from agentflow.core.events_bus import EventBus
from agentflow.core.scheduler import TaskRunner
from agentflow.llm.gateway import LLMGateway
from agentflow.storage import models as m
from agentflow.storage.db import create_db_engine
from agentflow.storage.events_log import EventLog
from sqlmodel import Session, select

DEMO_DIR = Path(__file__).resolve().parents[3] / "demo"

FILES = {
    "pyproject.toml": (
        '[project]\nname = "demo-lib"\nversion = "0.1.0"\nrequires-python = ">=3.10"\n\n'
        "[tool.pytest.ini_options]\npythonpath = [\"src\"]\n"
    ),
    "src/demo_lib/__init__.py": "",
    "src/demo_lib/core.py": (
        "# demo 库：待实现的 add 函数\n\n"
        "def add(a, b):\n"
        "    raise NotImplementedError(\"add 尚未实现\")\n"
    ),
    "tests/test_core.py": (
        "from demo_lib.core import add\n\n\n"
        "def test_add():\n"
        "    assert add(2, 3) == 5\n\n\n"
        "def test_add_negative():\n"
        "    assert add(-1, 1) == 0\n"
    ),
}


def _git_repo_ok(d: Path) -> bool:
    """d 是否为自身独立的完好 git 仓库。"""
    import subprocess as sp

    if not (d / ".git").exists():
        return False
    r = sp.run(["git", "rev-parse", "--git-dir"], cwd=d, capture_output=True)
    if r.returncode != 0:
        return False
    gitdir = Path(r.stdout.decode(errors="replace").strip())
    if not gitdir.is_absolute():
        gitdir = (d / gitdir).resolve()
    return gitdir == (d / ".git").resolve()


def _rmtree_force(p: Path) -> None:
    """Windows 下 .git 内只读 pack 文件会让 rmtree 中断残留（正是空 .git 的成因），强制清。"""
    import os
    import shutil
    import stat as st

    def _onerr(fn, path, _exc):
        try:
            os.chmod(path, st.S_IWRITE)
            fn(path)
        except OSError:
            pass

    shutil.rmtree(p, onerror=_onerr)


def init_demo_project() -> Path:
    """初始化 demo 项目（幂等）：建文件 + git init + 初始 commit。"""

    if DEMO_DIR.exists():
        if _git_repo_ok(DEMO_DIR):
            r = subprocess.run(["git", "branch"], cwd=DEMO_DIR, capture_output=True, text=True)
            for line in (r.stdout or "").splitlines():
                b = line.strip().lstrip("* ").strip()
                if b.startswith("task/") or b == "dev":
                    subprocess.run(["git", "branch", "-D", b], cwd=DEMO_DIR, capture_output=True)
            subprocess.run(["git", "checkout", "main"], cwd=DEMO_DIR, capture_output=True)
            subprocess.run(["git", "reset", "--hard", "HEAD"], cwd=DEMO_DIR, capture_output=True)
            core = DEMO_DIR / "src/demo_lib/core.py"
            if not core.exists() or "NotImplementedError" not in core.read_text(encoding="utf-8"):
                _rmtree_force(DEMO_DIR)
        else:
            _rmtree_force(DEMO_DIR)

    DEMO_DIR.mkdir(parents=True, exist_ok=True)
    for rel, content in FILES.items():
        p = DEMO_DIR / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        if not p.exists():
            p.write_text(content, encoding="utf-8")

    if not _git_repo_ok(DEMO_DIR):
        subprocess.run(["git", "init", "-b", "main"], cwd=DEMO_DIR, check=True, capture_output=True)
        subprocess.run(["git", "add", "-A"], cwd=DEMO_DIR, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "demo 初始（stub）"], cwd=DEMO_DIR, check=True, capture_output=True)
    return DEMO_DIR


def run_demo() -> dict:
    settings = Settings.load()
    engine = create_db_engine(settings)
    demo_dir = init_demo_project()

    with Session(engine) as s:
        proj = s.exec(select(m.Project).where(m.Project.name == "demo")).first()
        if not proj:
            from agentflow.projects.registry import register_project

            proj = register_project(s, "demo", str(demo_dir))

        from agentflow.projects.invariant_tpl import suggest_invariants
        from agentflow.verifiers.builtin import suggest_commands

        stack = json.loads(proj.stack)
        cfg = json.loads(proj.config) if proj.config else {}
        cfg["verifiers"] = suggest_commands(json.dumps(stack))
        proj.config = json.dumps(cfg, ensure_ascii=False)
        for text in suggest_invariants(stack):
            if not s.query(m.Invariant).filter(m.Invariant.project_id == proj.id, m.Invariant.text == text).first():
                s.add(m.Invariant(project_id=proj.id, layer=m.InvariantLayer.template, text=text))
        s.add(proj)
        s.commit()
        project_id = proj.id


    with Session(engine) as s:
        t = m.Task(project_id=project_id, title="实现 add 函数并通过测试", raw_request="给 demo_lib.core 实现 add 函数并让测试通过")
        s.add(t)
        s.commit()
        task_id = t.id

    gateway = LLMGateway(settings)
    bus = EventBus(EventLog(settings))


    from agentflow.agents.lead import clarify_round, generate_spec

    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        t.status = m.TaskStatus.clarifying
        s.commit()
        clarify_round(gateway, s, t, "实现即可，保持简单")
        proj = s.get(m.Project, project_id)
        generate_spec(gateway, s, t, proj)
        t.status = m.TaskStatus.spec_pending
        spec = s.exec(select(m.Spec).where(m.Spec.task_id == task_id).order_by(m.Spec.id.desc())).first()
        spec.confirmed_at = _now()
        s.add(spec)
        s.add(t)
        s.commit()


    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        t.status = m.TaskStatus.running
        s.commit()
    runner = TaskRunner(engine, gateway, bus, settings, task_id)
    asyncio.run(runner.run())


    result = _assert(task_id, engine, demo_dir)
    return {"task_id": task_id, **result}


def _assert(task_id: int, engine, demo_dir: Path) -> dict:
    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        anchors = s.exec(select(m.GreenAnchor).where(m.GreenAnchor.task_id == task_id)).all()
        feats = s.exec(select(m.Feature).where(m.Feature.task_id == task_id)).all()

    core = demo_dir / "src/demo_lib/core.py"
    implemented = core.exists() and "NotImplementedError" not in core.read_text(encoding="utf-8")
    test_ok = _pytest_ok(demo_dir)

    ok = (
        t.status == m.TaskStatus.done
        and bool(anchors)
        and implemented
        and test_ok
        and all(f.status == m.FeatureStatus.passed for f in feats)
    )
    print("=" * 56)
    print("demo 闭环断言")
    print(f"  任务状态: {t.status.value} (期望 done)")
    print(f"  绿点数:   {len(anchors)} (期望 ≥1)")
    print(f"  add 已实现: {implemented}")
    print(f"  pytest 通过: {test_ok}")
    print(f"  功能状态: {[f.status.value for f in feats]}")
    print(f"  结果: {'通过 ✅' if ok else '失败 ❌'}")
    print("=" * 56)
    if not ok:
        sys.exit(1)
    return {
        "task_status": t.status.value,
        "anchors": len(anchors),
        "implemented": implemented,
        "pytest_ok": test_ok,
    }


def _pytest_ok(demo_dir: Path) -> bool:
    try:
        r = subprocess.run(
            [sys.executable, "-m", "pytest", "tests/", "-q"],
            cwd=demo_dir,
            capture_output=True,
            text=True,
            timeout=120,
        )
        return r.returncode == 0
    except Exception:
        return False


def _now() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()
