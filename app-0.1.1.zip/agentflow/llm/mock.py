"""MockLLM：脚本化 + 内置模板的确定性 LLM（开发期/测试用，DECISIONS ）。"""

from __future__ import annotations

import json
import re
import textwrap
from pathlib import Path
from typing import Optional

from agentflow.config import Settings
from agentflow.llm.gateway import LLMResult


DEFAULT_TEMPLATES: dict = {
    "implementations": {
        "add": "def add(a, b):\n    return a + b\n",
        "multiply": "def multiply(a, b):\n    return a * b\n",
        "subtract": "def subtract(a, b):\n    return a - b\n",
        "inc": "def inc(x):\n    return x + 1\n",
    }
}

_FUNC_RE = re.compile(r"[：:，,]?\s*(?:实现|implement|write|add)?\s*[:：]?\s*(\w+)\s*(?:函数|方法|function|method)?", re.I)


class MockLLM:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._scripts: dict[str, list[dict]] = {}
        self._templates = self._load_templates()


    def _load_templates(self) -> dict:
        tpl = json.loads(json.dumps(DEFAULT_TEMPLATES))
        user_file = self.settings.home / "mock_templates.json"
        if user_file.exists():
            try:
                tpl.update(json.loads(user_file.read_text(encoding="utf-8")))
            except (json.JSONDecodeError, OSError):
                pass
        return tpl

    def _load_scripts(self, role: str) -> list[dict]:
        if role in self._scripts:
            return self._scripts[role]
        out: list[dict] = []

        for base in (self.settings.home / "mock_scripts", Path(__file__).parent / "mock_scripts"):
            p = base / f"{role}.jsonl"
            if p.exists():
                for line in p.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        out.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        self._scripts[role] = out
        return out


    def generate(self, role: str, prompt: str = "", system: Optional[str] = None, tools: Optional[list] = None, messages: Optional[list] = None, images: Optional[list] = None) -> LLMResult:

        if messages and not prompt:
            prompt = self._messages_to_prompt(messages)
            if not system:
                system = next((m.get("content") for m in messages if m.get("role") == "system"), None)

        if images:
            prompt = prompt + f"\n[附图 x{len(images)}]"
        text = self._dispatch(role, prompt, system or "")

        tok = max(1, int(len(text) * 0.6))
        return LLMResult(text=text, tokens_in=max(1, int(len(prompt) * 0.6)), tokens_out=tok)

    def _dispatch(self, role: str, prompt: str, system: str) -> str:
        for rule in self._load_scripts(role):
            match = rule.get("match")
            if match and match in prompt:
                return rule.get("response", "")
        handlers = {
            "planner": self._as_planner,
            "lead": self._as_planner,
            "developer": self._as_developer,
            "fixer": self._as_developer,
            "verifier": self._as_verifier,
            "qa": self._as_verifier,
        }
        fn = handlers.get(role, self._as_default)
        return fn(prompt, system)


    def _messages_to_prompt(self, messages: list) -> str:
        """把多轮消息数组拼回文本 prompt（mock 脚本匹配用）。"""
        parts: list[str] = []
        for m in messages:
            r = m.get("role")
            c = m.get("content")
            if isinstance(c, list):

                _texts = [p.get("text", "") for p in c if isinstance(p, dict) and p.get("type") == "text"]
                _imgs = sum(1 for p in c if isinstance(p, dict) and p.get("type") == "image_url")
                c = "\n".join(_texts) + (f"\n[附图 x{_imgs}]" if _imgs else "")
            c = c or ""
            if r == "user" and not parts:
                parts.append(c)
            elif r == "user":
                parts.append(f"[user]\n{c}")
            elif r == "assistant":
                tcs = m.get("tool_calls") or []
                names = ",".join(tc.get("function", {}).get("name", "") for tc in tcs if isinstance(tc, dict))
                parts.append(f"[assistant]\n{c}" + (f"\n[tool_calls: {names}]" if names else ""))
            elif r == "tool":
                parts.append(f"[tool {m.get('tool_call_id', '')}]\n{c}")
        return "\n\n".join(parts)


    def _as_default(self, prompt: str, system: str) -> str:
        return "<tool_call>\n{\"name\": \"done\", \"args\": {}}\n</tool_call>"

    def _as_planner(self, prompt: str, system: str) -> str:
        title = self._extract_title(prompt)

        scope, verify, rel = self._probe_project(prompt + "\n" + system)
        req = self._extract_request(prompt)
        feature_title = self._extract_feature_title(req) or title or "实现需求功能"
        lines = [
            "title: " + (title or "新任务"),
            "features:",
            f"  - seq: 1",
            f"    title: \"{feature_title}\"",
            "    file_scope:",
            *[f"      - \"{g}\"" for g in scope],
            "    verify_commands:",
            *[f"      - verifier: {v}\n        cmd: \"{c}\"\n        timeout: {t}\n        classification_hint: {cl}" for v, c, t, cl in verify],
            "    depends_on: []",
            "    related_files:",
            *[f"      - \"{r}\"" for r in rel],
            "invariants: []",
            "budget:",
            "  max_retries: 3",
            "  feature_timeout_s: 600",
            "  task_max_tokens: 500000",
            "  task_max_cost_usd: 5.0",
        ]
        yaml_text = "\n".join(lines)
        return (
            f"我已经理解需求，产出如下 Spec 草稿：\n\n"
            f"```yaml\n{yaml_text}\n```\n\n"
            f"<tool_call>\n{{\"name\": \"done\", \"args\": {{}}}}\n</tool_call>"
        )

    def _as_developer(self, prompt: str, system: str) -> str:
        target = self._extract_target_file(prompt)
        func_name = self._extract_func_name(prompt)
        content = self._implementation(func_name)
        if not target or "[tool " in prompt:

            if "[tool " in prompt:
                report = (
                    "[DEV_REPORT]\n"
                    "做了什么: 实现 " + (func_name or "目标函数") + "\n"
                    "改动文件: 见上一轮 write_file\n"
                    "测试: mock 跳过\n"
                    "[/DEV_REPORT]\n"
                )
                return report + "<tool_call>\n{\"name\": \"done\", \"args\": {}}\n</tool_call>"
        call = json.dumps({"name": "write_file", "args": {"path": target, "content": content}}, ensure_ascii=False)
        return f"<tool_call>\n{call}\n</tool_call>"

    def _as_verifier(self, prompt: str, system: str) -> str:
        return (
            "失败归因（mock）：校验器未通过。建议检查目标文件实现是否符合预期签名，"
            "补全边界情况后重试。已尝试方案请勿重复。"
        )


    def _extract_title(self, prompt: str) -> str:
        m = re.search(r"任务标题[:：]\s*(.+)", prompt)
        return m.group(1).strip() if m else ""

    def _extract_request(self, prompt: str) -> str:
        m = re.search(r"原始需求[:：]\s*(.+)", prompt)
        return m.group(1).strip() if m else ""

    def _extract_feature_title(self, req: str) -> str:

        req = req.strip()
        if not req:
            return "实现需求功能"
        req = req.strip("。，！？")
        return req[:30]

    def _probe_project(self, system: str) -> tuple[list[str], list[tuple], list[str]]:
        """根据 system 或 prompt 里的项目路径探测技术栈，产出 file_scope / verify / related_files。"""
        m = re.search(r"(?:PROJECT_PATH|项目路径)[:：]\s*(\S+)", system)
        root = Path(m.group(1)) if m else Path.cwd()
        py_files = sorted(str(p.relative_to(root)).replace("\\", "/") for p in root.rglob("*.py") if "test" not in p.name.lower())
        has_py = bool(py_files)
        has_pkg = (root / "package.json").exists()
        has_src = (root / "src").is_dir()

        if has_py:
            scope = ["src/**"] if has_src else [str((Path(py_files[0]).parent)).replace("\\", "/") + "/**" if py_files else "**/*.py"]
            verify = [("pytest", "python -m pytest tests/ -q", 120, "blocking")]
        elif has_pkg:
            scope = ["src/**"] if has_src else ["**/*.{ts,tsx,js,jsx}"]
            verify = [("build", "npm run build", 180, "blocking")]
        else:
            scope = ["**/*"]
            verify = [("noop", "python -c \"print('ok')\"", 30, "blocking")]
        rel = sorted(py_files, key=lambda p: (p.endswith("__init__.py"), p))[:10] if py_files else []
        return scope, verify, rel

    def _extract_target_file(self, prompt: str) -> str:
        m = re.search(r"TARGET_FILE[:：]\s*(\S+)", prompt)
        return m.group(1).strip() if m else ""

    def _extract_func_name(self, prompt: str) -> str:
        m = re.search(r"目标函数[:：]\s*(\w+)", prompt)
        if m:
            return m.group(1)
        m2 = re.search(r"(?:实现|implement)\s*[:：]?\s*(\w+)\s*(?:函数|方法|function|method)", prompt)
        if m2:
            return m2.group(1)

        m3 = re.search(r"- \[\d+\] (?:实现|implement)?\s*[:：]?\s*(\w+)\s*(?:函数|方法|function|method)?", prompt)
        return m3.group(1) if m3 else ""

    def _implementation(self, func_name: str) -> str:
        impls = self._templates.get("implementations", {})
        if func_name in impls:
            return textwrap.dedent(impls[func_name]).strip() + "\n"
        if func_name:
            return f"def {func_name}(*args, **kwargs):\n    return args[0] if args else None\n"
        return "pass\n"
