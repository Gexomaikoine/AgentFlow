"""项目 routes（FR0）。"""

from __future__ import annotations

import fnmatch
import json
import re
from pathlib import Path

from agentflow.api.auth import require_auth
from agentflow.git_runtime.repo import RepoHandle
from agentflow.projects.invariant_tpl import suggest_invariants
from agentflow.projects.registry import register_project, update_project_config
from agentflow.storage import models as m
from agentflow.verifiers.builtin import suggest_commands
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlmodel import select

router = APIRouter(tags=["projects"])


class ProjectIn(BaseModel):
    name: str
    repo_path: str


class WizardConfirm(BaseModel):
    verifiers: list[dict] = []
    invariants: list[str] = []


class RuleIn(BaseModel):
    title: str = ""
    content: str = ""
    enabled: bool = True



@router.get("/projects/{pid}/rules")
def list_rules(pid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        if not s.get(m.Project, pid):
            raise HTTPException(404, "project not found")
        rows = s.exec(
            select(m.ProjectRule).where(m.ProjectRule.project_id == pid).order_by(m.ProjectRule.sort_order, m.ProjectRule.id)
        ).all()
        return [_rule_dto(r) for r in rows]


@router.post("/projects/{pid}/rules")
def create_rule(pid: int, body: RuleIn, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        if not s.get(m.Project, pid):
            raise HTTPException(404, "project not found")
        max_order = s.exec(
            select(m.ProjectRule.sort_order).where(m.ProjectRule.project_id == pid).order_by(m.ProjectRule.sort_order.desc())
        ).first()
        rule = m.ProjectRule(
            project_id=pid,
            title=body.title.strip()[:60],
            content=body.content.strip()[:2000],
            enabled=body.enabled,
            sort_order=(max_order or 0) + 1,
        )
        s.add(rule)
        s.commit()
        return _rule_dto(rule)


@router.put("/projects/{pid}/rules/{rid}")
def update_rule(pid: int, rid: int, body: RuleIn, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        rule = s.get(m.ProjectRule, rid)
        if not rule or rule.project_id != pid:
            raise HTTPException(404, "rule not found")
        rule.title = body.title.strip()[:60]
        rule.content = body.content.strip()[:2000]
        rule.enabled = body.enabled
        s.add(rule)
        s.commit()
        return _rule_dto(rule)


@router.delete("/projects/{pid}/rules/{rid}")
def delete_rule(pid: int, rid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        rule = s.get(m.ProjectRule, rid)
        if not rule or rule.project_id != pid:
            raise HTTPException(404, "rule not found")
        s.delete(rule)
        s.commit()
        return {"ok": True}



@router.get("/projects/{pid}/git-log")
def git_log(pid: int, request: Request, limit: int = 100, _: str = Depends(require_auth)):
    """项目 git 树（分支装饰 + 提交历史 + 远端领先/落后）。只读。"""
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        proj = s.get(m.Project, pid)
        if not proj:
            raise HTTPException(404, "project not found")
    try:
        from agentflow.git_runtime.repo import RepoHandle

        repo = RepoHandle(proj.repo_path)
        cur = repo.current_branch()

        branches = [b.name for b in repo.repo.branches]

        raw = repo.repo.git.log(
            "--all", f"--max-count={int(limit)}", "--date=short",
            "--pretty=format:%H|%an|%ad|%s|%D",
        )
        commits = []
        for line in raw.splitlines():
            parts = line.split("|", 4)
            if len(parts) != 5:
                continue
            h, author, date, msg, refs = parts
            commits.append({
                "hash": h,
                "short": h[:8],
                "author": author,
                "date": date,
                "message": msg,
                "refs": [r.strip() for r in refs.split(",") if r.strip() and r.strip() != "HEAD"],
            })

        remote = None
        unpushed = 0
        unpushed_files: list[dict] = []
        if repo.repo.remotes:
            remote = repo.repo.remotes[0].name
            rng = f"{remote}/{cur}..{cur}"
            try:
                out = repo.repo.git.rev_list("--count", rng).strip()
                unpushed = int(out or "0")
            except Exception:
                unpushed = 0

            if unpushed > 0:
                try:
                    counts: dict[str, tuple[int, int]] = {}
                    for line in repo.repo.git.diff(rng, "--numstat").splitlines():
                        add, dele, p = line.split("\t", 2)
                        counts[p] = ("-" if add == "-" else int(add), "-" if dele == "-" else int(dele))
                    for line in repo.repo.git.diff(rng, "--name-status").splitlines():
                        parts = line.split("\t")
                        st, p = parts[0], parts[-1]
                        add, dele = counts.get(p, (None, None))
                        unpushed_files.append({"path": p, "status": st, "additions": add, "deletions": dele})
                except Exception:
                    unpushed_files = []
        return {
            "current_branch": cur,
            "branches": branches,
            "commits": commits,
            "remote": remote,
            "unpushed": unpushed,
            "unpushed_files": unpushed_files,
        }
    except Exception as e:
        raise HTTPException(400, f"git 读取失败: {e}")




_GIT_IGNORE_GLOBS = [
    "__pycache__/*", "*.pyc", "node_modules/*", "dist/*", "build/*", ".next/*",
    "coverage/*", ".venv/*", "venv/*", "*.log", "*.tmp", "*.bak", "*.orig",
    "*.swp", ".DS_Store", "Thumbs.db", "*.local", "tmp_*", "*.pid",
    "data/output/*", "data/images/*",
]


_SECRET_RE = re.compile(r"(^|/)(\.env(\..*)?|.*\.pem|.*\.key|.*\.pfx|.*\.p12|id_rsa.*|.*secret.*|.*credential.*|.*password.*|secrets\.(py|json|ya?ml|toml))$", re.I)


def _is_secret_path(path: str) -> bool:
    """路径是否命中密钥/凭据形态（提交建议与 diff 展示共用同一套规则）。"""
    name = path.rsplit("/", 1)[-1]
    return bool(_SECRET_RE.match(path) or _SECRET_RE.match(name))


def _classify_git_entry(path: str, tracked: bool) -> tuple[str, str]:
    """单文件提交建议：(suggestion, reason)。suggestion ∈ commit/ignore/review。"""
    name = path.rsplit("/", 1)[-1]
    if _is_secret_path(path):
        return "ignore", "疑似密钥/凭据文件，禁止入库（Key 只落 ~/.agentflow/.env 或本地）"
    if any(fnmatch.fnmatch(path, g) or fnmatch.fnmatch(name, g) for g in _GIT_IGNORE_GLOBS):
        return "ignore", "产物/临时文件，建议加入 .gitignore 而非提交"
    if not tracked:
        return "review", "新文件，请确认是否纳入版本管理"
    return "commit", "已跟踪文件的改动"



_MAX_NEW_FILE_PATCH_BYTES = 200_000


def _synth_untracked_patch(repo: RepoHandle, path: str) -> tuple[str, bool]:
    """为未跟踪文件合成「新增文件」patch（只读，不 add、不动索引）。"""
    root = Path(repo.repo.working_tree_dir or repo.repo_path)
    raw_fp = root / path
    if raw_fp.is_symlink():
        return "", False
    fp = raw_fp.resolve()
    try:
        fp.relative_to(root.resolve())
    except ValueError:
        return "", False
    if not fp.is_file():
        return "", False
    try:
        raw = fp.read_bytes()
    except OSError:
        return "", False
    if b"\x00" in raw[:8192]:
        return "", False
    truncated = len(raw) > _MAX_NEW_FILE_PATCH_BYTES
    text = raw[:_MAX_NEW_FILE_PATCH_BYTES].decode("utf-8", errors="replace")
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    if not lines:
        return "", False
    body = "\n".join("+" + ln for ln in lines)
    patch = (
        f"diff --git a/{path} b/{path}\n"
        "new file mode 100644\n"
        "--- /dev/null\n"
        f"+++ b/{path}\n"
        f"@@ -0,0 +1,{len(lines)} @@\n"
        f"{body}\n"
    )
    if truncated:
        patch += "…（文件过大，patch 已截断）\n"
    return patch, truncated


def _worktree_patch(repo: RepoHandle, path: str) -> tuple[str, bool]:
    """工作区 vs HEAD 的单文件 patch（提交页展示 + 拟定提交信息共用）。"""
    out = repo.repo.git.diff("HEAD", "--", path)
    if out or _is_secret_path(path):
        return out, False
    return _synth_untracked_patch(repo, path)


@router.get("/projects/{pid}/git-status")
def git_status(pid: int, request: Request, _: str = Depends(require_auth)):
    """未提交变更清单（工作区+暂存区），带逐文件提交建议与增删行数。只读。"""
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        proj = s.get(m.Project, pid)
        if not proj:
            raise HTTPException(404, "project not found")
    try:
        repo = RepoHandle(proj.repo_path)


        raw = repo.repo.git.status("--porcelain", "--untracked-files=all")
        tracked_files = set(
            repo.repo.git.ls_files().splitlines()
        )
        numstat: dict[str, tuple[int, int]] = {}
        try:
            for line in repo.repo.git.diff("HEAD", "--numstat").splitlines():
                add, dele, p = line.split("\t", 2)
                numstat[p] = ("-" if add == "-" else int(add), "-" if dele == "-" else int(dele))
        except Exception:
            pass
        entries = []
        for line in raw.splitlines():
            if not line.strip():
                continue
            xy, path = line[:2], line[3:]
            if " -> " in path:
                path = path.split(" -> ", 1)[1]
            tracked = path in tracked_files
            add, dele = numstat.get(path, (None, None))
            suggestion, reason = _classify_git_entry(path, tracked)
            entries.append({
                "path": path,
                "index_status": xy[0].strip() or "-",
                "work_status": xy[1].strip() or "-",
                "tracked": tracked,
                "additions": add,
                "deletions": dele,
                "suggestion": suggestion,
                "reason": reason,
            })
        entries.sort(key=lambda e: ({"commit": 0, "review": 1, "ignore": 2}[e["suggestion"]], e["path"]))
        return {"entries": entries}
    except Exception as e:
        raise HTTPException(400, f"git status 读取失败: {e}")


class GitCommitIn(BaseModel):
    files: list[str]
    message: str


@router.post("/projects/{pid}/git-commit")
def git_commit(pid: int, request: Request, body: GitCommitIn, _: str = Depends(require_auth)):
    """手动提交：按用户勾选的显式文件清单 add + commit。"""
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        proj = s.get(m.Project, pid)
        if not proj:
            raise HTTPException(404, "project not found")
    files = list(dict.fromkeys(f.strip() for f in body.files if f.strip()))
    if not files:
        raise HTTPException(400, "未选择任何文件")
    message = body.message.strip()
    if not message:
        raise HTTPException(400, "提交信息不能为空")
    for f in files:
        if f.startswith("/") or ".." in f.split("/") or "\\" in f or f.startswith("-"):
            raise HTTPException(400, f"非法路径: {f}")
    try:
        repo = RepoHandle(proj.repo_path)
        repo.repo.git.add("--", *files)
        out = repo.repo.git.commit("-m", message[:500])
        sha = repo.repo.head.commit.hexsha
        return {
            "ok": True,
            "short": sha[:8],
            "branch": repo.current_branch(),
            "message": message[:500],
            "detail": out.splitlines()[0] if out else "",
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, f"commit 失败: {e}")


class GitSummarizeIn(BaseModel):
    files: list[str]


@router.post("/projects/{pid}/git-commit-message")
def git_commit_message(pid: int, request: Request, body: GitSummarizeIn, _: str = Depends(require_auth)):
    """AI 拟定提交信息：汇总勾选文件的工作区 diff，交给 lead 模型生成中文提交文案。"""
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        proj = s.get(m.Project, pid)
        if not proj:
            raise HTTPException(404, "project not found")
    files = list(dict.fromkeys(f.strip() for f in body.files if f.strip()))
    if not files:
        raise HTTPException(400, "未选择任何文件")
    for f in files:
        if f.startswith("/") or ".." in f.split("/") or "\\" in f or f.startswith("-"):
            raise HTTPException(400, f"非法路径: {f}")
    try:
        repo = RepoHandle(proj.repo_path)
        per_file_cap = 15_000
        parts: list[str] = []
        for f in files:
            if _is_secret_path(f):
                parts.append(f"### {f}\n（疑似密钥/凭据文件，内容不展示）")
                continue

            d, _ = _worktree_patch(repo, f)
            if len(d) > per_file_cap:
                d = d[:per_file_cap] + "\n…（该文件 diff 过长已截断）"
            parts.append(f"### {f}\n{d or '（无文本差异）'}")
        bundle = "\n\n".join(parts)
        if len(bundle) > 80_000:
            bundle = bundle[:80_000] + "\n…（总 diff 过长已截断）"
        result = af.gateway.generate(
            role="lead",
            system=(
                "你是 git 提交信息助手。根据用户给出的 git diff，拟定中文提交信息："
                "第一行为一句话综合概述，随后 2~5 行以「- 」开头的要点列出具体改动。"
                "只输出提交信息本身，不要任何解释、前缀或 markdown 代码块。不超过 400 字。"
            ),
            prompt=f"请为以下改动拟定提交信息（共 {len(files)} 个文件）：\n\n{bundle}",
        )
        msg = result.text.strip().strip("`").strip()
        if msg.lower().startswith("```"):
            msg = "\n".join(msg.splitlines()[1:])
        msg = msg.strip().strip('"').strip()
        if not msg:
            raise HTTPException(400, "模型返回空文案，请手写提交信息")
        return {"ok": True, "message": msg[:500], "files": len(files)}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, f"拟定提交信息失败: {e}")


@router.get("/projects/{pid}/git-diff")
def git_diff(pid: int, request: Request, path: str, base: str = "HEAD", _: str = Depends(require_auth)):
    """单文件 diff：base=HEAD → 工作区 vs HEAD（提交页）；base=<ref> → ref..HEAD 已提交区间（推送页）。"""
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        proj = s.get(m.Project, pid)
        if not proj:
            raise HTTPException(404, "project not found")
    if not path or path.startswith("/") or ".." in path.split("/") or "\\" in path or path.startswith("-"):
        raise HTTPException(400, f"非法路径: {path[:80]}")
    if base != "HEAD" and (not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_/.-]*", base) or ".." in base):
        raise HTTPException(400, f"非法 ref: {base[:80]}")
    if base == "HEAD" and _is_secret_path(path):
        raise HTTPException(400, "疑似密钥/凭据文件，不提供 diff 内容")
    try:
        repo = RepoHandle(proj.repo_path)
        if base == "HEAD":
            out, truncated = _worktree_patch(repo, path)
        else:
            out = repo.repo.git.diff(f"{base}..HEAD", "--", path)
            truncated = False
        if len(out) > 200_000:
            out = out[:200_000] + "\n…（diff 过长已截断）"
            truncated = True
        return {"path": path, "base": base, "diff": out, "truncated": truncated}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, f"diff 读取失败: {e}")


@router.get("/projects/{pid}/git-transport")
def get_git_transport(pid: int, request: Request, _: str = Depends(require_auth)):
    """当前项目的远端传输策略与候选通道（设置→Git 页签展示/测试用）。"""
    af = request.app.state.af
    from agentflow.git_runtime import transport as tp
    from sqlmodel import Session

    with Session(af.engine) as s:
        proj = s.get(m.Project, pid)
        if not proj:
            raise HTTPException(404, "project not found")
    repo = RepoHandle(proj.repo_path)
    remote_name = repo.repo.remotes[0].name if repo.repo.remotes else ""
    remote_url = repo.repo.remotes[0].url if repo.repo.remotes else ""
    git_cfg = dict(af.settings.data.get("git") or {})
    return {
        "git": git_cfg,
        "remote": remote_name,
        "remote_url": remote_url,
        "candidates": tp.candidates(remote_url, git_cfg) if remote_url else [],
    }


@router.post("/projects/{pid}/git-transport/test")
def test_git_transport(pid: int, request: Request, _: str = Depends(require_auth)):
    """连通性自检：对每个候选通道跑只读 `git ls-remote`（不推送）。"""
    af = request.app.state.af
    from agentflow.git_runtime import transport as tp
    from sqlmodel import Session

    with Session(af.engine) as s:
        proj = s.get(m.Project, pid)
        if not proj:
            raise HTTPException(404, "project not found")
    repo = RepoHandle(proj.repo_path)
    if not repo.repo.remotes:
        raise HTTPException(400, "项目无远端 remote")
    remote_url = repo.repo.remotes[0].url
    return tp.test(proj.repo_path, remote_url, af.settings.data.get("git") or {})


def _mark_project_tasks_pushed(af, pid: int, branch: str) -> int:
    """推送成功后把该项目「待推送」的任务转「已推送」（人审通过 + 推送成功 = 终态）。"""
    if branch not in ("main", "master"):
        return 0
    from sqlmodel import Session

    with Session(af.engine) as s:
        rows = s.exec(
            select(m.Task).where(m.Task.project_id == pid, m.Task.status == m.TaskStatus.pending_push)
        ).all()
        ids = [int(t.id) for t in rows]
        for t in rows:
            t.status = m.TaskStatus.pushed
            s.add(t)
        s.commit()
    for tid in ids:
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "pushed"})
        af.bus.publish_task(tid, "log.appended", {
            "level": "human", "message": "已推送：main 已到远端，任务转入「已推送」终态",
        })
    return len(ids)


@router.post("/projects/{pid}/git-push")
def git_push(pid: int, request: Request, _: str = Depends(require_auth)):
    """推送当前分支到远端：按设置→Git 的传输策略（协议/优先顺序/代理）逐个通道尝试。"""
    af = request.app.state.af
    from agentflow.git_runtime import transport as tp
    from sqlmodel import Session

    with Session(af.engine) as s:
        proj = s.get(m.Project, pid)
        if not proj:
            raise HTTPException(404, "project not found")
    repo = RepoHandle(proj.repo_path)
    if not repo.repo.remotes:
        raise HTTPException(400, "项目无远端 remote，无法 push")
    remote_name = repo.repo.remotes[0].name
    remote_url = repo.repo.remotes[0].url
    cur = repo.current_branch()
    result = tp.push(proj.repo_path, cur, remote_url, af.settings.data.get("git") or {},
                     remote_name=remote_name)
    if not result.get("ok"):
        detail = "；".join(
            f"{t['scheme']}: {t.get('error') or '失败'}" for t in (result.get("tries") or [])
        )[:600]
        raise HTTPException(400, f"push 失败（已尝试 {len(result.get('tries') or [])} 个通道）: {detail}")
    return {"ok": True, "branch": cur, "used": result.get("used"), "url": result.get("url"),
            "tries": result.get("tries"), "tasks_pushed": _mark_project_tasks_pushed(af, pid, cur)}


def _rule_dto(r: m.ProjectRule) -> dict:
    return {
        "id": r.id,
        "project_id": r.project_id,
        "title": r.title,
        "content": r.content,
        "enabled": r.enabled,
        "sort_order": r.sort_order,
        "created_at": r.created_at,
    }


@router.post("/projects")
def create_project(body: ProjectIn, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        try:
            proj = register_project(s, body.name, body.repo_path)
            return {"id": proj.id, "name": proj.name, "repo_path": proj.repo_path, "stack": json.loads(proj.stack)}
        except Exception as e:
            raise HTTPException(400, str(e))


@router.get("/projects")
def list_projects(request: Request, archived: int = 0, _: str = Depends(require_auth)):
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        q = select(m.Project)
        q = q.where(m.Project.archived_at.is_not(None)) if archived else q.where(m.Project.archived_at.is_(None))
        rows = s.exec(q.order_by(m.Project.sort_order.asc(), m.Project.id.asc())).all()
        return [_project_dto(p) for p in rows]


def _raise_explorer_window(full_path: str) -> None:
    """Windows：把资源管理器窗口提到前台（仅 win32，失败静默不影响打开）。"""
    import ctypes
    import ctypes.wintypes as wt
    import time

    full_path = str(full_path).rstrip("\\/") or full_path
    folder_name = full_path.rsplit("\\", 1)[-1].rsplit("/", 1)[-1]
    try:
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32


        user32.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
        user32.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
        user32.GetWindowTextLengthW.argtypes = [wt.HWND]
        user32.SetForegroundWindow.argtypes = [wt.HWND]
        user32.ShowWindow.argtypes = [wt.HWND, ctypes.c_int]
        user32.BringWindowToTop.argtypes = [wt.HWND]
        user32.GetForegroundWindow.restype = wt.HWND
        user32.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]
        user32.GetWindowThreadProcessId.restype = wt.DWORD
        user32.AttachThreadInput.argtypes = [wt.DWORD, wt.DWORD, wt.BOOL]
        kernel32.GetCurrentThreadId.restype = wt.DWORD

        def find_hwnd():
            found = []

            def enum_cb(hwnd, _):

                cls = ctypes.create_unicode_buffer(64)
                user32.GetClassNameW(hwnd, cls, 64)
                if cls.value != "CabinetWClass":
                    return True
                length = user32.GetWindowTextLengthW(hwnd)
                if length:
                    buf = ctypes.create_unicode_buffer(length + 1)
                    user32.GetWindowTextW(hwnd, buf, length + 1)
                    title = buf.value

                    if title.casefold() == folder_name.casefold() or title.casefold().startswith(full_path.casefold()):
                        found.append(hwnd)
                        return False
                return True

            WNDENUMPROC = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
            user32.EnumWindows(WNDENUMPROC(enum_cb), 0)
            return found[0] if found else None


        hwnd = None
        deadline = time.time() + 3
        while time.time() < deadline:
            hwnd = find_hwnd()
            if hwnd is not None:
                break
            time.sleep(0.15)
        if hwnd is None:
            return

        user32.ShowWindow(hwnd, 9)

        user32.keybd_event(0x12, 0, 0, 0)
        cur_tid = kernel32.GetCurrentThreadId()
        fg = user32.GetForegroundWindow()
        fg_tid = user32.GetWindowThreadProcessId(fg, None) if fg else 0
        if fg_tid and fg_tid != cur_tid:

            user32.AttachThreadInput(cur_tid, fg_tid, True)
            user32.SetForegroundWindow(hwnd)
            user32.BringWindowToTop(hwnd)
            user32.AttachThreadInput(cur_tid, fg_tid, False)
        else:
            user32.SetForegroundWindow(hwnd)
            user32.BringWindowToTop(hwnd)
        user32.keybd_event(0x12, 0, 2, 0)
    except Exception:
        return


@router.post("/projects/{pid}/open-dir")
def open_project_dir(pid: int, request: Request, _: str = Depends(require_auth)):
    """在系统资源管理器中打开项目目录。只从 DB 读已注册项目的 repo_path，无路径参数（防任意目录打开）。"""
    import subprocess
    import sys
    from pathlib import Path

    from sqlmodel import Session

    af = request.app.state.af
    with Session(af.engine) as s:
        proj = s.get(m.Project, pid)
        if not proj or not proj.repo_path:
            raise HTTPException(404, "project not found")
    path = Path(proj.repo_path)
    if not path.is_dir():
        raise HTTPException(400, f"repo_path 不存在: {proj.repo_path}")
    try:
        if sys.platform == "win32":


            subprocess.Popen(["explorer.exe", str(path)])
            _raise_explorer_window(str(path.resolve()))
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
        return {"ok": True}
    except Exception as e:
        raise HTTPException(400, f"打开失败: {e}")


@router.post("/projects/{pid}/archive")
def archive_project(pid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        p = s.get(m.Project, pid)
        if not p:
            raise HTTPException(404, "project not found")

        running = s.query(m.Task).filter(m.Task.project_id == pid, m.Task.status == m.TaskStatus.running).first()
        if running:
            raise HTTPException(400, "项目内有运行中任务，不可归档")
        p.archived_at = _utcnow()
        s.add(p)
        s.commit()
        return {"ok": True}


@router.post("/projects/{pid}/unarchive")
def unarchive_project(pid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        p = s.get(m.Project, pid)
        if not p:
            raise HTTPException(404, "project not found")
        p.archived_at = None
        s.add(p)
        s.commit()
        return {"ok": True}


@router.delete("/projects/{pid}")
def delete_project(pid: int, request: Request, _: str = Depends(require_auth)):
    """删除项目（归档界面）：级联清理该项目在 AgentFlow 中的全部记录（storage/cleanup.py）。"""
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        proj = s.get(m.Project, pid)
        if not proj:
            raise HTTPException(404, "project not found")

        active = s.exec(
            select(m.Task.id).where(
                m.Task.project_id == pid,
                m.Task.status.in_([m.TaskStatus.running, m.TaskStatus.merging]),
            )
        ).first()
        if active:
            raise HTTPException(400, "项目内有运行中/合并中任务，不可删除")

    from agentflow.storage.cleanup import delete_project_records

    return {"ok": True, **delete_project_records(af.engine, af.settings.home, pid)}


class OrderIn(BaseModel):
    order: list[dict]


@router.put("/projects/order")
def reorder_projects(body: OrderIn, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        for item in body.order:
            p = s.get(m.Project, int(item["id"]))
            if p:
                p.sort_order = int(item.get("sort_order", 0))
                s.add(p)
        s.commit()
        return {"ok": True}


@router.get("/projects/{pid}/scan")
def scan_project(pid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        p = s.get(m.Project, pid)
        if not p:
            raise HTTPException(404, "project not found")
        stack = json.loads(p.stack)
        return {
            "project_id": pid,
            "stack": stack,
            "verifier_draft": suggest_commands(json.dumps(stack)),
            "invariant_draft": suggest_invariants(stack),
        }


@router.post("/projects/{pid}/confirm-wizard")
def confirm_wizard(pid: int, body: WizardConfirm, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    from sqlmodel import Session

    with Session(af.engine) as s:
        p = s.get(m.Project, pid)
        if not p:
            raise HTTPException(404, "project not found")
        cfg = json.loads(p.config) if p.config else {}
        cfg["verifiers"] = body.verifiers
        update_project_config(s, pid, cfg)

        for text in body.invariants:
            if not s.query(m.Invariant).filter(m.Invariant.project_id == pid, m.Invariant.text == text).first():
                s.add(m.Invariant(project_id=pid, layer=m.InvariantLayer.template, text=text))
        s.commit()
        return {"ok": True}


def _project_dto(p: m.Project) -> dict:
    return {
        "id": p.id,
        "name": p.name,
        "repo_path": p.repo_path,
        "stack": json.loads(p.stack),
        "created_at": p.created_at,
        "archived_at": p.archived_at,
        "sort_order": p.sort_order,
    }


def _utcnow() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()
