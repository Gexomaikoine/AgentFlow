"""Spec DSL：Pydantic 模型 + YAML 解析/渲染。"""

from __future__ import annotations

import json
import re

import yaml
from pydantic import BaseModel, Field, field_validator, model_validator


class VerifyCommand(BaseModel):
    verifier: str = "pytest"
    cmd: str = ""
    timeout: int = 120
    classification_hint: str = "blocking"
    stage: str = "light"
    shell: str = ""

    @field_validator("stage", mode="before")
    @classmethod
    def _coerce_stage(cls, v):


        return v if str(v or "").strip().lower() in ("light", "heavy") else "light"


class FeatureDef(BaseModel):
    seq: int = 1
    title: str = ""
    file_scope: list[str] = Field(default_factory=list)
    verify_commands: list[VerifyCommand] = Field(default_factory=list)
    depends_on: list[int] = Field(default_factory=list)
    related_files: list[str] = Field(default_factory=list)

    @field_validator("file_scope", "related_files", mode="before")
    @classmethod
    def _coerce_str_list(cls, v):
        """容错：LLM 可能给单个字符串或逗号分隔串，统一转列表。"""
        if v is None:
            return []
        if isinstance(v, str):
            return [s.strip() for s in v.split(",") if s.strip()]
        if isinstance(v, dict):
            return list(v.keys())
        return v

    @field_validator("depends_on", mode="before")
    @classmethod
    def _coerce_int_list(cls, v):
        if v is None:
            return []
        if isinstance(v, (int, str)):
            try:
                return [int(v)]
            except (TypeError, ValueError):
                return []
        if isinstance(v, list):
            out = []
            for x in v:
                try:
                    out.append(int(x))
                except (TypeError, ValueError):
                    continue
            return out
        return v

    @field_validator("verify_commands", mode="before")
    @classmethod
    def _coerce_cmds(cls, v):
        """容错：verify_commands 可能是单个对象/字符串，统一转列表。"""
        if v is None:
            return []
        if isinstance(v, dict):
            return [v]
        if isinstance(v, str):
            return [{"cmd": v}]
        return v


class Budget(BaseModel):
    max_retries: int = 3
    feature_timeout_s: int = 600
    task_max_tokens: int = 500000
    task_max_cost_usd: float = 5.0


def _invariant_text(item: object) -> str:
    """不变量条目 → 一行文本。LLM 常把不变量写成 YAML 映射项（`- 规则: 说明`）或嵌套列表，"""
    if isinstance(item, str):
        return item.strip()
    if isinstance(item, dict):
        return "；".join(filter(None, (f"{k}: {_invariant_text(v)}" if v else str(k) for k, v in item.items())))
    if isinstance(item, (list, tuple)):
        return "；".join(filter(None, (_invariant_text(x) for x in item)))
    return "" if item is None else str(item)


class SpecDoc(BaseModel):
    title: str = ""
    features: list[FeatureDef] = Field(default_factory=list)
    invariants: list[str] = Field(default_factory=list)
    budget: Budget = Field(default_factory=Budget)
    complexity: str = "standard"
    grouping: list[list[int]] = Field(default_factory=list)

    @field_validator("complexity", mode="before")
    @classmethod
    def _coerce_complexity(cls, v):

        return "simple" if str(v or "").strip().lower() == "simple" else "standard"

    @field_validator("grouping", mode="before")
    @classmethod
    def _coerce_grouping(cls, v):
        if v is None:
            return []
        if isinstance(v, dict):

            return [list(x) if isinstance(x, list) else [x] for x in v.values()]
        return v

    @field_validator("invariants", mode="before")
    @classmethod
    def _coerce_invariants(cls, v):
        if v is None:
            return []
        if isinstance(v, str):
            return [v]
        if isinstance(v, list):
            return [t for t in (_invariant_text(x) for x in v) if t]
        return v

    @field_validator("budget", mode="before")
    @classmethod
    def _coerce_budget(cls, v):
        """容错：LLM 可能把 budget 写成字符串（如 '30m'）→ 回退默认预算。"""
        if isinstance(v, dict):
            return v
        return {}

    @model_validator(mode="before")
    @classmethod
    def _coerce(cls, data):
        """容错：LLM 产出的 Spec 可能不严格符合 schema（如字符串代替列表）。"""
        if isinstance(data, dict):
            feats = data.get("features")
            if isinstance(feats, dict):

                data["features"] = [v if isinstance(v, dict) else {"title": str(k)} for k, v in feats.items()]
        return data


_COLON_SCALAR_RE = re.compile(r"^(\s*(?:-\s+)?[A-Za-z_][\w\-]*\s*:\s+)(.*)$")


def repair_yaml_colon_scalars(yaml_text: str) -> tuple[str, int]:
    """把「值里含 `: `（冒号+空格）」的**未加引号**标量整体加单引号，返回 (修好的文本, 修复处数)。"""
    out: list[str] = []
    fixed = 0
    for line in (yaml_text or "").splitlines():
        m = _COLON_SCALAR_RE.match(line)
        if m and ": " in m.group(2):
            val = m.group(2)
            if not val.startswith(("'", '"', "{", "[", "|", ">")):
                out.append(m.group(1) + "'" + val.replace("'", "''") + "'")
                fixed += 1
                continue
        out.append(line)
    return "\n".join(out), fixed


def parse_spec(yaml_text: str, repair_note: list[str] | None = None) -> SpecDoc:
    """解析 Spec YAML → SpecDoc。宽容处理：缺省字段用默认值。"""
    try:
        raw = yaml.safe_load(yaml_text) or {}
    except yaml.YAMLError:
        repaired, n = repair_yaml_colon_scalars(yaml_text)
        if not n:
            raise
        raw = yaml.safe_load(repaired) or {}
        if repair_note is not None:
            repair_note.append(f"Spec YAML 有 {n} 处未加引号的含冒号标量（类型注解/证据文案），已自动加引号后解析成功")
    return SpecDoc.model_validate(raw)


def dump_spec(doc: SpecDoc) -> str:
    """SpecDoc → YAML。"""
    data = json.loads(doc.model_dump_json())
    return yaml.safe_dump(data, allow_unicode=True, sort_keys=False)


def render_spec_prompt(doc: SpecDoc) -> str:
    """把 Spec 渲染成 agent 系统提示片段（分流渐进披露给开发者）。"""
    lines = ["## Spec 契约", f"任务: {doc.title}", "", "### 功能清单"]
    for f in doc.features:
        deps = f" 依赖: {f.depends_on}" if f.depends_on else ""
        scope = " 写集: " + ", ".join(f.file_scope) if f.file_scope else ""
        rel = " 相关文件: " + ", ".join(f.related_files) if f.related_files else ""
        lines.append(f"- [{f.seq}] {f.title}{scope}{rel}{deps}")
    if doc.invariants:
        lines.append("")
        lines.append("### 不变量（全程遵守）")
        for inv in doc.invariants:
            lines.append(f"- {inv}")
    lines.append("")
    lines.append("### 预算")
    b = doc.budget
    lines.append(
        f"- max_retries={b.max_retries} feature_timeout_s={b.feature_timeout_s} "
        f"task_max_tokens={b.task_max_tokens} max_cost_usd={b.task_max_cost_usd}"
    )
    return "\n".join(lines)


def expand_file_scope(scope_globs: list[str]) -> list[str]:
    """把 file_scope glob 列表归一化为规范形式（仅用于展示/提示，不实际展开）。"""
    return [re.sub(r"[\\/]+$", "", g) for g in scope_globs]
