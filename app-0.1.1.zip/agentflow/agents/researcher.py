"""调研 Agent（researcher）：代码定位 + 依赖映射 + 环境检查（P4 新增，只读）。"""

from __future__ import annotations

from agentflow.storage import models as m


def build_researcher_system() -> str:
    return (
        "你是代码调研 agent。任务启动阶段做只读调研，产出结构化报告：\n"
        "1. 关键文件定位：与本任务相关的现有实现、接口、入口。\n"
        "2. 依赖映射：涉及模块间的调用/数据流关系。\n"
        "3. 环境要点：技术栈、构建/测试命令、易错点。\n"
        "只读：可用 read_file/grep/glob/run_cmd（只读命令）。禁止写文件。\n"
        "**报告必须控制在 1600 字以内**：下游只把前 2000 字注入 developer 提示词，超出的部分"
        "等于白写。\n"
        "**先看已给的现场诊断结论**（若有）：那是已查证的事实，直接采信，不要重读它列出的文件；"
        "你的价值在补它没覆盖的部分。若确认无新增信息，直接写「无新增待查项」并一句话复述结论即可——"
        "绝不为了凑篇幅重读已给内容（：researcher 连读 57 个文件、烧 49.5 万 token，"
        "结论只有一句「无新增待查项」，纯浪费预算）。\n"
        "报告用简体中文，最后调用 done。"
    )


def build_researcher_prompt(
    task: m.Task, project: m.Project, features_summary: str, diagnosis: str = "",
) -> str:
    parts = [
        f"任务 #{task.id}「{task.title}」规模较大，任务开发前请先做一次代码调研。\n"
        f"PROJECT_PATH: {project.repo_path}\n\n"
        f"功能清单:\n{features_summary}\n",
    ]
    if diagnosis:
        parts.append(
            "\n## 已完成的现场诊断（Lead 只读查证，**直接采信，勿重复探索**）\n" + diagnosis[:2500] + "\n"
        )
    parts.append(
        "\n请在上面的基础上**只补诊断未覆盖的信息**（依赖关系/环境要点/易错点），"
        "输出 1600 字以内的简洁调研报告后调用 done。"
    )
    return "".join(parts)
