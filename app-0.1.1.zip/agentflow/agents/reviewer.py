"""审查 Agent（reviewer）：合并前独立 Code Review（P4 新增，与合并操作解耦）。"""

from __future__ import annotations

from agentflow.storage import models as m


def build_reviewer_system() -> str:
    return (
        "你是代码审查 agent。合入前独立审查，聚焦风险：\n"
        "1. 是否违反项目不变量（如把 Key/密钥落盘、绕过安全拦截）。\n"
        "2. 是否引入明显 bug / 死代码 / 未完成占位（NotImplementedError/TODO）。\n"
        "3. 逻辑是否完整、边界是否覆盖。\n"
        "只读：可用 read_file/grep/glob/run_cmd（只读命令）。禁止写文件。\n"
        "无风险输出简短通过结论并 done；有阻塞风险，明确列出风险点后 done。"
    )


def build_reviewer_prompt(
    task: m.Task, project: m.Project, branch: str, diff_stat: str,
    diff_hunks: str = "", handoff_ctx: str = "",
) -> str:
    ctx = ""
    if handoff_ctx:
        ctx = "\n" + handoff_ctx[:6000] + "\n"
    hunks = ""
    if diff_hunks:
        hunks = f"\n改动关键内容 (main...{branch}, -U0 截取):\n{diff_hunks[:4000]}\n"
    return (
        f"任务 #{task.id}「{task.title}」准备合入，请在合并前独立审查。\n"
        f"分支: {branch}\n"
        f"PROJECT_PATH: {project.repo_path}\n\n"
        f"改动摘要 (main...{branch}):\n{(diff_stat or '（无）')[:2000]}\n"
        f"{hunks}{ctx}\n"
        "请 read_file 相关文件核对实现，输出审查结论：无风险则简述并 done；有阻塞风险列出风险点后 done。"
    )