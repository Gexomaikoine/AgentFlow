"""项目注册与配置隔离（FR0）。"""

from __future__ import annotations

import json
from pathlib import Path

from agentflow.projects.detect import detect_stack
from agentflow.storage import models as m
from sqlmodel import Session


class ProjectError(Exception):
    pass


def register_project(session: Session, name: str, repo_path: str) -> m.Project:
    """注册项目：路径必须存在且为 git 仓库；自动探测技术栈与默认依赖策略。"""
    p = Path(repo_path)
    if not p.exists() or not (p / ".git").exists():
        raise ProjectError(f"不是 git 仓库: {repo_path}")
    if session.query(m.Project).filter(m.Project.name == name).first():
        raise ProjectError(f"项目名已存在: {name}")
    stack = detect_stack(p)
    config = {"dep_strategy": default_dep_strategy(stack)}
    proj = m.Project(
        name=name,
        repo_path=str(p.resolve()),
        stack=json.dumps(stack, ensure_ascii=False),
        config=json.dumps(config, ensure_ascii=False),
    )
    session.add(proj)
    session.commit()
    return proj


def default_dep_strategy(stack: dict) -> str:
    """按探测到的语言栈给出默认依赖策略。"""
    langs = stack.get("languages", [])
    if "javascript" in langs or "typescript" in langs:
        return "junction_node_modules"
    if "python" in langs:
        return "shared_venv"
    return "per_worktree_install"


def project_runtime_data_dirs(session: Session, project_id: int) -> list[str]:
    """读取项目运行时数据目录清单（config.runtime_data_dirs，相对主 checkout 路径）。"""
    config = project_config(session, project_id)
    dirs = config.get("runtime_data_dirs") or []
    return [d for d in dirs if isinstance(d, str) and d.strip()]


def project_dep_strategy(session: Session, project_id: int) -> str:
    """读取项目依赖策略（config.dep_strategy），缺失则按栈回退默认。"""
    config = project_config(session, project_id)
    strategy = config.get("dep_strategy")
    if strategy:
        return strategy
    p = session.get(m.Project, project_id)
    stack = json.loads(p.stack) if p and p.stack else {}
    return default_dep_strategy(stack)


def project_config(session: Session, project_id: int) -> dict:
    p = session.get(m.Project, project_id)
    return json.loads(p.config) if p and p.config else {}


def update_project_config(session: Session, project_id: int, config: dict) -> m.Project:
    p = session.get(m.Project, project_id)
    p.config = json.dumps(config, ensure_ascii=False)
    session.add(p)
    session.commit()
    return p
