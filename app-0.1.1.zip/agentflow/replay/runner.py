"""回放基准：加载回放集 → 逐 case 跑完整闭环 → 成功率报表。"""

from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from agentflow.config import Settings
from agentflow.core.budget import fmt_tokens
from agentflow.storage import models as m
from agentflow.storage.cleanup import delete_project_records
from sqlmodel import Session, select

SUCCESS_STATUSES = {
    m.TaskStatus.done,
    m.TaskStatus.human_review,
    m.TaskStatus.pending_push,
    m.TaskStatus.pushed,
    m.TaskStatus.merged,
    m.TaskStatus.passed,
}

DEFAULT_DEMO_CASE = {
    "name": "demo-add",
    "kind": "demo",
    "title": "实现 add 函数并通过测试",
    "raw_request": "给 demo_lib.core 实现 add 函数并让测试通过",
    "clarify_reply": "实现即可，保持简单",
    "expect": [
        {"check": "file_not_contains", "path": "src/demo_lib/core.py", "text": "NotImplementedError"},
        {"check": "pytest_ok"},
    ],
}


def load_suite(path: str | None) -> dict:
    """加载回放集 JSON；缺省返回内置 demo 套件。"""
    if not path:
        return {"name": "default", "cases": [dict(DEFAULT_DEMO_CASE)]}
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not raw.get("cases"):
        raise ValueError(f"回放集缺少 cases: {path}")
    raw.setdefault("name", Path(path).stem)
    return raw


def run_suite(suite_path: str | None, only_case: str | None = None, use_mock: bool = False, cleanup: bool = True) -> dict:
    """跑完整回放集，落报表 JSON 并打印汇总；有失败由调用方决定退出码。"""
    settings = Settings.load()
    if use_mock:
        settings.data["llm"]["provider"] = "mock"
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except (ValueError, OSError):
                pass
    from agentflow.storage.db import create_db_engine

    engine = create_db_engine(settings)
    suite = load_suite(suite_path)
    cases = suite["cases"]
    if only_case:
        cases = [c for c in cases if c["name"] == only_case]
        if not cases:
            raise ValueError(f"回放集中无此 case: {only_case}")

    results = []
    started = time.monotonic()
    for case in cases:
        print(f"\n=== replay case: {case['name']} ===")
        try:
            r = run_case(settings, engine, case, cleanup=cleanup)
        except Exception as e:
            r = {"case": case["name"], "ok": False, "error": f"{type(e).__name__}: {e}"}
        results.append(r)
        print(f"=== {case['name']} → {'PASS ✅' if r.get('ok') else 'FAIL ❌'} ===")

    report = _aggregate(suite["name"], results, time.monotonic() - started)
    out = _write_report(settings, report)
    report["report_file"] = out.name
    _print_report(report, out)
    return report


def run_case(settings: Settings, engine, case: dict, cleanup: bool = True) -> dict:
    name = case["name"]
    kind = case.get("kind", "demo")
    ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    started = time.monotonic()

    if kind == "demo":
        from agentflow.demo.demo import init_demo_project

        repo_dir = init_demo_project()
    elif kind == "inline":
        repo_dir = _prepare_inline_workspace(settings.home / "replay_workspaces" / f"{name}-{ts}", case.get("files") or {})
    else:
        raise ValueError(f"未知 case kind: {kind}（case={name}）")

    project_name = f"replay-{name}-{ts}"
    try:
        project_id, task_id = _setup_and_run(settings, engine, project_name, repo_dir, case)
        r = _collect(engine, name, project_name, project_id, task_id, case, repo_dir, time.monotonic() - started)
    except Exception:

        if cleanup:
            _cleanup_by_name(engine, settings.home, project_name)
        raise
    if cleanup:
        _cleanup_by_name(engine, settings.home, project_name)
        if kind == "inline":
            shutil.rmtree(repo_dir, ignore_errors=True)
        r["cleaned"] = True
    return r


def _cleanup_by_name(engine, home: Path, project_name: str) -> None:
    """按项目名清理回放项目；失败只告警不打断回放流程（指标已落报表）。"""
    try:
        with Session(engine) as s:
            proj = s.exec(select(m.Project).where(m.Project.name == project_name)).first()
            pid = proj.id if proj else None
        if pid is not None:
            delete_project_records(engine, home, pid)
    except Exception as e:
        print(f"[warn] 回放项目清理失败（{project_name}）: {type(e).__name__}: {e}")


def _prepare_inline_workspace(workspace: Path, files: dict[str, str]) -> Path:
    """inline case：从零搭一个 git 仓库工作区（每次全新目录，天然可重复）。"""
    if workspace.exists():
        shutil.rmtree(workspace)
    workspace.mkdir(parents=True)
    for rel, content in files.items():
        p = workspace / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    subprocess.run(["git", "init", "-b", "main"], cwd=workspace, check=True, capture_output=True)
    subprocess.run(["git", "add", "-A"], cwd=workspace, check=True, capture_output=True)
    subprocess.run(
        ["git", "-c", "user.name=replay", "-c", "user.email=replay@local", "commit", "-m", "replay 初始"],
        cwd=workspace,
        check=True,
        capture_output=True,
    )
    return workspace


def _setup_and_run(settings: Settings, engine, project_name: str, repo_dir: Path, case: dict) -> tuple[int, int]:
    """注册项目→向导确认→建任务→澄清→Spec 签署→TaskRunner 闭环（复用 demo 流程）。返回 (project_id, task_id)。"""
    from agentflow.agents.lead import clarify_round, generate_spec
    from agentflow.core.events_bus import EventBus
    from agentflow.core.scheduler import TaskRunner
    from agentflow.llm.gateway import LLMGateway
    from agentflow.projects.invariant_tpl import suggest_invariants
    from agentflow.projects.registry import register_project
    from agentflow.storage.events_log import EventLog
    from agentflow.verifiers.builtin import suggest_commands

    gateway = LLMGateway(settings)
    bus = EventBus(EventLog(settings))

    with Session(engine) as s:
        proj = register_project(s, project_name, str(repo_dir))
        stack = json.loads(proj.stack)
        cfg = json.loads(proj.config) if proj.config else {}
        cfg["verifiers"] = case.get("verifiers") or suggest_commands(json.dumps(stack))
        proj.config = json.dumps(cfg, ensure_ascii=False)
        for text in suggest_invariants(stack):
            if not s.query(m.Invariant).filter(m.Invariant.project_id == proj.id, m.Invariant.text == text).first():
                s.add(m.Invariant(project_id=proj.id, layer=m.InvariantLayer.template, text=text))
        s.add(proj)
        s.commit()
        project_id = proj.id

        t = m.Task(
            project_id=project_id,
            title=case.get("title") or case["name"],
            raw_request=case.get("raw_request") or case.get("title") or case["name"],
        )
        s.add(t)
        s.commit()
        task_id = t.id

    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        t.status = m.TaskStatus.clarifying
        s.commit()
        clarify_round(gateway, s, t, case.get("clarify_reply") or "实现即可，保持简单")
        proj = s.get(m.Project, project_id)
        generate_spec(gateway, s, t, proj)
        t.status = m.TaskStatus.spec_pending
        spec = s.exec(select(m.Spec).where(m.Spec.task_id == task_id).order_by(m.Spec.id.desc())).first()
        if not spec:
            raise RuntimeError(f"Spec 未生成（case={case['name']} task={task_id}）")
        spec.confirmed_at = datetime.now(timezone.utc).isoformat()
        s.add(spec)
        s.add(t)
        s.commit()

    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        t.status = m.TaskStatus.running
        s.commit()
    runner = TaskRunner(engine, gateway, bus, settings, task_id)
    asyncio.run(runner.run())
    return project_id, task_id


def _collect(engine, case_name: str, project_name: str, project_id: int, task_id: int, case: dict, repo_dir: Path, duration_s: float) -> dict:
    _wait_merge_done(engine, task_id)
    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        feats = s.exec(select(m.Feature).where(m.Feature.task_id == task_id)).all()
        anchors = s.exec(select(m.GreenAnchor).where(m.GreenAnchor.task_id == task_id)).all()
        runs = s.exec(select(m.VerifierRun).where(m.VerifierRun.task_id == task_id)).all()
        evo = s.exec(select(m.EvolutionEntry).where(m.EvolutionEntry.task_id == task_id)).first()
        sos_count = len(s.exec(select(m.SosPacket).where(m.SosPacket.task_id == task_id)).all())
        budget = json.loads(t.used_budget) if t.used_budget else {}

    status = t.status
    passed_feats = sum(1 for f in feats if f.status == m.FeatureStatus.passed)
    retries = sum(f.retry_count for f in feats)
    vf_pass = sum(1 for r in runs if r.exit_code == 0 and r.classification is None)
    vf_fail = len(runs) - vf_pass
    post_ok, post_detail = _run_expect(case, repo_dir)

    ok = status in SUCCESS_STATUSES and bool(feats) and passed_feats == len(feats) and bool(anchors) and post_ok
    return {
        "case": case_name,
        "project": project_name,
        "project_id": project_id,
        "task_id": task_id,
        "ok": ok,
        "status": status.value,
        "features_passed": passed_feats,
        "features_total": len(feats),
        "anchors": len(anchors),
        "retries": retries,
        "verifier_pass": vf_pass,
        "verifier_fail": vf_fail,
        "sos_breakers": sos_count,
        "evolution_score": evo.score if evo else None,
        "tokens_in": budget.get("tokens_in", 0),
        "tokens_out": budget.get("tokens_out", 0),
        "cost_usd": budget.get("cost_usd", 0),
        "duration_s": round(duration_s, 1),
        "post_checks": post_detail,
    }


def _wait_merge_done(engine, task_id: int, timeout_s: float = 60.0) -> None:
    """合并队列是后台异步出队（2 秒轮询）：后置断言须等本次合并到终态再跑。"""
    import time as _t

    deadline = _t.monotonic() + timeout_s
    while _t.monotonic() < deadline:
        with Session(engine) as s:
            entry = s.exec(
                select(m.MergeQueueEntry).where(m.MergeQueueEntry.task_id == task_id).order_by(m.MergeQueueEntry.id.desc())
            ).first()
        if entry is None or entry.status in ("merged", "failed", "aborted"):
            return
        _t.sleep(1.0)


def _run_expect(case: dict, repo_dir: Path) -> tuple[bool, list[dict]]:
    """执行 case 的 expect 后置断言（file_not_contains / file_contains / pytest_ok）。"""
    detail = []
    ok = True
    for exp in case.get("expect") or []:
        check = exp.get("check")
        item = {"check": check, "ok": False}
        try:
            if check == "pytest_ok":
                item["ok"] = _pytest_ok(repo_dir)
            elif check in ("file_not_contains", "file_contains"):
                text = (repo_dir / exp["path"]).read_text(encoding="utf-8")
                contains = exp["text"] in text
                item["ok"] = (not contains) if check == "file_not_contains" else contains
        except Exception as e:
            item["error"] = f"{type(e).__name__}: {e}"
        detail.append(item)
        ok = ok and item["ok"]
    return ok, detail


def _pytest_ok(repo_dir: Path) -> bool:
    try:
        r = subprocess.run(
            [sys.executable, "-m", "pytest", "tests/", "-q"],
            cwd=repo_dir,
            capture_output=True,
            text=True,
            timeout=120,
        )
        return r.returncode == 0
    except Exception:
        return False


def _aggregate(suite_name: str, results: list[dict], duration_s: float) -> dict:
    total = len(results)
    passed = sum(1 for r in results if r.get("ok"))
    return {
        "suite": suite_name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "cases_total": total,
        "cases_passed": passed,
        "success_rate": round(passed / total, 4) if total else 0.0,
        "tokens_in": sum(r.get("tokens_in", 0) or 0 for r in results),
        "tokens_out": sum(r.get("tokens_out", 0) or 0 for r in results),
        "cost_usd": round(sum(r.get("cost_usd", 0) or 0 for r in results), 4),
        "duration_s": round(duration_s, 1),
        "results": results,
        "all_ok": passed == total and total > 0,
    }


def _write_report(settings: Settings, report: dict) -> Path:
    out_dir = settings.home / "replay_reports"
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    out = out_dir / f"{ts}-{report['suite']}.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def _print_report(report: dict, out: Path) -> None:
    print("=" * 60)
    print(f"回放报表：{report['suite']}  ({report['created_at']})")
    print(
        f"成功率: {report['cases_passed']}/{report['cases_total']} = {report['success_rate']:.0%}"
        f"  tokens_in={fmt_tokens(report['tokens_in'])}  tokens_out={fmt_tokens(report['tokens_out'])}"
        f"  cost=${report['cost_usd']}  耗时={report['duration_s']}s"
    )
    for r in report["results"]:
        if r.get("error"):
            print(f"  [FAIL] {r['case']}: 异常 {r['error']}")
            continue
        mark = "PASS" if r["ok"] else "FAIL"
        evo = f" 进化{r['evolution_score']}" if r.get("evolution_score") is not None else ""
        cleaned = " 记录已清理" if r.get("cleaned") else ""
        print(
            f"  [{mark}] {r['case']}: status={r['status']}"
            f" 功能{r['features_passed']}/{r['features_total']} 绿点{r['anchors']}"
            f" 重试{r['retries']} 校验{r['verifier_pass']}✓/{r['verifier_fail']}✗"
            f" SOS×{r['sos_breakers']}{evo} {r['duration_s']}s{cleaned}"
        )
        for c in r.get("post_checks") or []:
            if not c["ok"]:
                print(f"         后置断言未过: {c}")
    print(f"报表已写入: {out}")
    print("=" * 60)
