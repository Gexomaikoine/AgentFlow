"""python -m agentflow 入口。"""

from agentflow.cli import main

if __name__ == "__main__":
    main()
