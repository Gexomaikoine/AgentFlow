"""Spec verifier 命令可执行性自检（dry-run，不执行业务副作用）。"""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

from agentflow.storage import models as m
from sqlmodel import Session, select


_CJK = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")

_FULLWIDTH = re.compile(r"[，。；：、「」【】！？]")

_STMT_SPLIT = re.compile(r"[\n;]|&&|\|\|")



_UI_INTENT = re.compile(r"browser|playwright|ui_test|uitest|web_?ui|screenshot|浏览器|界面|页面自测", re.I)




SPEC_DEFECT_MARK = "[spec-defect:cmd-not-executable]"

SPEC_DEFECT_EXIT = 127


def first_tokens(cmd: str) -> list[str]:
    """拆出每条语句的首 token（命令名位置）。空语句跳过。"""
    out: list[str] = []
    for stmt in _STMT_SPLIT.split(cmd or ""):
        s = stmt.strip().lstrip("({[").strip()
        if not s:
            continue
        out.append(s.split()[0].strip("\"'`"))
    return out


def prose_reason(cmd: str) -> str:
    """判定 cmd 是自然语言描述而非可执行命令。返回原因（空串=像命令）。"""
    text = (cmd or "").strip()
    if not text:
        return "cmd 为空"
    tokens = first_tokens(text)
    if not tokens:
        return "cmd 解析不出任何语句"
    for tok in tokens:
        if _CJK.search(tok):
            return f"命令名位置是中文词「{tok[:24]}」——自然语言描述不能当命令执行"

    if _FULLWIDTH.search(text) and not re.search(r"[\"'][^\"']*[，。；：、][^\"']*[\"']", text):
        return "cmd 含全角句读（，。；：等）且未被引号包裹，判定为自然语言描述而非命令"
    return ""


def ui_declaration_reason(verifier: str, cmd: str) -> str:
    """ui 校验器的 cmd 必须是 JSON 检查声明（start_cmd/pages + 端口契约），否则运行期必炸。"""
    if (verifier or "").strip().lower() != "ui":
        return ""
    text = (cmd or "").strip()
    if not text.startswith("{"):
        return 'verifier=ui 的 cmd 必须是 JSON 检查声明（形如 {"start_cmd":"... -p {port}","port":"auto","pages":[...]}），不能是自然语言'
    try:
        obj = json.loads(text)
    except Exception as e:
        return f"verifier=ui 的 cmd 不是合法 JSON: {e}"
    if not isinstance(obj, dict) or not obj.get("start_cmd"):
        return "verifier=ui 的 JSON 声明缺 start_cmd"
    from agentflow.core.services import ENV_PORT_VAR, PORT_PLACEHOLDER

    start_cmd = str(obj.get("start_cmd") or "")
    if PORT_PLACEHOLDER not in start_cmd and ENV_PORT_VAR not in start_cmd:
        return (
            f"verifier=ui 的 start_cmd 未声明机审端口契约：请用 {PORT_PLACEHOLDER} 占位符"
            f'（如 "npm run dev -- -p {PORT_PLACEHOLDER}"，port 写 "auto"）或引用环境变量 {ENV_PORT_VAR}；'
            "写死端口号会因端口被占用卡住机审。"
        )
    from agentflow.verifiers.ui_dsl import declaration_problems

    problems = declaration_problems(obj)
    if problems:
        return "verifier=ui 的 JSON 检查声明结构非法: " + "；".join(problems[:3])
    return ""


def ui_hint(verifier: str, cmd: str) -> str:
    """cmd/名字透露出浏览器 UI 自测意图但没走 ui 校验器 → 给定向纠偏提示。"""
    if not _UI_INTENT.search(verifier or "") and not _UI_INTENT.search(cmd or ""):
        return ""
    if (verifier or "").strip().lower() == "ui":
        return ""
    return (
        "如需真实浏览器 UI 自测，必须用 verifier: ui + JSON 检查声明"
        '（{"start_cmd":"npm run dev -- -p {port}","port":"auto","pages":[{"url":"/","selectors":["h1"]}]}），'
        "由 Playwright 执行并断言；不要把中文测试描述写进 cmd 交给 shell。"
    )


def smoke_direction_reason(verifier: str, hint: str, cmd: str, title: str, repo_root) -> str:
    """smoke 断言方向预检。"""
    text = cmd or ""
    markers = f"{verifier or ''} {hint or ''}".lower()
    if "smoke" not in markers and "smoke" not in text.lower():
        return ""

    if re.search(r"-Quiet\s*\)\s*\{?\s*exit\s*1", text, re.I) or re.search(
        r"if\s*\(.*?(?:Found|Contains|\-match|Test-Path).*?\)\s*\{?\s*exit\s*1", text, re.I | re.S
    ):
        lits = [m for m in _QUOTED.findall(text) if len(m) >= 4]
        removal = bool(_REMOVAL_INTENT.search(title or ""))
        for lit in lits:
            hit_in_title = lit.lower() in (title or "").lower()
            hit_in_repo = bool(repo_root) and _literal_in_sources(lit, repo_root)
            if (hit_in_title or hit_in_repo) and not removal:
                where = "功能标题" if hit_in_title else "仓库源码"
                return (
                    f"smoke 断言方向可疑：命令在「找到 {lit}」时退出 1（断言其不存在），"
                    f"但 {where}中存在该关键词——若是本功能要新增/保留的能力，断言方向写反了。"
                    "存在性断言应当是「找不到才 exit 1」，请对照功能描述复核并修正方向。"
                )

    if re.search(r"LastIndexOf|IndexOf", text, re.I) and re.search(r"-(?:gt|ge|lt|le)\b", text, re.I) and "exit 1" in text:
        return (
            "smoke 顺序断言（IndexOf/LastIndexOf 比较 + exit 1）方向极易写反："
            "请对照功能描述复核「谁应在谁前面」与退出码方向，确保『不满足预期 → exit 1』。"
        )
    return ""




_SELECTSTRING = re.compile(
    r"(?P<neg>-not\s+)?\(?\s*Select-String\s+-Path\s+(?P<path>\"[^\"]+\"|'[^']+'|[^\s)]+)"
    r"\s+-Pattern\s+(?P<pat>\"[^\"]*\"|'[^']*'|[^\s)]+)",
    re.I,
)


def _unquote(s: str) -> str:
    s = (s or "").strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "\"'":
        return s[1:-1]
    return s


def selectstring_baseline_pass(cmd: str, repo_root) -> bool | None:
    """静态复现一条 Select-String 断言在**基线仓库**上的通过与否。"""
    text = cmd or ""
    if "-quiet" not in text.lower():
        return None
    m = _SELECTSTRING.search(text)
    if not m:
        return None
    rel = _unquote(m.group("path"))
    pat = _unquote(m.group("pat"))
    if not rel or not pat:
        return None

    if any(ch in rel for ch in "*?[]{}$") or any(ch in pat for ch in "$("):
        return None
    from pathlib import Path

    f = Path(str(repo_root)) / rel.replace("\\", "/")
    if not f.is_file():
        found = False
    else:
        try:
            content = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return None
        try:
            found = re.search(pat, content, re.I) is not None
        except re.error:
            return None
    return found if m.group("neg") else (not found)


def smoke_indistinct_reason(cmds: list[dict], repo_root) -> str:
    """整批 light 断言在基线仓库上是否已全部成立（= 对本功能零区分度）。"""
    if not repo_root:
        return ""
    known: list[tuple[str, bool]] = []
    unjudgeable: list[str] = []
    for v in cmds or []:
        stage = (v.get("stage") or "light").strip().lower()
        verifier = (v.get("verifier") or "").strip().lower()
        if stage != "light":

            return ""
        if verifier == "ui":


            continue
        verdict = selectstring_baseline_pass(v.get("cmd", ""), repo_root)
        if verdict is None:


            unjudgeable.append(v.get("cmd", ""))
            continue
        known.append((v.get("cmd", ""), verdict))
    if not known:

        return ""
    if any(passed is False for _, passed in known):
        return ""
    if unjudgeable:

        return ""
    sample = known[0][0].strip()[:160]
    return (
        f"本功能 {len(known)} 条 light 断言在**基线仓库上全部已成立**"
        f"（例如 `{sample}`）——零改动即可全绿，无法区分「已实现」与「未实现」，会产出假绿点。"
        "请至少补一条『改动前必然失败』的断言（断言本功能新增/搬移后的结构或文案），"
        "使其能证明本功能的产出；纯防回归断言不能作为本功能唯一的 light 校验。"
    )


_QUOTED = re.compile(r"""['"]([^'"\n]{4,80})['"]""")




_REMOVAL_INTENT = re.compile(

    r"去掉|移除|去除|删除|删掉|不再|取消|禁止|移出|清理|不出现"




    r"|去换行|去折行|不换行|不允许换行|不得换行|单行|禁折行",
    re.I,
)


def _literal_in_sources(lit: str, repo_root) -> bool:
    """关键词是否出现在仓库源码里（复用 missing_testids 的扫描口径，限文本类源码）。"""
    import os

    for dirpath, dirnames, filenames in os.walk(str(repo_root)):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for fn in filenames:
            if os.path.splitext(fn)[1].lower() not in _SRC_SUFFIXES:
                continue
            try:
                with open(os.path.join(dirpath, fn), encoding="utf-8", errors="replace") as fh:
                    if lit.lower() in fh.read().lower():
                        return True
            except OSError:
                continue
    return False


def check_command(verifier: str, cmd: str, shell: str | None) -> tuple[bool, str]:
    """可执行性自检。返回 (是否可用, 错误摘要)。"""
    from agentflow.verifiers.registry import is_registered

    if is_registered(verifier or ""):
        reason = ui_declaration_reason(verifier, cmd)
        return (False, reason) if reason else (True, "")
    reason = prose_reason(cmd)
    if reason:
        hint = ui_hint(verifier, cmd)
        return False, reason + (f"。{hint}" if hint else "")
    return probe_command(cmd, shell)


def probe_command(cmd: str, shell: str | None) -> tuple[bool, str]:
    """返回 (语法是否可用, 错误摘要)。非 powershell 命令本次跳过（只检最高频翻车面）。"""
    if (shell or "").lower() not in ("powershell", "pwsh"):
        return True, ""

    wrapper = (
        "$o=$null;$err=$null;"
        "[void][System.Management.Automation.Language.Parser]::ParseInput(@'\n" + cmd + "\n'@, [ref]$o, [ref]$err);"
        "if ($err) { Write-Output ('BAD::' + ($err -join ';;')); exit 3 }; exit 0"
    )
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command", wrapper],
            capture_output=True, text=True, timeout=20,
            encoding="utf-8", errors="replace",
        )
        if r.returncode != 0 or "BAD::" in (r.stdout or ""):
            return False, ((r.stdout or "").split("BAD::", 1)[-1] or (r.stderr or ""))[:400]
        return True, ""
    except Exception as e:
        return True, f"probe-unavailable: {e}"


_SRC_SUFFIXES = {".tsx", ".ts", ".jsx", ".js", ".vue", ".svelte", ".html", ".astro"}
_SKIP_DIRS = {".git", "node_modules", ".next", "out", "dist", "build", ".venv", "__pycache__"}




_DYNAMIC_TESTID_PREFIX = re.compile(
    r"""data-testid\s*=\s*\{\s*[`'"](?P<pre>[A-Za-z0-9_-]+)(?:\$\{|[`'"]?\s*\+)"""
)




def _stmt_is_assertive(cmd: str) -> bool:
    '''命令里是否有**断言语义**（不只是"执行/编译"，而是"判定"）。'''
    c = cmd or ""
    if re.search(r"\b(pytest|unittest|jest|vitest|mocha)\b", c, re.I):
        return True
    if re.search(r"\b(assert|expect)\w*\b", c, re.I):
        return True

    if re.search(r"-(?:eq|ne|gt|ge|lt|le|match|notmatch|contains|notcontains)\b", c, re.I) and "exit 1" in c:
        return True

    if re.search(r"\bcurl\b|\bInvoke-WebRequest\b|\biwr\b", c, re.I):
        if re.search(r"\bgrep\b.*-q|-Quiet|\bTest-\w+|exit\s+1", c, re.I):
            return True
    return False


def _ui_decl_has_assertion(cmd: str) -> bool:
    '''ui 声明里是否含**行为型断言**动作（相对"存在性查询"而言）。'''
    try:
        obj = json.loads(cmd or "{}")
    except Exception:
        return False
    if any(p.get("assert_selected_count") for p in obj.get("pages") or []):
        return True
    for page in obj.get("pages") or []:
        for a in page.get("actions") or []:
            if not isinstance(a, dict):
                continue
            if any(str(k).startswith("assert_") for k in a):
                return True
    return False



_DOC_PATH = re.compile(r"(^|/)(docs?|README|CHANGELOG)|\.md$", re.I)


def _is_doc_feature(feature) -> bool:
    """纯文档 feature：全部 file_scope 都落在文档类路径上。"""
    scope = getattr(feature, "file_scope", None)
    if not scope:
        return False
    try:
        files = json.loads(scope) if isinstance(scope, str) else list(scope)
    except Exception:
        return False
    if not files:
        return False
    return all(_DOC_PATH.search(str(f).replace("\\", "/")) for f in files)


def behavior_coverage_reason(cmds: list[dict], feature, repo_root=None) -> str:
    """行为覆盖判据（**硬拦档**）：本功能的验收里**连一条内容断言都没有**。"""
    if _is_doc_feature(feature):
        return ""
    if _is_ops_feature(feature):
        return ""
    cmds = cmds or []
    if not cmds:
        return ""
    if has_content_assertion(cmds):
        return ""

    if not _has_only_exec_or_pathcheck(cmds):
        return ""
    sample = (cmds[0].get("cmd", "") or "").strip()[:150]
    return (
        f"本功能 {len(cmds)} 条命令**没有一条断言内容或运行结果**（例如 `{sample}`）——"
        "它们只是执行/构建/编译或检查文件是否存在。"
        "「编译通过」「文件在」都无法证明需求被实现，等于没有验收。"
        "请至少补一条内容断言："
        "① `Select-String`/`grep` 断言文件里出现本功能新增/搬移后的结构或文案；"
        "② 或测试/脚本断言具体状态变化；"
        "③ 或 ui 声明里加 assert_* 动作。"
    )



_CONTENT_ASSERT = re.compile(
    r"Select-String|\bgrep\b|\bfindstr\b|\bfind\s+/|"
    r"\b(pytest|unittest|jest|vitest|mocha)\b|"
    r"\b(assert|expect)\w*\b|"
    r"-(?:eq|ne|gt|ge|lt|le|match|notmatch|contains|notcontains)\b|"
    r"-notmatch|-match\b|"
    r"\bGet-Content\b|"
    r"\bcurl\b|\bInvoke-WebRequest\b|\biwr\b",
    re.I,
)


_EXEC_ONLY = re.compile(
    r"^\s*(?:cd\s+\S+[;&]+\s*)*"
    r"(?:npx\s+tsc|tsc\s+--noEmit|npm\s+run|npm\s+install|npm\s+i\b|yarn\b|pnpm\b|"
    r"node\s|python\s+-m\s+(?!pytest)|pip\s+install|"
    r"\./sop\.(?:ps1|sh)|sop\.(?:ps1|sh))",
    re.I,
)





_OPS_FEATURE = re.compile(
    r"诊断|排查|巡检|重启|重启后|修复|恢复|运维|部署|发布|上线|回滚|停服|启动服务|拉起",
    re.I,
)


def has_content_assertion(cmds: list[dict]) -> bool:
    '''整批命令里是否至少有**一条**在断言"文件内容"或"运行结果"。'''
    for v in cmds or []:
        cmd = (v.get("cmd", "") or "")
        if _CONTENT_ASSERT.search(cmd):
            return True
    return False


def _has_only_exec_or_pathcheck(cmds: list[dict]) -> bool:
    """整批是否只由"纯执行/构建" + "纯路径存在性"组成（无任何内容断言）。"""
    for v in cmds or []:
        cmd = (v.get("cmd", "") or "").strip()
        if not cmd:
            continue
        if _EXEC_ONLY.search(cmd):
            continue

        if re.search(r"Test-Path", cmd, re.I) and not re.search(r"-Pattern|-match|Get-Content", cmd, re.I):
            continue
        if re.search(r"\b(test|\[)\s+-[efd]\s", cmd) and not _CONTENT_ASSERT.search(cmd):
            continue
        return False
    return True


def behavior_coverage_hint(cmds: list[dict], feature, repo_root=None) -> str:
    '''**提示档**（不阻断）：需求语义属"交互行为"类，但断言全是字面检查。'''
    if not behavior_demands_assertion(feature):
        return ""
    cmds = cmds or []
    if not cmds or not has_content_assertion(cmds):
        return ""
    for v in cmds:
        verifier = (v.get("verifier") or "").strip().lower()
        cmd = v.get("cmd", "") or ""
        if verifier == "ui":
            if _ui_decl_has_assertion(cmd):
                return ""
            continue
        if _stmt_is_assertive(cmd):
            return ""
    return (
        f"提示（不阻断）：本功能要求的是**交互行为**（{_behavior_hint(feature)}），"
        "但现有断言只有字面/结构检查，**没有一条断言交互后的状态变化**。"
        "字面存在 ≠ 行为正确——若条件允许，建议补一条行为断言"
        "（ui 声明加 assert_style/assert_count/assert_text，或脚本断言滚动/点击后的实际状态）。"
    )



_BEHAVIOR_INTENT = re.compile(
    r"滚动|滚轮|横向滚|拖动|拖拽|点击|单击|双击|悬停|hover|滑|touch|手势|"
    r"展开|收起|折叠|切换|跳转|路由|导航|"
    r"过滤|筛选|排序|搜索|检索|分页|加载更多|"
    r"多选|单选|勾选|取消选中|"
    r"输入|填写|提交|保存后|回车|键盘|快捷键|"
    r"实时|动态|响应式|自适应|联动|同步后|自动更新|"
    r"动画|过渡|渐入|淡出|"
    r"scroll|wheel|drag|click|hover|toggle|filter|sort|input",
    re.I,
)










_STRUCTURAL_ACTION = re.compile(
    r"移入|移出|移动到|移至|搬移|位置调整|调整.*位置|"
    r"替换|替换为|改为|改成|收口|统一收口|抽成|抽取|提取为|封装为|"
    r"对齐|靠右|靠左|同行|上移|下移|左移|右移|置灰|"
    r"去掉|移除|新增|添加|补上|插入|"
    r"重命名|改名|迁移|"
    r"启用|禁用(?!.*(点击|点击后))",
    re.I,
)


_NON_BEHAVIOR_INTENT = re.compile(
    r"文档|docs?/|readme|changelog|说明|注释|"
    r"启动.*服务|dev\s*服务|构建|build|部署|打包|"
    r"排查|诊断|调研|分析|统计|列出|梳理|"
    r"清理|类型检查|tsc|lint|格式化",
    re.I,
)


def _is_ops_feature(feature) -> bool:
    '''诊断/运维类 feature：动作本身即产出，不适用"内容断言"要求。'''
    text = " ".join(
        str(x) for x in (
            getattr(feature, "title", "") or "",
            getattr(feature, "description", "") or "",
        ) if x
    )
    return bool(_OPS_FEATURE.search(text))


def behavior_demands_assertion(feature) -> bool:
    """该 feature 的需求语义是否**倾向**要求行为断言（供提示档使用，不做硬拦）。"""
    text = " ".join(
        str(x) for x in (
            getattr(feature, "title", "") or "",
            getattr(feature, "description", "") or "",
        ) if x
    )
    if not text.strip():
        return False
    if _NON_BEHAVIOR_INTENT.search(text):
        return False
    if _STRUCTURAL_ACTION.search(text):
        return False
    if _BEHAVIOR_INTENT.search(text):
        return True
    return False


def _behavior_hint(feature) -> str:
    """给出命中的行为特征词，让打回理由可证可复核。"""
    text = " ".join(
        str(x) for x in (
            getattr(feature, "title", "") or "",
            getattr(feature, "description", "") or "",
        ) if x
    )
    hits = list({m.group(0) for m in _BEHAVIOR_INTENT.finditer(text)})
    return "、".join(hits[:4]) if hits else "交互类"





_EARLY_RETURN = re.compile(
    r"if\s*\([^)]{0,120}\)\s*(?:\{\s*)?return\s+(?:null|<>|\(\)|false)",
    re.I | re.S,
)


def _hosts_of_testid(tid: str, repo_root) -> list[tuple[str, int, str]]:
    '''定位**所有**含 `data-testid="<tid>"` 的宿主源码文件，返回 [(相对路径, 行号, 该行)]。'''
    pat = re.compile(rf"""data-testid\s*=\s*['"`]?{re.escape(tid)}['"`]?""")
    root = Path(str(repo_root))
    found: list[tuple[str, int, str]] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for fn in filenames:
            if os.path.splitext(fn)[1].lower() not in _SRC_SUFFIXES:
                continue
            fp = Path(dirpath) / fn
            try:
                lines = fp.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for i, line in enumerate(lines, 1):
                if pat.search(line):
                    try:
                        rel = str(fp.relative_to(root)).replace("\\", "/")
                    except ValueError:
                        rel = str(fp)
                    found.append((rel, i, line.strip()))
    return found


def unreachable_testids(cmd: str, repo_root) -> list[str]:
    '''ui 声明引用的 testid 是否**可达**（不只是"存在"）。'''
    if not repo_root:
        return []
    ids = set(re.findall(r"data-testid\s*=\s*([A-Za-z0-9_-]+)", cmd or ""))
    if not ids:
        return []
    out: list[str] = []
    for tid in sorted(ids):
        hosts = _hosts_of_testid(tid, repo_root)
        if not hosts:
            continue
        for rel, lineno, _line in hosts:
            try:
                src = (Path(str(repo_root)) / rel).read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            m = _EARLY_RETURN.search(src)
            if m:
                snippet = " ".join(m.group(0).split())[:120]
                out.append(
                    f"[data-testid={tid}] 宿主 {rel}:{lineno} 所在组件存在**早退条件**"
                    f"（`{snippet}`）：该条件下组件整体不渲染，选择器必然不可达。"
                    "ui 声明需补**前置动作**（先切到满足渲染条件的 tab/状态）再断言，"
                    "或改用在该上下文下恒定渲染的锚点；否则机审将超时失败。"
                )
    return out


def missing_testids(cmd: str, repo_root) -> list[str]:
    '''提取 ui 声明里引用的 `[data-testid=X]`，返回在仓库源码里找不到对应 `data-testid="X"` 的 X。'''
    ids = set(re.findall(r"data-testid\s*=\s*([A-Za-z0-9_-]+)", cmd or ""))
    if not ids:
        return []
    root = str(repo_root)
    present: set[str] = set()
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for fn in filenames:
            if os.path.splitext(fn)[1].lower() not in _SRC_SUFFIXES:
                continue
            try:
                with open(os.path.join(dirpath, fn), encoding="utf-8", errors="replace") as fh:
                    txt = fh.read()
            except OSError:
                continue
            prefixes = {m.group("pre") for m in _DYNAMIC_TESTID_PREFIX.finditer(txt)}
            for tid in ids - present:
                if re.search(rf"""data-testid\s*=\s*\{{?\s*['"`]?{re.escape(tid)}['"`]?""", txt):
                    present.add(tid)
                elif any(tid.startswith(p) for p in prefixes):
                    present.add(tid)
            if present == ids:
                break
        if present == ids:
            break
    return sorted(ids - present)


def _planned_new_testids(spec_yaml: str, names: list[str]) -> list[str]:
    """names 里哪些在 Spec YAML 的**非 ui 声明行**被提到（= 本功能明确要新增的锚点）。"""
    lines = [ln for ln in (spec_yaml or "").splitlines() if "start_cmd" not in ln]
    return [n for n in names if any(n in ln for ln in lines)]




def _norm_route(u: object) -> str:
    """ui 声明里的 url → 归一化路由（去 query/fragment、补前导 /、去尾 /；根为 "/"）。"""
    from urllib.parse import urlparse

    try:
        path = urlparse(str(u or "").strip()).path or "/"
    except ValueError:
        path = str(u or "/").strip() or "/"
    if not path.startswith("/"):
        path = "/" + path
    return path.rstrip("/") or "/"


def _scope_page_routes(file_scope_raw: object) -> dict[str, str]:
    """feature.file_scope(JSON) → {路由: 页面文件}，只取**静态路由页面**（防误报的保守口径）。"""
    from agentflow.core.repomap import route_of

    out: dict[str, str] = {}
    try:
        items = json.loads(file_scope_raw or "[]")
    except Exception:
        return out
    if not isinstance(items, list):
        return out
    for it in items:
        p = str(it or "").replace("\\", "/").strip()
        if not p or any(ch in p for ch in "*?{}[]$"):
            continue
        route = route_of(p)
        if route:
            out.setdefault(route, p)
    return out


def _collect_ui_decl_routes(cmd: str, out: set[str]) -> None:
    """收集一条 ui 声明 JSON 里已声明页面的归一化路由（坏 JSON/结构由 check_command 负责报）。"""
    try:
        obj = json.loads(cmd or "{}")
    except Exception:
        return
    if not isinstance(obj, dict):
        return
    for pg in obj.get("pages") or []:
        if isinstance(pg, dict) and str(pg.get("url") or "").strip():
            out.add(_norm_route(pg.get("url")))


def scope_ui_coverage_findings(scope_rows: list[dict], decl_routes: set[str]) -> list[dict]:
    '''任务级对账：写集内静态路由页面必须被 ui 声明覆盖——"改了哪些页面"与"验了哪些页面"对账。'''
    gaps: dict[int, dict] = {}
    declared = decl_routes or set()
    for row in scope_rows or []:
        for route in sorted((row.get("pages") or {}).keys()):
            if route in declared:
                continue
            g = gaps.setdefault(int(row.get("seq") or 0), {
                "title": row.get("title") or "", "routes": [], "hint_worthy": False,
            })
            g["routes"].append(route)
            g["hint_worthy"] = g["hint_worthy"] or bool(row.get("hint_worthy"))
    has_decl = bool(decl_routes)
    out: list[dict] = []
    for seq, g in sorted(gaps.items()):
        if not has_decl and not g["hint_worthy"]:
            continue
        routes = g["routes"]
        shown = "、".join(routes[:8]) + (f" 等 {len(routes)} 个" if len(routes) > 8 else "")
        entry: dict = {"feature": seq, "title": g["title"], "index": 0, "cmd": "（写集↔ui 声明覆盖对账）"}
        if has_decl:
            entry["error"] = (
                f"写集内静态路由页面 {shown} 未被本任务任何 ui 声明覆盖——ui 机审只验 pages 中"
                "声明过的页面，同批被改的其余页面会静默漏验。请在 ui 声明 pages 里补上这些页面"
                "（用例可比照已声明的页面）；若为**有意抽样**（同构重构只验代表页），请在对应 "
                "feature 描述中写明抽样策略与理由。"
            )
        else:
            entry["advisory"] = True
            entry["error"] = (
                f"写集含静态路由页面 {shown}（需求属交互/行为类），但本任务没有任何 ui 机审"
                "声明——建议补一条 ui 声明覆盖可见行为改动；若不适用可忽略本提示。"
            )
        out.append(entry)
    return out





_MODULE_SPEC = re.compile(r"""(?:from|import)\s*\(?\s*['"]([^'"]+)['"]""", re.I)

_GENERIC_STEMS = {"index", "main", "types", "utils", "helpers", "constants", "layout", "page"}


def _scope_impact_modules(scope_raw: object) -> dict[str, str]:
    """file_scope(JSON) → {模块 stem: 写集内非页面源码文件}（供反查引用页）。"""
    from agentflow.core.repomap import route_of

    out: dict[str, str] = {}
    try:
        items = json.loads(scope_raw or "[]")
    except Exception:
        return out
    if not isinstance(items, list):
        return out
    for it in items:
        p = str(it or "").replace("\\", "/").strip()
        if not p or any(ch in p for ch in "*?{}[]$"):
            continue
        if os.path.splitext(p)[1].lower() not in (".tsx", ".ts", ".jsx", ".js"):
            continue
        if route_of(p):
            continue
        stem = os.path.splitext(os.path.basename(p))[0]
        if len(stem) < 3 or stem.lower() in _GENERIC_STEMS:
            continue
        out.setdefault(stem, p)
    return out


def _referencing_page_routes(stems: dict[str, str], repo_root) -> dict[str, list[str]]:
    """反查：哪些**页面文件** import 了这些模块（一层引用，静态启发式，忽略传递闭包）。"""
    from agentflow.core.repomap import route_of

    found: dict[str, list[str]] = {}
    if not repo_root or not stems:
        return found
    root = str(repo_root)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for fn in filenames:
            if os.path.splitext(fn)[1].lower() not in (".tsx", ".ts", ".jsx", ".js"):
                continue
            fp = os.path.join(dirpath, fn)
            rel = os.path.relpath(fp, root).replace("\\", "/")
            route = route_of(rel)
            if not route:
                continue
            try:
                with open(fp, encoding="utf-8", errors="replace") as fh:
                    text = fh.read()
            except OSError:
                continue
            if not any(s in text for s in stems):
                continue
            for m in _MODULE_SPEC.finditer(text):
                base = m.group(1).replace("\\", "/").rstrip("/").rsplit("/", 1)[-1]
                if base in stems:
                    found.setdefault(base, [])
                    if route not in found[base]:
                        found[base].append(route)
    return found


def scope_ui_impact_findings(
    ref_pages: dict[str, list[str]], impact_meta: dict[str, dict], scope_routes: set[str], decl_routes: set[str]
) -> list[dict]:
    """影响面 advisory（不阻断）：写集内共享模块的**引用页面**中，写集外且未被 ui 声明覆盖的。"""
    declared = decl_routes or set()
    in_scope = scope_routes or set()
    by_feat: dict[int, dict] = {}
    for stem, routes in (ref_pages or {}).items():
        meta = impact_meta.get(stem) or {}
        seq = int(meta.get("seq") or 0)
        g = by_feat.setdefault(seq, {"title": meta.get("title") or "", "mods": set(), "routes": set()})
        g["mods"].add(stem)
        g["routes"].update(routes)
    out: list[dict] = []
    for seq, g in sorted(by_feat.items()):
        uncovered = sorted(r for r in g["routes"] if r not in declared and r not in in_scope)
        if not uncovered:
            continue
        mods = "、".join(sorted(g["mods"])[:6])
        shown = "、".join(uncovered[:8]) + (f" 等 {len(uncovered)} 个" if len(uncovered) > 8 else "")
        out.append({
            "feature": seq, "title": g["title"], "index": 0, "advisory": True,
            "cmd": "（写集外影响面对账）",
            "error": (
                f"写集内共享模块 {mods} 被以下页面直接引用，且它们不在本任务的 ui 声明覆盖内: {shown}——"
                "若本改动可能波及这些页面的渲染/行为，建议一并验证；确不影响可忽略本提示。"
            ),
        })
    return out


def ui_coverage_summary(features: list) -> str:
    """任务级验收覆盖摘要（一行，供合并门禁/人审时间线）：写集页面 N、ui 声明覆盖 M、未覆盖清单。"""
    scope: set[str] = set()
    decl: set[str] = set()
    for f in features or []:
        scope.update(_scope_page_routes(getattr(f, "file_scope", None)).keys())
        for v in json_cmds(getattr(f, "verify_commands", None)):
            if (v.get("verifier") or "").strip().lower() == "ui":
                _collect_ui_decl_routes(v.get("cmd", ""), decl)
    if not scope:
        return ""
    covered = len([r for r in scope if r in decl])
    gaps = sorted(r for r in scope if r not in decl)
    line = f"验收覆盖摘要：写集页面 {len(scope)} 个，ui 声明覆盖 {covered} 个"
    if gaps:
        line += "，未覆盖 " + "、".join(gaps[:8]) + (f" 等 {len(gaps)} 个" if len(gaps) > 8 else "")
    else:
        line += "（全覆盖 ✓）"
    return line


def probe_spec_verify_commands(session: Session, task_id: int) -> list[dict]:
    """自检本任务**最新一轮** Spec 的全部 verify 命令。返回 [{feature, index, cmd, error}]（空=全过）。"""
    spec = session.exec(select(m.Spec).where(m.Spec.task_id == task_id).order_by(m.Spec.id.desc())).first()
    if spec is None:
        return []
    task = session.get(m.Task, task_id)
    project = session.get(m.Project, task.project_id) if task and task.project_id else None
    repo_root = getattr(project, "repo_path", None)
    bad: list[dict] = []
    scope_rows: list[dict] = []
    decl_routes: set[str] = set()
    impact_meta: dict[str, dict] = {}
    for f in session.exec(select(m.Feature).where(m.Feature.spec_id == spec.id)).all():
        cmds = json_cmds(f.verify_commands)
        pages = _scope_page_routes(getattr(f, "file_scope", None))
        if pages:
            scope_rows.append({
                "seq": f.seq, "title": f.title, "pages": pages,

                "hint_worthy": behavior_demands_assertion(f),
            })
        for stem, path in _scope_impact_modules(getattr(f, "file_scope", None)).items():
            impact_meta.setdefault(stem, {"path": path, "seq": f.seq, "title": f.title})
        for i, v in enumerate(cmds):
            ok, err = check_command(v.get("verifier", ""), v.get("cmd", ""), v.get("shell", ""))
            if not ok:
                bad.append({"feature": f.seq, "title": f.title, "index": i, "cmd": v.get("cmd", ""), "error": err})
                continue

            if (v.get("verifier", "") or "").strip().lower() == "ui":
                _collect_ui_decl_routes(v.get("cmd", ""), decl_routes)

            dir_reason = smoke_direction_reason(
                v.get("verifier", ""), v.get("classification_hint", ""), v.get("cmd", ""), f.title, repo_root
            )
            if dir_reason:
                bad.append({"feature": f.seq, "title": f.title, "index": i, "cmd": v.get("cmd", ""), "error": dir_reason})
                continue

            if (v.get("verifier", "").strip().lower() == "ui") and repo_root:
                miss = missing_testids(v.get("cmd", ""), repo_root)




                if miss:
                    _planned = _planned_new_testids(getattr(spec, "yaml_raw", "") or "", miss)
                    miss = [t for t in miss if t not in _planned]
                if miss:
                    bad.append({
                        "feature": f.seq, "title": f.title, "index": i, "cmd": v.get("cmd", ""),
                        "error": (
                            f"ui 声明引用的 data-testid 在仓库中不存在: {miss}。"
                            "要么改用真实存在的选择器，要么把「加该 testid」写成本功能明确的实现改动。"
                        ),
                    })


                unreach = unreachable_testids(v.get("cmd", ""), repo_root)
                for ur in unreach:
                    bad.append({
                        "feature": f.seq, "title": f.title, "index": i, "cmd": v.get("cmd", ""),
                        "error": ur,
                    })




        coverage = behavior_coverage_reason(cmds, f, repo_root)
        if coverage:
            bad.append({
                "feature": f.seq, "title": f.title, "index": 0,
                "cmd": "（整批断言）", "error": coverage,
            })

        hint = behavior_coverage_hint(cmds, f, repo_root)
        if hint:
            bad.append({
                "feature": f.seq, "title": f.title, "index": 0,
                "cmd": "（整批断言·提示）", "error": hint, "advisory": True,
            })

        indistinct = smoke_indistinct_reason(cmds, repo_root)
        if indistinct:
            bad.append({
                "feature": f.seq, "title": f.title, "index": 0,
                "cmd": "（整批 light 断言）", "error": indistinct,
            })

    bad.extend(scope_ui_coverage_findings(scope_rows, decl_routes))

    if impact_meta and repo_root:
        ref = _referencing_page_routes({s: meta["path"] for s, meta in impact_meta.items()}, repo_root)
        scope_all_routes = {r for row in scope_rows for r in row["pages"]}
        bad.extend(scope_ui_impact_findings(ref, impact_meta, scope_all_routes, decl_routes))
    return bad


def split_probe_results(results: list[dict]) -> tuple[list[dict], list[dict]]:
    """把 probe 结果拆成 (阻断项, 提示项)。"""
    bad, adv = [], []
    for r in results or []:
        (adv if r.get("advisory") else bad).append(r)
    return bad, adv


def json_cmds(raw: str | None) -> list[dict]:
    try:
        return json.loads(raw or "[]")
    except Exception:
        return []
