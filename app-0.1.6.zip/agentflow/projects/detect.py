"""技术栈探测（FR0 接入向导）。"""

from __future__ import annotations

from pathlib import Path


def _find_pkg(root: Path) -> Path | None:
    """定位 package.json：根目录优先；缺失则探测一层子目录（常见布局：site/、web/、frontend/）。"""
    if (root / "package.json").exists():
        return root / "package.json"
    for p in sorted(root.glob("*/package.json")):
        if "node_modules" in p.parts or ".git" in p.parts:
            continue
        return p
    return None


def detect_stack(root: Path) -> dict:
    """探测语言/框架/构建/测试工具。返回 dict。"""
    stack: dict = {"languages": [], "frameworks": [], "build": [], "test": []}

    has = lambda name: (root / name).exists()

    pkg_path = _find_pkg(root)
    pkg_dir = pkg_path.parent if pkg_path else root


    if has("pyproject.toml") or has("requirements.txt") or has("setup.py"):
        stack["languages"].append("python")
    if pkg_path is not None:
        stack["languages"].append("javascript")
        if (pkg_dir / "tsconfig.json").exists() or has("tsconfig.json"):
            stack["languages"].append("typescript")
    if has("go.mod"):
        stack["languages"].append("go")
    if has("Cargo.toml"):
        stack["languages"].append("rust")


    pkg = _read_pkg(pkg_path) if pkg_path else {}
    if pkg:
        deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
        if "next" in deps:
            stack["frameworks"].append("next.js")
        if "react" in deps:
            stack["frameworks"].append("react")
        if "vite" in deps:
            stack["frameworks"].append("vite")
        if "fastapi" in deps or has("app/main.py") or has("server"):
            pass


    if has("tsconfig.json") or (pkg_dir / "tsconfig.json").exists():
        stack["build"].append("tsc")
    if has("pyproject.toml"):
        stack["build"].append("build")
    if pkg and pkg.get("scripts", {}).get("build"):
        stack["build"].append("npm-run-build")


    if has("tests") or has("test"):
        if "python" in stack["languages"]:
            stack["test"].append("pytest")
    if pkg:
        deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
        if "vitest" in deps or "jest" in deps or "playwright" in deps:
            stack["test"].append(pkg_test_framework(deps))

    return stack


def pkg_test_framework(deps: dict) -> str:
    for name in ("vitest", "jest", "playwright"):
        if name in deps:
            return name
    return ""


def _read_pkg(path: Path) -> dict:
    import json

    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
