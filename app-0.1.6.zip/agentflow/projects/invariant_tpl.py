"""不变量模板库（FR9 模板层）。"""

from __future__ import annotations

TEMPLATES: dict[str, list[str]] = {
    "next.js": [
        "颜色必须走配置文件，禁止硬编码色值",
        "组件手写，不使用 shadcn/ui",
        "样式使用 Tailwind 类，禁止内联 style 硬编码布局",
    ],
    "python": [
        "新增函数必须带类型注解",
        "公共函数必须写 docstring",
        "不允许打印调试日志混入业务代码（用 logger）",
    ],
    "typescript": [
        "新增导出必须带类型声明",
        "禁止使用 any",
        "错误处理必须显式，禁止静默吞异常",
    ],
    "default": [
        "改动必须保持现有项目约定（内部文档 优先）",
    ],
}


def suggest_invariants(stack: dict) -> list[str]:
    """按探测结果建议不变量草稿（接入向导带出）。"""
    out: list[str] = []
    if "next.js" in stack.get("frameworks", []):
        out += TEMPLATES["next.js"]
    if "typescript" in stack.get("languages", []):
        out += TEMPLATES["typescript"]
    if "python" in stack.get("languages", []):
        out += TEMPLATES["python"]
    if not out:
        out = list(TEMPLATES["default"])
    return out
