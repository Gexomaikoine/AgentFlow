"""Spec 轮次作用域：一个任务可以有多轮 Spec（每次「确认 Spec」追加一行、旧行不删），"""

from __future__ import annotations

from sqlmodel import Session, select

from agentflow.storage import models as m


def current_spec(session: Session, task_id: int) -> m.Spec | None:
    return session.exec(
        select(m.Spec).where(m.Spec.task_id == task_id).order_by(m.Spec.id.desc())
    ).first()


def current_features(session: Session, task_id: int) -> list[m.Feature]:
    """当前轮次的功能清单。无 Spec → 空列表（调用方须响亮处理，不得当成"没有活儿要干"放过）。"""
    spec = current_spec(session, task_id)
    if spec is None:
        return []
    return session.exec(
        select(m.Feature).where(m.Feature.spec_id == spec.id).order_by(m.Feature.seq)
    ).all()
