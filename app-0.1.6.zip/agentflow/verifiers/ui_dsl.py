"""UI 机审声明（verifier=ui 的 cmd JSON）的词汇与结构规则（唯一真源）。"""

from __future__ import annotations


ACTION_KEYS = {
    "click", "fill", "wait", "screenshot",
    "expect_url", "expect_selector",
    "assert_selected", "assert_count", "assert_visible", "assert_hidden", "assert_text",
    "assert_style",
}

COMPANION_KEYS = {"expect_url", "expect_selector"}


PAGE_KEYS = {"url", "selectors", "actions", "assert_selected_count", "viewport"}

_SUPPORTED = (
    "click/fill/wait/screenshot/assert_selected/assert_count/assert_visible/assert_hidden/assert_text，"
    "伴随 click 的 expect_url/expect_selector"
)





GRAMMAR_HINT = (
    '声明格式：{"start_cmd":"<含 {port} 的启动命令>","port":"auto","pages":['
    '{"url":"/path","viewport":{"width":480,"height":900},"selectors":["<选择器>"],'
    '"actions":[{"wait":1200},{"click":"<选择器>"},'
    '{"assert_style":["<选择器>",{"flexWrap":"nowrap","overflowX":"auto"}]},'
    '{"screenshot":"名字"}]}]}。'
    "页级键只有 url / selectors / actions / viewport / assert_selected_count；"
    "动作键只有 click / fill / wait / screenshot / assert_selected / assert_count / "
    "assert_visible / assert_hidden / assert_text / assert_style"
    "（expect_url / expect_selector 只能作为 click 的伴随键同时出现，不能单独成动作）；"
    "列表型断言一律 [选择器, 期望值]（assert_style 的期望值是 CSS 属性对象）。未列出的键会响亮失败。"



    "**可达性硬规则**：断言不得依赖「默认筛选档 / 默认分页 / 列表非空」这类运行期数据状态。"
    "目标控件若只在某档位/某 tab/数据非空时才渲染，声明必须先用 click 切到**有数据的稳定档位**"
    "再 wait / 断言；否则一律改断言在该上下文恒定渲染的锚点。"
)


def _str_field(a: dict, key: str, j: int, problems: list[str]) -> None:
    """字符串类动作键的严格类型校验（必须是 str 且非空）。"""
    if key not in a:
        return
    v = a[key]
    if not isinstance(v, str) or not v.strip():
        problems.append(
            f"actions[{j}] {key} 需为选择器字符串（实际 {type(v).__name__}: {str(v)[:60]}）；"
            "多个选择器请拆成多条动作"
        )


def _check_action(j: int, a) -> list[str]:
    if not isinstance(a, dict) or not a:
        return [f"actions[{j}] 需为对象（如 {{\"click\": \"<选择器>\"}}）"]
    unknown = sorted(set(a) - ACTION_KEYS)
    if unknown:
        return [f"actions[{j}] 含未支持的键 {unknown}（受支持: {_SUPPORTED}）"]

    loners = sorted(set(a) & COMPANION_KEYS)
    if loners and "click" not in a:
        hint = "、".join(loners)
        alt = "assert_visible" if "expect_selector" in a else "assert_text"
        return [
            f"actions[{j}] {hint} 是 click 的伴随键，不能单独作为动作："
            f"请写成 {{\"click\": \"<选择器>\", \"{loners[0]}\": ...}}；"
            f"若本意是独立断言，请改用 {alt}（如 {{\"{alt}\": \"<选择器>\"}}）"
        ]
    problems: list[str] = []
    for key in ("click", "screenshot", "expect_url", "expect_selector", "assert_visible", "assert_hidden"):
        _str_field(a, key, j, problems)
    if "wait" in a:

        wv = a["wait"]
        if not isinstance(wv, (int, float)) and not (isinstance(wv, str) and wv.strip()):
            problems.append(f"actions[{j}] wait 需为选择器字符串或等待毫秒数（实际 {type(wv).__name__}）")
    if "fill" in a:
        fv = a["fill"]
        if not (isinstance(fv, (list, tuple)) and len(fv) == 2
                and isinstance(fv[0], str) and fv[0].strip()):
            problems.append(f'actions[{j}] fill 需为 [选择器, 文本]（实际 {str(fv)[:60]}）')
    if "assert_selected" in a:
        v = a["assert_selected"]
        if "click" not in a and not (isinstance(v, (list, tuple)) and len(v) == 2):
            problems.append(f"actions[{j}] 独立 assert_selected 需为 [选择器, true/false]")
    if "assert_count" in a:
        v = a["assert_count"]
        if not (isinstance(v, (list, tuple)) and len(v) == 2
                and isinstance(v[0], str) and v[0].strip()):
            problems.append(f"actions[{j}] assert_count 需为 [选择器, 数字]（实际 {str(v)[:60]}）")
    if "assert_text" in a:
        v = a["assert_text"]
        if not (isinstance(v, (list, tuple)) and len(v) == 2
                and isinstance(v[0], str) and v[0].strip()):
            problems.append(f"actions[{j}] assert_text 需为 [选择器, 文本]（实际 {str(v)[:60]}）")
    if "assert_style" in a:


        v = a["assert_style"]
        if not (
            isinstance(v, (list, tuple)) and len(v) == 2
            and isinstance(v[0], str) and v[0].strip()
            and isinstance(v[1], dict) and v[1]
            and all(isinstance(k, str) and k.strip() and isinstance(x, (str, int, float))
                    for k, x in v[1].items())
        ):
            problems.append(
                f'actions[{j}] assert_style 需为 [选择器, {{"css属性": "期望值", ...}}] '
                f"（实际 {str(v)[:80]}）"
            )
    return problems


def declaration_problems(obj) -> list[str]:
    """结构校验：返回问题清单（空 = 结构合法）。文案直接指导重写。"""
    if not isinstance(obj, dict):
        return ["声明需为 JSON 对象"]
    problems: list[str] = []
    pages = obj.get("pages")
    if not isinstance(pages, list) or not pages:
        return ["声明缺 pages（需为 [{url, selectors, actions}] 列表，至少一页）"]
    for i, pg in enumerate(pages):
        if not isinstance(pg, dict):
            problems.append(f"pages[{i}] 需为对象（url/selectors/actions）")
            continue
        unknown = sorted(set(pg) - PAGE_KEYS)
        if unknown:
            problems.append(
                f"pages[{i}] 含未支持的页级键 {unknown}"
                f"（受支持: url/selectors/actions/assert_selected_count；"
                "选中态断言用 assert_selected_count 或 actions 里的 assert_selected）"
            )
        if "url" in pg and not str(pg["url"] or "").strip():
            problems.append(f"pages[{i}] url 为空")
        vp = pg.get("viewport")
        if vp is not None:
            ok_vp = (
                isinstance(vp, dict)
                and not (set(vp) - {"width", "height"})
                and all(
                    isinstance(vp.get(k), int) and not isinstance(vp.get(k), bool) and vp.get(k) > 0
                    for k in ("width", "height")
                )
            )
            if not ok_vp:
                problems.append(
                    f'pages[{i}] viewport 需为 {{"width": <正整数>, "height": <正整数>}}'
                    f"（实际 {str(vp)[:60]}）；用于验证**窄视口**行为（如"
                    "『本行塞不下时不换行、改横向滚动』——1440 宽下塞得下，永远测不出这类缺陷）"
                )
        selectors = pg.get("selectors")
        if selectors is not None:
            if not isinstance(selectors, list) or any(not str(x or "").strip() for x in selectors):
                problems.append(
                    f'pages[{i}] selectors 需为选择器字符串列表（如 ["table"]）'
                )
        actions = pg.get("actions")
        if actions is not None:
            if not isinstance(actions, list):
                problems.append(f"pages[{i}] actions 需为动作对象列表")
            else:
                for j, a in enumerate(actions):
                    problems.extend(_check_action(j, a))
        asc = pg.get("assert_selected_count")
        if asc is not None and not (isinstance(asc, (list, tuple)) and len(asc) == 2):
            problems.append(f'pages[{i}] assert_selected_count 需为 [选择器, 数字]')
    return problems
