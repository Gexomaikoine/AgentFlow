"""UI 机审校验器（Playwright + 本机已装浏览器）：浏览器行为归约为命令式 exit code。"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path
from urllib.parse import urlparse

from agentflow.core.services import (
    HARNESS_MARK,
    ServiceError,
    acquire_service,
    parse_ui_review,
    resolve_ui_port,
    stop_service,
    touch_warm,
)
from agentflow.verifiers.base import Verifier, VerifierResult




from agentflow.verifiers.ui_dsl import ACTION_KEYS as _ACTION_KEYS
from agentflow.verifiers.ui_dsl import COMPANION_KEYS as _COMPANION_KEYS
from agentflow.verifiers.ui_dsl import PAGE_KEYS as _PAGE_KEYS


def _run_step(page, op: str, target: str, fn, steps: list, value: str | None = None) -> bool:
    """执行单步并记录 {op, target, value?, ok, ms, err?}；返回是否成功。"""
    t0 = time.monotonic()
    step: dict = {"op": op, "target": target[:200]}
    if value is not None:
        step["value"] = str(value)[:200]
    try:
        fn()
        step["ok"] = True
        ok = True
    except Exception as e:
        step["ok"] = False
        step["err"] = str(e)[:200]
        ok = False
    step["ms"] = int((time.monotonic() - t0) * 1000)
    steps.append(step)
    return ok


def _shot(page, evidence_dir: Path, name: str, steps: list) -> bool:
    """截图并记录步骤；返回是否成功。name 为相对 evidence_dir 的文件名。"""
    shot = evidence_dir / f"{name}.png"
    return _run_step(page, "screenshot", name, lambda: page.screenshot(path=str(shot), full_page=False), steps)


def attach_media(rep: dict | None, evidence_dir: Path, settings_home: Path) -> None:
    """report 的截图步骤补 media 相对路径（/api/v1/media 可服务，WebUI 页签出缩略图）。"""
    if not rep:
        return
    try:
        rel_base = evidence_dir.resolve().relative_to(Path(settings_home).resolve()).as_posix()
    except ValueError:
        return
    for pg in rep.get("pages") or []:
        for st in pg.get("steps") or []:
            if st.get("op") == "screenshot" and st.get("target"):
                st["media"] = f"{rel_base}/{st['target']}.png"





SELECTED_ATTR = "aria-pressed"

_UI_TIMEOUT_MS = 15_000

_DOM_MAX_BUTTONS = 14


def page_inventory(page) -> list[str]:
    """页面可见按钮清单（文本 + data-testid + 禁用态），失败证据用。"""
    out: list[str] = []
    try:
        items = page.locator("button, [role=button], a").all()[: _DOM_MAX_BUTTONS * 2]
        for el in items:
            try:
                if not el.is_visible():
                    continue
                text = " ".join((el.inner_text() or "").split())[:24]
                tid = el.get_attribute("data-testid") or ""
                dis = el.get_attribute("disabled") is not None


                marks = "".join([f"[data-testid={tid}]" if tid else "", "[disabled]" if dis else ""])
                out.append(f"{text}{(' ' + marks) if marks else ''}".strip() or tid)
            except Exception:
                continue
            if len(out) >= _DOM_MAX_BUTTONS:
                break
    except Exception:
        pass
    return out


def _push_step(steps: list, op: str, target: str, ok: bool, value=None, err: str | None = None) -> None:
    d: dict = {"op": op, "target": str(target)[:200], "ok": bool(ok), "ms": 0}
    if value is not None:
        d["value"] = str(value)[:200]
    if err:
        d["err"] = str(err)[:200]
    steps.append(d)


def _assert_selected(page, sel: str, want: bool, failures: list, steps: list, j: int) -> None:
    """断言 sel 的 aria-pressed == want（点击后的选中/反选断言）。"""
    try:
        got_raw = page.locator(sel).first.get_attribute(SELECTED_ATTR)
        ok = (got_raw == "true") == want
        err = None if ok else f"{SELECTED_ATTR}={got_raw!r}，期望 {'true' if want else 'false'}"
    except Exception as e:
        ok, err = False, str(e)[:150]
    _push_step(steps, "assert_selected", sel, ok, value="true" if want else "false", err=err)
    if not ok:
        failures.append(f"[action {j}] 断言失败: {sel} 选中态应为 {want}（{err}）")


def _assert_count(page, sel: str, n: int, failures: list, steps: list, j: int) -> None:
    try:
        cnt = page.locator(sel).count()
        ok, err = cnt == n, (None if cnt == n else f"实际 {cnt} 个")
    except Exception as e:
        ok, err = False, str(e)[:150]
    _push_step(steps, "assert_count", sel, ok, value=n, err=err)
    if not ok:
        failures.append(f"[action {j}] 断言失败: {sel} 期望 {n} 个元素（{err}）")


def _assert_visible(page, sel: str, want: bool, failures: list, steps: list, j: int) -> None:
    op = "assert_visible" if want else "assert_hidden"
    try:
        vis = page.locator(sel).first.is_visible()
        ok, err = vis == want, (None if vis == want else f"visible={vis}")
    except Exception as e:
        ok, err = False, str(e)[:150]
    _push_step(steps, op, sel, ok, err=err)
    if not ok:
        failures.append(f"[action {j}] 断言失败: {sel} 应{'可见' if want else '不可见'}（{err}）")


def _assert_text(page, sel: str, want: str, failures: list, steps: list, j: int) -> None:
    try:
        txt = page.locator(sel).first.inner_text()
        ok, err = want in txt, (None if want in txt else f"实际文本 {txt[:80]!r}")
    except Exception as e:
        ok, err = False, str(e)[:150]
    _push_step(steps, "assert_text", sel, ok, value=want, err=err)
    if not ok:
        failures.append(f"[action {j}] 断言失败: {sel} 文本应含 {want!r}（{err}）")


def _two(a, key: str, conv, failures: list, steps: list, j: int) -> tuple | None:
    """取 [x, y] 形状的参数；非法则记失败并返回 None。"""
    v = a[key]
    if isinstance(v, (list, tuple)) and len(v) == 2:
        try:
            return (str(v[0]), conv(v[1]))
        except (TypeError, ValueError):
            pass
    failures.append(f"[action {j}] 非法 {key}（需 [selector, 值]）")
    steps.append({"op": "invalid", "target": str(v)[:100], "ok": False, "ms": 0,
                  "err": f"非法 {key} 形状"})
    return None


def _bad_string(key: str, v, j: int, failures: list, steps: list) -> bool:
    """字符串类键的执行前类型防御：非字符串/空值 → 清晰失败。"""
    if isinstance(v, str) and v.strip():
        return False
    failures.append(
        f"[action {j}] {key} 值非法（需为选择器字符串，实际 {type(v).__name__}: {str(v)[:80]}）"
    )
    steps.append({"op": "invalid", "target": str(v)[:100], "ok": False, "ms": 0,
                  "err": f"{key} 非字符串选择器"})
    return True


def _style_value_matches(prop: str, want, got: str) -> bool:
    """计算样式值比对：字符串精确匹配；px 数值容忍 ±1px 渲染误差"""
    w, g = str(want).strip(), str(got).strip()
    if w.lower() == g.lower():
        return True
    m_w, m_g = re.fullmatch(r"(-?[\d.]+)px", w), re.fullmatch(r"(-?[\d.]+)px", g)
    if m_w and m_g:


        return abs(float(m_w.group(1)) - float(m_g.group(1))) <= 0.5
    return False


def _assert_style(page, sel: str, expected: dict, failures: list, steps: list, j: int) -> None:
    """计算样式断言：视觉规格（圆角/尺寸/字号）的机器验收。"""
    t0 = time.monotonic()
    expr = (
        "(el, exp) => { const cs = getComputedStyle(el);"
        " return Object.fromEntries(Object.keys(exp).map(k => [k, String(cs[k])])) }"
    )
    try:
        actual = page.locator(sel).first.evaluate(expr, expected)
    except Exception as e:
        failures.append(f"[action {j}] assert_style 读取样式失败: {sel}（{type(e).__name__}: {str(e)[:120]}）")
        steps.append({"op": "assert_style", "target": sel, "ok": False, "ms": 0,
                      "err": str(e)[:120]})
        return
    mismatches = {
        k: f"期望 {want}，实际 {actual.get(k, '(无该属性)')}"
        for k, want in expected.items()
        if not _style_value_matches(k, want, str(actual.get(k, "")))
    }
    ok = not mismatches
    steps.append({
        "op": "assert_style", "target": sel, "ok": ok,
        "ms": int((time.monotonic() - t0) * 1000),
        "expected": expected, "actual": actual,
    })
    if not ok:
        detail = "；".join(f"{k}: {v}" for k, v in list(mismatches.items())[:4])
        failures.append(f"[action {j}] 样式断言失败: {sel}（{detail}）")


def _run_actions(page, actions: list, failures: list, steps: list, evidence_dir: Path) -> None:
    """逐个执行动作/断言（声明式，代码执行；失败进 failures 归约 exit code）。"""
    for j, a in enumerate(actions or []):
        if not isinstance(a, dict) or not a:
            failures.append(f"[action {j}] 非法 action（需为对象: click/fill/wait/screenshot/assert_*）")
            steps.append({"op": "invalid", "target": str(a)[:100], "ok": False, "ms": 0,
                          "err": "非法 action 形状"})
            continue
        unknown = sorted(set(a) - _ACTION_KEYS)
        if unknown:
            failures.append(f"[action {j}] 未支持的断言/动作键 {unknown}（机审不静默忽略断言）")
            steps.append({"op": "invalid", "target": str(a)[:100], "ok": False, "ms": 0,
                          "err": f"未知键 {unknown}"})
            continue

        typed_bad = False
        for key in ("click", "screenshot", "expect_url", "expect_selector", "assert_visible", "assert_hidden"):
            if key in a and _bad_string(key, a[key], j, failures, steps):
                typed_bad = True
        if typed_bad:
            continue
        if "click" in a:
            sel = a["click"].strip()
            ok = _run_step(page, "click", sel, lambda s=sel: page.locator(s).first.click(timeout=_UI_TIMEOUT_MS), steps)
            if not ok:
                failures.append(f"[action {j}] 点击失败: {sel}")
            if ok and a.get("expect_url"):
                exp = a["expect_url"].strip()
                ok2 = _run_step(
                    page, "expect_url", exp,
                    lambda e=exp: page.wait_for_url(lambda u, e=e: e in str(u), timeout=_UI_TIMEOUT_MS), steps)
                if not ok2:
                    failures.append(f"[action {j}] 点击后未跳转到预期地址（URL 需含 {exp}，实际 {page.url[:150]}）")
            if ok and a.get("expect_selector"):
                sel2 = a["expect_selector"].strip()
                ok2 = _run_step(page, "expect_selector", sel2,
                                lambda s=sel2: page.locator(s).first.wait_for(state="visible", timeout=_UI_TIMEOUT_MS), steps)
                if not ok2:
                    failures.append(f"[action {j}] 点击后元素未出现: {sel2}")
            if ok and "assert_selected" in a:
                _assert_selected(page, sel, bool(a["assert_selected"]), failures, steps, j)
        elif "fill" in a:
            fv = a["fill"]
            if not (isinstance(fv, (list, tuple)) and len(fv) == 2
                    and isinstance(fv[0], str) and fv[0].strip()):
                failures.append(f"[action {j}] 非法 fill（需 [selector, text]）")
                steps.append({"op": "invalid", "target": str(fv)[:100], "ok": False, "ms": 0,
                              "err": "非法 fill 形状"})
                continue
            sel, text = fv[0].strip(), str(fv[1])
            ok = _run_step(page, "fill", sel, lambda s=sel, t=text: page.locator(s).first.fill(t, timeout=_UI_TIMEOUT_MS),
                           steps, value=text)
            if not ok:
                failures.append(f"[action {j}] 填表失败: {sel}")
        elif "wait" in a:
            wv = a["wait"]


            if isinstance(wv, (int, float)) or (isinstance(wv, str) and wv.strip().isdigit()):
                ms = float(wv)
                ok = _run_step(page, "wait", f"{ms:g}ms", lambda m=ms: page.wait_for_timeout(m), steps)
                if not ok:
                    failures.append(f"[action {j}] 等待中断: {ms:g}ms")
            elif isinstance(wv, str) and wv.strip():
                sel = wv.strip()
                ok = _run_step(page, "wait", sel,
                               lambda s=sel: page.locator(s).first.wait_for(state="visible", timeout=_UI_TIMEOUT_MS), steps)
                if not ok:
                    failures.append(f"[page] 等待选择器不可见: {sel}")
            else:
                failures.append(
                    f"[action {j}] wait 值非法（需为选择器字符串或等待毫秒数，实际 {type(wv).__name__}: {str(wv)[:60]}）"
                )
                steps.append({"op": "invalid", "target": str(wv)[:100], "ok": False, "ms": 0,
                              "err": "wait 值非法"})
        elif "screenshot" in a:
            name = a["screenshot"].strip().replace("\\", "_").replace("/", "_") or "shot"
            if not _shot(page, evidence_dir, name, steps):
                failures.append(f"[action {j}] 截图失败: {name}")
        elif "assert_selected" in a:
            two = _two(a, "assert_selected", lambda v: bool(v), failures, steps, j)
            if two:
                _assert_selected(page, two[0], two[1], failures, steps, j)
        elif "assert_count" in a:
            two = _two(a, "assert_count", int, failures, steps, j)
            if two:
                _assert_count(page, two[0], two[1], failures, steps, j)
        elif "assert_visible" in a:
            _assert_visible(page, a["assert_visible"].strip(), True, failures, steps, j)
        elif "assert_hidden" in a:
            _assert_visible(page, a["assert_hidden"].strip(), False, failures, steps, j)
        elif "assert_text" in a:
            two = _two(a, "assert_text", str, failures, steps, j)
            if two:
                _assert_text(page, two[0], two[1], failures, steps, j)
        elif "assert_style" in a:
            two = _two(a, "assert_style", lambda v: v, failures, steps, j)
            if two and isinstance(two[1], dict):
                _assert_style(page, two[0], two[1], failures, steps, j)
        else:
            lone = sorted(set(a) & _COMPANION_KEYS)
            if lone:

                alt = "assert_visible" if "expect_selector" in a else "assert_text"
                failures.append(
                    f"[action {j}] {'、'.join(lone)} 是 click 的伴随键，不能单独作为动作："
                    f'请写成 {{"click": "<选择器>", "{lone[0]}": ...}}；独立断言请改用 {alt}'
                )
            else:
                failures.append(
                    f"[action {j}] 不支持的动作键: {list(a.keys())[:5]}"
                    "（受支持: click/fill/wait/screenshot/assert_*，expect_url 与 expect_selector 需伴随 click）"
                )
            steps.append({"op": "invalid", "target": str(a)[:100], "ok": False, "ms": 0,
                          "err": "不支持的动作键"})


def run_ui_checks(ui: dict, cwd: Path, evidence_dir: Path, label: str = "", report: bool = False):
    """执行 UI 机审检查集，返回命令式结果（exit 0=通过 / 1=失败，output=证据摘要）。"""
    start = time.monotonic()
    base = f"http://127.0.0.1:{int(ui['port'])}"
    failures: list[str] = []
    pages_report: list[dict] = []
    evidence_dir.mkdir(parents=True, exist_ok=True)

    def _finish() -> VerifierResult | tuple:
        duration = int((time.monotonic() - start) * 1000)
        pages_n = len(ui.get("pages") or [])
        rules = (f"console_block={bool(ui.get('console_block', True))}, "
                 f"http_max_code={int(ui.get('http_max_code') or 399)}, "
                 f"选择器/动作超时=5s")
        if failures:


            harness = any(
                f.startswith(("[service]", "[browser]")) or HARNESS_MARK in f for f in failures
            )
            output = "UI 机审失败:\n" + "\n".join(failures[:10]) + f"\n（截图证据: {evidence_dir}）"
            if harness:
                output = f"{HARNESS_MARK} " + output
            rep = {
                "pages": pages_report,
                "failures": failures[:30],
                "verdict": f"失败: {len(failures)} 项硬证据未过（规则: {rules}）",
                "config": {"console_block": bool(ui.get("console_block", True)),
                           "http_max_code": int(ui.get("http_max_code") or 399),
                           "channel": str(ui.get("channel") or "")},
            }
            res = VerifierResult(verifier="ui", cmd=label or "[ui]", exit_code=1,
                                 output=output[:4000], duration_ms=duration,
                                 classification=("harness" if harness else "blocking"))
        else:
            output = f"UI 机审通过: {pages_n} 页检查全过（console/HTTP/选择器/动作断言），证据: {evidence_dir}"
            rep = {
                "pages": pages_report,
                "failures": [],
                "verdict": f"通过: {pages_n} 页全部检查过（规则: {rules}）",
                "config": {"console_block": bool(ui.get("console_block", True)),
                           "http_max_code": int(ui.get("http_max_code") or 399),
                           "channel": str(ui.get("channel") or "")},
            }
            res = VerifierResult(verifier="ui", cmd=label or "[ui]", exit_code=0,
                                 output=output[:4000], duration_ms=duration, classification=None)
        return (res, rep) if report else res

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        res = VerifierResult(
            verifier="ui", cmd=label or "[ui]",
            exit_code=1,
            output=f"{HARNESS_MARK} UI 机审依赖未安装：pip install -e \".[ui]\"（playwright）",
            duration_ms=0, classification="harness",
        )



        return (res, None) if report else res
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(channel=str(ui.get("channel") or "msedge"))
            try:
                ctx = browser.new_context(viewport={"width": 1440, "height": 900})
                page = ctx.new_page()
                console_errors: list[str] = []
                bad_responses: list[str] = []
                allow_hosts = set(ui.get("allow_hosts") or [])
                max_code = int(ui.get("http_max_code") or 399)


                ignore = set(ui.get("ignore_paths") or ["/favicon.ico"])

                if ui.get("console_block", True):
                    page.on("console", lambda m: console_errors.append(m.text[:200])
                            if m.type == "error" else None)
                    page.on("pageerror", lambda e: console_errors.append(f"pageerror: {str(e)[:200]}"))
                page.on("response", lambda r: bad_responses.append(f"{r.status} {r.url[:150]}")
                        if r.status >= max_code and (not allow_hosts or urlparse(r.url).hostname in allow_hosts)
                        and urlparse(r.url).path not in ignore
                        else None)

                for i, pg in enumerate(ui.get("pages") or []):
                    url = pg.get("url") or "/"
                    ce_start, br_start = len(console_errors), len(bad_responses)
                    page_steps: list[dict] = []
                    page_failures: list[str] = []
                    if not isinstance(pg, dict):
                        failures.append(f"[page {i}] 非法 page（需为对象: url/selectors/actions/assert_selected_count）")
                        continue
                    unknown_pg = sorted(set(pg) - _PAGE_KEYS)
                    if unknown_pg:
                        page_failures.append(
                            f"[page {url}] 未支持的页级键 {unknown_pg}（机审不静默忽略断言，"
                            "可用 assert_selected / assert_count / assert_selected_count）"
                        )



                    vp = pg.get("viewport")
                    if isinstance(vp, dict) and vp.get("width") and vp.get("height"):
                        try:
                            page.set_viewport_size(
                                {"width": int(vp["width"]), "height": int(vp["height"])}
                            )
                            page_steps.append({"op": "viewport", "target": f'{vp["width"]}x{vp["height"]}', "ok": True, "ms": 0})
                        except Exception as e:
                            page_failures.append(f"[page {url}] 设置视口失败: {e}")
                    if not _run_step(page, "goto", url,
                                     lambda u=f"{base}{url}": page.goto(u, wait_until="domcontentloaded", timeout=30_000),
                                     page_steps):
                        page_failures.append(f"[page {url}] 页面加载失败")
                    else:




                        try:
                            page.wait_for_load_state("networkidle", timeout=10_000)
                        except Exception:
                            pass
                    for sel in (pg.get("selectors") or []):
                        if not _run_step(page, "wait", sel,
                                         lambda s=sel: page.locator(s).first.wait_for(state="visible", timeout=_UI_TIMEOUT_MS),
                                         page_steps):
                            page_failures.append(f"[page {url}] 选择器不可见: {sel}")
                    try:
                        _run_actions(page, pg.get("actions"), page_failures, page_steps, evidence_dir)
                    except Exception as e:
                        page_failures.append(f"[page {url}] 动作执行异常: {str(e)[:150]}")

                    asc = pg.get("assert_selected_count")
                    if asc is not None:
                        if isinstance(asc, (list, tuple)) and len(asc) == 2:
                            asel = str(asc[0])
                            try:
                                an = int(asc[1])
                                total = page.locator(asel).count()
                                got_n = sum(
                                    1 for k in range(total)
                                    if page.locator(asel).nth(k).get_attribute(SELECTED_ATTR) == "true"
                                )
                                ok_a, err_a = got_n == an, (None if got_n == an else f"实际 {got_n} 个选中")
                            except Exception as e:
                                ok_a, err_a = False, str(e)[:150]
                            _push_step(page_steps, "assert_selected_count", asel, ok_a, value=asc[1], err=err_a)
                            if not ok_a:
                                page_failures.append(f"[page {url}] 断言失败: {asel} 选中数应为 {asc[1]}（{err_a}）")
                        else:
                            page_failures.append(f"[page {url}] 非法 assert_selected_count（需 [selector, 数字]）")
                    shot_name = f"page{i}_{url.strip('/').replace('/', '_') or 'index'}"
                    if not _shot(page, evidence_dir, shot_name, page_steps):
                        page_failures.append(f"[page {url}] 截图失败")
                    inv = page_inventory(page) if page_failures else []
                    if inv:





                        page_failures.append(
                            f"[page {url}] 页面可见控件（当前状态快照）: {' | '.join(inv)}"
                            "（目标控件不在清单里时，先排查是否漏了导航动作——如先 click 承载它的页签）"
                        )

                    failures.extend(page_failures)


                    page_console = [
                        e for e in console_errors[ce_start:]
                        if not e.startswith("Failed to load resource")
                        and not any(p in e for p in ignore)
                    ]
                    page_bad = bad_responses[br_start:]
                    pages_report.append({
                        "url": url, "ok": not page_failures,
                        "steps": page_steps,
                        "dom": inv,
                        "console_errors": page_console[:20],
                        "bad_responses": page_bad[:20],
                        "failures": page_failures[:20],
                    })




                console_errors = [
                    e for e in console_errors
                    if not e.startswith("Failed to load resource")
                    and not any(p in e for p in ignore)
                ]
                if ui.get("console_block", True) and console_errors:
                    failures.append(f"[console] {len(console_errors)} 个错误: {'; '.join(console_errors[:5])}")
                if bad_responses:
                    failures.append(f"[http] {len(bad_responses)} 个响应 ≥ {max_code}: {'; '.join(bad_responses[:5])}")
            finally:
                browser.close()
    except ServiceError as e:
        failures.append(f"[service] {e}")
    except Exception as e:

        failures.append(f"[browser] {str(e)[:300]}（channel={ui.get('channel')}，需本机已装对应浏览器）")

    return _finish()


class UiVerifier(Verifier):
    """UI 机审：cmd 为 JSON 检查声明（与 project config ui_review 同构）。"""

    name = "ui"

    def run(self, cmd: str, cwd: Path, timeout: int = 120, shell: str | None = None) -> VerifierResult:
        from agentflow.config import Settings


        try:
            import playwright
        except ImportError:
            return VerifierResult(
                verifier="ui", cmd="[ui]", exit_code=1,
                output=f"{HARNESS_MARK} UI 机审依赖未安装：pip install -e \".[ui]\"（playwright）",
                duration_ms=0, classification="harness",
            )
        spec = dict(cmd) if isinstance(cmd, dict) else dict(_loads(cmd))
        spec["enabled"] = True
        try:
            ui = resolve_ui_port(parse_ui_review({"ui_review": spec}))
        except ServiceError as e:
            return VerifierResult(
                verifier="ui", cmd="[ui]", exit_code=1,
                output=f"{HARNESS_MARK} UI 机审无法启动：{e}",
                duration_ms=0, classification="harness",
            )

        evidence_dir = Settings.load().home / "screenshots" / "verifier-direct"
        label = f"[ui] port={ui['port']} channel={ui.get('channel')}"
        handle = None
        warm = False
        try:
            handle, warm = acquire_service(ui, Path(cwd))
        except ServiceError as e:
            return VerifierResult(
                verifier="ui", cmd=label, exit_code=1,
                output=str(e), duration_ms=0, classification="harness",
            )
        try:
            result, rep = run_ui_checks(ui, Path(cwd), evidence_dir, label=label, report=True)
        finally:
            if warm:
                touch_warm(handle)
            else:
                stop_service(handle)


        if rep:
            attach_media(rep, evidence_dir, Settings.load().home)
            result.detail = json.dumps(rep, ensure_ascii=False)[:20000]
        return result


def _loads(cmd: str) -> dict:
    try:
        return json.loads(cmd) if isinstance(cmd, str) and cmd.strip().startswith("{") else {}
    except Exception:
        return {}


from agentflow.verifiers import registry as _registry

_registry.register("ui", UiVerifier)
