'''验收声明**强度对比**（P0，2026-09-29）：防"自动重写把验收改弱"。'''

from __future__ import annotations

import json


_ASSERT_RANK = {
    "assert_text": 3,
    "assert_style": 3,
    "assert_count": 2,
    "assert_selected": 2,
    "assert_visible": 1,
    "assert_hidden": 1,
}
_WEAK_RANK = 1


def _as_decl(obj) -> dict | None:
    """接受 dict 或 JSON 字符串；解析不了返回 None（预检是增强，不因解析失败阻断）。"""
    if isinstance(obj, str):
        try:
            obj = json.loads(obj)
        except (ValueError, TypeError):
            return None
    return obj if isinstance(obj, dict) else None


def _sel_of(value) -> str:
    """从断言值里取目标选择器：列表型取 [0]，字符串型取自身。"""
    if isinstance(value, (list, tuple)) and value:
        return str(value[0] or "").strip()
    return str(value or "").strip() if isinstance(value, str) else ""


def ui_strength(decl) -> dict:
    """把一份 ui 声明压成可比较的强度特征（断言目标 → 最强档、页面集合、条数）。"""
    d = _as_decl(decl) or {}
    pages: set[str] = set()
    by_target: dict[str, int] = {}
    keys_by_target: dict[str, set[str]] = {}
    style_props: dict[str, int] = {}
    count = 0
    for pg in d.get("pages") or []:
        if not isinstance(pg, dict):
            continue
        url = str(pg.get("url") or "").strip()
        if url:
            pages.add(url)
        for a in pg.get("actions") or []:
            if not isinstance(a, dict):
                continue
            for key, rank in _ASSERT_RANK.items():
                if key not in a:
                    continue
                sel = _sel_of(a[key])
                if not sel:
                    continue
                count += 1
                by_target[sel] = max(by_target.get(sel, 0), rank)
                keys_by_target.setdefault(sel, set()).add(key)
                if key == "assert_style" and isinstance(a[key], (list, tuple)) and len(a[key]) == 2 \
                        and isinstance(a[key][1], dict):
                    style_props[f"{sel}|{key}"] = len(a[key][1])
    return {"pages": pages, "by_target": by_target, "keys": keys_by_target,
            "style_props": style_props, "count": count}


def compare_ui(old, new) -> tuple[list[str], list[str]]:
    """新旧 ui 声明强度对比。返回 (bad, advisory)：bad 非空应拒绝写回，advisory 只留痕。"""
    so, sn = ui_strength(old), ui_strength(new)
    if not so["by_target"] and not so["pages"]:
        return [], []
    bad: list[str] = []
    adv: list[str] = []


    for target, rank in sorted(so["by_target"].items()):
        if rank <= _WEAK_RANK:
            continue
        new_rank = sn["by_target"].get(target)
        old_keys = "/".join(sorted(so["keys"].get(target) or []))
        if new_rank is None:
            adv.append(f"断言目标已移除：{target}（原 {old_keys}）")
            continue
        if new_rank <= _WEAK_RANK:
            new_keys = "/".join(sorted(sn["keys"].get(target) or []))
            bad.append(f"断言降级：{target} 由 {old_keys} 降为 {new_keys}（只剩存在性判定）")


    if so["pages"] and sn["pages"] and sn["pages"] < so["pages"]:
        bad.append("页面覆盖缩小：声明不再覆盖 " + "、".join(sorted(so["pages"] - sn["pages"])))


    if not bad and sn["count"] < so["count"]:
        adv.append(f"断言条数减少：{so['count']} → {sn['count']}")


    for k, c in sorted(so["style_props"].items()):
        nc = sn["style_props"].get(k)
        if nc is not None and nc < c:
            adv.append(f"样式断言属性减少：{k} {c} → {nc} 项")
    return bad, adv


def find_ui_decl(verify_commands_raw) -> dict | None:
    """从 feature.verify_commands（JSON 列表）里取 ui 项的声明对象。无 → None。"""
    try:
        cmds = json.loads(verify_commands_raw or "[]")
    except (ValueError, TypeError):
        return None
    if not isinstance(cmds, list):
        return None
    for c in cmds:
        if isinstance(c, dict) and str(c.get("verifier") or "").strip().lower() == "ui":
            return _as_decl(c.get("cmd"))
    return None


def gate_ui_rewrite(old_raw, new_decl) -> str | None:
    """写入点守卫：新声明相对旧声明是否**弱化**。返回拒绝理由文本（None = 放行）。"""
    old = find_ui_decl(old_raw) if not isinstance(old_raw, dict) else _as_decl(old_raw)
    bad, _adv = compare_ui(old, new_decl)
    if not bad:
        return None
    return "（强度哨兵）" + "；".join(bad[:3]) + "。若确为修正，请保持原断言强度或补上等价断言后重写"
