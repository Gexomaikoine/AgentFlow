"""Spec 期 ui 声明**实测预检**的数据层（P0，2026-09-27）。"""
from __future__ import annotations

import json
import re
from pathlib import Path

DIRNAME = "preflight"


def report_path(home, tid: int, spec_id: int) -> Path:
    return Path(str(home)) / DIRNAME / f"task_{tid}_spec{spec_id}.json"


def save_report(home, tid: int, spec_id: int, report: dict) -> Path:
    p = report_path(home, tid, spec_id)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
    return p


def load_report(home, tid: int) -> dict | None:
    """取本任务 spec_id 最大的一份报告（无则 None）。读失败/损坏一律 None（预检是增强）。"""
    d = Path(str(home)) / DIRNAME
    if not d.is_dir():
        return None
    best: tuple[int, Path] | None = None
    for p in d.glob(f"task_{tid}_spec*.json"):
        m = re.search(r"spec(\d+)\.json$", p.name)
        if not m:
            continue
        sid = int(m.group(1))
        if best is None or sid > best[0]:
            best = (sid, p)
    if best is None:
        return None
    try:
        data = json.loads(best[1].read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


_REACHABILITY_HINTS = (
    "不可见", "未找到", "找不到", "超时", "等待选择器", "不在 dom", "未渲染",
    "not found", "no element", "timeout", "unreachable", "not visible", "no node",
)


def reachability_failures(fail_items: list[dict]) -> list[str]:
    """只保留**元素级不可达**类失败的 target（P0 判据，2026-09-27）。"""
    out: list[str] = []
    for it in fail_items or []:
        err = str(it.get("err") or "").lower()
        target = str(it.get("target") or "")
        if target and any(h in err for h in _REACHABILITY_HINTS):
            out.append(target)
    return list(dict.fromkeys(out))


def parse_verifier_report(result) -> tuple[list[str], list[str], list[dict]]:
    """从 VerifierResult.detail 抽（失败步骤 target 列表, 页面可见控件快照, 失败明细 [{target, err}]）。"""
    fail_targets: list[str] = []
    fail_items: list[dict] = []
    snapshot: list[str] = []
    try:
        rep = json.loads(getattr(result, "detail", "") or "{}")
    except (json.JSONDecodeError, TypeError):
        rep = {}
    for pg in (rep.get("pages") or []):
        for st in (pg.get("steps") or []):
            if not st.get("ok") and st.get("target"):
                fail_targets.append(str(st["target"]))
                fail_items.append({"target": str(st["target"]), "err": str(st.get("err") or "")})
        dom = pg.get("dom")
        if dom:
            snapshot.extend(str(x) for x in dom)
    if not fail_targets:

        for m in re.finditer(r"\[action \d+\][^\n]*?[:：]\s*(\S[^\n（(]*)", getattr(result, "output", "") or ""):
            t = m.group(1).strip()
            fail_targets.append(t)
            fail_items.append({"target": t, "err": m.group(0)})
    if not snapshot and getattr(result, "output", ""):

        for line in str(result.output).splitlines():
            if "页面可见控件" not in line:
                continue
            body = line.split(":", 1)[-1]
            snapshot.extend(p.strip() for p in body.split("|") if p.strip())
            break
    dedup: list[str] = []
    for t in fail_targets:
        if t not in dedup:
            dedup.append(t)
    return dedup[:20], snapshot[:40], fail_items[:40]


def format_feedback(report: dict, max_len: int = 1600) -> str:
    """把实测报告格式化成**可回灌**的证据文本（Spec 作者重生成 / 开发节点提示词共用一份口径）。"""
    out = (report.get("output") or "").strip()
    snapshot = report.get("snapshot") or []
    candidates = ""
    if snapshot:
        items = [str(x).strip() for x in snapshot if str(x).strip()]
        items = [it for it in items if not it.startswith("（")][:12]
        if items:
            candidates = (
                "\n实测快照里的可见控件（**前置 click 只能从这里挑，禁止凭空发明控件名/文案**）：\n"
                + "\n".join(f"- {it}" for it in items)
                + "\n"
            )
    return (
        "本功能 ui 声明已在**当前基线仓库实测**跑过同一套机审（提前跑，避免烧掉整个开发周期后才发现"
        "声明打不中控件）。实测输出：\n"
        f"{out[:max_len]}\n"
        f"{candidates}"
        "\n改写要求（硬性，逐条照做）：\n"
        '1. actions 的**第一个动作必须是 click**，目标取自上面「可见控件」清单：'
        '条目里带 `[data-testid=…]` 的直接用它；只有文本的写成 `{"click": "button:has-text(\\"<条目文本>\\")"}`'
        "（Playwright 选择器语法）。\n"
        '2. 紧接着 `{"wait": "<目标选择器>"}`，确认目标控件已被 click 唤出。\n'
        "3. 然后才写 assert_* 断言。\n"
        "4. 在没有任何前置 click 之前直接断言目标选择器 = 必然超时失败，不要这么写；"
        "也不要把断言页换成另一个同样会命中早退条件的页面。\n"
        "5. **禁止依赖「默认档位/默认筛选/数据条数」的渲染**：数据是时间相关的（演示数据可能早于"
        "「今日」档 → 列表被筛空 → 控件条件渲染为 null）。要断言就先用 click 切到**有数据的稳定档位**"
        "（如「近一月」），或改断言在该上下文恒定渲染的锚点。\n"
    )


def dev_hint(home, tid: int, max_len: int = 1200) -> str:
    """给开发节点（Lead 直做/developer）的**环境事实**注入块（无报告返回空串）。"""
    rep = load_report(home, tid)
    if not rep:
        return ""
    head = (
        "## ui 机审环境事实（Spec 期实测预检产物，**直接采信，勿重复探索**）\n"
        "本功能的 ui 声明已在基线仓库实测跑过一次，结果："
        + ("通过 ✓" if rep.get("ok") else "未通过 ✗")
        + "\n"
    )
    reach = reachability_failures(rep.get("fail_items") or [])
    if reach:
        head += "**元素级不可达**（基线已知事实，实现/自测时优先关注）：\n" + "\n".join(
            f"- {t}" for t in reach[:8]
        ) + "\n"
        return head + format_feedback(rep, max_len=max_len)
    others = [str(t) for t in (rep.get("fail_targets") or [])][:8]
    if others:
        head += (
            "基线未命中的目标（多为「新行为尚未实现」的预期失败，**不要据此改写声明**，"
            "照 Spec 实现即可）：\n" + "\n".join(f"- {t}" for t in others) + "\n"
        )
    return head
