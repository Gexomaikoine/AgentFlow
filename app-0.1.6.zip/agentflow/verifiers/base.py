"""校验器基类与注册表（插件式）。判定依据 exit code。"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from agentflow.safety.command import run_command


@dataclass
class VerifierResult:
    verifier: str
    cmd: str
    exit_code: int
    output: str
    duration_ms: int = 0
    classification: str | None = None
    detail: str | None = None


class Verifier:
    """校验器 = 包 CLI 的命令适配器。子类实现 name/run。"""

    name = "base"

    def run(self, cmd: str, cwd: Path, timeout: int = 120, shell: str | None = None) -> VerifierResult:
        """执行命令，按 exit code 判定。"""
        import re
        import sys
        import time

        cmd = re.sub(r"(?<![\w.-])(python|python3)(?=\s)", _quote(sys.executable), cmd)
        start = time.monotonic()
        exit_code, output = run_command(cmd, cwd, timeout, shell=shell)
        duration = int((time.monotonic() - start) * 1000)
        return VerifierResult(
            verifier=self.name,
            cmd=cmd,
            exit_code=exit_code,
            output=output,
            duration_ms=duration,
        )


class BuiltinVerifier(Verifier):
    """通用 CLI 校验器：name 即 CLI 类型，命令由 Spec 提供。"""

    def __init__(self, name: str):
        self.name = name


def _quote(p: str) -> str:
    import shlex

    return shlex.quote(p.replace("\\", "/"))
