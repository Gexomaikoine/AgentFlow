"""内置校验器构造器：typecheck / build / test / smoke / noop。"""

from __future__ import annotations

from agentflow.verifiers.base import BuiltinVerifier


def verifier_for(name: str) -> BuiltinVerifier:
    """按名字构造内置校验器（校验器 = 通用 CLI 适配，name 用于 trace/展示）。"""
    return BuiltinVerifier(name)



def suggest_commands(stack: str) -> list[dict]:
    """根据技术栈探测结果建议校验命令（FR0 接入向导）。"""
    s = stack.lower()
    if "python" in s or "pyproject" in s or "requirements" in s:
        return [{"verifier": "pytest", "cmd": "python -m pytest tests/ -q", "timeout": 120, "classification_hint": "blocking"}]
    if "next" in s or "typescript" in s or "node" in s:
        return [
            {"verifier": "typecheck", "cmd": "tsc --noEmit", "timeout": 120, "classification_hint": "blocking"},
            {"verifier": "build", "cmd": "npm run build", "timeout": 180, "classification_hint": "blocking"},
        ]
    return [{"verifier": "noop", "cmd": "python -c \"print('ok')\"", "timeout": 30, "classification_hint": "blocking"}]
