"""校验器注册表：名字 → 构造器。插件可在 registry.register 挂载。"""

from __future__ import annotations

from agentflow.verifiers.base import Verifier
from agentflow.verifiers.builtin import verifier_for

_REGISTRY: dict[str, type[Verifier] | object] = {}


def register(name: str, factory) -> None:
    _REGISTRY[name] = factory


def get_verifier(name: str) -> Verifier:
    """返回一个 Verifier 实例。已注册名 → 真实校验器；其余 → 通用 shell 适配器。"""
    if name in _REGISTRY:
        factory = _REGISTRY[name]
        return factory() if callable(factory) else factory
    return verifier_for(name)


def is_registered(name: str) -> bool:
    """该名字是否有真实校验器实现（False = 会走通用 shell 适配器）。"""
    return name in _REGISTRY


def available() -> list[str]:
    return ["typecheck", "build", "test", "smoke", "noop", *_REGISTRY.keys()]









from agentflow.verifiers import ui as _ui
