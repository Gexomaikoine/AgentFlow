"""AgentFlow CLI（typer）。与 REST 同构，直接操作 engine（无 HTTP）。"""

from __future__ import annotations

import asyncio
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import typer
import uvicorn

from agentflow.config import Settings
from agentflow.storage.db import create_db_engine
from agentflow.storage import models as m
from sqlmodel import Session, select

app = typer.Typer(add_completion=False, help="AgentFlow 执行面 CLI")


def _ctx():
    settings = Settings.load()
    engine = create_db_engine(settings)
    return settings, engine


def _delete_guard_warning() -> str | None:
    """检测本进程是否带着沙箱「批量删除守卫」启动（sitecustomize 注入）。命中返回证据串。"""
    import os
    import sys

    hints: list[str] = []
    for name in ("sitecustomize", "usercustomize"):
        mod = sys.modules.get(name)
        if mod is None:
            continue
        src = getattr(mod, "__file__", "") or "(未知来源)"
        hints.append(f"{name} → {src}")
    rm = getattr(os, "remove", None)


    mod_name = getattr(rm, "__module__", "os") if rm is not None else ""
    if rm is not None and mod_name not in ("os", "nt", "posix"):
        hints.append(f"os.remove 已被替换为 {mod_name}.{getattr(rm, '__name__', '?')}")
    return "；".join(hints) if hints else None



@app.command()
def serve(
    host: str = typer.Option(None, help="监听地址（默认取 config）"),
    port: int = typer.Option(None, help="端口（默认取 config）"),
    open_browser: bool = typer.Option(
        True,
        "--open/--no-open",
        help="就绪后打开浏览器直连控制台（带 token 引导）；开机自启/无桌面环境请用 --no-open",
    ),
):
    """启动执行面常驻服务（Web UI 客户端）。"""
    settings, _ = _ctx()
    from agentflow.api.auth import ensure_token

    tok = ensure_token(settings)
    h = host or settings.data["server"]["host"]
    p = port or settings.data["server"]["port"]
    guard = _delete_guard_warning()
    if guard:
        typer.secho(
            "⚠️  检测到沙箱「批量删除守卫」已注入本进程：\n"
            f"    {guard}\n"
            "    后果：GitPython 提交、worktree 清理等正常操作一旦单次删除 >50 个文件，\n"
            "    守卫会 raise SystemExit(1) 直接打死执行面（BaseException，业务 try/except 拦不住），\n"
            "    表现为服务静默消失、且可能残留 index.lock 锁死后续所有 git 操作。\n"
            "    修复：停服后 `unset PYTHONPATH` 再启动本命令。",
            fg=typer.colors.YELLOW,
        )
    typer.echo(f"AgentFlow Executor: http://{h}:{p}  token: ~/.agentflow/token")
    from agentflow.api.app import create_app



    if open_browser and h in ("127.0.0.1", "localhost", "::1"):
        _open_browser_when_ready(f"http://127.0.0.1:{p}/?token={tok}", p)
        typer.echo("控制台即将自动打开（未打开：访问上面地址，token 见 ~/.agentflow/token）")
    uvicorn.run(create_app(settings), host=h, port=p)


def _open_browser_when_ready(url: str, port: int, timeout_s: float = 30.0) -> None:
    """后台等执行面就绪再打开浏览器（打开过早会看到"连不上"，观感差）。"""
    import threading
    import urllib.request
    import webbrowser

    def _worker() -> None:
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{port}/api/v1/health", timeout=1).read()
                break
            except Exception:
                time.sleep(0.3)
        try:
            webbrowser.open(url)
        except Exception:
            pass

    threading.Thread(target=_worker, daemon=True, name="agentflow-open-browser").start()



@app.command("project-add")
def project_add(name: str, path: str):
    """注册项目（自动探测技术栈）。"""
    _, engine = _ctx()
    from agentflow.projects.registry import register_project

    with Session(engine) as s:
        p = register_project(s, name, path)
        typer.echo(f"项目已注册: id={p.id} name={p.name} stack={p.stack}")


@app.command("project-scan")
def project_scan(name: str):
    """技术栈探测 → 校验器/不变量草稿。"""
    _, engine = _ctx()
    with Session(engine) as s:
        p = s.exec(select(m.Project).where(m.Project.name == name)).first()
        if not p:
            typer.echo("项目不存在", err=True)
            raise typer.Exit(1)
        from agentflow.projects.invariant_tpl import suggest_invariants
        from agentflow.verifiers.builtin import suggest_commands

        stack = json.loads(p.stack)
        typer.echo("技术栈: " + json.dumps(stack, ensure_ascii=False))
        typer.echo("校验器草稿: " + json.dumps(suggest_commands(json.dumps(stack)), ensure_ascii=False))
        typer.echo("不变量草稿: " + "\n  - ".join([""] + suggest_invariants(stack)))


@app.command("project-confirm-wizard")
def project_confirm_wizard(name: str):
    """确认向导草稿生效（写回项目 config + 不变量）。"""
    _, engine = _ctx()
    with Session(engine) as s:
        p = s.exec(select(m.Project).where(m.Project.name == name)).first()
        if not p:
            typer.echo("项目不存在", err=True)
            raise typer.Exit(1)
        from agentflow.projects.invariant_tpl import suggest_invariants
        from agentflow.verifiers.builtin import suggest_commands

        stack = json.loads(p.stack)
        cfg = json.loads(p.config) if p.config else {}
        cfg["verifiers"] = suggest_commands(json.dumps(stack))
        p.config = json.dumps(cfg, ensure_ascii=False)
        for text in suggest_invariants(stack):
            if not s.query(m.Invariant).filter(m.Invariant.project_id == p.id, m.Invariant.text == text).first():
                s.add(m.Invariant(project_id=p.id, layer=m.InvariantLayer.template, text=text))
        s.commit()
        typer.echo("向导已确认")


@app.command("project-list")
def project_list():
    _, engine = _ctx()
    with Session(engine) as s:
        for p in s.exec(select(m.Project)).all():
            typer.echo(f"{p.id}\t{p.name}\t{p.repo_path}")



@app.command("task-new")
def task_new(project: str, title: str, request: str = ""):
    """创建任务。"""
    _, engine = _ctx()
    from agentflow.git_runtime.repo import RepoHandle

    with Session(engine) as s:
        p = s.exec(select(m.Project).where(m.Project.name == project)).first()
        if not p:
            typer.echo("项目不存在", err=True)
            raise typer.Exit(1)
        repo = RepoHandle(p.repo_path)
        if not repo.is_clean():
            typer.echo("主 checkout 有未提交改动，拒绝创建任务（FR6）", err=True)
            raise typer.Exit(1)
        t = m.Task(project_id=p.id, title=title, raw_request=request or title)
        s.add(t)
        s.commit()
        typer.echo(f"任务已创建: id={t.id}")


@app.command("task-clarify")
def task_clarify(task_id: int, message: str = "开始澄清"):
    """澄清对话一轮。"""
    settings, engine = _ctx()
    from agentflow.llm.gateway import LLMGateway

    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        if not t:
            typer.echo("任务不存在", err=True)
            raise typer.Exit(1)
        from agentflow.agents.lead import clarify_round

        t.status = m.TaskStatus.clarifying
        s.commit()
        reply = clarify_round(LLMGateway(settings), s, t, message)
        typer.echo(reply)


@app.command("task-spec")
def task_spec(task_id: int):
    """查看当前 Spec。"""
    _, engine = _ctx()
    with Session(engine) as s:
        spec = s.exec(select(m.Spec).where(m.Spec.task_id == task_id).order_by(m.Spec.id.desc())).first()
        if not spec:
            typer.echo("尚无 Spec", err=True)
            raise typer.Exit(1)
        typer.echo(spec.yaml_raw)


@app.command("task-confirm")
def task_confirm(
    task_id: int,
    run: bool = typer.Option(False, "--run", help="Spec 生成后立即接续运行（等价前端「确认 Spec 并运行」，免二次点按）"),
):
    """签署 Spec（生成并落库）；加 --run 则一步跑到终态。"""
    settings, engine = _ctx()
    from agentflow.agents.lead import generate_spec
    from agentflow.llm.gateway import LLMGateway

    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        if not t:
            typer.echo("任务不存在", err=True)
            raise typer.Exit(1)
        p = s.get(m.Project, t.project_id)
        doc = generate_spec(LLMGateway(settings), s, t, p)
        spec = s.exec(select(m.Spec).where(m.Spec.task_id == task_id).order_by(m.Spec.id.desc())).first()
        if spec:
            spec.confirmed_at = datetime.now(timezone.utc).isoformat()
            s.add(spec)
        t.status = m.TaskStatus.spec_pending
        from agentflow.spec.schema import dump_spec

        typer.echo(f"Spec 已确认，功能数: {len(doc.features)}")
        typer.echo(dump_spec(doc))
        s.commit()
    if run:
        typer.echo("接续运行（--run，阻塞至终态）…")
        _run_task_blocking(settings, engine, task_id)


def _run_task_blocking(settings, engine, task_id: int) -> None:
    """本地阻塞跑任务（CLI 闭环共用：task-run / task-confirm --run）。"""
    from agentflow.core.events_bus import EventBus
    from agentflow.core.scheduler import TaskRunner
    from agentflow.llm.gateway import LLMGateway
    from agentflow.storage.events_log import EventLog

    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        if not t:
            typer.echo("任务不存在", err=True)
            raise typer.Exit(1)
        spec = s.exec(select(m.Spec).where(m.Spec.task_id == task_id).order_by(m.Spec.id.desc())).first()
        if not spec or not spec.confirmed_at:
            typer.echo("请先确认 Spec", err=True)
            raise typer.Exit(1)
        t.status = m.TaskStatus.running
        s.commit()

    gateway = LLMGateway(settings)
    bus = EventBus(EventLog(settings))
    runner = TaskRunner(engine, gateway, bus, settings, task_id)
    asyncio.run(runner.run())

    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        typer.echo(f"任务状态: {t.status.value}")


@app.command("task-run")
def task_run(task_id: int):
    """运行任务（单写闭环，阻塞至完成或停机）。"""
    settings, engine = _ctx()
    _run_task_blocking(settings, engine, task_id)


@app.command("task-status")
def task_status(task_id: int):
    _, engine = _ctx()
    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        if not t:
            typer.echo("任务不存在", err=True)
            raise typer.Exit(1)
        typer.echo(f"id={t.id} status={t.status.value} branch={t.branch}")
        feats = s.exec(select(m.Feature).where(m.Feature.task_id == task_id).order_by(m.Feature.seq)).all()
        for f in feats:
            typer.echo(f"  feature[{f.seq}] {f.title} → {f.status.value} (retry={f.retry_count})")
        anchors = s.exec(select(m.GreenAnchor).where(m.GreenAnchor.task_id == task_id)).all()
        for a in anchors:
            tag = " [已失效]" if a.invalidated_at else ""
            typer.echo(f"  anchor[{a.id}] {a.commit_hash[:8]} feature={a.feature_id}{tag}")


@app.command("task-graph")
def task_graph(task_id: int):
    """导出图谱快照（json）。"""
    _, engine = _ctx()
    from agentflow.api.routes.tasks import _synthesize_edges, _node_dto, _feature_dto, _anchor_dto

    with Session(engine) as s:
        nodes = s.exec(select(m.Node).where(m.Node.task_id == task_id).order_by(m.Node.seq)).all()
        feats = s.exec(select(m.Feature).where(m.Feature.task_id == task_id).order_by(m.Feature.seq)).all()
        anchors = s.exec(select(m.GreenAnchor).where(m.GreenAnchor.task_id == task_id)).all()
        typer.echo(json.dumps({
            "nodes": [_node_dto(n) for n in nodes],
            "edges": _synthesize_edges(nodes),
            "features": [_feature_dto(f) for f in feats],
            "anchors": [_anchor_dto(a) for a in anchors],
        }, ensure_ascii=False, indent=2))


@app.command("task-rollback")
def task_rollback(task_id: int, anchor: int):
    """回滚到指定绿点。"""
    _, engine = _ctx()
    from agentflow.git_runtime.repo import RepoHandle

    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        if not t:
            typer.echo("任务不存在", err=True)
            raise typer.Exit(1)
        a = s.get(m.GreenAnchor, anchor)
        if not a or a.task_id != task_id:
            typer.echo("锚点不存在", err=True)
            raise typer.Exit(1)
        p = s.get(m.Project, t.project_id)
        repo = RepoHandle(p.repo_path)
        try:
            repo.checkout(t.branch)
        except Exception:
            pass
        from agentflow.git_runtime import anchors as anchors_mod

        anchors_mod.rollback_task(s, repo, t, a)
        t.status = m.TaskStatus.spec_pending
        s.commit()
        typer.echo("已回滚")


@app.command("task-merge")
def task_merge(task_id: int):
    _, engine = _ctx()
    from agentflow.git_runtime.repo import RepoHandle

    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        if not t:
            typer.echo("任务不存在", err=True)
            raise typer.Exit(1)
        p = s.get(m.Project, t.project_id)
        repo = RepoHandle(p.repo_path)
        from agentflow.git_runtime import merge as merge_mod

        merge_mod.merge_task_branch(s, repo, t)
        typer.echo("已合并回主分支")


@app.command("task-abort")
def task_abort(task_id: int):
    _, engine = _ctx()
    with Session(engine) as s:
        t = s.get(m.Task, task_id)
        if not t:
            typer.echo("任务不存在", err=True)
            raise typer.Exit(1)
        p = s.get(m.Project, t.project_id)
        if p and t.branch:
            from agentflow.git_runtime import branch as branch_mod
            from agentflow.git_runtime.repo import RepoHandle

            try:
                branch_mod.delete_task_branch(RepoHandle(p.repo_path), task_id)
            except Exception:
                pass
        t.status = m.TaskStatus.aborted
        s.commit()
        typer.echo("任务已废弃")



@app.command("demo-run")
def demo_run():
    """一键跑通 demo 闭环：接入→澄清→Spec→执行→绿点→验证。"""
    from agentflow.demo.demo import run_demo

    run_demo()
    typer.echo("demo 闭环完成 ✅")



@app.command("replay")
def replay(
    suite: str = typer.Option(None, "--suite", help="回放集 JSON 路径（缺省=内置 demo 套件）"),
    case: str = typer.Option(None, "--case", help="只跑指定 case 名"),
    mock: bool = typer.Option(False, "--mock", help="用 MockLLM 离线跑（验证回放链路，不验模型能力）"),
    keep: bool = typer.Option(False, "--keep", help="保留回放产生的项目/任务记录（默认跑完即清理）"),
):
    """回放基准：跑回放集并产出成功率报表（成功率主攻方向的度量基建）。"""
    from agentflow.replay.runner import run_suite

    report = run_suite(suite, case, use_mock=mock, cleanup=not keep)
    if not report["all_ok"]:
        raise typer.Exit(1)



@app.command("corpus")
def corpus(
    events: str = typer.Option(None, "--events", help="事件流目录（缺省 ~/.agentflow/events）"),
    out: str = typer.Option(None, "--out", help="语料输出根目录（缺省 ~/.agentflow/replay_corpus）"),
    since: str = typer.Option(None, "--since", help="只看该日期起的事件（YYYY-MM-DD；跨阶段混算会失真，如 detector 上线日 2026-09-14）"),
):
    """失败语料库 + 阈值校准：扫历史事件流，统计失败模式分布与闸门阈值实测分位点。"""
    from agentflow.replay.corpus import run_corpus

    run_corpus(events, out, since=since)



@app.command("warm-sweep")
def warm_sweep(
    dry_run: bool = typer.Option(False, "--dry-run", help="只报告将清扫哪些，不实际杀进程"),
):
    """清扫孤儿暖服务：上一代 serve 被强杀后遗留的 next dev/vite 常驻进程（会锁住 worktree 目录）。"""
    from agentflow.config import Settings
    from agentflow.core.services import render_sweep_report, sweep_orphan_warm

    settings = Settings.load()
    typer.echo(render_sweep_report(sweep_orphan_warm(settings.home, dry_run=dry_run)))



skill_app = typer.Typer(help="技能包（经验包）：列表 / 新建。技能清单常驻 prompt，正文由 agent 按需 skill_load 加载。")
app.add_typer(skill_app, name="skill")


@skill_app.command("list")
def skill_list():
    """列出技能包（~/.agentflow/skills/<name>/内部文档）。"""
    from agentflow.config import Settings
    from agentflow.core.skills import list_skills, skills_dir

    settings = Settings.load()
    rows = list_skills(settings.home, include_disabled=True)
    if not rows:
        typer.echo(f"（无技能包；目录：{skills_dir(settings.home)}）")
        return
    for sk in rows:
        flag = "" if sk.enabled else "  [已停用]"
        scope = f"  scope={sk.scope}" if sk.scope else ""
        typer.echo(f"- {sk.name}{flag}{scope}\n    {sk.description}\n    {sk.path}")


@skill_app.command("new")
def skill_new(name: str = typer.Argument(..., help="技能名（同时作为目录名，建议 kebab-case）")):
    """新建技能包模板（写入 ~/.agentflow/skills/<name>/内部文档）。"""
    from agentflow.config import Settings
    from agentflow.core.skills import SKILL_FILE, skill_template, skills_dir

    f = skills_dir(Settings.load().home) / name / SKILL_FILE
    if f.exists():
        typer.echo(f"已存在，未覆盖：{f}")
        raise typer.Exit(1)
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(skill_template(name), encoding="utf-8")
    typer.echo(f"已创建：{f}\n把 description 写具体（它会常驻注入所有 agent），正文写做法与坑。")


def main():

    from agentflow.core import win_silent

    win_silent.install()
    app()