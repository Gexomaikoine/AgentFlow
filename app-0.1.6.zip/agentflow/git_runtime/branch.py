"""任务分支管理：创建/删除/清理。"""

from __future__ import annotations

from agentflow.git_runtime.repo import RepoHandle


def task_branch_name(task_id: int) -> str:
    return f"task/{task_id}"


def create_task_branch(repo: RepoHandle, task_id: int, main_ref: str = "main") -> str:
    """切到主分支基线，创建任务分支并检出。"""
    try:
        repo.checkout(main_ref)
    except Exception:

        pass
    name = task_branch_name(task_id)
    repo.ensure_branch(name)
    return name


def delete_task_branch(repo: RepoHandle, task_id: int, back_to: str = "main") -> None:
    """删除任务分支并切回基线。"""
    name = task_branch_name(task_id)
    try:
        repo.checkout(back_to)
    except Exception:
        pass
    repo.delete_branch(name)
