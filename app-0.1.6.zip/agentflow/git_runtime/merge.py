"""合并权威（P1）：串行队列编排的底层原语。"""

from __future__ import annotations

import re

from agentflow.git_runtime.repo import GitError, RepoHandle
from agentflow.storage import models as m
from sqlmodel import Session





_MARKER_RE = re.compile(r"^(?:<{7,} |={7,}$|>{7,} )")


def _conflict_files(repo: RepoHandle) -> list[str]:
    try:
        out = repo.repo.git.diff("--name-only", "--diff-filter=U")
        return [l for l in (out or "").splitlines() if l.strip()]
    except Exception:
        return []


def start_merge(
    repo: RepoHandle,
    branch: str,
    main_ref: str = "main",
    anchors: list[dict] | None = None,
) -> list[str]:
    """干跑 --no-commit 检出冲突，统一留在半合并态（不提交），返回冲突文件列表。"""


    try:
        if repo.current_branch() != main_ref:
            repo.checkout(main_ref)
    except Exception:
        try:
            repo.checkout(main_ref)
        except Exception:
            pass





    repo.repo.git.merge(
        "--no-ff", "--no-commit", "--no-edit", "-X", "ignore-space-at-eol", branch,
        with_exceptions=False,
    )
    conflicts = _conflict_files(repo)
    if conflicts or not anchors:
        return conflicts
    if not _merge_dropped_all_branch_content(repo, branch):
        return []

    abort_merge(repo)
    return _cherry_pick_anchors(repo, anchors)


def _merge_dropped_all_branch_content(repo: RepoHandle, branch: str) -> bool:
    """判定 git merge 是否把任务分支的内容整体丢弃（revert-then-remerge 陷阱）。"""
    try:
        base = (repo.repo.git.merge_base("HEAD", branch) or "").strip()
        if not base:
            return False
        branch_changed = (repo.repo.git.diff("--name-only", base, branch) or "").strip()
        if branch_changed:
            return False
        main_changed = (repo.repo.git.diff("--name-only", base) or "").strip()
        return bool(main_changed)
    except Exception:
        return False


def _cherry_pick_anchors(repo: RepoHandle, anchors: list[dict]) -> list[str]:
    """逐个绿点 cherry-pick --no-commit 重放（revert-then-remerge 兜底路径）。"""
    for a in anchors:
        sha = str(a.get("commit") or "").strip()
        if not sha:
            continue

        repo.repo.git.cherry_pick(
            "--no-commit", "-X", "ignore-space-at-eol", sha, with_exceptions=False
        )
        conflicts = _conflict_files(repo)
        if conflicts:
            return conflicts
    return []


def merge_conflict_details(repo: RepoHandle, files: list[str]) -> str:
    """提取各冲突文件的冲突片段（供 PM 审查两侧标记）。"""
    out = []
    for f in files[:20]:
        try:
            content = (repo.repo_path / f).read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue

        lines = content.splitlines()
        keep, inside = [], False
        for i, ln in enumerate(lines):
            if ln.startswith("<<<<<<<"):
                inside = True
                keep.append(ln)
            elif ln.startswith(">>>>>>>"):
                keep.append(ln)
                inside = False
            elif inside:
                keep.append(ln)
        if keep:
            out.append(f"--- {f} ---\n" + "\n".join(keep[:120]))
    return "\n".join(out)


def conflicts_unresolved(repo: RepoHandle, files: list[str]) -> bool:
    """仍有残留冲突标记 → 并入不完整（响亮错，不强登）。"""
    for f in files:
        try:
            content = (repo.repo_path / f).read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        if any(_MARKER_RE.match(ln) for ln in content.splitlines()):
            return True
    return False


class TaskNotMergeable(Exception):
    """任务已到不可合并的人工终态（废弃）：合并必须停手。"""


def _refuse_if_task_aborted(task: m.Task) -> None:
    """废弃是最高优先级人工意图：见到即抛 TaskNotMergeable（响亮错，不静默继续）。"""
    if task.status == m.TaskStatus.aborted:
        raise TaskNotMergeable(f"任务已废弃（{task.status.value}），合并停手：不提交、不写状态")


def _mark_merging(session: Session, task: m.Task) -> None:
    """合并期间把任务同步为 merging（AgentRuntime 状态白名单只放行 running/merging/spec_generating）。"""
    if task.status in (m.TaskStatus.done, m.TaskStatus.failed, m.TaskStatus.running):
        task.status = m.TaskStatus.merging
    session.add(task)
    session.commit()


def commit_resolved_merge(
    session: Session,
    repo: RepoHandle,
    task: m.Task,
    files: list[str],
) -> bool:
    """解完冲突后 git add 冲突文件 → 完成 --no-ff 合并提交。"""

    _refuse_if_task_aborted(task)







    repo.repo.git.add("-u")
    staged = repo.repo.git.diff("--cached", "--numstat", "HEAD") or ""
    if not staged.strip():
        _mark_merging(session, task)
        return False

    msg = f"合并任务：{task.title}"
    repo.repo.git.commit("--no-edit", "-m", msg)
    _mark_merging(session, task)
    return True


def advance_main(main_repo: RepoHandle, wt_repo: RepoHandle, main_ref: str = "main") -> None:
    """合并提交后，把主 checkout 的 main 快进到合并 worktree 的 HEAD。"""
    sha = wt_repo.repo.git.rev_parse("HEAD").strip()
    cur = main_repo.current_branch()
    if cur != main_ref:
        raise GitError(f"主 checkout 当前在 {cur} 而非 {main_ref}，main 前移需人工处理")
    try:
        main_repo.repo.git.merge("--ff-only", sha)
    except Exception as e:
        raise GitError(f"main 前移失败（主 checkout 状态异常，需人工处理）: {e}") from e
    after = main_repo.repo.git.rev_parse(main_ref).strip()
    if after != sha:
        raise GitError(
            f"main 未前移到合并提交：{main_ref}={after[:8]}，期望 {sha[:8]}。"
            "通常意味着合并 worktree 停在旧基线（未刷新 main 最新 tip），"
            f"或 {sha[:8]} 已是 {main_ref} 的祖先（--ff-only 静默 no-op）。"
            "**本任务并未真正合入**，已置失败，请人工检查合并 worktree 状态。"
        )


def is_merge_commit(repo: RepoHandle, sha: str) -> bool:
    """判定 sha 是否为 merge commit（>1 个 parent）：revert -m 1 仅对 merge commit 有效。"""
    try:
        out = repo.repo.git.rev_list("--parents", "-n", "1", sha)
        return len((out or "").strip().split()) > 2
    except Exception:
        return False


def abort_merge(repo: RepoHandle) -> None:
    """中止合并，把工作区还原到干净状态（M3 / 门禁③）。"""
    try:
        repo.repo.git.merge("--abort", with_exceptions=False)
    except Exception:
        pass
    try:
        if not repo.is_clean():
            repo.repo.git.cherry_pick("--abort", with_exceptions=False)
    except Exception:
        pass
    try:
        if not repo.is_clean():
            repo.repo.git.reset("--hard", with_exceptions=False)
    except Exception:
        pass


def merge_changes_present(repo: RepoHandle, merge_sha: str, main_ref: str = "main") -> bool:
    '''该任务合并引入的净改动，是否仍体现在 main 上？（人审"重做"的幂等前置判定）'''
    try:
        files = [
            f for f in repo.repo.git.diff("--name-only", f"{merge_sha}^", merge_sha).split("\n") if f.strip()
        ]
        if not files:
            return False
        drift = repo.repo.git.diff("--name-only", main_ref, merge_sha, "--", *files).strip()
        return not drift
    except Exception:
        return True


def revert_merge_commit(repo: RepoHandle, merge_sha: str, reason: str = "") -> list[str]:
    '''revert 一个任务合并 commit（人审"重做"通道）。'''
    cur = repo.current_branch()
    if cur != "main":
        raise GitError(f"主 checkout 当前在 {cur} 而非 main，revert 需在 main 上执行")
    if not repo.is_clean():
        raise GitError("主 checkout 工作区不干净，revert 需人工处理（防丢失未提交改动）")
    if is_merge_commit(repo, merge_sha):
        repo.repo.git.revert("--no-commit", "-m", "1", merge_sha, with_exceptions=False)
    else:
        repo.repo.git.revert("--no-commit", merge_sha, with_exceptions=False)
    conflicts = _conflict_files(repo)
    if conflicts:
        return conflicts
    staged = repo.repo.git.diff("--cached", "--numstat", "HEAD") or ""
    if not staged.strip():
        raise GitError(f"revert {merge_sha[:8]} 无内容差异（可能已被 revert 过），已中止")
    msg = f"重做撤销：revert 合并 {merge_sha[:8]}" + (f"（{reason[:120]}）" if reason else "")
    repo.repo.git.commit("--no-edit", "-m", msg)
    return []


def abort_revert(repo: RepoHandle) -> None:
    """中止 revert，工作区还原（revert 冲突超限停机人工 / 异常复位）。"""
    try:
        repo.repo.git.revert("--abort", with_exceptions=False)
    except Exception:
        pass
    try:


        if not repo.is_clean():
            repo.repo.git.checkout("--", ".")
    except Exception:
        pass


def merge_task_branch(
    session: Session,
    repo: RepoHandle,
    task: m.Task,
    main_ref: str = "main",
) -> list[str]:
    """兼容旧接口：全自动合并（无冲突直接成）。有冲突停机抛 GitError（保留旧语义）。"""
    if task.status != m.TaskStatus.done:
        raise GitError("仅 done 状态可合并")
    conflicts = start_merge(repo, task.branch, main_ref)
    if conflicts:
        abort_merge(repo)
        raise GitError(f"合并冲突: {conflicts}")
    commit_resolved_merge(session, repo, task, [])
    return []