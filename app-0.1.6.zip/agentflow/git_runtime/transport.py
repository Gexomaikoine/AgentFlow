"""Git 远端传输策略：SSH / HTTPS（可带代理）+ 优先顺序 + 连通性自检。"""

from __future__ import annotations

import re
import subprocess
import time
from pathlib import Path

SCHEME_SSH = "ssh"
SCHEME_HTTPS = "https"
DEFAULT_ORDER = [SCHEME_SSH, SCHEME_HTTPS]


def _strip_dot_git(u: str) -> str:
    return u[:-4] if u.endswith(".git") else u


def derive_urls(remote_url: str) -> dict[str, str | None]:
    """由现有 remote URL 推导 ssh / https 两种形式（支持 scp-like、ssh://、https://）。"""
    u = (remote_url or "").strip()
    if not u:
        return {SCHEME_SSH: None, SCHEME_HTTPS: None}
    host = path = ""
    m = re.match(r"^(?:ssh://)?[^@/]+@([^:/]+)[:/](.+)$", u)
    if m:
        host, path = m.group(1), m.group(2)
    else:
        m = re.match(r"^https?://([^/]+)/(.+)$", u)
        if m:
            host, path = m.group(1), m.group(2)
    path = _strip_dot_git(path).lstrip("/")
    if not host or not path:
        return {SCHEME_SSH: None, SCHEME_HTTPS: None}
    return {SCHEME_SSH: f"git@{host}:{path}.git", SCHEME_HTTPS: f"https://{host}/{path}.git"}


def candidates(remote_url: str, git_cfg: dict | None) -> list[dict]:
    """按设置给出候选通道：[{scheme,url,proxy}]（按尝试顺序）。"""
    cfg = git_cfg or {}
    proto = str(cfg.get("protocol") or "auto").lower()
    prefer = [s for s in (cfg.get("prefer") or DEFAULT_ORDER) if s in (SCHEME_SSH, SCHEME_HTTPS)]
    order = [proto] if proto in (SCHEME_SSH, SCHEME_HTTPS) else (prefer or DEFAULT_ORDER)
    urls = derive_urls(remote_url)
    proxy = str(cfg.get("proxy") or "").strip() or None
    use_proxy = bool(cfg.get("use_proxy")) and bool(proxy)
    out: list[dict] = []
    for s in order:
        u = urls.get(s)
        if not u:
            continue
        out.append({"scheme": s, "url": u, "proxy": (proxy if (s == SCHEME_HTTPS and use_proxy) else None)})
    if not out:

        out = [{"scheme": "remote", "url": remote_url, "proxy": proxy if use_proxy else None}]
    return out


def _git_cmd(scheme_cand: dict, *args: str) -> list[str]:
    cmd = ["git"]
    if scheme_cand.get("proxy"):
        cmd += ["-c", f"http.proxy={scheme_cand['proxy']}"]
    cmd += list(args)
    return cmd


def _run(cmd: list[str], cwd: Path, timeout_s: int) -> tuple[bool, str, int]:
    t0 = time.monotonic()
    try:
        p = subprocess.run(
            cmd, cwd=str(cwd), capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=timeout_s,
        )
        err = (p.stderr or "").strip() or (p.stdout or "").strip()
        return p.returncode == 0, err[-400:], int((time.monotonic() - t0) * 1000)
    except subprocess.TimeoutExpired:
        return False, f"超时（>{timeout_s}s）", int((time.monotonic() - t0) * 1000)
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"[:400], int((time.monotonic() - t0) * 1000)


def _sync_tracking_ref(repo_path: Path, remote_name: str, branch: str) -> None:
    """推送成功后把 `refs/remotes/<remote>/<branch>` 对齐到本地分支。"""
    if not remote_name:
        return
    try:
        sha = subprocess.run(
            ["git", "rev-parse", branch], cwd=str(repo_path),
            capture_output=True, text=True, timeout=15,
        ).stdout.strip()
        if not sha:
            return
        subprocess.run(
            ["git", "update-ref", f"refs/remotes/{remote_name}/{branch}", sha], cwd=str(repo_path),
            capture_output=True, timeout=15, check=False,
        )
    except Exception:
        pass


def push(repo_path: str | Path, branch: str, remote_url: str, git_cfg: dict | None,
         timeout_s: int = 180, remote_name: str = "") -> dict:
    """按优先顺序尝试各通道推送；成功后即止。不改 remote 配置（显式 URL push）。"""
    tries: list[dict] = []
    path = Path(repo_path)
    for cand in candidates(remote_url, git_cfg):
        cmd = _git_cmd(cand, "push", cand["url"], branch)
        ok, err, ms = _run(cmd, path, timeout_s)
        tries.append({**cand, "ok": ok, "ms": ms, "error": "" if ok else err})
        if ok:
            _sync_tracking_ref(path, remote_name, branch)
            return {"ok": True, "used": cand["scheme"], "url": cand["url"], "tries": tries}
    return {"ok": False, "used": None, "url": None, "tries": tries}


def test(repo_path: str | Path, remote_url: str, git_cfg: dict | None, timeout_s: int = 30) -> dict:
    """连通性自检：对每个候选通道跑只读 `git ls-remote --heads <url>`。"""
    tries: list[dict] = []
    for cand in candidates(remote_url, git_cfg):
        cmd = _git_cmd(cand, "ls-remote", "--heads", cand["url"])
        ok, err, ms = _run(cmd, Path(repo_path), timeout_s)
        tries.append({**cand, "ok": ok, "ms": ms, "error": "" if ok else err})
    return {"tries": tries, "any_ok": any(t["ok"] for t in tries)}
