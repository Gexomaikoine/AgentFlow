"""专用合并 worktree 管理（P1）：每项目 1 个常驻，依赖只配一次。"""

from __future__ import annotations

from pathlib import Path

from agentflow.config import Settings
from agentflow.git_runtime.repo import GitError, RepoHandle


def merge_worktree_base(settings: Settings) -> Path:
    """合并 worktree 根目录（配置为空时用 <agentflow_home>/merge_worktrees）。"""
    cfg = settings.data.get("merge", {})
    base = (cfg.get("worktree_base_dir") or "").strip()
    return Path(base) if base else settings.home / "merge_worktrees"


def merge_worktree_path(settings: Settings, project_id: int) -> Path:
    return merge_worktree_base(settings) / f"project-{project_id}"


def _discard_stale_worktree(wt: Path) -> None:
    """清除失效的 worktree 残留目录（目录在但 .git 链接失效等）。"""
    try:
        _unlink_junctions(wt)
    except Exception:
        pass
    import shutil

    shutil.rmtree(wt, ignore_errors=True)
    if wt.exists():
        import time as _t

        aside = wt.with_name(f"{wt.name}.stale-{int(_t.time())}")
        try:
            wt.rename(aside)
        except Exception as e:
            raise RuntimeError(
                f"残留合并 worktree 目录 {wt} 既清不掉也改不了名（{e}）；"
                "请先关闭占用它的进程再重试。"
            ) from e


def ensure_merge_worktree(
    settings: Settings, repo_path: str | Path, project_id: int, main_ref: str = "main"
) -> Path:
    """确保项目专用合并 worktree 存在（常驻），返回其路径。"""
    base = merge_worktree_base(settings)
    base.mkdir(parents=True, exist_ok=True)
    wt = merge_worktree_path(settings, project_id)
    if wt.exists() and (wt / ".git").exists():


        try:
            repo = RepoHandle(wt)
            repo.repo.git.rev_parse("--git-dir")




            _reset_merge_worktree_to_main(repo, repo_path, main_ref)
            return wt
        except Exception:
            pass
    if wt.exists():
        _discard_stale_worktree(wt)

    main_repo = RepoHandle(repo_path)
    try:
        main_repo.repo.git.worktree("add", "--detach", str(wt), main_ref)
    except Exception:

        try:
            main_repo.repo.git.worktree("prune")
            main_repo.repo.git.worktree("add", "--detach", str(wt), main_ref)
        except Exception:
            main_repo.repo.git.worktree("add", "--detach", str(wt))
    return wt


def _reset_merge_worktree_to_main(wt_repo: RepoHandle, repo_path: str | Path, main_ref: str) -> None:
    """把常驻合并 worktree 硬重置到 main 最新 tip（脏基线自愈）。"""
    from agentflow.git_runtime.repo import GitError

    try:
        tip = RepoHandle(repo_path).repo.git.rev_parse(main_ref).strip()
        wt_repo.repo.git.reset("--hard", tip)
    except Exception as e:
        raise GitError(f"合并 worktree 无法重置到 {main_ref} 最新（{e}）：拒绝在脏基线上合并") from e


def merge_worktree_handle(settings: Settings, project_id: int, repo_path: str | Path) -> RepoHandle:
    """获取项目专用合并 worktree 的 RepoHandle（确保已存在）。"""
    wt = ensure_merge_worktree(settings, repo_path, project_id)
    return RepoHandle(wt)


def remove_merge_worktree(settings: Settings, repo_path: str | Path, project_id: int) -> None:
    """清理项目合并 worktree（归档项目/手动清理用）。"""
    wt = merge_worktree_path(settings, project_id)
    if not wt.exists():
        return
    try:
        main_repo = RepoHandle(repo_path)
        main_repo.repo.git.worktree("remove", "--force", str(wt))
    except GitError:
        pass
    except Exception:
        pass




def dev_worktree_base(settings: Settings) -> Path:
    """任务开发 worktree 根目录（默认 <agentflow_home>/dev_worktrees）。"""
    cfg = settings.data.get("scheduler", {})
    base = (cfg.get("dev_worktree_base_dir") or "").strip()
    return Path(base) if base else settings.home / "dev_worktrees"


def dev_worktree_path(settings: Settings, task_id: int) -> Path:
    return dev_worktree_base(settings) / f"dev-{task_id}"


def _kill_lockers(path: Path) -> list[int]:
    """收割命令行引用 path 的进程。"""
    import os
    import subprocess

    try:
        pat = str(path).replace("'", "''")
        ps = (
            "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like "
            f"'*{pat}*' -and $_.ProcessId -ne $PID -and $_.ProcessId -ne {os.getpid()} }} "
            "| Select-Object -ExpandProperty ProcessId"
        )
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, timeout=30,
        )
        pids = [int(x) for x in (r.stdout or "").split() if x.strip().isdigit()]
    except Exception:
        return []
    killed: list[int] = []
    for pid in pids:
        try:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True, timeout=15)
            killed.append(pid)
        except Exception:
            continue
    return killed


def ensure_dev_worktree(settings: Settings, repo_path: str | Path, task_id: int, main_ref: str = "main") -> Path:
    """确保任务独立开发 worktree 存在（detached main），返回其路径。"""
    base = dev_worktree_base(settings)
    base.mkdir(parents=True, exist_ok=True)
    wt = dev_worktree_path(settings, task_id)
    if wt.exists() and (wt / ".git").exists():
        try:
            repo = RepoHandle(wt)
            repo.repo.git.rev_parse("--git-dir")
            return wt
        except Exception:
            pass
    if wt.exists():



        try:
            _unlink_junctions(wt)
        except Exception:
            pass
        import shutil

        shutil.rmtree(wt, ignore_errors=True)
        if wt.exists():




            import time as _t

            aside = wt.with_name(f"{wt.name}.stale-{int(_t.time())}")
            try:
                wt.rename(aside)
            except Exception as e:


                killed = _kill_lockers(wt)
                if killed:
                    _t.sleep(1.0)
                    shutil.rmtree(wt, ignore_errors=True)
                    if not wt.exists():
                        pass
                    else:
                        try:
                            wt.rename(aside)
                        except Exception as e2:
                            raise RuntimeError(
                                f"残留开发目录 {wt} 清不掉也改不了名（{e2}）；"
                                f"已自动收割占用进程 {killed} 仍失败，请人工检查后重试。"
                            ) from e2
                else:
                    raise RuntimeError(
                        f"残留开发目录 {wt} 既清不掉也改不了名（{e}）；"
                        "请先关闭占用它的进程（多为上次机审残留的 dev server）再重试。"
                    ) from e
    wt.mkdir(parents=True, exist_ok=True)
    main_repo = RepoHandle(repo_path)
    try:
        main_repo.repo.git.worktree("add", "--detach", str(wt), main_ref)
    except Exception:

        try:
            main_repo.repo.git.worktree("prune")
            main_repo.repo.git.worktree("add", "--detach", str(wt), main_ref)
        except Exception:
            main_repo.repo.git.worktree("add", "--detach", str(wt))


    try:
        from agentflow.safety.path import AGENT_TMP_DIR

        (wt / AGENT_TMP_DIR).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return wt


def _unlink_junctions(root: Path) -> tuple[int, int]:
    """拆除 root 下所有 junction（Windows），返回 (已拆除, 拆除失败) 数。"""
    import os
    import stat

    def _is_link_dir(p: str) -> bool:



        if os.path.islink(p):
            return True
        try:
            st = os.lstat(p)
        except OSError:
            return False
        return bool(getattr(st, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT)

    removed = 0
    blocked = 0
    for cur, dirs, _files in os.walk(root, followlinks=False):
        for d in list(dirs):
            p = os.path.join(cur, d)
            if not _is_link_dir(p):
                continue
            try:
                os.rmdir(p)
                removed += 1
                dirs.remove(d)
            except OSError:
                blocked += 1
                dirs.remove(d)
    return removed, blocked


def _git_processes_running() -> bool:
    """是否有 git 进程在跑。检测不了就返回 True（保守：宁可不清锁，也不误删活跃锁）。"""
    import platform
    import subprocess

    try:
        if platform.system().lower() == "windows":
            r = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq git.exe", "/NH"],
                capture_output=True, text=True, timeout=10,
            )
            return "git.exe" in (r.stdout or "").lower()
        r = subprocess.run(["pgrep", "-x", "git"], capture_output=True, text=True, timeout=10)
        return r.returncode == 0
    except Exception:
        return True


def clear_stale_index_lock(repo_path: str | Path, max_age_s: int = 120) -> list[str]:
    """清理**陈旧**的 git index.lock，返回已清理的锁路径（空 = 无需/不宜清理）。"""
    import time

    repo = Path(repo_path)
    candidates: list[Path] = []
    candidates += list((repo / ".git").glob("index.lock"))
    wt_dir = repo / ".git" / "worktrees"
    if wt_dir.is_dir():
        candidates += list(wt_dir.glob("*/index.lock"))
    if not candidates:
        return []
    now = time.time()
    stale = []
    for p in candidates:
        try:
            if now - p.stat().st_mtime > max_age_s:
                stale.append(p)
        except OSError:
            continue
    if not stale:
        return []
    if _git_processes_running():
        return []
    cleared: list[str] = []
    for p in stale:
        try:
            p.unlink()
            cleared.append(str(p))
        except OSError:
            continue
    return cleared


def remove_dev_worktree(settings: Settings, repo_path: str | Path, task_id: int) -> bool:
    """清理任务开发 worktree（任务终态自动清理，）。返回是否清理了目录。"""
    wt = dev_worktree_path(settings, task_id)
    if not wt.exists():
        return False
    removed, blocked = _unlink_junctions(wt)
    if blocked:
        return False
    try:
        main_repo = RepoHandle(repo_path)
        main_repo.repo.git.worktree("remove", "--force", str(wt))
        return True
    except Exception:
        pass

    import shutil

    shutil.rmtree(wt, ignore_errors=True)
    if wt.exists():

        killed = _kill_lockers(wt)
        if killed:
            import time as _t

            _t.sleep(1.0)
            shutil.rmtree(wt, ignore_errors=True)
    return not wt.exists()




def _node_modules_dirs(root: Path) -> list[Path]:
    """递归收集目录下所有 node_modules 目录（含嵌套，如 site/node_modules）。"""
    found: list[Path] = []
    for d in root.rglob("node_modules"):
        if d.is_dir():
            found.append(d)
    return found


def link_node_deps(main_root: Path, worktree_root: Path) -> list[tuple[Path, Path]]:
    """将主 checkout 的 node_modules 以 junction 链接到 worktree，免每任务重装。"""
    import platform

    if platform.system().lower() != "windows":
        return []
    import subprocess

    created: list[tuple[Path, Path]] = []
    for main_nm in _node_modules_dirs(main_root):
        try:
            rel = main_nm.relative_to(main_root)
        except ValueError:
            continue
        wt_nm = worktree_root / rel
        if wt_nm.exists() or wt_nm.is_symlink():
            continue
        wt_nm.parent.mkdir(parents=True, exist_ok=True)
        try:
            subprocess.run(
                ["cmd", "/c", "mklink", "/J", str(wt_nm), str(main_nm)],
                check=True,
                capture_output=True,
                timeout=15,
            )
            created.append((wt_nm, main_nm))
        except Exception:
            continue
    return created


def link_runtime_data(
    main_root: Path, worktree_root: Path, rel_dirs: list[str]
) -> tuple[list[tuple[Path, Path]], list[tuple[str, str]]]:
    """将主 checkout 的 git-ignored 运行时数据目录以 junction 链接到 worktree。"""
    import platform
    import subprocess

    if platform.system().lower() != "windows":
        return [], []
    created: list[tuple[Path, Path]] = []
    failed: list[tuple[str, str]] = []
    for rel in rel_dirs:
        main_dir = (main_root / rel).resolve()
        if not main_dir.is_dir():
            continue
        wt_dir = worktree_root / rel
        if wt_dir.exists() or wt_dir.is_symlink():
            continue
        wt_dir.parent.mkdir(parents=True, exist_ok=True)
        try:
            r = subprocess.run(
                ["cmd", "/c", "mklink", "/J", str(wt_dir), str(main_dir)],
                check=True,
                capture_output=True,
                timeout=15,
            )
            created.append((wt_dir, main_dir))
        except subprocess.CalledProcessError as e:
            detail = (e.stderr or e.stdout or b"").decode("utf-8", "replace").strip()[:200]
            failed.append((rel, detail or f"mklink 退出码 {e.returncode}"))
        except Exception as e:
            failed.append((rel, f"{type(e).__name__}: {e}"))
    return created, failed
