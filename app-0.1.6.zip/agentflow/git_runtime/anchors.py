"""绿点与回滚（FR6）。"""

from __future__ import annotations

from pathlib import Path

from agentflow.git_runtime.repo import RepoHandle
from agentflow.storage import models as m
from sqlmodel import Session


def create_green_commit(
    repo: RepoHandle,
    feature: m.Feature,
    files: list[str],
    message: str | None = None,
) -> str:
    """功能全绿 → 按租约文件集 commit（禁 add -A）。"""
    msg = message or f"功能 F{feature.seq}：{feature.title}"
    return repo.commit_files(files, msg)


def clean_untracked(repo: RepoHandle, scope: Path | None) -> list[str]:
    """删除未跟踪文件（P3 可逆性补齐）。"""
    if scope is None:
        return []
    root = repo.repo_path.resolve()
    scope_r = Path(scope).resolve()
    deleted: list[str] = []
    for rel in list(repo.repo.untracked_files):
        target = (root / rel).resolve()
        if not target.is_relative_to(scope_r):
            continue
        try:
            if target.is_file() or target.is_symlink():
                target.unlink()
                deleted.append(rel)
        except OSError:
            continue
    for d in sorted({(root / r).parent for r in deleted}, key=lambda p: len(str(p)), reverse=True):
        try:
            cur = d
            while cur != root and cur.is_relative_to(root) and not any(cur.iterdir()):
                cur.rmdir()
                cur = cur.parent
        except OSError:
            continue
    return deleted


def rollback_task(
    session: Session,
    repo: RepoHandle,
    task: m.Task,
    anchor: m.GreenAnchor,
    clean_scope: Path | None = None,
) -> list[str]:
    """回滚到指定绿点，状态回退按三（FR6）。返回被清理的未跟踪文件清单。"""

    anchor.invalidated_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
    session.add(anchor)


    repo.reset_hard(anchor.commit_hash)


    cleaned = clean_untracked(repo, clean_scope)


    anchors = session.query(m.GreenAnchor).filter(m.GreenAnchor.task_id == task.id).all()
    anchor_created = min((a.created_at for a in anchors if not a.invalidated_at), default="")
    feats = session.query(m.Feature).filter(m.Feature.task_id == task.id).order_by(m.Feature.seq).all()
    rolled = False
    for f in feats:
        if f.status in (m.FeatureStatus.passed,) and _is_after(f, anchor, session):
            f.status = m.FeatureStatus.pending
            session.add(f)
            rolled = True
        elif f.status in (m.FeatureStatus.queued, m.FeatureStatus.fixing, m.FeatureStatus.failed, m.FeatureStatus.stale):
            f.status = m.FeatureStatus.pending
            session.add(f)


    for q in session.query(m.FailureQueueEntry).filter(m.FailureQueueEntry.task_id == task.id).all():
        session.delete(q)


    nodes = session.query(m.Node).filter(m.Node.task_id == task.id, m.Node.ended_at != None).all()
    for n in nodes:
        if n.ended_at and _ts_gt(n.ended_at, anchor.created_at):
            n.rolled_back = True
            session.add(n)

    session.commit()
    return cleaned


def _is_after(feature: m.Feature, anchor: m.GreenAnchor, session: Session) -> bool:
    """feature 是否在锚点之后（按其最后绿点时间或直接按其 seq 与锚点 feature 比较）。"""
    if feature.id == anchor.feature_id:
        return False
    anchor_feat = session.get(m.Feature, anchor.feature_id) if anchor.feature_id else None
    if anchor_feat is None:
        return True
    return feature.seq > anchor_feat.seq


def _ts_gt(a: str, b: str) -> bool:
    return (a or "") > (b or "")
