"""Git 运行时：底层 GitPython 封装。"""

from __future__ import annotations

import subprocess
from pathlib import Path

from git import Repo


class GitError(Exception):
    pass




MINIMAL_GITIGNORE = """\
# AgentFlow 接入时自动生成（该目录此前不是 git 仓库）
node_modules/
.venv/
venv/
__pycache__/
*.pyc
dist/
build/
.next/
.idea/
.vscode/
.DS_Store
"""

_INIT_COMMIT_MESSAGE = "chore: 接入 AgentFlow 时初始化仓库"


def needs_git_init(repo_path: str | Path) -> bool:
    """该目录是否需要初始化（只读判定，不改动任何文件）。"""
    p = Path(repo_path)
    if not (p / ".git").exists():
        return True
    return not _has_head(p)


def ensure_initialized_repo(repo_path: str | Path) -> bool:
    """把目录兜底成「有 HEAD 提交、且默认分支为 main」的 git 仓库，返回本次是否动过手。"""
    p = Path(repo_path)
    acted = False
    if not (p / ".git").exists():
        _run_git(["init", "-b", "main"], p)
        acted = True
    if _has_head(p):
        return acted

    if _current_branch(p) != "main":
        _run_git(["branch", "-m", "main"], p)
    gitignore = p / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text(MINIMAL_GITIGNORE, encoding="utf-8")
    _run_git(["add", "-A"], p)

    _run_git(["commit", "--allow-empty", "-m", _INIT_COMMIT_MESSAGE], p)
    return True


def _current_branch(repo_path: Path) -> str:
    """当前分支名（unborn HEAD 也能拿到，返回空串表示取不到）。"""
    proc = subprocess.run(
        ["git", "symbolic-ref", "--short", "HEAD"],
        cwd=repo_path, capture_output=True, text=True,
    )
    return proc.stdout.strip() if proc.returncode == 0 else ""


def _has_head(repo_path: Path) -> bool:
    proc = subprocess.run(
        ["git", "rev-parse", "--verify", "HEAD"],
        cwd=repo_path, capture_output=True, text=True,
    )
    return proc.returncode == 0


def _run_git(args: list[str], cwd: Path) -> None:
    proc = subprocess.run(
        ["git", *args], cwd=cwd, capture_output=True, text=True, errors="replace"
    )
    if proc.returncode != 0:
        raise GitError(
            f"git {' '.join(args)} 失败（exit {proc.returncode}）: "
            f"{(proc.stderr or proc.stdout).strip()}"
        )


class RepoHandle:
    """对目标仓库的封装。单进程内串行访问（同项目同时仅 1 任务）。"""

    def __init__(self, repo_path: str | Path):
        self.repo_path = Path(repo_path)
        if not (self.repo_path / ".git").exists():
            raise GitError(f"不是 git 仓库: {self.repo_path}")
        self.repo = Repo(self.repo_path)

    def release(self) -> None:
        """终止 GitPython 的 cat-file 常驻子进程。"""
        try:
            self.repo.git.clear_cache()
        except Exception:
            pass


    def current_branch(self) -> str:
        try:
            return self.repo.active_branch.name
        except Exception:
            return self.repo.git.rev_parse("--abbrev-ref", "HEAD")

    def is_clean(self) -> bool:
        """跟踪文件无未提交改动（容忍未跟踪文件，如 __pycache__）。"""
        return not self.repo.is_dirty()

    def head_hash(self) -> str:
        return self.repo.head.commit.hexsha

    def relpath(self, p: str | Path) -> str:
        """把任意路径转为相对仓库根的 posix 路径（供 git add 使用）。"""
        rp = (self.repo_path / p).resolve()
        rel = rp.relative_to(self.repo_path.resolve())
        return rel.as_posix()


    def ensure_branch(self, name: str) -> None:
        """从当前 HEAD 创建任务分支并检出。已存在则切过去。"""
        if name in self.repo.branches:
            self.repo.git.checkout(name)
        else:
            self.repo.git.checkout("-b", name)

    def checkout(self, ref: str) -> None:
        self.repo.git.checkout(ref)

    def delete_branch(self, name: str) -> None:
        if name in self.repo.branches:
            self.repo.git.branch("-D", name)


    def commit_files(self, files: list[str], message: str) -> str:
        """按指定文件集 add + commit（禁 add -A，FR6）。返回 commit hash。"""
        rel = [self.relpath(f) for f in files if (self.repo_path / f).exists()]
        if rel:
            self.repo.index.add(rel)
            self.repo.index.commit(message)
        else:
            self.repo.git.commit("--allow-empty", "-m", message)
        return self.repo.head.commit.hexsha

    def reset_hard(self, commit_hash: str) -> None:
        self.repo.git.reset("--hard", commit_hash)


    def merge_noff(self, branch: str, message: str) -> None:
        try:
            self.repo.git.merge("--no-ff", branch, "-m", message)
        except Exception as e:
            raise GitError(f"合并冲突: {e}")

    def log(self, n: int = 20) -> list[dict]:
        out = []
        for c in self.repo.iter_commits(max_count=n):
            out.append({"hash": c.hexsha, "message": c.message.strip()})
        return out

    def commit_exists(self, commit_hash: str) -> bool:
        try:
            self.repo.git.rev_parse(commit_hash + "^{commit}")
            return True
        except Exception:
            return False
