"""路径安全：写操作必须落在 repo 内（realpath 归一化）。租约双重检查由 leases.py 提供。"""

from __future__ import annotations

import hashlib
from pathlib import Path






AGENT_TMP_DIR = ".agentflow_tmp"


class PathViolation(Exception):
    pass


def is_agent_tmp(path: str) -> bool:
    """是否落在 worktree 内的合法临时区（免租约、不纳入绿点）。"""
    posix = (path or "").replace("\\", "/")
    norm = posix[2:] if posix.startswith("./") else posix
    return (
        norm == AGENT_TMP_DIR
        or norm.startswith(AGENT_TMP_DIR + "/")
        or f"/{AGENT_TMP_DIR}/" in posix
    )


def resolve_inside(root: Path, path: str) -> Path:
    """把相对/绝对路径解析到 root 内并校验。返回归一化绝对路径，越界抛 PathViolation。"""
    root_real = root.resolve()
    candidate = (root_real / path).resolve() if not Path(path).is_absolute() else Path(path).resolve()
    try:
        candidate.relative_to(root_real)
    except ValueError as e:
        raise PathViolation(
            f"路径越界: {path} 不在项目内 {root_real}。"
            f"不会进交付物的一次性辅助脚本请写在项目内 {AGENT_TMP_DIR}/ 下"
            "（该目录免写集租约、不纳入绿点与合并）；只有需要交付的改动才写真实源码路径。"
        ) from e
    return candidate


def compute_hash(path: Path) -> str:
    """文件 sha256。不存在返回 'missing'。"""
    if not path.exists() or path.is_dir():
        return "missing"
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()
