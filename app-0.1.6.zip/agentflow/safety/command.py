"""命令安全：三档分级引擎（deny/ask/allow）+ 环境变量脱敏 + 真实执行。"""

from __future__ import annotations

import logging
import os
import re
import signal
import subprocess
import time
from pathlib import Path
from typing import Optional

from agentflow.config import Settings

_log = logging.getLogger(__name__)

ALLOW, ASK, DENY = "allow", "ask", "deny"
_RANK = {ALLOW: 0, ASK: 1, DENY: 2}


PATH_BOUNDARY_MARK = "项目外路径"


_PLATFORM_DB_NAMES = {"agentflow.db", "agentflow.db-wal", "agentflow.db-shm", "agentflow.repair.db"}





_GIT_STORE_DESTRUCTIVE = {
    "gc": "git gc",
    "prune": "git prune",
    "filter-branch": "git filter-branch",
    "filter-repo": "git filter-repo",
    "update-ref": "git update-ref",
}

_GIT_STORE_DESTRUCTIVE_PAIR = {("reflog", "expire"), ("worktree", "prune")}



_OUTBOUND_GIT_SUBCMDS = {"push"}
_OUTBOUND_PROGS = {"ssh", "scp", "sftp", "rsync"}


_WRITE_PROGS = {

    "rm", "unlink", "shred", "rmdir", "rd", "del", "erase", "remove-item", "ri",

    "mv", "move", "move-item", "mi", "rename", "ren", "rename-item",

    "cp", "copy", "copy-item", "xcopy", "robocopy", "rsync", "install",
    "tar", "zip", "unzip", "7z", "expand-archive", "compress-archive",

    "mkdir", "md", "touch", "truncate", "dd", "mkfile", "fsutil",
    "set-content", "add-content", "out-file", "new-item",
    "export-csv", "export-clixml", "tee-object",

    "sed", "patch", "split", "csplit",

    "chmod", "chown", "attrib", "icacls", "takeown", "mklink", "ln",

    "git",
}






_GIT_READ_SUBCMDS = {
    "status", "log", "show", "diff", "diff-tree", "diff-index", "diff-files",
    "rev-parse", "rev-list", "ls-files", "ls-tree", "cat-file", "blame", "annotate",
    "describe", "grep", "shortlog", "show-ref", "for-each-ref", "symbolic-ref",
    "name-rev", "merge-base", "whatchanged", "count-objects", "cherry", "check-ignore",
    "verify-commit", "verify-tag", "version", "help", "var",
}

_GIT_OPTS_WITH_VALUE = {
    "-C", "-c", "--git-dir", "--work-tree", "--namespace", "--exec-path",
    "--config-env", "--super-prefix", "--attr-source",
}


def _git_subcommand_index(toks: list[str]) -> int:
    """定位 git 子命令在 toks 中的下标（跳过全局选项及其值）；找不到返回 -1。"""
    i = 1
    while i < len(toks):
        t = toks[i]
        if t in _GIT_OPTS_WITH_VALUE:
            i += 2
            continue
        if t.startswith("-"):
            i += 1
            continue
        return i
    return -1


def _git_subcommand(toks: list[str]) -> str:
    """定位 git 子命令（跳过全局选项及其值）；找不到返回空串。"""
    i = _git_subcommand_index(toks)
    return toks[i].lower() if i >= 0 else ""


_CD_PROGS = {"cd", "chdir", "pushd", "set-location", "sl"}


_WIN_FLAG_TOKENS = {
    "/s", "/q", "/y", "/f", "/e", "/i", "/h", "/r", "/c", "/k", "/j", "/w",
    "/v", "/b", "/a", "/d", "/l", "/n", "/z", "/t", "/g", "/u", "/o", "/m",
    "/p", "/x",
}




_EXEC_WRAPPERS = {
    "xargs", "env", "timeout", "nice", "nohup", "setsid", "stdbuf", "ionice",
    "command", "exec", "builtin", "time", "doas", "pkexec",
}

_WRAP_SKIP_VALUE: dict[str, set[str]] = {
    "xargs": {"-I", "-i", "-n", "-P", "-d", "-a", "-E", "-s", "-L",
              "--replace", "--max-args", "--max-procs", "--delimiter",
              "--arg-file", "--eof", "--max-lines", "--max-chars"},
    "env": {"-u", "-C", "-S", "--unset", "--chdir", "--split-string"},
    "timeout": {"-s", "-k", "--signal", "--kill-after"},
    "nice": {"-n", "--adjustment"},
    "stdbuf": {"-i", "-o", "-e", "--input", "--output", "--error"},
    "ionice": {"-c", "-n", "-p", "--class", "--classdata", "--pid"},
    "command": {"-p"},
}

_SHELL_C_CLUSTER = re.compile(r"-[a-z]*c[a-z]*\Z")

_CMD_RUN_FLAG = re.compile(r"//?[ck]\Z", re.I)


def _bash_unescape(tok: str) -> str:
    """bash 反斜杠转义的保守还原（仅用于程序名/flag 语义判定，不用于路径解析）。"""
    if "\\" not in tok:
        return tok
    if re.match(r"^[A-Za-z]:", tok) or tok.startswith("\\\\"):
        return tok
    return tok.replace("\\", "")


def _bash_tokens(toks: list[str]) -> Optional[list[str]]:
    """反斜杠还原变体 token 列表；无变化返回 None（判定时与原 token 取更重档）。"""
    out = [_bash_unescape(t) for t in toks]
    return out if out != toks else None


def _unwrap_exec(toks: list[str]) -> Optional[list[str]]:
    """剥离执行包装器，返回被包装命令的 token 列表；非包装器/无被包命令返回 None。"""
    if not toks:
        return None
    prog = _prog(toks[0])
    if prog not in _EXEC_WRAPPERS:
        return None
    skip = _WRAP_SKIP_VALUE.get(prog, set())
    i, n = 1, len(toks)
    while i < n:
        t = toks[i]
        if prog == "env" and re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", t):
            i += 1
            continue
        if t.startswith("-"):
            base = t.lower().split("=", 1)[0]
            if base in skip and "=" not in t:
                i += 2
            else:
                i += 1
            continue
        break
    if prog == "timeout" and i < n and re.fullmatch(r"[0-9]+(\.[0-9]+)?[smhd]?", toks[i].lower()):
        i += 1
    return toks[i:] if i < n else None


class CommandError(Exception):
    pass




def _split_commands(cmd: str) -> list[list[str]]:
    chains: list[list[str]] = [[]]
    seg: list[str] = []
    quote: str | None = None

    def flush_seg() -> None:
        s = "".join(seg).strip()
        if s:
            chains[-1].append(s)
        seg.clear()

    i, n = 0, len(cmd)
    while i < n:
        ch = cmd[i]
        if quote:
            seg.append(ch)
            if ch == quote:
                quote = None
            i += 1
            continue
        if ch in ("'", '"'):
            quote = ch
            seg.append(ch)
            i += 1
            continue
        if ch == "$" and i + 1 < n and cmd[i + 1] == "(":


            j, _closed = _scan_cmd_substitution(cmd, i)
            seg.append(cmd[i:j])
            i = j
            continue
        if ch in "<>" and i + 1 < n and cmd[i + 1] == "(":


            j, _closed = _scan_paren_block(cmd, i + 1)
            seg.append(cmd[i:j])
            i = j
            continue
        two = cmd[i:i + 2]
        if two in ("&&", "||"):
            flush_seg()
            chains.append([])
            i += 2
            continue
        if ch == "|":
            flush_seg()
            i += 1
            continue
        if ch in (";", "\n", "\r"):
            flush_seg()
            chains.append([])
            i += 1
            continue
        seg.append(ch)
        i += 1
    flush_seg()
    return [c for c in chains if c]


def _tokens(segment: str) -> list[str]:
    """引号感知分词（引号剥除并拼接内容：`-r"f"` → `-rf`，即 GuardFall 归一化）。"""
    toks: list[str] = []
    buf: list[str] = []
    quote: str | None = None
    for ch in segment:
        if quote:
            if ch == quote:
                quote = None
            else:
                buf.append(ch)
        elif ch in ("'", '"'):
            quote = ch
        elif ch.isspace():
            if buf:
                toks.append("".join(buf))
                buf = []
        else:
            buf.append(ch)
    if buf:
        toks.append("".join(buf))
    return toks


def _prog(tok: str) -> str:
    """程序名归一化：取 basename、去 .exe、小写。"""
    p = tok.replace("\\", "/").split("/")[-1]
    if p.lower().endswith(".exe"):
        p = p[:-4]
    return p.lower()


def _is_ps_script_call(toks: list[str]) -> bool:
    """首 token 是否为 .ps1 脚本调用（./x.ps1、.\\x.ps1、x.ps1、& x.ps1）。"""
    if not toks:
        return False
    first = toks[1] if toks[0] == "&" and len(toks) > 1 else toks[0]
    return _prog(first).endswith(".ps1")






_PS_PROGS = ("powershell", "pwsh")
_PS_COMMAND_FLAGS = ("-command", "--command", "-c")


def _is_ps_command_invocation(toks: list[str]) -> bool:
    """首 token 是否 `powershell/pwsh … -Command/-c <脚本>` 显式包裹调用。"""
    if not toks or _prog(toks[0]) not in _PS_PROGS:
        return False
    return any(t.lower() in _PS_COMMAND_FLAGS for t in toks[1:])


def looks_like_powershell(cmd: str) -> bool:
    """命令是否 PowerShell 方言（cmd.exe 必然无法解释的形态）。"""
    for chain in _split_commands(cmd):
        for seg in chain:
            toks = _tokens(seg)
            if _is_ps_script_call(toks) or _is_ps_command_invocation(toks) or "$env:" in seg.lower():
                return True
    return False


_BASH_DQ_ESCAPABLE = ("`", "$", '"', "\\", "\n")


def _bash_dq_unescape(s: str) -> str:
    '''还原 bash 双引号内的反斜杠转义（`\\"` → `"`、`\\\\` → `\\`、`\\$` → 字面 `$`）。'''
    out: list[str] = []
    i, n = 0, len(s)
    while i < n:
        c = s[i]
        if c == "\\" and i + 1 < n and s[i + 1] in _BASH_DQ_ESCAPABLE:
            out.append(s[i + 1])
            i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


def _unwrap_ps_command(cmd: str) -> str | None:
    """拆 `powershell/pwsh [flags] -Command <脚本>` 包裹，返回内层脚本；不是该形态 → None。"""
    chains = _split_commands(cmd)
    if len(chains) != 1 or len(chains[0]) != 1:
        return None
    seg = chains[0][0].strip()
    if not _is_ps_command_invocation(_tokens(seg)):
        return None

    flag_end = -1
    quote: str | None = None
    tok_start = 0
    for i in range(len(seg) + 1):
        ch = seg[i] if i < len(seg) else " "
        if quote:
            if ch == quote:
                quote = None
            continue
        if ch in ("'", '"'):
            quote = ch
            continue
        if ch.isspace():
            val = _tokens(seg[tok_start:i])
            if val and val[0].lower() in _PS_COMMAND_FLAGS:
                flag_end = i
                break
            tok_start = i + 1
    if flag_end < 0:
        return None
    script = seg[flag_end:].strip()
    if not script:
        return None
    if len(script) >= 2 and script[0] == script[-1] == "'":
        return script[1:-1]
    if len(script) >= 2 and script[0] == script[-1] == '"':
        return _bash_dq_unescape(script[1:-1])
    return script





_PS_SCRIPT_CMD_POS = re.compile(
    r"(?P<pre>(?:^|[;&|\n])[ \t]*)(?P<path>(?:[A-Za-z]:)?(?:\.{0,2}[\\/])?[^\s;&|<>\"'(){}]+\.ps1)"
    r"(?=[\s;&|]|$)",
    re.M,
)
_PS_FILE_PREFIX = "powershell -NoProfile -ExecutionPolicy Bypass -File "


def _has_bare_ps_script(cmd: str) -> bool:
    """命令位是否存在裸 `.ps1` 调用（未被 powershell -File 包装）。"""
    return ".ps1" in cmd.lower() and _PS_SCRIPT_CMD_POS.search(cmd) is not None


def _wrap_bare_ps_scripts(cmd: str) -> str:
    """把命令位上的裸 `.ps1` 调用就地包成 `powershell -File`（其余原文原样保留）。"""
    if ".ps1" not in cmd.lower():
        return cmd
    return _PS_SCRIPT_CMD_POS.sub(lambda m: m.group("pre") + _PS_FILE_PREFIX + m.group("path"), cmd)



_UNKNOWN_CMD_MARKS = ("不是内部或外部命令", "is not recognized as", "识别为 cmdlet")



_CMD_NOT_FOUND_EXIT = 9009

_BASH_CMD_NOT_FOUND_MARKS = ("command not found", "未找到命令")
_BASH_NOT_FOUND_EXIT = 127


def _unknown_command(out: str, exit_code: int | None = None) -> bool:
    """命令未识别判定：优先语言/编码无关的退出码（cmd=9009），再退回报错特征文本。"""
    if exit_code == _CMD_NOT_FOUND_EXIT:
        return True
    low = out.lower()
    if any(m.lower() in low for m in _UNKNOWN_CMD_MARKS):
        return True
    if exit_code == _BASH_NOT_FOUND_EXIT and any(m in low for m in _BASH_CMD_NOT_FOUND_MARKS):
        return True
    return False


def _is_single_segment(cmd: str) -> bool:
    """单段命令（无 &&/||/;/| 链式）——重试仅限此形态：链式首段可能已成功执行，"""
    chains = _split_commands(cmd)
    return len(chains) == 1 and len(chains[0]) == 1


def _needs_bash_ps_wrap(cmd: str) -> bool:
    """链式命令里含裸 `.ps1` 调用 → 必须留 bash 并就地包装。"""
    return (not _is_single_segment(cmd)) and _has_bare_ps_script(cmd)


def cmd_prefix(cmd: str) -> str:
    """命令前缀（任务级免审粒度）：程序名 + 可选非 flag 子命令（如 `pip install`、`curl`）。"""
    chains = _split_commands(cmd)
    if not chains:
        return ""
    toks = _tokens(chains[0][0])
    if not toks:
        return ""
    parts = [_prog(toks[0])]
    if len(toks) > 1 and not toks[1].startswith("-") and not toks[1].startswith("/"):
        parts.append(toks[1].lower())
    return " ".join(parts)





_PIPE_DENY_PROGS = {
    "bash", "sh", "zsh", "dash", "python", "python3", "node", "perl", "ruby",
    "iex", "invoke-expression", "sudo",
}


_NESTED_SHELLS: dict[str, tuple[str, ...]] = {
    "bash": ("-c",), "sh": ("-c",), "zsh": ("-c",), "dash": ("-c",),
    "powershell": ("-command",), "pwsh": ("-command",), "cmd": ("/c", "-c"),
}


_NETWORK_PROGS = {
    "curl", "wget", "nc", "ncat", "ssh", "scp", "sftp", "ftp", "telnet",
    "invoke-webrequest", "iwr", "irm", "invoke-restmethod",
}


_INSTALL_SUBS: dict[str, tuple[str, ...]] = {
    "pip": ("install",), "pip3": ("install",),
    "npm": ("install", "i", "add", "ci"), "yarn": ("add", "install"),
    "pnpm": ("add", "install", "i"), "uv": ("add", "pip", "sync"),
    "cargo": ("add", "install"), "gem": ("install",),
    "composer": ("require", "install"), "dotnet": ("add", "install"),
    "go": ("get", "install"), "conda": ("install", "create"),
    "poetry": ("add", "install"), "nuget": ("install",),
}


_ASK_PROGS = {
    "docker", "kill", "taskkill", "pkill", "stop-process",
    "base64", "tee", "reg", "regedit", "attrib", "icacls", "takeown",
    "mklink", "schtasks", "net", "netsh",
}


_SECRET_HINTS = (
    ".env", "id_rsa", "id_ed25519", "id_ecdsa", "credentials", ".pem",
    ".aws", ".ssh", ".gnupg", ".kube", "secrets",
)
_READER_PROGS = {"cat", "type", "get-content", "gc", "more", "less", "head", "tail"}


_REDIRECT_SAFE_RE = re.compile(
    r"(?:\d)?>>?\s*(?:/dev/null|nul)\b|&>>?\s*(?:/dev/null|nul)\b|\d>&\d", re.I
)


_SECRET_KEY_RE = re.compile(r"key|token|secret|passw|credential|auth|cookie|session", re.I)


ENV_POLICY = "sanitize"


def sanitize_env(env: dict[str, str]) -> dict[str, str]:
    """剔除密钥类环境变量（PATH/TEMP 等系统变量不受影响）。"""
    return {k: v for k, v in env.items() if not _SECRET_KEY_RE.search(k)}


def _effective_env(env: Optional[dict]) -> Optional[dict]:
    if env is not None:
        return env
    base = dict(os.environ)
    return base if ENV_POLICY == "inherit" else sanitize_env(base)




def _deny_reason(prog: str, toks: list[str]) -> Optional[str]:
    rest = toks[1:]
    low = [t.lower() for t in rest]




    for t in low:
        if os.path.basename(t.replace("\\", "/").rstrip("/")) in _PLATFORM_DB_NAMES:
            return (
                "触碰 AgentFlow 平台状态库（编排 DB 及其 WAL）——任务内不得读写："
                "它不是你的工作区，读它拿不到有效信息，写它会破坏平台运行态。"
                "缺上下文请按 Spec 字面实现或写清假设交 done。"
            )
    if prog == "sudo":
        return "sudo 提权"
    if prog in ("pkexec", "doas"):
        return f"提权: {prog}"
    if prog.startswith("mkfs") or prog == "format":
        return f"磁盘格式化: {prog}"
    if prog in ("iex", "invoke-expression"):
        return "Invoke-Expression 动态执行"
    if prog == "rm":
        rec = force = False
        for t in low:
            if t == "--recursive":
                rec = True
            elif t == "--force":
                force = True
            elif t.startswith("-") and not t.startswith("--"):
                body = t.lstrip("-")
                if body and set(body) <= {"r", "f"}:
                    rec = rec or "r" in body
                    force = force or "f" in body
        if rec and force:
            return "rm 递归强删（任意 flag 形态）"
    if prog in ("rd", "rmdir") and any(t.startswith("/s") or t in ("-s", "--recursive") for t in low):
        return "rd /s 递归删除目录"
    if prog == "del" and any(t.startswith("/s") for t in low):
        return "del /s 递归删除"
    if prog in ("remove-item", "ri"):
        r = any(t.startswith("-rec") for t in low)
        f = any(t.startswith("-force") or t == "-fo" for t in low)
        if r and f:
            return "Remove-Item -Recurse -Force"
    if prog in ("powershell", "pwsh") and any(
        t == "-enc" or t.startswith("-encodedcommand") or t.startswith("-encodedc") for t in low
    ):
        return "EncodedCommand（Base64 载荷，典型绕过手法）"
    if prog == "chmod" and "777" in low:
        return "chmod 777"
    if prog == "git" and rest:


        gi = _git_subcommand_index(toks)
        sub = toks[gi].lower() if gi >= 0 else ""
        flags = [t.lower() for t in toks[gi + 1:]] if gi >= 0 else []
        if sub == "push" and ("--force" in flags or "-f" in flags) and "--force-with-lease" not in flags:
            return "git push --force"
        if sub == "reset" and "--hard" in flags:
            return "git reset --hard"
        if sub == "clean" and "-f" in flags and ("-d" in flags or "-x" in flags):
            return "git clean -f -d/-x"

        if sub in _GIT_STORE_DESTRUCTIVE:
            return (
                f"{_GIT_STORE_DESTRUCTIVE[sub]}——破坏 worktree 并行共享的 .git"
                "（objects/refs/reflog），波及并行任务与主 checkout，且绿点回滚依赖对象库完好"
                "（内部文档 红线 #2）"
            )
        if (sub, flags[0] if flags else "") in _GIT_STORE_DESTRUCTIVE_PAIR:
            return (
                f"git {sub} {flags[0]}——破坏 worktree 并行共享的 .git（refs/reflog/工作树注册），"
                "波及并行任务与主 checkout（内部文档 红线 #2）"
            )
        if sub == "config" and _git_config_writes(toks[gi + 1:]):
            return (
                "git config 写配置——.git/config 为 worktree 并行共享，会波及并行任务与主 checkout"
                "（只读形式 --get/--get-all/--get-regexp/-l/--list 与单键查询 `git config <key>` 放行）"
            )
    return None


def _ask_reason(prog: str, toks: list[str], segment: str, trusted_domains: list[str]) -> Optional[str]:
    rest = toks[1:]
    low = [t.lower() for t in rest]
    seg_low = segment.lower()
    if prog in _NETWORK_PROGS:
        for d in trusted_domains:
            if d and d.lower() in seg_low:
                return None
        return f"网络出站命令: {prog}"
    if prog in _INSTALL_SUBS and rest and low[0] in _INSTALL_SUBS[prog]:
        return f"安装依赖: {prog} {low[0]}"
    if prog in _ASK_PROGS:
        return f"高风险程序: {prog}"
    if prog in ("python", "python3") and rest:

        if "-c" in low:
            return "python -c 内联代码"
        if "-" in low:
            return "python 从 stdin 执行代码"
        for i, t in enumerate(low):
            if t == "-m" and i + 2 < len(low) and low[i + 1] == "pip" and low[i + 2] == "install":
                return "pip 安装依赖"
    if prog == "node" and rest and ("-e" in low or "--eval" in low):
        return "node -e 内联代码"
    if prog in ("perl", "ruby") and rest and "-e" in low:
        return f"{prog} -e 内联代码"
    if prog in _READER_PROGS and any(h in seg_low for h in _SECRET_HINTS):
        return "读取敏感文件（.env/密钥类）"
    if prog == "git" and rest and low[0] == "push":
        return "git push 推送远端"
    return _redirect_reason(segment)


def _redirect_reason(segment: str) -> Optional[str]:
    """引号外存在输出重定向（丢弃 /dev/null、NUL、fd 复制后仍剩 >）→ ask。"""
    def _has_gt(s: str) -> bool:
        quote = None
        for ch in s:
            if quote:
                if ch == quote:
                    quote = None
            elif ch in ("'", '"'):
                quote = ch
            elif ch == ">":
                return True
        return False

    if not _has_gt(segment):
        return None
    if _has_gt(_REDIRECT_SAFE_RE.sub("", segment)):
        return "输出重定向写文件（绕过写集租约）"
    return None


def _cd_target_outside(seg: str, repo_root: Path) -> bool:
    """该段是否为「cd/pushd 到 repo 外」。（写边界判定用：链内先切出项目外后，后续相对路径不再可信）"""
    toks = _tokens(seg)
    if not toks:
        return False
    prog = _prog(toks[0])
    if prog not in _CD_PROGS:
        return False
    for t in toks[1:]:
        tl = t.lower()
        if tl in ("-d", "/d", "-p", "-literalpath"):
            continue
        if tl.startswith("-"):
            continue
        return _token_outside(t, repo_root)
    return False


def _token_outside(tok: str, repo_root: Path, rel_base_outside: bool = False) -> bool:
    """单个 token 是否解析到 repo 外（realpath 归一化，不存在也判——先删后建的路径同样拦）。"""




    t = (tok or "").strip().strip("'\"").rstrip(";|&").strip("'\"")
    if not t:
        return False
    if "=" in t and not t.startswith("-"):

        t = t.split("=", 1)[1]
        if not t:
            return False
    if t.startswith("~"):
        return True
    if re.match(r"^[A-Za-z]:", t) or t.startswith("\\\\"):



        return not _inside_root(t, repo_root)
    if t.startswith("/"):

        return t.lower() not in _WIN_FLAG_TOKENS
    if t.startswith("-"):
        return False
    if (t.startswith("$") or t.startswith("%")) and ("/" in t or "\\" in t):
        return True
    if rel_base_outside:
        return True
    return not _inside_root(t, repo_root)


def _inside_root(t: str, repo_root: Path) -> bool:
    """token 解析后是否落在 repo_root 内（含 repo_root 自身）。相对路径按 repo_root 展开。"""
    try:
        p = Path(t)
        if not p.is_absolute():
            p = Path(repo_root) / t
        p.resolve().relative_to(Path(repo_root).resolve())
    except ValueError:
        return False
    except OSError:
        return False
    return True


def _path_boundary_reason(
    prog: str, toks: list[str], repo_root: Path, rel_base_outside: bool = False,
) -> Optional[str]:
    """写语义命令的路径参数解析到 repo 外 → ask（PATH_BOUNDARY_MARK 标记人审兜底）。"""
    if prog not in _WRITE_PROGS:
        return None
    if prog == "sed" and not any(t.lower().startswith("-i") or t.lower() == "--in-place" for t in toks[1:]):
        return None
    if prog == "git":
        i = _git_subcommand_index(toks)
        sub = toks[i].lower() if i >= 0 else ""
        if sub in _GIT_READ_SUBCMDS:
            return None


        if sub == "branch" and all(t.startswith("-") for t in toks[i + 1:]):
            return None
    for tok in toks[1:]:
        if _token_outside(tok, repo_root, rel_base_outside):
            return f"写操作目标在{PATH_BOUNDARY_MARK}: {tok}（外部文件无 git/租约保护，需人工确认）"
    return None


def _scan_paren_block(s: str, open_idx: int) -> tuple[int, bool]:
    """从 open_idx（指向 '('）扫描平衡括号段，返回 (闭括号后一位, 是否闭合)。"""
    n = len(s)
    depth, quote, j = 1, None, open_idx + 1
    while j < n and depth:
        ch = s[j]
        if ch == "\\" and j + 1 < n:
            j += 2
            continue
        if quote:
            if ch == quote:
                quote = None
        elif ch in ("'", '"'):
            quote = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        j += 1
    return (j, True) if depth == 0 else (n, False)


def _scan_cmd_substitution(s: str, start: int) -> tuple[int, bool]:
    """从 start（指向 $( 的 $）扫描平衡替换段，返回 (闭括号后一位, 是否闭合)。"""
    return _scan_paren_block(s, start + 1)


def _extract_backtick_spans(segment: str) -> list[str]:
    """提取反引号包裹段（\\` 转义的反引号视为字面量，不成对）。"""
    out: list[str] = []
    open_i = 0
    i, n = 0, len(segment)
    while i < n:
        ch = segment[i]
        if ch == "\\" and i + 1 < n and segment[i + 1] == "`":
            i += 2
            continue
        if ch == "`":
            if open_i:
                out.append(segment[open_i:i])
                open_i = 0
            else:
                open_i = i + 1
        i += 1
    return out


def _extract_cmd_substitutions(segment: str) -> tuple[list[str], bool]:
    """提取 $(...) 命令替换/子表达式内层（引号感知 + 反斜杠转义感知的平衡括号）。"""
    out: list[str] = []
    i, n = 0, len(segment)
    while i < n - 1:
        if segment[i] == "$" and segment[i + 1] == "(":
            j, closed = _scan_cmd_substitution(segment, i)
            if not closed:
                return out, True
            out.append(segment[i + 2 : j - 1])
            i = j
        else:
            i += 1
    return out, False


def _extract_proc_substitutions(segment: str) -> tuple[list[str], bool]:
    """提取 <( ) / >( ) 进程替换内层（bash 激活面，）：内层是真执行的命令。"""
    out: list[str] = []
    i, n = 0, len(segment)
    while i < n - 1:
        if segment[i] in "<>" and segment[i + 1] == "(":
            j, closed = _scan_paren_block(segment, i + 1)
            if not closed:
                return out, True
            out.append(segment[i + 2 : j - 1])
            i = j
        else:
            i += 1
    return out, False


def _has_ansi_c_quote(segment: str) -> bool:
    """非引号上下文里是否出现 ANSI-C 引用 `$'…'`（\\xNN 可构造任意命令字节）。"""
    quote: Optional[str] = None
    i, n = 0, len(segment)
    while i < n:
        ch = segment[i]
        if quote:
            if ch == "\\" and quote == '"' and i + 1 < n:
                i += 2
                continue
            if ch == quote:
                quote = None
            i += 1
            continue
        if ch == "$" and i + 1 < n and segment[i + 1] == "'":
            return True
        if ch in ("'", '"'):
            quote = ch
            i += 1
            continue
        if ch == "\\" and i + 1 < n:
            i += 2
            continue
        i += 1
    return False


def _classify_segment(
    segment: str, trusted_domains: list[str], depth: int = 0, repo_root: Optional[Path] = None,
    rel_base_outside: bool = False, ps_ctx: bool = False,
) -> tuple[str, str]:
    """段级判定入口：分词后做 token 级判定（含 bash 反斜杠还原变体，双跑取更重档）。"""
    return _classify_toks(segment, _tokens(segment), trusted_domains, depth, repo_root, rel_base_outside, ps_ctx)


def _classify_toks(
    segment: str, toks: list[str], trusted_domains: list[str], depth: int,
    repo_root: Optional[Path], rel_base_outside: bool, ps_ctx: bool = False,
) -> tuple[str, str]:
    v, r = _classify_core(segment, toks, trusted_domains, depth, repo_root, rel_base_outside, ps_ctx)
    if v == DENY:
        return v, r
    alt = _bash_tokens(toks)
    if alt is not None:
        v2, r2 = _classify_core(segment, alt, trusted_domains, depth, repo_root, rel_base_outside, ps_ctx)
        if _RANK[v2] > _RANK[v]:
            return v2, r2
    return v, r




_ASSIGN_BASH = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=")
_ASSIGN_PS = re.compile(
    r"^(?:\$[A-Za-z_:][A-Za-z0-9_:]*|\$\{[A-Za-z_][A-Za-z0-9_]*\}|%[A-Za-z][A-Za-z0-9_]*%|%%[A-Za-z])="
)


def _strip_brace_group(toks: list[str]) -> Optional[list[str]]:
    """剥离命令位的 bash 花括号分组记号 `{` / `}`（结构，非动态展开）。"""
    if not toks:
        return None
    if toks[0] == "}":
        return []
    if toks[0] == "{":
        return toks[1:]
    return None


def _strip_assign_prefix(toks: list[str]) -> Optional[list[str]]:
    """剥离命令位的前缀赋值（`FOO=1 rm -r -f x` → [rm, -r, -f, x]）。"""
    out = list(toks)
    changed = False
    while out:
        t0 = out[0]
        m = _ASSIGN_PS.match(t0)
        if m:
            rhs = t0[m.end():]
            out = ([rhs] if rhs else []) + out[1:]
            changed = True
            continue
        if _ASSIGN_BASH.match(t0):
            out = out[1:]
            changed = True
            continue
        break
    return out if changed else None


def _classify_core(
    segment: str, toks: list[str], trusted_domains: list[str], depth: int,
    repo_root: Optional[Path], rel_base_outside: bool, ps_ctx: bool = False,
) -> tuple[str, str]:
    if not toks:
        return ALLOW, ""

    prog = _prog(toks[0])


    ps_ctx = ps_ctx or prog in ("powershell", "pwsh")


    reason = _deny_reason(prog, toks)
    if reason:
        return DENY, reason



    if repo_root is not None:
        reason = _path_boundary_reason(prog, toks, repo_root, rel_base_outside)
        if reason:
            return ASK, reason





    if "$(" in segment:
        if depth >= 2:
            return ASK, "命令替换嵌套过深，无法静态判定"
        subs, unclosed = _extract_cmd_substitutions(segment)
        if unclosed:
            return ASK, "含未闭合 $( 子表达式，无法静态判定"
        for inner in subs:
            for chain in _split_commands(inner):

                for seg2 in chain[1:]:
                    ptoks = _tokens(seg2)
                    if ptoks and _prog(ptoks[0]) in _PIPE_DENY_PROGS:
                        return DENY, f"命令替换 $( 内管道串接解释器: {_prog(ptoks[0])}"
                for seg2 in chain:
                    v, r = _classify_segment(seg2, trusted_domains, depth + 1, repo_root, rel_base_outside, ps_ctx)
                    if v == DENY:
                        return DENY, f"命令替换 $( 内含危险命令: {r}"
                    if v == ASK:
                        return ASK, f"命令替换 $( : {r}"


    if "<(" in segment or ">(" in segment:
        if depth >= 2:
            return ASK, "进程替换嵌套过深，无法静态判定"
        subs, unclosed = _extract_proc_substitutions(segment)
        if unclosed:
            return ASK, "含未闭合进程替换 <( / >( ，无法静态判定"
        for inner in subs:
            for chain in _split_commands(inner):
                for seg2 in chain[1:]:
                    ptoks = _tokens(seg2)
                    if ptoks and _prog(ptoks[0]) in _PIPE_DENY_PROGS:
                        return DENY, f"进程替换内管道串接解释器: {_prog(ptoks[0])}"
                for seg2 in chain:
                    v, r = _classify_segment(seg2, trusted_domains, depth + 1, repo_root, rel_base_outside, ps_ctx)
                    if v == DENY:
                        return DENY, f"进程替换 <( ) 内含危险命令: {r}"
                    if v == ASK:
                        return ASK, f"进程替换 <( ): {r}"



    if "`" in segment:
        for span in _extract_backtick_spans(segment):
            v, r = _classify_segment(span, trusted_domains, depth + 1, repo_root, rel_base_outside, ps_ctx)
            if v == DENY:
                return DENY, f"反引号内含危险命令: {r}"
        return ASK, "含反引号（转义/替换元字符，无法静态判定）"


    if _has_ansi_c_quote(segment):
        return ASK, "含 ANSI-C 引用 $'…'（转义序列可构造任意命令字节），无法静态判定"



    stripped = _strip_assign_prefix(toks)
    if stripped is not None:
        if not stripped:
            return ALLOW, ""
        return _classify_toks(
            " ".join(stripped), stripped, trusted_domains, depth + 1, repo_root, rel_base_outside, ps_ctx
        )





    grouped = _strip_brace_group(toks)
    if grouped is not None:
        if not grouped:
            return ALLOW, ""
        return _classify_toks(
            " ".join(grouped), grouped, trusted_domains, depth + 1, repo_root, rel_base_outside, ps_ctx
        )




    first = toks[0]
    if not ps_ctx and any(ch in first for ch in ("$", "{", "%", "*")):
        return ASK, f"命令名含动态展开，无法静态判定: {first[:60]}"



    wrapped = _unwrap_exec(toks)
    if wrapped:
        if depth >= 2:
            return ASK, "执行包装器嵌套过深，无法静态判定"
        v, r = _classify_segment(
            " ".join(wrapped), trusted_domains, depth + 1, repo_root, rel_base_outside, ps_ctx
        )
        if v == DENY:
            return DENY, f"{prog} 包装的执行: {r}"
        if v == ASK:
            return ASK, r
        return ALLOW, ""



    if prog == "find":
        hit = _find_action_reason(toks, trusted_domains, depth, repo_root, rel_base_outside, ps_ctx)
        if hit:
            return hit




    if prog in _NESTED_SHELLS and depth < 2:
        flags = _NESTED_SHELLS[prog]
        rest_toks = toks[1:]
        for i, t in enumerate(rest_toks):
            tl = t.lower()
            hit = tl in flags
            if not hit and prog in ("powershell", "pwsh"):
                hit = tl.startswith("-command") or (
                    tl.startswith("-") and len(tl) > 1 and "-command".startswith(tl)
                )
            if not hit and prog in ("bash", "sh", "zsh", "dash", "ksh"):
                hit = bool(_SHELL_C_CLUSTER.match(tl))
            if not hit and prog == "cmd":
                hit = bool(_CMD_RUN_FLAG.match(tl))
            if hit:
                if prog in ("powershell", "pwsh"):
                    inner = " ".join(rest_toks[i + 1:])
                else:
                    inner = rest_toks[i + 1] if i + 1 < len(rest_toks) else ""
                if inner:






                    _inner_rel_out = rel_base_outside
                    _child_ps = ps_ctx or prog in ("powershell", "pwsh")
                    for inner_chain in _split_commands(inner):
                        for seg2 in inner_chain:
                            v, r = _classify_segment(
                                seg2, trusted_domains, depth + 1, repo_root, _inner_rel_out, _child_ps
                            )
                            if v == DENY:
                                return DENY, f"嵌套 {prog} 内含危险命令: {r}"
                            if v == ASK:
                                return ASK, f"嵌套 {prog}: {r}"
                            if repo_root is not None and _cd_target_outside(seg2, repo_root):
                                _inner_rel_out = True
                break


    reason = _ask_reason(prog, toks, segment, trusted_domains)
    if reason:
        return ASK, reason
    return ALLOW, ""


def _find_action_reason(
    toks: list[str], trusted_domains: list[str], depth: int,
    repo_root: Optional[Path], rel_base_outside: bool, ps_ctx: bool = False,
) -> Optional[tuple[str, str]]:
    """find 的 -delete/-exec 判定。返回 (verdict, reason) 或 None（无危险动作）。"""
    low_toks = [t.lower() for t in toks]
    if "-delete" in low_toks:
        return DENY, "find -delete 删除匹配文件（删除范围无法静态界定）"
    for i, tl in enumerate(low_toks):
        if tl not in ("-exec", "-execdir", "-ok", "-okdir"):
            continue
        inner: list[str] = []
        for w in toks[i + 1:]:
            if w in (";", "+"):
                break
            if w.endswith(";"):
                inner.append(w.rstrip(";"))
                break
            inner.append(w)
        if not inner:
            return ASK, f"find {tl} 但内层命令不可见，无法静态判定"
        v, r = _classify_segment(
            " ".join(inner), trusted_domains, depth + 1, repo_root, rel_base_outside, ps_ctx
        )
        iprog = _prog(_bash_unescape(inner[0]))
        if v == DENY:
            return DENY, f"find {tl} 内层危险命令: {r}"
        if v == ASK or iprog in _WRITE_PROGS or iprog in _ASK_PROGS or iprog in _NETWORK_PROGS:
            return ASK, f"find {tl} 对匹配文件执行 {iprog}（执行范围无法静态界定）"
    return None


class Safety:
    """命令三档分级拦截器：deny（停机人工）/ ask（审批门）/ allow（放行）。"""

    def __init__(self, settings: Settings):
        self.settings = settings
        sc = settings.data.get("safety", {})
        self._blocked = [re.compile(re.escape(p), re.I) for p in sc.get("blocked_commands", [])]
        self._allowed = [re.compile(re.escape(p), re.I) for p in sc.get("allowed_commands", [])]
        self._trusted_domains = [str(d).lower() for d in sc.get("trusted_network_domains", [])]

    def check(
        self, cmd: str, approved_prefixes: Optional[set[str]] = None,
        repo_root: Optional[Path] = None,
    ) -> tuple[str, str]:
        """返回 (verdict, reason)，verdict ∈ allow/ask/deny。"""
        for p in self._blocked:
            if p.search(cmd):
                return DENY, f"用户黑名单命中: {p.pattern}"
        verdict, reason = ALLOW, ""
        boundary = False




        ps_entry = looks_like_powershell(cmd) and not _needs_bash_ps_wrap(cmd)


        _rel_out = False
        for chain in _split_commands(cmd):

            for seg in chain[1:]:
                stoks = _tokens(seg)
                if stoks and _prog(stoks[0]) in _PIPE_DENY_PROGS:
                    return DENY, f"管道串接解释器: {_prog(stoks[0])}"
            for seg in chain:
                v, r = _classify_segment(
                    seg, self._trusted_domains, repo_root=repo_root, rel_base_outside=_rel_out, ps_ctx=ps_entry
                )
                if v == DENY:
                    return DENY, r
                if v == ASK:
                    if PATH_BOUNDARY_MARK in r:
                        boundary = True
                        verdict, reason = ASK, r
                    elif verdict == ALLOW:
                        verdict, reason = ASK, r
                if repo_root is not None and _cd_target_outside(seg, repo_root):
                    _rel_out = True
        if verdict == ASK:




            if "无法静态判定" in reason and not any(h in cmd.lower() for h in _SECRET_HINTS):
                for p in self._allowed:
                    if p.search(cmd):
                        return ALLOW, "用户白名单命中"
            if approved_prefixes and not boundary and cmd_prefix(cmd) in approved_prefixes:
                return ALLOW, "任务级已批准前缀"
        return verdict, reason


def _git_config_writes(args: list[str]) -> bool:
    """`git config <args>` 是否属于**写**语义（共享 .git/config）。"""
    low = [t.lower() for t in args]
    if any(t in ("--unset", "--unset-all", "--add", "--replace-all", "--rename-section",
                 "--remove-section", "-e", "--edit", "--set") for t in low):
        return True
    if any(t == "-l" or t == "--list" or t.startswith("--get") for t in low):
        return False
    pos: list[str] = []
    skip = False
    for t in args:
        if skip:
            skip = False
            continue
        if t.lower() in ("-f", "--file"):
            skip = True
            continue
        if t.startswith("-"):
            continue
        pos.append(t)
    return len(pos) >= 2


def has_outbound_side_effect(cmd: str) -> bool:
    '''命令串里是否含"对外副作用"动作（推送/远端部署）。'''
    for chain in _split_commands(cmd):
        for seg in chain:
            toks = _tokens(seg)
            if not toks:
                continue


            cands = [toks]
            alt = _bash_tokens(toks)
            if alt:
                cands.append(alt)
            for tk in cands:
                uw = _unwrap_exec(tk)
                if uw:
                    tk = uw
                prog = _prog(tk[0])
                if prog == "git":
                    i = _git_subcommand_index(tk)
                    if i >= 0 and tk[i].lower() in _OUTBOUND_GIT_SUBCMDS:
                        return True
                elif prog in _OUTBOUND_PROGS:
                    return True
                elif prog == "docker":
                    low = [t.lower() for t in tk[1:]]
                    if low[:1] == ["push"]:
                        return True
    return False


def _oem_codec() -> str:
    """Windows 控制台（OEM）代码页对应的 Python 编解码名；非 Windows 恒 utf-8。"""
    if os.name != "nt":
        return "utf-8"
    try:
        import ctypes

        return f"cp{int(ctypes.windll.kernel32.GetOEMCP())}"
    except Exception:
        return "mbcs"


def _decode_spawn_output(raw: bytes) -> str:
    """子进程输出解码：优先 UTF-8（严格），失败回退 OEM 控制台代码页。"""
    if not raw:
        return ""
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode(_oem_codec(), errors="replace")


_BASH_CACHE: str = ""


def _reject_non_git_bash(p: str) -> bool:
    """拒绝 WSL 假名（System32/WindowsApps 的 bash.exe 是 WSL 入口，文件系统命名空间不同）。"""
    lp = p.lower().replace("/", "\\")
    return ("windowsapps" in lp) or ("\\system32\\bash.exe" in lp) or ("\\system32\\wsl" in lp)


def resolve_bash() -> Optional[str]:
    """定位 Git Bash 绝对路径。结果进程内缓存。"""
    global _BASH_CACHE
    if _BASH_CACHE:
        return _BASH_CACHE if _BASH_CACHE != "-" else None
    import shutil

    if os.name != "nt":
        _BASH_CACHE = shutil.which("bash") or "-"
        return None if _BASH_CACHE == "-" else _BASH_CACHE

    cands: list[Path] = []
    for env_key, tail in (
        ("ProgramFiles", ("Git", "bin", "bash.exe")),
        ("ProgramFiles(x86)", ("Git", "bin", "bash.exe")),
        ("LocalAppData", ("Programs", "Git", "bin", "bash.exe")),
    ):
        base = os.environ.get(env_key)
        if base:
            cands.append(Path(base).joinpath(*tail))
    git = shutil.which("git")
    if git:
        gp = Path(git).resolve()

        for up in (2, 3):
            root = gp
            for _ in range(up):
                root = root.parent
            cands.append(root / "bin" / "bash.exe")
    w = shutil.which("bash")
    if w and not _reject_non_git_bash(w):
        cands.append(Path(w))
    for c in cands:
        try:
            if c.exists() and not _reject_non_git_bash(str(c)):
                _BASH_CACHE = str(c)
                _log.info("[safety] Windows 主执行壳已定位 Git Bash: %s", _BASH_CACHE)
                return _BASH_CACHE
        except OSError:
            continue
    _BASH_CACHE = "-"
    _log.warning("[safety] 未找到 Git Bash（Git\\bin\\bash.exe）；Windows 默认链回退 cmd")
    return None


def _spawn(cmd: str, cwd: Path, timeout: int, env: Optional[dict], kind: str) -> tuple[int, str]:
    """单次执行（kind ∈ cmd|powershell|bash），返回 (exit_code, 截断输出)。不抛异常。"""
    if kind == "powershell":
        full: str | list[str] = ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd]
        use_shell = False
    elif kind == "bash":
        bp = resolve_bash()
        if not bp:
            return 127, "[bash 不可用] 未找到 Git Bash（Windows 需安装 Git for Windows，或把 [execution].windows_shell 切回 cmd）"
        full = [bp, "-c", cmd]
        use_shell = False
    else:
        full = cmd
        use_shell = True
    try:
        if os.name == "nt":
            proc = subprocess.Popen(full, shell=use_shell, cwd=str(cwd), stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, env=env)
        else:

            proc = subprocess.Popen(full, shell=use_shell, cwd=str(cwd), stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, env=env,
                                    start_new_session=True)
        try:
            raw, _ = proc.communicate(timeout=timeout)
            return proc.returncode, _truncate(_decode_spawn_output(raw or b""), 8000)
        except subprocess.TimeoutExpired:
            _kill_tree(proc.pid)
            try:
                raw, _ = proc.communicate(timeout=15)
            except subprocess.TimeoutExpired:
                return 124, f"[timeout after {timeout}s] (tree kill incomplete)"
            return 124, _truncate(f"[timeout after {timeout}s]\n{_decode_spawn_output(raw or b'')}", 8000)
    except Exception as e:
        return 1, f"[run error] {e}"


def _windows_shell() -> str:
    """Windows 主执行壳：读 [execution].windows_shell（默认 bash）。"""
    try:
        from agentflow.config import default_windows_shell

        return default_windows_shell()
    except Exception:
        return "bash"


def _run_via_powershell(cmd: str, cwd: Path, timeout: int, env: Optional[dict]) -> tuple[int, str]:
    """PS 路由统一入口：显式 `powershell/pwsh -Command` 包裹先拆包直跑内层脚本"""
    inner = _unwrap_ps_command(cmd)
    if inner is not None:
        code, out = _spawn(inner, cwd, timeout, env, "powershell")
        return code, _truncate(f"[powershell 包裹拆包执行]\n{out}")
    return _spawn(cmd, cwd, timeout, env, "powershell")


def run_command(
    cmd: str,
    cwd: Path,
    timeout: int = 120,
    env: Optional[dict] = None,
    shell: Optional[str] = None,
) -> tuple[int, str]:
    """执行命令，返回 (exit_code, 截断输出)。不抛异常。"""
    env = _effective_env(env)
    if shell == "powershell":
        return _run_via_powershell(cmd, cwd, timeout, env)
    if shell == "bash":
        return _spawn(cmd, cwd, timeout, env, "bash")
    if shell == "cmd":
        return _spawn(cmd, cwd, timeout, env, "cmd")

    if os.name != "nt":

        return _spawn(cmd, cwd, timeout, env, "cmd")




    if _needs_bash_ps_wrap(cmd):
        cmd = _wrap_bare_ps_scripts(cmd)
    elif looks_like_powershell(cmd):
        return _run_via_powershell(cmd, cwd, timeout, env)

    mode = _windows_shell()
    if mode == "bash" and resolve_bash():
        code, out = _spawn(cmd, cwd, timeout, env, "bash")
        if code != 0 and _is_single_segment(cmd) and _unknown_command(out, code):
            code2, out2 = _run_via_powershell(cmd, cwd, timeout, env)
            if code2 == 0 or not _unknown_command(out2, code2):
                merged = f"[bash exit {code}] {out}\n[自动改用 powershell 重试] {out2}"
                return code2, _truncate(merged, 8000)
        return code, out
    if mode == "powershell":
        return _run_via_powershell(cmd, cwd, timeout, env)


    code, out = _spawn(cmd, cwd, timeout, env, "cmd")
    if code != 0 and _is_single_segment(cmd) and _unknown_command(out, code):
        code2, out2 = _run_via_powershell(cmd, cwd, timeout, env)
        if code2 == 0 or not _unknown_command(out2, code2):
            merged = f"[cmd exit {code}] {out}\n[自动改用 powershell 重试] {out2}"
            return code2, _truncate(merged, 8000)
    return code, out


def _kill_tree(pid: int) -> None:
    """按进程树杀进程：Windows 用 taskkill /T，POSIX 用进程组信号。失败静默（上层有兜底）。"""
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, timeout=15)
        else:
            os.killpg(os.getpgid(pid), signal.SIGKILL)
    except Exception:
        try:
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True, timeout=15)
            else:
                os.kill(pid, signal.SIGKILL)
        except Exception:
            pass


def _truncate(text: str, limit: int = 8000) -> str:
    return text if len(text) <= limit else text[:limit] + f"\n...[truncated {len(text) - limit} chars]"
