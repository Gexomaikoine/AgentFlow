"""OpenAI 适配器（provider=openai）：用 OpenAI 兼容网关 API 作为模型后端。"""

from __future__ import annotations

import os
from typing import Callable, Optional
from uuid import uuid4

from agentflow.config import Settings
from agentflow.llm.gateway import LLMError, LLMResult, effort_of, norm_base_url, profile_env_key, profile_for


class OpenAIAdapter:
    def __init__(self, settings: Settings):
        try:
            from openai import OpenAI
        except ImportError as e:
            raise RuntimeError("provider=openai 但未安装 openai，请 pip install openai") from e

        self.settings = settings
        self._missing_key = ""
        self._clients: dict[str, object] = {}
        self._session = os.environ.get("OPENCODE_SESSION_ID", "").strip() or str(uuid4())


        self.client = self._build_client(profile=None)
        if self.client is None:
            self._missing_key = self._missing_message()

    def _missing_message(self) -> str:
        return (
            "未检测到 API Key。请在 设置→模型 页签填写并保存（全局或档案专用），"
            "或于 ~/.agentflow/.env 写入 OPENAI_API_KEY=... 后重启执行面。"
        )

    def _resolve_key(self, profile: dict | None = None) -> str:
        """Key 优先级：档案专用 > 兼容变量（旧版遗留） > 全局默认。都未设则空。"""
        if profile:
            k = os.environ.get(profile_env_key(profile["name"]), "").strip()
            if k:
                return k
        return os.environ.get("OPENCODE_API_KEY", "").strip() or os.environ.get("OPENAI_API_KEY", "").strip()

    def _effective_base(self, profile: dict | None = None) -> str:
        cfg = self.settings.data["llm"].get("openai", {})
        if profile:
            b = norm_base_url(str(profile.get("base_url") or ""))
            if b:
                return b
        return norm_base_url(cfg.get("base_url") or os.environ.get("OPENAI_BASE_URL", ""))

    def _build_client(self, profile: dict | None = None):
        key = self._resolve_key(profile)
        if not key:
            return None
        from openai import OpenAI

        cfg = self.settings.data["llm"].get("openai", {})
        kwargs: dict = {"api_key": key}


        kwargs["timeout"] = float(cfg.get("timeout_s", 150))
        kwargs["max_retries"] = 0
        base_url = self._effective_base(profile)
        if base_url:
            kwargs["base_url"] = base_url


        if "opencode.ai" in base_url.lower() or (profile is None and os.environ.get("OPENCODE_API_KEY", "").strip()):
            kwargs["default_headers"] = {"X-Opencode-Session": self._session}
        return OpenAI(**kwargs)

    def _client_for(self, profile: dict):
        """档案 → 客户端：无专属网关/Key 时复用全局客户端；有则按档案建并缓存。"""
        name = profile["name"]
        has_own = norm_base_url(str(profile.get("base_url") or "")) or os.environ.get(profile_env_key(name), "").strip()
        if not has_own:
            return self.client
        c = self._clients.get(name)
        if c is None:
            c = self._build_client(profile)
            self._clients[name] = c
        return c

    def generate(self, role: str, prompt: str = "", system: Optional[str] = None, tools: Optional[list] = None, messages: Optional[list] = None, images: Optional[list] = None, on_delta: Optional[Callable] = None) -> LLMResult:

        import time

        last_err: Exception | None = None
        for attempt in range(3):
            try:
                return self._generate_once(role, prompt, system, tools, messages, images, on_delta=on_delta)
            except Exception as e:
                name = type(e).__name__
                transient = any(k in name for k in ("Connection", "Timeout", "RateLimit", "InternalServer", "APIStatus"))
                last_err = e
                if not transient or attempt == 2:
                    raise
                time.sleep(1.5 * (attempt + 1))
        raise last_err

    def _generate_once(self, role: str, prompt: str, system: Optional[str], tools: Optional[list], messages: Optional[list] = None, images: Optional[list] = None, on_delta: Optional[Callable] = None) -> LLMResult:
        profile = profile_for(self.settings, role)
        model = profile["model"]
        if images and not profile.get("vision"):
            raise LLMError(
                f"模型档案 {profile['name']} 未开启视觉（vision），角色 {role} 无法处理图片请求；"
                "请在 设置→模型 页签为该档案勾选视觉或改用视觉模型"
            )
        client = self._client_for(profile)
        if client is None:
            raise LLMError(self._missing_message())
        if messages is None:
            messages = []
            if system:
                messages.append({"role": "system", "content": system})

            if images:
                content: list = [{"type": "text", "text": prompt}]
                for url in images:
                    content.append({"type": "image_url", "image_url": {"url": url}})
                messages.append({"role": "user", "content": content})
            else:
                messages.append({"role": "user", "content": prompt})
        kwargs: dict = {"model": model, "messages": messages}
        if tools:
            kwargs["tools"] = tools


        effort = effort_of(profile)
        if effort:
            kwargs["reasoning_effort"] = effort




        resp_stream = client.chat.completions.create(
            **kwargs, stream=True, stream_options={"include_usage": True}
        )
        content_parts: list[str] = []
        tc_acc: dict[int, dict] = {}
        usage = None
        for chunk in resp_stream:
            if getattr(chunk, "usage", None):
                usage = chunk.usage
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta
            if delta.content:
                content_parts.append(delta.content)
                if on_delta:
                    try:
                        on_delta(delta.content)
                    except Exception:
                        pass
            for tc in getattr(delta, "tool_calls", None) or []:
                acc = tc_acc.setdefault(tc.index, {"id": "", "name": "", "arguments": ""})
                if tc.id:
                    acc["id"] = tc.id
                fn = getattr(tc, "function", None)
                if fn and fn.name:
                    acc["name"] += fn.name
                if fn and fn.arguments:
                    acc["arguments"] += fn.arguments


        tool_calls = []
        text = "".join(content_parts)
        for acc in (tc_acc[i] for i in sorted(tc_acc)):
            args = {}
            try:
                import json

                args = json.loads(acc["arguments"] or "{}")
            except (json.JSONDecodeError, TypeError):
                args = {}
            tool_calls.append({"name": acc["name"], "arguments": args})


            if acc["name"] == "done" and not text:
                text = "done"

        return LLMResult(
            text=text,
            tokens_in=usage.prompt_tokens if usage else 0,
            tokens_out=usage.completion_tokens if usage else 0,
            tokens_in_cached=_cached_tokens(usage),
            tool_calls=tool_calls,
        )


def _cached_tokens(usage) -> int:
    """前缀缓存命中的输入 token（provider 报告口径不一，两处都认，取到即用）。"""
    if usage is None:
        return 0
    details = getattr(usage, "prompt_tokens_details", None)
    cached = getattr(details, "cached_tokens", None) if details is not None else None
    if cached is None:
        raw = usage.get("prompt_cache_hit_tokens") if isinstance(usage, dict) else getattr(usage, "prompt_cache_hit_tokens", None)
        cached = raw
    try:
        return int(cached or 0)
    except (TypeError, ValueError):
        return 0
