"""LLM 网关：统一 generate 接口。provider=mock|litellm，可切换（DECISIONS ）。"""

from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from typing import Callable, Optional

from agentflow.config import Settings


@dataclass
class LLMResult:
    text: str
    tokens_in: int = 0
    tokens_out: int = 0




    tokens_in_cached: int = 0

    tool_calls: list = field(default_factory=list)


class LLMError(Exception):
    """LLM 配置/调用错误（响亮错：档案缺失/能力不符时拒绝，不静默回退）。"""



VISION_ROLES = frozenset({"lead"})


def profile_for(settings: Settings, role: str) -> dict:
    """角色 → 模型档案。无默认模型回退：未分配/档案缺失/模型名空一律响亮报错。"""
    llm = settings.data["llm"]
    effective = llm.get("effective_roles") or {}
    name = effective.get(role) or (llm.get("roles") or {}).get(role, "")
    name = name.strip() if isinstance(name, str) else ""
    if not name:
        raise LLMError(f"角色 {role} 未分配模型档案，请在 设置→模型 页签配置")
    p = (llm.get("profiles") or {}).get(name)
    if not isinstance(p, dict):
        raise LLMError(f"角色 {role} 指向的模型档案 {name!r} 不存在，请在 设置→模型 页签修正")
    if not str(p.get("model") or "").strip():
        raise LLMError(f"模型档案 {name!r} 未填写模型名")
    return {"name": name, **p}


def effort_of(profile: dict) -> str:
    """档案思考档位：未开启思考 → 空（不传 reasoning_effort，走网关/模型默认）。"""
    if not profile.get("thinking"):
        return ""
    return str(profile.get("effort") or "").strip()



_FAMILY_KEYWORDS: tuple[tuple[str, str], ...] = (
    ("chatglm", "zhipu"), ("glm", "zhipu"), ("deepseek", "deepseek"),
    ("claude", "anthropic"), ("gpt", "openai"), ("o1", "openai"), ("o3", "openai"), ("o4", "openai"),
    ("gemini", "google"), ("qwen", "qwen"), ("qwq", "qwen"), ("kimi", "moonshot"), ("moonshot", "moonshot"),
    ("doubao", "bytedance"), ("ernie", "baidu"), ("hunyuan", "tencent"), ("llama", "meta"),
    ("mistral", "mistral"), ("minimax", "minimax"), ("grok", "xai"),
)


ADVERSARIAL_REVIEW_ROLES = ("qa",)
ADVERSARIAL_WRITER_ROLES = ("lead", "fixer")


def model_family(profile: dict) -> str:
    """档案 → 模型家族：显式 family 字段优先，否则按模型名关键词推断，推断不出为 unknown。"""
    fam = str(profile.get("family") or "").strip()
    if fam:
        return fam.lower()
    name = str(profile.get("model") or "").lower()
    for kw, fam in _FAMILY_KEYWORDS:
        if kw in name:
            return fam
    return "unknown"


def apply_adversarial_review(settings: Settings) -> dict[str, str]:
    """跨模型对抗评审（C）：reviewer/qa 与 developer/fixer 同家族时自动改用异家族档案。"""
    llm = settings.data["llm"]
    llm["effective_roles"] = {}
    if llm.get("cross_review") is False:
        return {}
    if str(llm.get("provider") or "") == "mock":
        return {}
    roles = llm.get("roles") or {}
    profiles = llm.get("profiles") or {}
    try:
        writer_fams = {model_family(profile_for(settings, r)) for r in ADVERSARIAL_WRITER_ROLES}
    except LLMError:
        return {}
    bound = {v for v in roles.values() if isinstance(v, str)}
    effective: dict[str, str] = {}
    for role in ADVERSARIAL_REVIEW_ROLES:
        name = (roles.get(role) or "").strip()
        p = profiles.get(name)
        if not isinstance(p, dict) or model_family(p) not in writer_fams:
            continue

        candidates = [
            n for n, pr in profiles.items()
            if isinstance(pr, dict) and str(pr.get("model") or "").strip()
            and model_family(pr) not in writer_fams
        ]
        candidates.sort(key=lambda n: (n not in bound, n))
        if candidates:
            effective[role] = candidates[0]
    llm["effective_roles"] = effective
    return effective


def norm_base_url(u: str) -> str:
    """网关地址规范化：剥尾部斜杠与误贴的 /chat/completions 后缀（SDK 会自行拼接端点，"""
    u = (u or "").strip().rstrip("/")
    if u.lower().endswith("/chat/completions"):
        u = u[: -len("/chat/completions")].rstrip("/")
    return u


def profile_env_key(profile_name: str) -> str:
    """档案专用 Key 的环境变量名（值存 ~/.agentflow/.env，不进 config.toml）："""
    import re

    slug = re.sub(r"[^A-Za-z0-9]+", "_", profile_name).strip("_").upper()[:40]
    return f"OPENAI_API_KEY__P_{slug or 'UNNAMED'}"


class LLMGateway:
    """按配置 provider 路由到 mock 或 litellm 实现。"""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.rebuild()

    def rebuild(self) -> None:
        """按当前 settings 重建底层实现（模型页签保存后热生效）。"""
        provider = self.settings.data["llm"]["provider"]
        if provider == "litellm":
            try:
                from agentflow.llm.litellm_adapter import LiteLLMAdapter

                self._impl = LiteLLMAdapter(self.settings)
            except ImportError:
                from agentflow.llm.mock import MockLLM

                self._impl = MockLLM(self.settings)
        elif provider == "openai":
            from agentflow.llm.openai_adapter import OpenAIAdapter

            self._impl = OpenAIAdapter(self.settings)
        else:
            from agentflow.llm.mock import MockLLM

            self._impl = MockLLM(self.settings)

    def generate(
        self,
        role: str,
        prompt: str = "",
        system: Optional[str] = None,
        tools: Optional[list] = None,
        messages: Optional[list] = None,
        images: Optional[list] = None,
        on_delta: Optional[Callable[[str], None]] = None,
    ) -> LLMResult:
        """调用模型。tools 为 OpenAI 原生 function schema（可选）。"""
        kwargs: dict = {"role": role, "prompt": prompt, "system": system, "tools": tools, "messages": messages, "images": images}
        if on_delta is not None and "on_delta" in inspect.signature(self._impl.generate).parameters:
            kwargs["on_delta"] = on_delta
        return self._impl.generate(**kwargs)

    def model_for(self, role: str) -> str:
        return profile_for(self.settings, role)["model"]
