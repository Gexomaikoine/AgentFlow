"""LiteLLM 适配位：安装 litellm 后启用真实多模型接入（DECISIONS  的切换面）。"""

from __future__ import annotations

from typing import Optional

from agentflow.config import Settings
from agentflow.llm.gateway import LLMError, LLMResult, effort_of, profile_for


class LiteLLMAdapter:
    """LiteLLM 薄封装。首次使用前需 `pip install litellm` 并在 设置→模型 配好档案与 Key。"""

    def __init__(self, settings: Settings):
        try:
            import litellm
        except ImportError as e:
            raise RuntimeError("provider=litellm 但未安装 litellm，请 pip install litellm 或改回 mock") from e
        self.settings = settings

    def generate(self, role: str, prompt: str = "", system: Optional[str] = None, tools: Optional[list] = None, messages: Optional[list] = None, images: Optional[list] = None) -> LLMResult:
        import litellm

        profile = profile_for(self.settings, role)
        if images and not profile.get("vision"):
            raise LLMError(
                f"模型档案 {profile['name']} 未开启视觉（vision），角色 {role} 无法处理图片请求；"
                "请在 设置→模型 页签为该档案勾选视觉或改用视觉模型"
            )
        if messages is None:
            messages = []
            if system:
                messages.append({"role": "system", "content": system})

            if images:
                content: list = [{"type": "text", "text": prompt}]
                for url in images:
                    content.append({"type": "image_url", "image_url": {"url": url}})
                messages.append({"role": "user", "content": content})
            else:
                messages.append({"role": "user", "content": prompt})
        kwargs: dict = {"model": profile["model"], "messages": messages}
        if tools:
            kwargs["tools"] = tools
        effort = effort_of(profile)
        if effort:
            kwargs["reasoning_effort"] = effort
        resp = litellm.completion(**kwargs)
        msg = resp.choices[0].message
        tool_calls = []
        text = getattr(msg, "content", None) or ""
        for tc in getattr(msg, "tool_calls", None) or []:
            fn = tc.function
            args = {}
            try:
                import json

                args = json.loads(fn.arguments or "{}")
            except (json.JSONDecodeError, TypeError):
                args = {}
            tool_calls.append({"name": fn.name, "arguments": args})


            if fn.name == "done" and not text:
                text = "done"
        usage = getattr(resp, "usage", None)
        from agentflow.llm.openai_adapter import _cached_tokens

        return LLMResult(
            text=text,
            tokens_in=usage.prompt_tokens if usage else 0,
            tokens_out=usage.completion_tokens if usage else 0,
            tokens_in_cached=_cached_tokens(usage),
            tool_calls=tool_calls,
        )
