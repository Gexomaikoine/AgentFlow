"""SQLModel 表模型：SQLite 即结构化黑板（唯一事实源）。"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Optional

from sqlmodel import Field, SQLModel


def _now() -> str:
    """北京时间（Asia/Shanghai, UTC+8）ISO 字符串。"""
    from datetime import datetime, timedelta, timezone

    return datetime.now(timezone(timedelta(hours=8))).isoformat()


class TaskStatus(str, Enum):
    draft = "draft"
    clarifying = "clarifying"
    spec_generating = "spec_generating"
    spec_pending = "spec_pending"
    running = "running"
    paused_human = "paused_human"
    merging = "merging"
    human_review = "human_review"
    rework = "rework"
    waiting_subtasks = "waiting_subtasks"
    done = "done"
    merged = "merged"
    pending_push = "pending_push"
    passed = "passed"
    pushed = "pushed"
    failed = "failed"



    resolved = "resolved"
    aborted = "aborted"








MERGED_OK_STATUSES: frozenset["TaskStatus"] = frozenset({
    TaskStatus.merged,
    TaskStatus.human_review,
    TaskStatus.pending_push,
    TaskStatus.pushed,
    TaskStatus.passed,
})


class FeatureStatus(str, Enum):
    pending = "pending"
    writing = "writing"
    verifying = "verifying"
    passed = "passed"
    failed = "failed"
    queued = "queued"
    fixing = "fixing"
    stale = "stale"
    blocked = "blocked"
    skipped = "skipped"


class NodeStatus(str, Enum):
    pending = "pending"
    running = "running"
    succeeded = "succeeded"
    failed = "failed"
    skipped = "skipped"
    interrupted = "interrupted"


class EdgeKind(str, Enum):
    sequence = "sequence"
    dependency = "dependency"
    kickback = "kickback"


class LeaseState(str, Enum):
    granted = "granted"
    applied = "applied"
    conflict = "conflict"
    denied_out_of_scope = "denied_out_of_scope"


class InvariantLayer(str, Enum):
    template = "template"
    custom = "custom"


class Project(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)
    repo_path: str
    stack: str = "{}"
    config: str = "{}"
    created_at: str = Field(default_factory=_now)
    archived_at: Optional[str] = None
    sort_order: int = 0


class Task(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    project_id: int = Field(index=True, foreign_key="project.id")
    title: str
    raw_request: str = ""
    status: TaskStatus = TaskStatus.draft
    branch: str = ""
    total_budget: str = "{}"
    used_budget: str = "{}"
    created_at: str = Field(default_factory=_now)
    updated_at: str = Field(default_factory=_now)
    archived_at: Optional[str] = None
    pinned: bool = False
    completed_at: Optional[str] = None
    parent_task_id: Optional[int] = Field(default=None, index=True)
    origin: str = ""


class Spec(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    version: int = 1
    yaml_raw: str = ""
    parsed: str = "{}"
    confirmed_at: Optional[str] = None
    complexity: str = "standard"


class ClarifyMessage(SQLModel, table=True):
    """澄清对话历史（持久化，切页不丢）。role: user|assistant"""

    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    role: str = "user"
    content: str = ""
    images: str = "[]"
    consumed_at: str = ""
    created_at: str = Field(default_factory=_now)


class Feature(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    spec_id: int = Field(index=True, foreign_key="spec.id")
    task_id: int = Field(index=True, foreign_key="task.id")
    seq: int = 0
    title: str = ""
    file_scope: str = "[]"
    verify_commands: str = "[]"
    depends_on: str = "[]"
    related_files: str = "[]"
    status: FeatureStatus = FeatureStatus.pending
    retry_count: int = 0


class AgentInstance(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    role: str = ""
    model: str = ""


class Node(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    agent_id: Optional[int] = None
    feature_id: Optional[int] = None
    seq: int = 0
    kind: str = "think"
    role: str = ""
    status: NodeStatus = NodeStatus.pending
    retries: int = 0
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
    rolled_back: bool = False
    token_in: int = 0
    token_out: int = 0
    token_in_cached: int = 0
    duration_ms: int = 0
    summary: str = ""
    trace_uri: str = ""


class Edge(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    from_node: int = 0
    to_node: int = 0
    kind: EdgeKind = EdgeKind.sequence


class Lease(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    feature_id: int = Field(index=True, foreign_key="feature.id")
    file_path: str = ""
    base_hash: str = ""
    state: LeaseState = LeaseState.granted


class GreenAnchor(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    feature_id: Optional[int] = None
    commit_hash: str = ""
    created_at: str = Field(default_factory=_now)
    invalidated_at: Optional[str] = None


class VerifierRun(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    feature_id: int = Field(index=True, foreign_key="feature.id")
    task_id: int = Field(index=True, foreign_key="task.id")
    node_id: Optional[int] = None
    verifier: str = ""
    cmd: str = ""
    exit_code: Optional[int] = None
    duration_ms: int = 0
    output_uri: str = ""
    classification: Optional[str] = None
    detail: Optional[str] = None
    fingerprint: Optional[str] = None


class FailureQueueEntry(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    feature_id: int = Field(index=True, foreign_key="feature.id")
    verifier_run_id: Optional[int] = None
    classification: str = ""
    attempts: int = 0
    status: str = "open"


class MergeQueueEntry(SQLModel, table=True):
    """合并队列（P1→队列化）：每项目串行合并。status: queued|merging|merged|failed|aborted。"""

    id: Optional[int] = Field(default=None, primary_key=True)
    project_id: int = Field(index=True, foreign_key="project.id")
    task_id: int = Field(index=True, foreign_key="task.id")
    status: str = "queued"
    attempts: int = 0
    round_no: int = 1
    redo_of: Optional[int] = None
    hold: bool = False
    merged_sha: Optional[str] = None
    created_at: str = Field(default_factory=_now)
    updated_at: str = Field(default_factory=_now)
    error: Optional[str] = None


class Invariant(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    project_id: int = Field(index=True, foreign_key="project.id")
    layer: InvariantLayer = InvariantLayer.custom
    text: str = ""
    verify_cmd: Optional[str] = None


class ProjectRule(SQLModel, table=True):
    """项目规则（#3）：用户自定义、多条管理；对每个任务具有最高优先级，"""

    id: Optional[int] = Field(default=None, primary_key=True)
    project_id: int = Field(index=True, foreign_key="project.id")
    title: str = ""
    content: str = ""
    enabled: bool = True
    sort_order: int = 0
    created_at: str = Field(default_factory=_now)


class GlobalRule(SQLModel, table=True):
    """全局规则（跨项目）：对所有项目的所有任务生效，注入所有 agent 的"""

    id: Optional[int] = Field(default=None, primary_key=True)
    title: str = ""
    content: str = ""
    enabled: bool = True
    sort_order: int = 0
    created_at: str = Field(default_factory=_now)


class CdEvent(SQLModel, table=True):
    """CD 部署事件回流（ghook/CD 平台 webhook 上报）。stages 为 JSON 数组字符串。"""

    id: Optional[int] = Field(default=None, primary_key=True)
    project_name: str = Field(index=True)
    env: str = "prod"
    trigger: str = ""
    prev_sha: str = ""
    new_sha: str = ""
    result: str = "success"
    stages: str = "[]"
    log_ref: str = ""
    finished_at: str = ""
    received_at: str = Field(default_factory=_now)


class MergeApproval(SQLModel, table=True):
    """合并门禁（T2）：人工批准/驳回记录。report 为批准时点 CI 快照 JSON（版本戳）。"""

    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    project_id: int = Field(index=True, foreign_key="project.id")
    status: str = "pending"
    reason: str = ""
    report: str = "{}"
    created_at: str = Field(default_factory=_now)
    decided_at: Optional[str] = None


class SelfHealProposal(SQLModel, table=True):
    """自愈提案档案：meta agent 基于失败聚类的结构性修复提案。"""

    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    project_id: int = Field(index=True, foreign_key="project.id")
    kind: str = "rule"
    title: str = ""
    detail: str = ""
    payload: str = "{}"
    status: str = "adopted"
    origin: str = "selfheal:auto"
    evidence_ids: str = "[]"
    preflight: str = "{}"
    applied_to: str = "{}"
    adopted_at: Optional[str] = None
    retired_at: Optional[str] = None
    hit_count: int = 0
    last_hit_at: Optional[str] = None
    expected_gain: str = ""
    validation: str = "[]"
    validation_unread: bool = False
    created_at: str = Field(default_factory=_now)
    decided_at: Optional[str] = None


class EvolutionEntry(SQLModel, table=True):
    """进化账本：每任务终态一行评分记录，构成项目自愈评分曲线。"""

    id: Optional[int] = Field(default=None, primary_key=True)
    project_id: int = Field(index=True, foreign_key="project.id")
    task_id: int = Field(index=True, foreign_key="task.id")
    generation: int = 0
    score: int = 100
    triggered: bool = False
    signals: str = "{}"
    created_at: str = Field(default_factory=_now)


class SosPacket(SQLModel, table=True):
    """SOS 求助包（自愈系统 P1）：熔断/求助证据 + Lead 决策留档。SQLite 唯一事实源。"""

    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    feature_id: Optional[int] = Field(default=None, index=True)
    trigger: str = ""
    symptom: str = "{}"
    tried: str = "[]"
    evidence: str = "[]"
    budget_left: str = "{}"
    decision: Optional[str] = None
    decision_payload: str = "{}"
    decision_valid: bool = False
    created_at: str = Field(default_factory=_now)


class HandoffNote(SQLModel, table=True):
    """交接笔记（上下文系统 ）：agent 间结构化交接物的持久化档案。"""

    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    feature_id: Optional[int] = Field(default=None, index=True)
    parent_task_id: Optional[int] = Field(default=None, index=True)
    role: str = ""
    kind: str = ""
    seq: int = 0
    content: str = ""
    files: str = ""
    risk: str = ""
    verify_evidence: str = ""
    created_at: str = Field(default_factory=_now)


class LLMExtraCall(SQLModel, table=True):
    """页外 LLM 调用记账（FR8 完整性）：不经过 Node 结算的 gateway.generate 调用"""

    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: int = Field(index=True, foreign_key="task.id")
    role: str = ""
    kind: str = ""
    purpose: str = ""
    tokens_in: int = 0
    tokens_out: int = 0
    tokens_in_cached: int = 0
    created_at: str = Field(default_factory=_now)
