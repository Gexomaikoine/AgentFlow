"""SQLite engine / session / 迁移（WAL 模式）。"""

from __future__ import annotations

from pathlib import Path

from sqlalchemy import event
from sqlalchemy.pool import NullPool
from sqlmodel import Session, SQLModel, create_engine

from agentflow.config import Settings


def create_db_engine(settings: Settings):
    settings.ensure_dirs()
    db_path = settings.home / "agentflow.db"
    engine = create_engine(
        f"sqlite:///{db_path.as_posix()}",


        poolclass=NullPool,
        connect_args={"check_same_thread": False},
        pool_pre_ping=True,
    )

    @event.listens_for(engine, "connect")
    def _set_sqlite_pragma(dbapi_connection, connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA busy_timeout=5000")
        cursor.close()

    SQLModel.metadata.create_all(engine)
    _migrate(engine)
    return engine



_MIGRATIONS: list[tuple[str, str, str]] = [
    ("task", "archived_at", "VARCHAR"),
    ("task", "pinned", "BOOLEAN"),
    ("task", "completed_at", "VARCHAR"),
    ("project", "archived_at", "VARCHAR"),
    ("project", "sort_order", "INTEGER"),
    ("spec", "complexity", "VARCHAR"),
    ("node", "role", "VARCHAR"),
    ("clarifymessage", "images", "VARCHAR"),
    ("clarifymessage", "consumed_at", "VARCHAR"),
    ("task", "parent_task_id", "INTEGER"),
    ("task", "origin", "VARCHAR"),
    ("mergequeueentry", "merged_sha", "VARCHAR"),
    ("mergequeueentry", "round_no", "INTEGER DEFAULT 1"),
    ("mergequeueentry", "redo_of", "INTEGER"),
    ("mergequeueentry", "hold", "BOOLEAN"),
    ("verifierrun", "detail", "TEXT"),
    ("verifierrun", "fingerprint", "VARCHAR"),
    ("node", "token_in_cached", "INTEGER DEFAULT 0"),
    ("llmextracall", "tokens_in_cached", "INTEGER DEFAULT 0"),
    ("selfhealproposal", "origin", "VARCHAR DEFAULT 'selfheal:auto'"),
    ("selfhealproposal", "evidence_ids", "VARCHAR DEFAULT '[]'"),
    ("selfhealproposal", "preflight", "VARCHAR DEFAULT '{}'"),
    ("selfhealproposal", "applied_to", "VARCHAR DEFAULT '{}'"),
    ("selfhealproposal", "adopted_at", "VARCHAR"),
    ("selfhealproposal", "retired_at", "VARCHAR"),
    ("selfhealproposal", "hit_count", "INTEGER DEFAULT 0"),
    ("selfhealproposal", "last_hit_at", "VARCHAR"),
    ("selfhealproposal", "expected_gain", "VARCHAR DEFAULT ''"),
    ("selfhealproposal", "validation", "VARCHAR DEFAULT '[]'"),
    ("selfhealproposal", "validation_unread", "BOOLEAN DEFAULT 0"),
]


def _migrate(engine) -> None:
    with engine.connect() as conn:

        pre_cols = {row[1] for row in conn.exec_driver_sql("PRAGMA table_info(selfhealproposal)")}
        for table, col, ctype in _MIGRATIONS:
            cols = {row[1] for row in conn.exec_driver_sql(f"PRAGMA table_info({table})")}
            if col not in cols:
                conn.exec_driver_sql(f"ALTER TABLE {table} ADD COLUMN {col} {ctype}")
        _migrate_selfheal_reset(conn, pre_cols)
        conn.commit()


def _migrate_selfheal_reset(conn, pre_cols: set) -> None:
    """ 一次性迁移：自愈语义从人审（pending/approved/rejected）改为全自动档案（adopted/…）。"""
    tabs = {row[0] for row in conn.exec_driver_sql(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    if "selfhealproposal" not in tabs:
        return
    if "origin" not in pre_cols:
        conn.exec_driver_sql("DELETE FROM selfhealproposal")


def get_session(engine):
    return Session(engine)
