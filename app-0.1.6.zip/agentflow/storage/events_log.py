"""事件 append-only 日志（回放数据源 + 断线补发基础）。"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

_SEQ_KEY = "seq"


def _now_ts() -> str:
    return datetime.now(timezone.utc).isoformat()


class EventLog:
    """按任务 append-only 事件日志（JSONL），seq 单调递增。"""

    def __init__(self, settings):
        self.home = settings.home
        (self.home / "events").mkdir(parents=True, exist_ok=True)

    def _path(self, task_id: int) -> Path:
        return self.home / "events" / f"task_{task_id}.jsonl"

    def append(self, task_id: int, event: str, payload: dict) -> dict:
        seq = self._next_seq(task_id)
        envelope = {"task_id": task_id, "seq": seq, "ts": _now_ts(), "event": event, "payload": payload}
        with self._path(task_id).open("a", encoding="utf-8") as f:
            f.write(json.dumps(envelope, ensure_ascii=False) + "\n")
        return envelope

    def _next_seq(self, task_id: int) -> int:
        p = self._path(task_id)
        if not p.exists():
            return 1

        last = ""
        with p.open("r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    last = line
        if not last:
            return 1
        try:
            return int(json.loads(last)[_SEQ_KEY]) + 1
        except (json.JSONDecodeError, KeyError, ValueError):
            return 1

    def since(self, task_id: int, after_seq: int = 0, limit: int = 2000) -> list[dict]:
        """返回 seq > after_seq 的事件。"""
        p = self._path(task_id)
        if not p.exists():
            return []
        out = []
        with p.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if ev.get(_SEQ_KEY, 0) > after_seq:
                    out.append(ev)
                    if len(out) >= limit:
                        break
        return out
