"""JSONL trace：原始证据层。每个 Node 一个文件。"""

from __future__ import annotations

import json
from pathlib import Path


def trace_dir_for(settings, project_name: str, task_id: int) -> Path:
    d = settings.home / "projects" / project_name / "tasks" / str(task_id) / "trace"
    d.mkdir(parents=True, exist_ok=True)
    return d


def new_trace_file(trace_dir: Path, node_id: int) -> str:
    return str(trace_dir / f"node_{node_id}.jsonl")


def append(trace_uri: str, kind: str, content=None, **extra) -> None:
    """追加一行 trace 事件。content 大对象自动转 blob ref（由调用方处理）。"""
    row = {"ts": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(), "kind": kind}
    if content is not None:
        row["content"] = content
    row.update(extra)
    with open(trace_uri, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def read_trace(trace_uri: str, limit: int = 10000) -> list[dict]:
    """读取 trace 文件，返回事件列表。"""
    events = []
    p = Path(trace_uri)
    if not p.exists():
        return events
    with p.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue
            if len(events) >= limit:
                break
    return events
