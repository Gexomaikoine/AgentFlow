"""项目级联删除：DB 全部关联行 + AgentFlow home 内落盘文件。"""

from __future__ import annotations

from pathlib import Path

from sqlmodel import Session, select

from agentflow.storage import models as m




_TASK_TABLES = (
    m.VerifierRun, m.FailureQueueEntry, m.Lease, m.GreenAnchor,
    m.MergeApproval, m.SelfHealProposal, m.EvolutionEntry, m.SosPacket,
    m.HandoffNote, m.LLMExtraCall,
    m.MergeQueueEntry, m.ClarifyMessage, m.AgentInstance, m.Node, m.Edge,
    m.Feature,
    m.Spec,
)

_PROJECT_TABLES = (m.Invariant, m.ProjectRule)



_LEGACY_TASK_TABLES = ("taskpitfall",)


def _delete_legacy_task_rows(session, task_id: int) -> None:
    from sqlalchemy import text

    for tbl in _LEGACY_TASK_TABLES:
        try:
            session.execute(text(f"DELETE FROM {tbl} WHERE task_id = :tid"), {"tid": task_id})
            session.flush()
        except Exception:
            pass


def delete_project_records(engine, home: Path, project_id: int) -> dict:
    """删除项目的全部 DB 关联行 + home 内落盘文件（事件日志/节点 trace）。"""
    tids: list[int] = []
    trace_uris: set[str] = set()
    with Session(engine) as s:
        tids = list(s.exec(select(m.Task.id).where(m.Task.project_id == project_id)).all())
        if tids:

            for row in s.exec(select(m.Node).where(m.Node.task_id.in_(tids))).all():
                if row.trace_uri:
                    trace_uris.add(row.trace_uri)
            for model in _TASK_TABLES:
                for row in s.exec(select(model).where(model.task_id.in_(tids))).all():
                    s.delete(row)
                s.flush()
            for tid in tids:
                _delete_legacy_task_rows(s, tid)
            for row in s.exec(select(m.Task).where(m.Task.project_id == project_id)).all():
                s.delete(row)
            s.flush()
        for model in _PROJECT_TABLES:
            for row in s.exec(select(model).where(model.project_id == project_id)).all():
                s.delete(row)
            s.flush()
        proj = s.get(m.Project, project_id)
        proj_name = proj.name if proj else ""
        if proj_name:

            for row in s.exec(select(m.CdEvent).where(m.CdEvent.project_name == proj_name)).all():
                s.delete(row)
            s.flush()
        if proj:
            s.delete(proj)
        s.commit()

    removed = _remove_task_files(Path(home), tids, trace_uris)
    return {"tasks": len(tids), "files": removed}


def delete_task_records(engine, home: Path, task_id: int) -> dict:
    """删除单个任务的 DB 全部关联行 + 落盘文件（事件流/节点 trace/澄清图片）。"""
    trace_uris: set[str] = set()
    existed = False
    with Session(engine) as s:
        for row in s.exec(select(m.Node).where(m.Node.task_id == task_id)).all():
            if row.trace_uri:
                trace_uris.add(row.trace_uri)
        for model in _TASK_TABLES:
            for row in s.exec(select(model).where(model.task_id == task_id)).all():
                s.delete(row)
            s.flush()
        _delete_legacy_task_rows(s, task_id)
        task = s.get(m.Task, task_id)
        if task:
            existed = True
            s.delete(task)
        s.commit()

    removed = _remove_task_files(Path(home), [task_id] if existed else [], trace_uris)
    import shutil

    img_dir = Path(home) / "clarify_images" / str(task_id)
    if img_dir.is_dir():
        shutil.rmtree(img_dir, ignore_errors=True)
        removed += 1
    return {"tasks": 1 if existed else 0, "files": removed}


def _remove_task_files(home: Path, tids: list[int], trace_uris: set[str]) -> int:
    removed = 0
    for tid in tids:
        ev = home / "events" / f"task_{tid}.jsonl"
        if ev.is_file():
            ev.unlink(missing_ok=True)
            removed += 1
    home_resolved = home.resolve()
    for uri in trace_uris:
        p = Path(uri)

        try:
            p.resolve().relative_to(home_resolved)
        except (ValueError, OSError):
            continue
        if p.is_file():
            p.unlink()
            removed += 1
    return removed
