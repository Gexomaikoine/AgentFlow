"""预算与停机判定（FR8）。"""

from __future__ import annotations

import json

from agentflow.config import Settings
from agentflow.storage import models as m
from sqlmodel import Session


def fmt_tokens(n: int) -> str:
    """token 量展示口径：统一用「w」（万，10⁴）为单位，按量级自适应小数位（前端 lib/fmt.ts 同口径）。"""
    n = int(n or 0)
    if n <= 0:
        return "0"
    w = n / 10_000
    if w < 0.01:
        return "<0.01w"
    digits = 0 if w >= 100 else 1 if w >= 10 else 2
    return f"{w:.{digits}f}w"


def budget_snapshot(session: Session, task: m.Task, settings: Settings) -> dict:
    used = json.loads(task.used_budget) if task.used_budget else {}

    total = (json.loads(task.total_budget) if task.total_budget else None) or settings.data["budget"]
    return {"used": used, "total": total}


def budget_exceeded(session: Session, task: m.Task, settings: Settings) -> tuple[bool, str]:
    """返回 (是否超限, 原因)。"""
    snap = budget_snapshot(session, task, settings)
    used, total = snap["used"], snap["total"]
    tok = used.get("tokens_in", 0) + (used.get("tokens_out", 0) or 0)
    cost = used.get("cost_usd", 0.0) or 0.0
    max_tok = total.get("task_max_tokens") or 0
    max_cost = total.get("task_max_cost_usd") or 0
    if max_tok > 0 and tok > max_tok:
        return True, f"token 超限 {fmt_tokens(tok)}/{fmt_tokens(max_tok)}"
    if max_cost > 0 and cost > max_cost:
        return True, f"费用超限 ${cost:.2f}/${max_cost}"
    return False, ""


def budget_soft_exceeded(session: Session, task: m.Task, settings: Settings, soft_ratio: float = 0.6) -> tuple[bool, str]:
    """软顶（硬顶的 soft_ratio，默认 60%）：先问人再继续，不自动熔断（FR8 续问交互）。"""
    snap = budget_snapshot(session, task, settings)
    used, total = snap["used"], snap["total"]
    tok = used.get("tokens_in", 0) + (used.get("tokens_out", 0) or 0)
    cost = used.get("cost_usd", 0.0) or 0.0
    max_tok = total.get("task_max_tokens") or 0
    max_cost = total.get("task_max_cost_usd") or 0
    if max_tok > 0 and tok > max_tok * soft_ratio:
        return True, f"token {fmt_tokens(tok)}/{fmt_tokens(max_tok)}（软顶 {fmt_tokens(int(max_tok * soft_ratio))}）"
    if max_cost > 0 and cost > max_cost * soft_ratio:
        return True, f"费用 ${cost:.2f}/${max_cost}（软顶 ${max_cost * soft_ratio:.2f}）"
    return False, ""


def add_usage(
    session: Session, task: m.Task, tokens_in: int, tokens_out: int, cost_usd: float = 0.0,
    tokens_in_cached: int = 0,
) -> None:
    """任务用量累加。tokens_in_cached 是 tokens_in 里命中前缀缓存的部分（单独记，不重复计入总量）。"""
    used = json.loads(task.used_budget) if task.used_budget else {}
    used["tokens_in"] = used.get("tokens_in", 0) + tokens_in
    used["tokens_out"] = used.get("tokens_out", 0) + tokens_out
    used["cost_usd"] = used.get("cost_usd", 0.0) + cost_usd
    if tokens_in_cached:
        used["tokens_in_cached"] = used.get("tokens_in_cached", 0) + tokens_in_cached
    task.used_budget = json.dumps(used)
    session.add(task)
    session.commit()
