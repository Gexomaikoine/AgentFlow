"""校验前工作区卫生：把 agent 留在 worktree 的散落文件收进 .agentflow_tmp/。"""

from __future__ import annotations

import subprocess
import time
from pathlib import Path

from sqlmodel import Session

from agentflow.storage import models as m

STRAY_ROOT = ".agentflow_tmp/strays"


def sweep_strays(
    session: Session, feature: m.Feature, repo_root: Path, bus=None,
    siblings: list[m.Feature] | None = None,
) -> list[str]:
    """收口散落文件：返回移走的相对路径列表（无散落返回空）。"""
    untracked = _untracked_files(repo_root)
    if not untracked:
        return []
    from agentflow.core.leases import matches_declared_scope

    scopes = [feature, *(siblings or [])]
    moved: list[str] = []
    stamp = time.strftime("%Y%m%d-%H%M%S")
    for rel in untracked:
        if rel.startswith(".agentflow_tmp/"):
            continue
        if any(matches_declared_scope(f, rel) for f in scopes):
            continue
        src = repo_root / rel
        if not src.is_file():
            continue
        dst = repo_root / STRAY_ROOT / stamp / rel
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            src.replace(dst)
        except OSError:
            continue
        moved.append(rel)
    if moved and bus is not None:
        try:
            bus.publish_task(feature.task_id, "log.appended", {
                "level": "sched",
                "message": (
                    f"校验前卫生收口：{len(moved)} 个散落文件（未跟踪且不在写集）已移入 "
                    f"{STRAY_ROOT}/{stamp}/（可恢复）——它们会污染 typecheck/build 等全目录扫描：\n"
                    + "\n".join(f"- {p}" for p in moved[:8])
                    + (f"\n- …（共 {len(moved)} 个）" if len(moved) > 8 else "")
                ),
            })
        except Exception:
            pass
    return moved


def _untracked_files(repo_root: Path) -> list[str]:
    """git 未跟踪文件清单（-uall 展开目录；quotepath=false 防中文路径被转义）。"""
    try:
        out = subprocess.run(
            ["git", "-c", "core.quotepath=false", "status", "--porcelain", "--untracked-files=all"],
            cwd=str(repo_root), capture_output=True, text=True, timeout=30,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if out.returncode != 0:
        return []
    files: list[str] = []
    for line in (out.stdout or "").splitlines():
        if not line.startswith("?? "):
            continue
        p = line[3:].strip()
        if len(p) >= 2 and p[0] == '"' and p[-1] == '"':
            p = p[1:-1]
        if p:
            files.append(p.replace("\\", "/"))
    return files
