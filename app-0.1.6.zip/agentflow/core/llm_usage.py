"""页外 LLM 调用记账（FR8 完整性）：调度器/后台的 gateway.generate 调用不经过"""

from __future__ import annotations

import logging

from sqlmodel import Session

from agentflow.core.budget import add_usage
from agentflow.storage import models as m

logger = logging.getLogger(__name__)


def record_extra(engine, task_id: int, role: str, kind: str, purpose: str, result) -> None:
    """把一次页外调用的用量入账（LLMExtraCall + used_budget）。"""
    try:
        own = not isinstance(engine, Session)
        session = Session(engine) if own else engine
        try:
            row = m.LLMExtraCall(
                task_id=task_id, role=role, kind=kind, purpose=purpose,
                tokens_in=result.tokens_in or 0, tokens_out=result.tokens_out or 0,
                tokens_in_cached=getattr(result, "tokens_in_cached", 0) or 0,
            )
            session.add(row)
            t = session.get(m.Task, task_id)
            if t is not None:

                add_usage(session, t, row.tokens_in, row.tokens_out, tokens_in_cached=row.tokens_in_cached or 0)
            else:
                session.commit()
        finally:
            if own:
                session.close()
    except Exception as e:
        logger.warning(f"[llm_usage] 记账失败 task={task_id} purpose={purpose}: {e}")
