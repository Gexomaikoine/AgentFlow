"""CD 回流隧道自动维持（serve 内置）。"""

from __future__ import annotations

import subprocess
import sys
import threading
from typing import Callable


class TunnelSupervisor:
    """探活 + 重建的巡检线程。notify 用于状态变化上报（事件流），不记录密钥。"""

    RETRY_WAIT_S = 15

    def __init__(self, cfg: dict, notify: Callable[[str], None] | None = None):
        self.host = str(cfg.get("ssh_host") or "")
        self.enabled = bool(cfg.get("enabled", True))
        self.remote_port = int(cfg.get("remote_port") or 18265)
        self.local_port = int(cfg.get("local_port") or 8765)
        self.interval = max(15, int(cfg.get("check_interval_s") or 60))
        self.notify = notify or (lambda msg: None)
        self._stop = threading.Event()
        self._proc: subprocess.Popen | None = None
        self._thread: threading.Thread | None = None
        self._was_down = False

    def start(self) -> None:
        if not self.enabled or not self.host or self._thread is not None:
            return
        self._thread = threading.Thread(target=self._loop, name="cd-tunnel", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._proc is not None and self._proc.poll() is None:
            try:
                self._proc.terminate()
            except Exception:
                pass

    def _loop(self) -> None:
        self.notify(f"CD 回流隧道巡检启动：{self.host} -R {self.remote_port}→127.0.0.1:{self.local_port}")
        while not self._stop.is_set():
            self._step()
            self._stop.wait(self.RETRY_WAIT_S if self._was_down else self.interval)

    def _step(self) -> None:
        if self._probe():
            if self._was_down:
                self._was_down = False
                self.notify("CD 回流隧道已恢复（探活通过）")
            return
        if not self._was_down:
            self._was_down = True
            self.notify("CD 回流隧道探活失败，正在重建…")
        self._kill_stale()
        try:
            self._spawn()
        except Exception as e:
            self.notify(f"CD 回流隧道重建失败：{e}")

    def _probe(self) -> bool:
        """端到端探活：本机 ssh 进程活着，且远端经隧道能摸到本机 /api/v1/health。"""
        if self._proc is not None and self._proc.poll() is not None:
            return False
        cmd = [
            "ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=8", self.host,
            "curl", "-sf", "-m", "5", f"http://127.0.0.1:{self.remote_port}/api/v1/health",
        ]
        try:
            return subprocess.run(cmd, capture_output=True, timeout=20).returncode == 0
        except Exception:
            return False

    def _kill_stale(self) -> None:
        """清本机残留的旧隧道 ssh。只按命令行里的 -R <remote_port>: 匹配，不动其他 ssh 连接。"""
        try:
            if sys.platform == "win32":
                ps = (
                    "Get-CimInstance Win32_Process -Filter \"Name='ssh.exe'\" | "
                    f"Where-Object {{ $_.CommandLine -like '*-R {self.remote_port}:*' }} | "
                    "ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
                )
                subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, timeout=20)
            else:
                subprocess.run(["pkill", "-f", f"ssh .*-R {self.remote_port}:"], capture_output=True, timeout=10)
        except Exception:
            pass

    def _spawn(self) -> None:
        cmd = [
            "ssh", "-N",
            "-o", "ServerAliveInterval=30", "-o", "ServerAliveCountMax=3",
            "-o", "ExitOnForwardFailure=yes", "-o", "ConnectTimeout=10",
            "-o", "StrictHostKeyChecking=accept-new",
            "-R", f"{self.remote_port}:127.0.0.1:{self.local_port}", self.host,
        ]
        self._proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
