"""写集分组（partition）：按 file_scope 不相交着色（FR2，多写架构核心）。"""

from __future__ import annotations

import glob as _glob
from dataclasses import dataclass, field
from pathlib import Path

from agentflow.storage import models as m


@dataclass
class ParallelGroup:
    feature_ids: list[int] = field(default_factory=list)
    phase: str = "writing"


def expand_glob(root: Path, pattern: str) -> list[str]:
    """把 file_scope glob 展开为相对仓库根的实际文件集（posix 路径）。"""
    if not pattern:
        return []
    norm = pattern.replace("\\", "/")
    matches = _glob.glob(str(root / norm), recursive=True)
    out = []
    root_res = root.resolve()
    for mm in matches:
        p = Path(mm)
        if p.is_dir():
            continue
        try:
            rel = p.resolve().relative_to(root_res).as_posix()
        except ValueError:
            continue
        if rel not in out:
            out.append(rel)
    return out


def feature_write_set(feature: m.Feature, repo_root: Path) -> set[str]:
    """功能的实际写集（file_scope 展开）。"""
    scope = __import__("json").loads(feature.file_scope) if feature.file_scope else []
    files: set[str] = set()
    for pat in scope:
        pat = pat.replace("\\", "/")
        if pat and not any(ch in pat for ch in "*?["):
            files.add(pat)
        else:
            files.update(expand_glob(repo_root, pat))
    return files






GLOBAL_SHARED_FILENAMES: frozenset[str] = frozenset({
    "requirements.txt", "requirements-dev.txt", "requirements.in",
    "pyproject.toml", "setup.py", "setup.cfg", "Pipfile", "Pipfile.lock",
    "package.json", "package-lock.json", "pnpm-lock.yaml", "yarn.lock", "bun.lockb",
    "poetry.lock", "uv.lock", "Cargo.lock", "go.mod", "go.sum", "tox.ini",
})


def is_global_shared_write(feature: m.Feature, repo_root: Path) -> bool:
    """写集命中全局共享文件名单 → 判为全局共享写者。"""
    ws = feature_write_set(feature, repo_root)
    return any(Path(f).name.lower() in GLOBAL_SHARED_FILENAMES for f in ws)


def _scope_roots(feature: m.Feature) -> list[str]:
    """file_scope 各模式的通配符前字面前缀（posix）。"""
    import json as _json

    scope = _json.loads(feature.file_scope) if feature.file_scope else []
    return scope_roots(scope)


def scope_roots(scope: list[str]) -> list[str]:
    """同上，但入参是**已解析的模式列表**（Spec 生成期用 SpecDoc，不经 DB）。"""
    roots = []
    for pat in scope or []:
        pat = str(pat).replace("\\", "/")
        cut = len(pat)
        for ch in "*?[":
            idx = pat.find(ch)
            if idx != -1:
                cut = min(cut, idx)
        roots.append(pat[:cut].rstrip("/"))
    return roots


def scopes_conflict(ra: list[str], rb: list[str]) -> bool:
    """两组模式前缀是否存在模式级冲突（一方是另一方的段边界前缀，或模式相同）。"""
    for a in ra:
        for b in rb:
            if not a or not b:
                continue
            if a == b or a.startswith(b + "/") or b.startswith(a + "/"):
                return True
    return False


def scope_conflict(fa: m.Feature, fb: m.Feature) -> bool:
    """模式级潜在冲突：一方前缀是另一方前缀的段边界前缀，或模式相同。"""
    return scopes_conflict(_scope_roots(fa), _scope_roots(fb))


def partition_features(
    features: list[m.Feature],
    repo_root: Path,
    group_size: int = 1,
) -> list[ParallelGroup]:
    """贪心不相交分组。"""
    features = sorted(features, key=lambda f: f.seq)
    groups: list[ParallelGroup] = []
    for f in features:
        fset = feature_write_set(f, repo_root)
        placed = False
        for g in groups:
            if len(g.feature_ids) >= group_size:
                continue
            disjoint = True
            for fid in g.feature_ids:
                other = next((x for x in features if x.id == fid), None)
                if other is None:
                    continue
                oset = feature_write_set(other, repo_root)
                if fset & oset or scope_conflict(f, other):
                    disjoint = False
                    break
            if disjoint:
                g.feature_ids.append(f.id)
                placed = True
                break
        if not placed:
            groups.append(ParallelGroup(feature_ids=[f.id]))
    return groups


def cluster_features(
    features: list[m.Feature],
    repo_root: Path,
    group_size: int = 1,
) -> list[ParallelGroup]:
    """P3：依赖拓扑 + 写集重叠度聚类的分组。"""
    import json as _json

    features = sorted(features, key=lambda f: f.seq)
    placed: set[int] = set()
    groups: list[ParallelGroup] = []

    def deps_ok(f: m.Feature) -> bool:
        deps = _json.loads(f.depends_on) if f.depends_on else []
        return all(d in placed for d in deps)

    while len(placed) < len(features):

        cur_files: set[str] = set()
        members: list[m.Feature] = []
        g = ParallelGroup(feature_ids=[])
        for f in features:
            if f.id in placed:
                continue
            if not deps_ok(f):
                continue
            if len(g.feature_ids) >= group_size:
                break
            if is_global_shared_write(f, repo_root):
                continue
            fset = feature_write_set(f, repo_root)
            if fset & cur_files:
                continue
            if any(scope_conflict(f, mb) for mb in members):
                continue
            g.feature_ids.append(f.id)
            placed.add(f.id)
            members.append(f)
            cur_files |= fset
        if not g.feature_ids:


            rest = [f for f in features if f.id not in placed and deps_ok(f)]
            if not rest:
                rest = [f for f in features if f.id not in placed]
            if not rest:
                break
            f = rest[0]
            g.feature_ids.append(f.id)
            placed.add(f.id)
        groups.append(g)
    return groups


def merge_overlapping_features(doc):
    """Spec 生成期归一化：把**写集重叠**的 feature 合并为一个，返回 (doc, 留痕说明)。"""
    feats = list(getattr(doc, "features", None) or [])
    if len(feats) < 2:
        return doc, []
    depended_on: set[int] = {int(d) for f in feats for d in (f.depends_on or [])}
    folded: set[int] = set()
    notes: list[str] = []
    for i, a in enumerate(feats):
        if a.seq in folded:
            continue
        for b in feats[i + 1:]:
            if b.seq in folded:
                continue
            if b.seq in (a.depends_on or []) or a.seq in (b.depends_on or []):
                continue
            if b.seq in depended_on:
                continue
            if not scopes_conflict(scope_roots(a.file_scope), scope_roots(b.file_scope)):
                continue
            a_title, b_title = a.title, b.title
            a.title = f"{a_title}；{b_title}" if b_title else a_title
            a.file_scope = list(dict.fromkeys([*(a.file_scope or []), *(b.file_scope or [])]))
            a.verify_commands = [*(a.verify_commands or []), *(b.verify_commands or [])]
            a.related_files = list(dict.fromkeys([*(a.related_files or []), *(b.related_files or [])]))
            folded.add(b.seq)
            notes.append(
                f"Spec 归一化：F{b.seq}《{b_title}》写集与 F{a.seq}《{a_title}》重叠 → 已合并为一个 feature"
                "（同文件改动拆成多个 feature 会被分区器强制串行）"
            )
    if not notes:
        return doc, []
    doc.features = [f for f in feats if f.seq not in folded]
    return doc, notes
