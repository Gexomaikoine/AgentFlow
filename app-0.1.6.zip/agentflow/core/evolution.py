"""自愈进化闭环：评分 → 失败聚类 → LLM 反思提案 → 机器预检 → 自动生效 → 退役。"""

from __future__ import annotations

import hashlib
import json
import sys
import threading
import traceback
from datetime import datetime, timezone
from pathlib import Path

from sqlmodel import Session, select

from agentflow.storage import models as m


EVOLVE_MIN_EVIDENCE = 2
RETIRE_IDLE_TASKS = 10
RULE_RELAPSE_LIMIT = 3
SCORE_WEIGHTS = {"retries": (25, 8), "white": (20, 3), "vfails": (20, 10),
                 "rejects": (20, 3), "human": (15, 2)}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def run_fingerprint(cmd: str, exit_code, output: str) -> str:
    """单 run 失败指纹（跨任务聚类用）：cmd + 退出码 + 输出前 200 字。"""
    return hashlib.sha1(f"{cmd}|{exit_code}|{(output or '')[:200]}".encode("utf-8", "replace")).hexdigest()




def score_task(session: Session, task) -> tuple[int, dict]:
    """任务终态评分（0-100，越高越好）+ 原始信号（全量入账本，权重可日后重放）。"""
    feats = session.exec(select(m.Feature).where(m.Feature.task_id == task.id)).all()
    retries = sum(f.retry_count or 0 for f in feats)
    failed_runs = session.exec(
        select(m.VerifierRun).where(m.VerifierRun.task_id == task.id, m.VerifierRun.exit_code != 0)
    ).all()
    vfails = len(failed_runs)
    white = _white_transfers(failed_runs)
    rejects = len(session.exec(
        select(m.MergeApproval).where(m.MergeApproval.task_id == task.id, m.MergeApproval.status == "rejected")
    ).all())
    human = len(session.exec(
        select(m.SosPacket).where(m.SosPacket.task_id == task.id)
    ).all())
    signals = {"retries": retries, "white": white, "vfails": vfails, "rejects": rejects, "human": human}
    score = 100
    for key, (weight, cap) in SCORE_WEIGHTS.items():
        score -= weight * min(signals[key], cap) / cap
    return max(0, round(score)), signals


def _white_transfers(failed_runs) -> int:
    """白转信号：同一功能连续 3 次同指纹失败（修复空转）。按落库指纹序列重算。"""
    by_feat: dict[int, list[str]] = {}
    for r in sorted(failed_runs, key=lambda x: x.id or 0):
        if r.fingerprint and r.feature_id is not None:
            by_feat.setdefault(r.feature_id, []).append(r.fingerprint)
    white = 0
    for seq in by_feat.values():
        for i in range(2, len(seq)):
            if seq[i] == seq[i - 1] == seq[i - 2]:
                white += 1
    return white


def _has_failure(signals: dict) -> bool:
    return any(signals.get(k, 0) > 0 for k in SCORE_WEIGHTS)




def cluster_failures(session: Session, project_id: int, focus_task_id: int | None = None) -> list[dict]:
    """按失败指纹聚类该项目全部失败 VerifierRun。返回按出现次数降序、且同指纹"""
    rows = session.exec(
        select(m.VerifierRun, m.Task)
        .join(m.Task, m.VerifierRun.task_id == m.Task.id)
        .where(m.Task.project_id == project_id, m.VerifierRun.exit_code != 0,
               m.VerifierRun.fingerprint != None)
        .order_by(m.VerifierRun.id.desc())
    ).all()
    groups: dict[str, dict] = {}
    for run, task in rows:
        g = groups.setdefault(run.fingerprint, {
            "fingerprint": run.fingerprint, "count": 0, "run_ids": [], "task_ids": [],
            "sample_cmd": run.cmd, "sample_exit": run.exit_code, "sample_output": "",
        })
        g["count"] += 1
        if run.id not in g["run_ids"]:
            g["run_ids"].append(run.id)
        if task.id not in g["task_ids"]:
            g["task_ids"].append(task.id)
        if not g["sample_output"]:
            g["sample_output"] = (run.output_uri or "")[-300:]
    out = sorted(
        (g for g in groups.values() if g["count"] >= EVOLVE_MIN_EVIDENCE),
        key=lambda g: g["count"], reverse=True,
    )
    if focus_task_id is not None:
        out = [g for g in out if focus_task_id in g["task_ids"]]
    return out




def match_history(session: Session, project_id: int, fingerprints: list[str]) -> list[dict]:
    """给定当前失败指纹，查跨任务同指纹历史 + 已采纳自愈提案。"""
    if not fingerprints:
        return []
    rows = session.exec(
        select(m.VerifierRun, m.Task)
        .join(m.Task, m.VerifierRun.task_id == m.Task.id)
        .where(m.Task.project_id == project_id, m.VerifierRun.exit_code != 0,
               m.VerifierRun.fingerprint.in_(fingerprints))
        .order_by(m.VerifierRun.id.desc())
    ).all()
    groups: dict[str, dict] = {}
    for run, task in rows:
        g = groups.setdefault(run.fingerprint, {
            "fingerprint": run.fingerprint, "count": 0, "task_ids": [], "sample_cmd": run.cmd,
        })
        g["count"] += 1
        if task.id not in g["task_ids"]:
            g["task_ids"].append(task.id)
    if not groups:
        return []
    adopted = session.exec(
        select(m.SelfHealProposal)
        .where(m.SelfHealProposal.project_id == project_id,
               m.SelfHealProposal.status == "adopted")
    ).all()
    fps = set(groups)
    for p in adopted:
        p_fps = fps & set(_evidence_fingerprints(session, p))
        if not p_fps:
            continue
        payload = _payload_of(p)
        cmd = payload.get("cmd") or ""
        for fp in p_fps:
            groups[fp].setdefault("adopted", []).append(
                {"kind": p.kind, "title": p.title, "cmd": cmd}
            )
    return sorted(groups.values(), key=lambda g: g["count"], reverse=True)


def format_history_evidence(hist: list[dict], limit: int = 1500) -> str:
    """match_history 结果 → 给 agent/SOS 包看的紧凑文本块。"""
    lines = []
    for g in hist:
        line = f"指纹 {str(g['fingerprint'])[:12]}…：历史失败 {g['count']} 次（任务 {g['task_ids'][:5]}）"
        for a in g.get("adopted") or []:
            line += f"；已采纳对策 [{a['kind']}] {a['title'][:80]}"
            if a.get("cmd"):
                line += f"（cmd: {a['cmd'][:120]}）"
        lines.append(line)
    return "\n".join(lines)[:limit]




def stall_digest(session: Session, project_id: int, events_dir, task_limit: int = 40) -> dict:
    """本项目近期「停机模式画像」。"""
    from collections import Counter

    from agentflow.replay.corpus import classify_reason

    out: dict = {"scanned": 0, "tasks": 0, "by_category": {}, "samples": []}
    if not events_dir:
        return out
    d = Path(str(events_dir))
    if not d.is_dir():
        return out
    tids = [int(t.id) for t in session.exec(
        select(m.Task).where(m.Task.project_id == project_id)
        .order_by(m.Task.id.desc())
    ).all()[:task_limit] if t.id is not None]
    cnt: Counter = Counter()
    labels: dict[str, str] = {}
    samples: list[str] = []
    for tid in tids:
        path = d / f"task_{tid}.jsonl"
        if not path.is_file():
            continue
        out["tasks"] += 1
        try:
            with path.open(encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    if "human.required" not in line:
                        continue
                    try:
                        ev = json.loads(line)
                    except ValueError:
                        continue
                    if ev.get("event") != "human.required":
                        continue
                    reason = str((ev.get("payload") or {}).get("reason") or "")
                    if not reason:
                        continue
                    cat = classify_reason(reason)
                    cnt[cat.key] += 1
                    labels[cat.key] = cat.label
                    out["scanned"] += 1
                    if len(samples) < 3:
                        samples.append(f"任务#{tid}：{reason[:120]}")
        except OSError:
            continue
    out["by_category"] = {
        f"{labels.get(k, k)}": n for k, n in cnt.most_common(6)
    }
    out["samples"] = samples
    return out




def _project_config(project) -> dict:
    try:
        return json.loads(project.config) if project.config else {}
    except Exception:
        return {}


def gate_duplicate(payload: dict, project) -> str | None:
    """守门：与现有配置重复 → 拒绝理由（None=通过）。仅 verifier 类有重放型重复。"""
    cmd = (payload.get("cmd") or "").strip()
    if not cmd:
        return None
    existing = [str(v.get("cmd") or "").strip()
                for v in _project_config(project).get("verifiers") or [] if isinstance(v, dict)]
    if cmd in existing:
        return f"与现有验收命令重复: {cmd[:120]}"
    return None


def preflight(kind: str, payload: dict, project, settings, evidence_count: int) -> dict:
    """机器预检（判定权在代码）。返回 preflight JSON；rejected=True 时提案应 discard。"""
    if kind != "verifier":
        return {"mode": "threshold", "evidence_count": evidence_count}
    from agentflow.safety.command import Safety
    from agentflow.verifiers.registry import get_verifier

    cmd = payload.get("cmd") or ""
    verdict, reason = Safety(settings).check(cmd, repo_root=Path(project.repo_path))
    if verdict != "allow":
        return {"mode": "exec", "rejected": True, "reason": f"安全分级 {verdict}: {reason}"}
    ok, probe_err = _syntax_probe(cmd)
    if not ok:
        return {"mode": "exec", "probe_ok": False, "probe_err": probe_err[:300], "rejected": True}
    try:
        result = get_verifier("custom").run(cmd, Path(project.repo_path), 60)
    except Exception as e:
        return {"mode": "exec", "probe_ok": True, "exec_err": str(e)[:300], "rejected": True}
    if result.exit_code != 0:
        return {"mode": "exec", "probe_ok": True, "exit": result.exit_code,
                "tail": (result.output or "")[-300:], "rejected": True}
    return {"mode": "exec", "probe_ok": True, "exit": 0}


def _syntax_probe(cmd: str) -> tuple[bool, str]:
    from agentflow.verifiers.probe import probe_command

    try:
        return probe_command(cmd, None)
    except Exception:
        return True, ""


def _payload_of(proposal) -> dict:
    try:
        return json.loads(proposal.payload) if isinstance(proposal.payload, str) else (proposal.payload or {})
    except Exception:
        return {}


def adopt(session: Session, proposal, project) -> dict:
    """生效写入（代码执行；三种落地与原人审 approve 同构）。返回 applied_to。"""
    payload = _payload_of(proposal)
    if proposal.kind == "rule":
        rule = m.ProjectRule(project_id=int(proposal.project_id), title=proposal.title,
                             content=payload.get("content") or proposal.detail)
        session.add(rule)
        session.flush()
        return {"type": "project_rule", "rule_id": rule.id}
    cfg = _project_config(project)
    if proposal.kind == "verifier":
        entry = {"verifier": "custom", "cmd": payload.get("cmd") or "",
                 "classification_hint": "blocking", "origin": f"selfheal:auto:{proposal.id}"}
        cfg.setdefault("verifiers", []).append(entry)
        project.config = json.dumps(cfg, ensure_ascii=False)
        session.add(project)
        return {"type": "project_verifiers", "cmd": entry["cmd"], "origin": entry["origin"]}

    cfg.setdefault("invariants", []).append(payload.get("content") or proposal.detail)
    project.config = json.dumps(cfg, ensure_ascii=False)
    session.add(project)
    return {"type": "project_invariants"}


def _unapply(session: Session, proposal, project) -> None:
    """退役清除：按 applied_to 回头删掉写入的配置项。"""
    applied = json.loads(proposal.applied_to or "{}")
    if applied.get("type") == "project_rule" and applied.get("rule_id"):
        rule = session.get(m.ProjectRule, int(applied["rule_id"]))
        if rule:
            session.delete(rule)
    elif applied.get("type") in ("project_verifiers", "project_invariants"):
        cfg = _project_config(project)
        key = "verifiers" if applied["type"] == "project_verifiers" else "invariants"
        items = cfg.get(key) or []
        origin = applied.get("origin")
        keep = [it for it in items if not (isinstance(it, dict) and origin and it.get("origin") == origin)]
        cfg[key] = keep
        project.config = json.dumps(cfg, ensure_ascii=False)
        session.add(project)


def retire_proposal(session: Session, proposal, reason: str = "") -> None:
    """退役 = 清除生效配置 + 状态留档（事后停用与自动退役共用）。"""
    project = session.get(m.Project, int(proposal.project_id))
    if project:
        _unapply(session, proposal, project)
    proposal.status = "retired"
    proposal.retired_at = _now()
    if reason:
        try:
            pf = json.loads(proposal.preflight or "{}")
        except Exception:
            pf = {}
        pf["retired_reason"] = reason
        proposal.preflight = json.dumps(pf, ensure_ascii=False)
    session.add(proposal)




def check_retirement(session: Session, project) -> None:
    """verifier：生效后 N 个后续任务无任何运行记录 → 退役；rule：同证据指纹复发 ≥N 次 → 退役。"""
    adopted = session.exec(
        select(m.SelfHealProposal)
        .where(m.SelfHealProposal.project_id == int(project.id), m.SelfHealProposal.status == "adopted")
    ).all()
    for p in adopted:
        evidence_fps = _evidence_fingerprints(session, p)
        tasks_after = len(session.exec(
            select(m.EvolutionEntry)
            .where(m.EvolutionEntry.project_id == int(project.id),
                   m.EvolutionEntry.created_at > (p.adopted_at or ""),
                   m.EvolutionEntry.task_id != p.task_id)
        ).all())
        if p.kind == "verifier":
            cmd = (json.loads(p.applied_to or "{}").get("cmd")) or _payload_of(p).get("cmd") or ""
            runs = session.exec(
                select(m.VerifierRun).where(m.VerifierRun.cmd == cmd)
            ).all()
            hits = [r for r in runs if r.exit_code is not None and r.exit_code != 0]
            p.hit_count = len(hits)
            p.last_hit_at = _now() if hits else p.last_hit_at
            if tasks_after >= RETIRE_IDLE_TASKS and len(runs) == 0:
                retire_proposal(session, p, reason=f"生效后 {tasks_after} 个后续任务无任何运行记录")
        elif p.kind == "rule" and evidence_fps:



            base = _evidence_base_run_id(session, p)
            relapse = session.exec(
                select(m.VerifierRun)
                .where(m.VerifierRun.exit_code != 0,
                       m.VerifierRun.fingerprint.in_(evidence_fps),
                       m.VerifierRun.id > base)
            ).all()
            p.hit_count = len(relapse)
            p.last_hit_at = _now() if relapse else p.last_hit_at
            if len(relapse) >= RULE_RELAPSE_LIMIT:
                retire_proposal(session, p, reason=f"同源失败复发 {len(relapse)} 次，规则未拦住")
        session.add(p)
    session.commit()


def _evidence_fingerprints(session: Session, proposal) -> list[str]:
    try:
        ids = json.loads(proposal.evidence_ids or "[]")
    except Exception:
        return []
    fps = []
    for rid in ids:
        try:
            run = session.get(m.VerifierRun, int(rid))
        except (TypeError, ValueError):
            continue
        if run and run.fingerprint:
            fps.append(run.fingerprint)
    return fps


def _evidence_base_run_id(session: Session, proposal) -> int:
    """生效分界：证据 run 的最大 id（VerifierRun 无时间戳，自增 id 即天然顺序）。"""
    try:
        ids = [int(x) for x in json.loads(proposal.evidence_ids or "[]")]
    except (ValueError, TypeError):
        return 0
    return max(ids) if ids else 0


def production_effect(session: Session, proposal) -> dict:
    """自愈提案的**生产效果**（真实运行数据，非回放集）：生效前后同类失败次数对比。"""
    out = {"before": 0, "after": 0, "tasks_after": 0, "fingerprints": 0, "verdict": "no_data"}
    fps = _evidence_fingerprints(session, proposal)
    if not fps:
        return out
    base = _evidence_base_run_id(session, proposal)
    rows = session.exec(
        select(m.VerifierRun).where(m.VerifierRun.exit_code != 0,
                                   m.VerifierRun.fingerprint.in_(fps))
    ).all()
    out["fingerprints"] = len(set(fps))
    out["before"] = sum(1 for r in rows if (r.id or 0) <= base)
    out["after"] = sum(1 for r in rows if (r.id or 0) > base)
    out["tasks_after"] = len(session.exec(
        select(m.EvolutionEntry)
        .where(m.EvolutionEntry.project_id == int(proposal.project_id),
               m.EvolutionEntry.created_at > (proposal.adopted_at or ""),
               m.EvolutionEntry.task_id != proposal.task_id)
    ).all())
    if out["tasks_after"] == 0:
        out["verdict"] = "insufficient_data"
    elif out["after"] == 0:
        out["verdict"] = "effective"
    else:
        out["verdict"] = "still_happening"
    return out




def maybe_evolve(engine, gateway, bus, settings, task_id: int) -> None:
    """任务终态/停机点调用：入账评分（幂等 upsert，重复调用只刷新）→ 首次失败痕迹时后台反思流。"""
    try:
        should_trigger = False
        project_id: int | None = None
        with Session(engine) as s:
            task = s.get(m.Task, task_id)
            if task is None:
                return
            project = s.get(m.Project, int(task.project_id))
            if project is None:
                return
            project_id = int(task.project_id)
            check_retirement(s, project)
            score, signals = score_task(s, task)
            generation = len(s.exec(
                select(m.SelfHealProposal)
                .where(m.SelfHealProposal.project_id == int(project.id),
                       m.SelfHealProposal.status == "adopted")
            ).all())
            entry = s.exec(
                select(m.EvolutionEntry).where(m.EvolutionEntry.task_id == task_id)
            ).first()
            if entry is None:
                entry = m.EvolutionEntry(project_id=int(project.id), task_id=task_id,
                                         generation=generation, score=score, triggered=False,
                                         signals=json.dumps(signals, ensure_ascii=False))
                s.add(entry)
            else:
                entry.score = score
                entry.signals = json.dumps(signals, ensure_ascii=False)
                entry.generation = generation
            should_trigger = not entry.triggered and _has_failure(signals)
            if should_trigger:
                entry.triggered = True
            s.commit()
        if should_trigger and project_id is not None:
            _spawn_reflect(engine, gateway, bus, settings, task_id, project_id)
    except Exception:
        pass


def _spawn_reflect(engine, gateway, bus, settings, task_id: int, project_id: int) -> None:
    import threading

    threading.Thread(target=_reflect, args=(engine, gateway, bus, settings, task_id, project_id),
                     daemon=True, name=f"evolve-{task_id}").start()


def _reflect(engine, gateway, bus, settings, task_id: int, project_id: int) -> None:
    """反思流（后台线程）：聚类 → meta LLM 提案 → 逐条守门/预检/自动生效。全程 best-effort。"""
    try:
        from agentflow.agents import meta as meta_mod

        with Session(engine) as s:
            task = s.get(m.Task, task_id)
            project = s.get(m.Project, project_id)
            if task is None or project is None:
                return
            clusters = cluster_failures(s, project_id, focus_task_id=task_id)
            if not clusters:
                return
            ctx = {
                "existing_rules": [r.content for r in s.exec(
                    select(m.ProjectRule).where(m.ProjectRule.project_id == project_id)).all()],
                "existing_verifier_cmds": [str(v.get("cmd") or "")
                                           for v in _project_config(project).get("verifiers") or []
                                           if isinstance(v, dict)],


                "stall_digest": stall_digest(
                    s, project_id,
                    (Path(str(settings.home)) / "events") if getattr(settings, "home", None) else None,
                ),
            }
            prompt = meta_mod.build_meta_prompt(task, clusters, ctx)
            system = meta_mod.build_meta_system()
        _result = gateway.generate("meta", prompt, system)
        advice = (_result.text or "").strip()
        try:
            from agentflow.core.llm_usage import record_extra

            record_extra(engine, task_id, "meta", "think", "meta_advice", _result)
        except Exception:
            pass
        proposals = meta_mod.parse_proposals(advice)
        for p in proposals:
            _handle_proposal(engine, bus, settings, p, task_id, project_id)
        if proposals:
            _emit(bus, task_id, project_id,
                  f"反思流完成：生成 {len(proposals)} 条提案（详情见 Report 自愈区块 / 设置 · 自愈）")
    except Exception:
        import sys
        traceback.print_exc(file=sys.stderr)


def _handle_proposal(engine, bus, settings, p: dict, task_id: int, project_id: int) -> None:
    """单条提案：入库 → 守门 → 预检 → 自动生效 / 丢弃留档。单条失败不影响其余。"""
    try:
        with Session(engine) as s:
            project = s.get(m.Project, project_id)
            if project is None:
                return
            proposal = m.SelfHealProposal(
                task_id=task_id, project_id=project_id, kind=p["kind"],
                title=(p["title"] or "")[:120], detail=(p["detail"] or "")[:1000],
                expected_gain=(p.get("expected_gain") or "")[:200],
                payload=json.dumps(p.get("payload") or {}, ensure_ascii=False),
                evidence_ids=json.dumps(p.get("evidence_ids") or [], ensure_ascii=False),
            )
            dup = gate_duplicate(p.get("payload") or {}, project)
            if dup:
                proposal.status = "discarded"
                proposal.preflight = json.dumps({"rejected": True, "reason": dup}, ensure_ascii=False)
                s.add(proposal)
                s.commit()
                _emit(bus, task_id, project_id, f"自愈提案被守门拒绝：{dup}")
                return
            pf = preflight(p["kind"], p.get("payload") or {}, project, settings,
                           len(p.get("evidence_ids") or []))
            if pf.get("rejected"):
                proposal.status = "discarded"
                proposal.preflight = json.dumps(pf, ensure_ascii=False)
                s.add(proposal)
                s.commit()
                reason = pf.get("reason") or pf.get("probe_err") or pf.get("exec_err") or f"试跑 exit={pf.get('exit')}"
                _emit(bus, task_id, project_id, f"自愈提案预检未通过（{str(reason)[:150]}），已留档")
                return
            proposal.preflight = json.dumps(pf, ensure_ascii=False)
            s.add(proposal)
            s.flush()
            applied = adopt(s, proposal, project)
            proposal.applied_to = json.dumps(applied, ensure_ascii=False)
            proposal.status = "adopted"
            proposal.origin = "selfheal:auto"
            proposal.adopted_at = _now()
            s.add(proposal)
            s.commit()
            ev = ",".join(str(i) for i in (p.get("evidence_ids") or [])[:5])
            _emit(bus, task_id, project_id,
                  f"自愈提案已自动生效：[{p['kind']}] {proposal.title[:80]}（证据 run: {ev}）")
    except Exception:
        traceback.print_exc(file=sys.stderr)


def _emit(bus, task_id: int, project_id: int, message: str, level: str = "sched") -> None:
    if bus is None:
        return
    try:
        bus.publish_task(task_id, "log.appended", {"level": level, "message": message})
        bus.publish_task(task_id, "selfheal.updated", {"task_id": task_id, "project_id": project_id})
    except Exception:
        pass
