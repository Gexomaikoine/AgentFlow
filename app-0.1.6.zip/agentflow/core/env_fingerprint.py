'''环境指纹对账（E）：区分"代码错"还是"环境脏"。'''

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path


_LOCKFILES = (
    "requirements.txt", "requirements-dev.txt", "pyproject.toml",
    "uv.lock", "poetry.lock", "Pipfile.lock",
    "package.json", "package-lock.json", "pnpm-lock.yaml", "yarn.lock",
)


def compute_fingerprint(repo_root: Path) -> dict:
    """计算环境指纹：解释器版本 + pip 冻结集哈希 + 锁文件哈希（项目根相对路径）。"""
    root = Path(repo_root)
    fp: dict = {"python": "", "pip_hash": "", "lockfiles": {}}
    fp["python"] = sys.version.split()[0]
    try:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "freeze", "--disable-pip-version-check"],
            capture_output=True, text=True, timeout=60,
        )
        if r.returncode == 0:
            lines = sorted(l for l in (r.stdout or "").splitlines() if l.strip())
            fp["pip_hash"] = hashlib.sha256("\n".join(lines).encode("utf-8", "replace")).hexdigest()[:16]
            fp["pip_count"] = len(lines)
    except (OSError, subprocess.TimeoutExpired):
        pass
    for name in _LOCKFILES:
        p = root / name
        if p.is_file():
            try:
                fp["lockfiles"][name] = hashlib.sha256(p.read_bytes()).hexdigest()[:16]
            except OSError:
                pass
    return fp


def diff_fingerprint(base: dict, current: dict) -> list[str]:
    """对比两个指纹，返回人类可读的漂移清单（空 = 无漂移）。"""
    drift: list[str] = []
    if base.get("pip_hash") and current.get("pip_hash") and base["pip_hash"] != current["pip_hash"]:
        b, c = base.get("pip_count"), current.get("pip_count")
        drift.append(f"Python 依赖集变化（pip freeze 哈希 {base['pip_hash']} → {current['pip_hash']}"
                     + (f"，包数 {b} → {c}" if b is not None and c is not None else "") + "）")
    if base.get("python") and current.get("python") and base["python"] != current["python"]:
        drift.append(f"解释器版本变化: {base['python']} → {current['python']}")
    lf_base = base.get("lockfiles") or {}
    lf_cur = current.get("lockfiles") or {}
    for name in sorted(set(lf_base) | set(lf_cur)):
        if lf_base.get(name) != lf_cur.get(name):
            drift.append(f"锁文件变化: {name}")
    return drift


def baseline_path(settings, project_name: str, task_id: int) -> Path:
    return Path(settings.home) / "projects" / project_name / "tasks" / str(task_id) / "env_fingerprint.json"


def save_baseline(settings, project_name: str, task_id: int, repo_root: Path) -> dict:
    """任务启动：计算并落盘环境基线。失败返回空 dict（不阻塞，指纹是增强）。"""
    try:
        fp = compute_fingerprint(repo_root)
        p = baseline_path(settings, project_name, task_id)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(fp, ensure_ascii=False), encoding="utf-8")
        return fp
    except Exception:
        return {}


def load_baseline(settings, project_name: str, task_id: int) -> dict:
    try:
        p = baseline_path(settings, project_name, task_id)
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except Exception:
        return {}


def check_drift(settings, project_name: str, task_id: int, repo_root: Path) -> list[str]:
    """失败归因时对账：返回漂移清单（空 = 无漂移或基线缺失）。"""
    base = load_baseline(settings, project_name, task_id)
    if not base:
        return []
    try:
        return diff_fingerprint(base, compute_fingerprint(repo_root))
    except Exception:
        return []
