"""事件总线：进程内 pub/sub → SSE + EventLog 落盘（回放/断线补发）。"""

from __future__ import annotations

import asyncio
from typing import Optional

from agentflow.storage.events_log import EventLog


class EventBus:
    def __init__(self, event_log: Optional[EventLog] = None):
        self._subs: dict[Optional[int], set[asyncio.Queue]] = {}
        self._log = event_log
        self._seq = 0

    def subscribe(self, task_id: Optional[int]) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=500)
        self._subs.setdefault(task_id, set()).add(q)
        return q

    def unsubscribe(self, task_id: Optional[int], q: asyncio.Queue) -> None:
        subs = self._subs.get(task_id)
        if subs and q in subs:
            subs.discard(q)

    def publish(self, task_id: Optional[int], event: str, payload: dict) -> dict:
        """发布事件，返回 envelope（含 seq，供断线补发）。"""
        if self._log and task_id is not None:
            envelope = self._log.append(task_id, event, payload)
            seq = envelope["seq"]
        else:
            seq = self._local_seq()
        return self._broadcast(task_id, event, payload, seq)

    def publish_ephemeral(self, task_id: Optional[int], event: str, payload: dict) -> None:
        """内存直通广播：不落 EventLog（LLM delta 等高频临时态专用）。"""
        self._broadcast(task_id, event, payload, self._local_seq())

    def _broadcast(self, task_id: Optional[int], event: str, payload: dict, seq: int) -> dict:
        subs = set(self._subs.get(None, set()))
        if task_id is not None:
            subs |= self._subs.get(task_id, set())
        for q in subs:
            try:
                q.put_nowait({"task_id": task_id, "event": event, "payload": payload, "seq": seq})
            except asyncio.QueueFull:
                pass
        return {"task_id": task_id, "event": event, "payload": payload, "seq": seq}

    def _local_seq(self) -> int:
        self._seq += 1
        return self._seq

    def publish_task(self, task_id: int, event: str, payload: dict) -> None:
        self.publish(task_id, event, payload)

    def publish_global(self, event: str, payload: dict) -> None:
        self.publish(None, event, payload)
