"""Windows 子进程静默（#5）：全局注入 CREATE_NO_WINDOW，消除 cmd 闪窗。"""

from __future__ import annotations

import subprocess
import sys

_CREATE_NO_WINDOW = 0x08000000
_installed = False


def install() -> None:
    """注入全局 Popen 补丁（幂等；非 Windows 平台直接返回）。"""
    global _installed
    if _installed or sys.platform != "win32":
        return
    _orig_init = subprocess.Popen.__init__

    def _silent_init(self, *args, **kwargs):
        if not kwargs.get("creationflags"):
            kwargs["creationflags"] = _CREATE_NO_WINDOW
        _orig_init(self, *args, **kwargs)

    subprocess.Popen.__init__ = _silent_init
    _installed = True
