"""文件租约管理（FR2 防线2）：预授 / 越区拒绝 / base 校验 / 绿点文件集。"""

from __future__ import annotations

from pathlib import Path

from agentflow.core.partition import feature_write_set
from agentflow.safety import path as spath
from agentflow.storage import models as m
from sqlmodel import Session


def grant_feature_leases(
    session: Session,
    feature: m.Feature,
    repo_root: Path,
) -> list[m.Lease]:
    """为功能预授写集内文件的租约（写集唯一实现 = partition.feature_write_set）。"""
    files = feature_write_set(feature, repo_root)
    leases = []
    for rel in sorted(files):
        lease = (
            session.query(m.Lease)
            .filter(m.Lease.feature_id == feature.id, m.Lease.file_path == rel)
            .first()
        )
        if lease is None:
            lease = m.Lease(
                task_id=feature.task_id,
                feature_id=feature.id,
                file_path=rel,
                state=m.LeaseState.granted,
            )
        lease.base_hash = spath.compute_hash(repo_root / rel)
        session.add(lease)
        leases.append(lease)
    session.commit()
    return leases


def is_authorized(session: Session, feature_id: int, file_path: str) -> bool:
    """检查文件是否在该功能的租约内。"""
    q = session.query(m.Lease).filter(
        m.Lease.feature_id == feature_id, m.Lease.file_path == file_path
    )
    return q.first() is not None


def check_write(
    session: Session,
    feature_id: int,
    file_path: str,
    repo_root: Path | None = None,
) -> tuple[bool, str]:
    """写前检查：租约内 + state 非 conflict + base_hash 未被外部改动。返回 (允许, 原因)。"""
    lease = (
        session.query(m.Lease)
        .filter(m.Lease.feature_id == feature_id, m.Lease.file_path == file_path)
        .first()
    )
    if lease is None:
        ok, granted, deny_reason = _match_scope_glob(session, feature_id, file_path)
        if ok:
            return True, "ok（glob 写集动态补授）"
        if deny_reason:
            return False, deny_reason


        ok2, deny2 = _grant_if_declared_related(session, feature_id, file_path, repo_root)
        if ok2:
            return True, "ok（Spec 已声明的相关文件，动态补授写集）"
        if deny2:
            return False, deny2


        from agentflow.safety.path import AGENT_TMP_DIR

        return False, (
            f"越区写拒绝: {file_path} 不在本功能租约内。"
            f"若这是不进交付物的一次性辅助脚本（如 UI/自测脚本），请改写 {AGENT_TMP_DIR}/ 下"
            "——该目录免租约、不纳入绿点与合并；"
            "若它确实是本功能需要的实现改动，说明 Spec 写集漏配，请报告该文件需要扩入写集。"
        )
    if lease.state == m.LeaseState.conflict:
        return False, f"该文件此前已冲突，请先重读"
    if lease.base_hash:
        root = repo_root or _feature_repo_root(session, session.get(m.Feature, feature_id))
        if root is not None:
            current = spath.compute_hash(root / file_path)
            if current != lease.base_hash:
                return False, (
                    f"基线校验失败: {file_path} 在租约授予后被外部改动（base_hash 不一致），"
                    "请先重读该文件再写（重读自动刷新基线）"
                )
    return True, "ok"


def _compile_scope_glob(pat: str):
    """写集 glob 模式编译（`**/` → 跨目录可选、`**` 尾缀 → 任意层级、`*` → 段内任意、`?` → 单字符）。"""
    import re

    out: list[str] = []
    i = 0
    while i < len(pat):
        if pat.startswith("**/", i):
            out.append("(?:.*/)?")
            i += 3
        elif pat.startswith("**", i):
            out.append(".*")
            i += 2
        elif pat[i] == "*":
            out.append("[^/]*")
            i += 1
        elif pat[i] == "?":
            out.append("[^/]")
            i += 1
        else:
            out.append(re.escape(pat[i]))
            i += 1
    return re.compile("^" + "".join(out) + "$")


def matches_declared_scope(feature: m.Feature, file_path: str) -> bool:
    """file_path 是否落在 feature 声明的写集内（字面精确 + glob 通配，纯函数无副作用）。"""
    import json as _json

    posix_path = file_path.replace("\\", "/")
    scope = _json.loads(feature.file_scope) if feature.file_scope else []
    for p in scope:
        pat = p.replace("\\", "/")
        if any(ch in pat for ch in "*?["):
            if _compile_scope_glob(pat).match(posix_path):
                return True
        elif pat == posix_path:
            return True
    return False


def _match_scope_glob(
    session: Session, feature_id: int, file_path: str
) -> tuple[bool, m.Lease | None, str | None]:
    """glob 写集回退匹配：file_path 命中 file_scope 任一通配符模式 → 动态补授 Lease。"""
    import json as _json

    feature = session.get(m.Feature, feature_id)
    if feature is None:
        return False, None, None
    posix_path = file_path.replace("\\", "/")
    scope = _json.loads(feature.file_scope) if feature.file_scope else []
    patterns = [p.replace("\\", "/") for p in scope if any(ch in p for ch in "*?[")]
    if not patterns:
        return False, None, None

    if not any(_compile_scope_glob(pat).match(posix_path) for pat in patterns):
        return False, None, None

    conflict = _conflict_holder(session, feature_id, posix_path)
    if conflict:
        return False, None, conflict

    from agentflow.safety import path as spath
    repo_root = _feature_repo_root(session, feature)
    lease = m.Lease(
        task_id=feature.task_id,
        feature_id=feature_id,
        file_path=posix_path,
        base_hash=spath.compute_hash(repo_root / posix_path) if repo_root else "",
        state=m.LeaseState.granted,
    )
    session.add(lease)
    session.commit()
    return True, lease, None




_ARBITRATION_ACTIVE: frozenset[m.FeatureStatus] = frozenset({
    m.FeatureStatus.pending,
    m.FeatureStatus.writing,
    m.FeatureStatus.verifying,
    m.FeatureStatus.queued,
    m.FeatureStatus.fixing,
})


def _conflict_holder(session: Session, feature_id: int, posix_path: str) -> str | None:
    """同任务其他**活跃**功能是否已持该文件租约。持则返回冲突说明，否则 None。"""
    feature = session.get(m.Feature, feature_id)
    if feature is None:
        return None
    other = (
        session.query(m.Lease)
        .filter(
            m.Lease.task_id == feature.task_id,
            m.Lease.file_path == posix_path,
            m.Lease.feature_id != feature_id,
            m.Lease.state.in_([m.LeaseState.granted, m.LeaseState.applied]),
        )
        .first()
    )
    if other is None:
        return None
    of = session.get(m.Feature, other.feature_id)
    if of is not None and of.status in _ARBITRATION_ACTIVE:
        return (
            f"写冲突: {posix_path} 已被功能[{of.seq}] {of.title} 持租约"
            f"（{of.status.value}），不可并行补授，请协调或改写其他文件"
        )
    return None


def _grant_if_declared_related(
    session: Session, feature_id: int, file_path: str, repo_root: Path | None
) -> tuple[bool, str]:
    """越区写兜底：目标文件若在 Spec 声明的 `related_files` 内 → 动态补授写集。"""
    import json

    from agentflow.safety import path as spath

    feature = session.get(m.Feature, feature_id)
    if feature is None:
        return False, ""
    posix_path = file_path.replace("\\", "/")
    try:
        related = json.loads(feature.related_files) if feature.related_files else []
    except Exception:
        related = []
    if posix_path not in {str(p).replace("\\", "/") for p in related}:
        return False, ""
    conflict = _conflict_holder(session, feature_id, posix_path)
    if conflict:
        return False, conflict
    root = repo_root or _feature_repo_root(session, feature)
    session.add(m.Lease(
        task_id=feature.task_id,
        feature_id=feature_id,
        file_path=posix_path,
        base_hash=spath.compute_hash(root / posix_path) if root else "",
        state=m.LeaseState.granted,
    ))


    try:
        scope = json.loads(feature.file_scope) if feature.file_scope else []
        if posix_path not in {str(p).replace("\\", "/") for p in scope}:
            scope.append(posix_path)
            feature.file_scope = json.dumps(scope, ensure_ascii=False)
            session.add(feature)
    except Exception:
        pass
    session.commit()
    return True, ""


def _feature_repo_root(session: Session, feature: m.Feature) -> Path | None:
    """租约补授时取 repo 根（base_hash 计算用；取不到返回 None 不阻塞）。"""
    try:
        task = session.get(m.Task, feature.task_id)
        if task is None:
            return None
        project = session.get(m.Project, task.project_id)
        return Path(project.repo_path) if project else None
    except Exception:
        return None


def record_write(session: Session, feature_id: int, file_path: str, repo_root: Path) -> None:
    """写后更新租约 base_hash（为下一次 base 校验做基线）。"""
    lease = (
        session.query(m.Lease)
        .filter(m.Lease.feature_id == feature_id, m.Lease.file_path == file_path)
        .first()
    )
    if lease:
        lease.base_hash = spath.compute_hash(repo_root / file_path)
        lease.state = m.LeaseState.applied
        session.add(lease)
        session.commit()


def refresh_base_on_read(session: Session, feature_id: int, file_path: str, repo_root: Path) -> None:
    """读后刷新租约基线（read_file 工具调用）。"""
    if repo_root is None:
        return
    lease = (
        session.query(m.Lease)
        .filter(m.Lease.feature_id == feature_id, m.Lease.file_path == file_path)
        .first()
    )
    if lease is None:
        return
    lease.base_hash = spath.compute_hash(repo_root / file_path)
    if lease.state == m.LeaseState.conflict:
        lease.state = m.LeaseState.granted
    session.add(lease)
    session.commit()


def applied_files(session: Session, feature_id: int) -> list[str]:
    """该功能已 applied 的租约文件（绿点 commit 文件集的事实来源）。"""
    rows = (
        session.query(m.Lease)
        .filter(m.Lease.feature_id == feature_id, m.Lease.state == m.LeaseState.applied)
        .all()
    )
    return [r.file_path for r in rows]
