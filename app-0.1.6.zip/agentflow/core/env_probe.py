"""本机能力探测：设置页「环境」检测的数据源。"""

from __future__ import annotations

import shutil
import socket
import subprocess
import sys


KNOWN_PORTS: dict[int, str] = {
    8765: "执行面控制台 + API（本服务）",
    5747: "集成校验服务（每项目一份）",
    18265: "CD 回流隧道（部署机侧）",
    5173: "Vite dev server（仅前端开发用）",
}


_NEED_LABEL = {"python": "Python", "node": "Node.js", "go": "Go", "rust": "Rust"}


_OPTIONAL_RUNTIMES: dict[str, tuple[str, str, list[str], str]] = {
    "go": ("Go 工具链", "go", ["go", "version"], "go version "),
    "rust": ("Rust / Cargo", "cargo", ["cargo", "--version"], "cargo "),
}


def _out(cmd: list[str], timeout: float = 5.0) -> str:
    """跑只读版本探测命令取首行输出；失败/超时返回空串。"""
    try:
        p = subprocess.run(
            cmd, capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=timeout,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    text = (p.stdout or p.stderr or "").strip()
    return text.splitlines()[0].strip() if text else ""


def _port_in_use(port: int) -> bool:
    """端口是否有服务在监听。**IPv4 与 IPv6 都要试**：只测 127.0.0.1 会漏掉仅监听 ::1 的"""
    for family, addr in ((socket.AF_INET, "127.0.0.1"), (socket.AF_INET6, "::1")):
        try:
            with socket.socket(family, socket.SOCK_STREAM) as s:
                s.settimeout(0.3)
                if s.connect_ex((addr, port)) == 0:
                    return True
        except OSError:
            continue
    return False


def _pkg_version(name: str) -> str:
    try:
        from importlib.metadata import version

        return version(name)
    except Exception:
        return ""


def _item(key: str, group: str, label: str, found: bool, *, version: str = "",
          path: str = "", required_for: str = "", severity: str = "required",
          note: str = "") -> dict:
    return {
        "key": key, "group": group, "label": label, "found": found,
        "version": version, "path": path, "required_for": required_for,
        "severity": severity, "note": note,
    }


def probe_items(extra_langs: set[str] | None = None) -> list[dict]:
    """本机能力清单（不依赖 DB）。"""
    items: list[dict] = []

    items.append(_item(
        "python", "platform", "Python 运行时", True,
        version=sys.version.split()[0], path=sys.executable,
        required_for="平台本体（执行面自身代码）",
        severity="required",
        note="执行面正在使用；安装包会内嵌自带解释器",
    ))

    git_path = shutil.which("git") or ""
    items.append(_item(
        "git", "platform", "Git", bool(git_path),
        version=_out(["git", "--version"]).replace("git version ", ""),
        path=git_path,
        required_for="任务分支 / 绿点提交 / 合并 / 回滚",
        severity="required",
        note="系统 git 优先；安装包内嵌 MinGit 作兜底",
    ))

    pw = _pkg_version("playwright")
    items.append(_item(
        "playwright", "platform", "Playwright（UI 机审驱动）", bool(pw),
        version=pw,
        required_for="UI 机审 / 浏览器回归门",
        severity="optional",
        note="浏览器走本机 Edge/Chrome，不下载内置浏览器；缺它做不了 UI 验收",
    ))

    node_path = shutil.which("node") or ""
    items.append(_item(
        "node", "project", "Node.js", bool(node_path),
        version=_out(["node", "--version"]).lstrip("v"),
        path=node_path,
        required_for="开发前端类项目（npm 验收、起 dev server 做 UI 测试）",
        severity="optional",
        note="AgentFlow 自身不需要 Node；仅任务目标是前端项目时才需要",
    ))

    for lang in sorted(set(extra_langs or ())):
        spec = _OPTIONAL_RUNTIMES.get(lang)
        if spec is None or any(i["key"] == lang for i in items):
            continue
        label, exe, ver_cmd, prefix = spec
        path = shutil.which(exe) or ""
        ver = ""
        if path:
            raw = _out(ver_cmd)
            if raw:
                trimmed = raw[len(prefix):] if prefix and raw.startswith(prefix) else raw
                ver = trimmed.split()[0] if trimmed.split() else ""
        items.append(_item(
            lang, "project", label, bool(path), version=ver, path=path,
            required_for=f"开发 {label} 项目",
            severity="optional",
            note="按项目按需：仅当任务目标是这类项目时才需要",
        ))
    return items


def probe_ports() -> list[dict]:
    return [
        {"port": p, "purpose": purpose, "in_use": _port_in_use(p)}
        for p, purpose in KNOWN_PORTS.items()
    ]


def project_needs(stack: dict, found_keys: set[str]) -> list[dict]:
    """按技术栈推出该项目需要哪些运行时（key 与 probe_items 对齐）。"""
    langs = set(stack.get("languages") or ())
    needs: list[str] = []
    if "python" in langs:
        needs.append("python")
    if langs & {"javascript", "typescript"}:
        needs.append("node")
    for lang in ("go", "rust"):
        if lang in langs:
            needs.append(lang)
    return [
        {"key": k, "label": _NEED_LABEL.get(k, k), "found": k in found_keys}
        for k in needs
    ]


def probe_environment(settings, projects: list[dict] | None = None,
                      extra_langs: set[str] | None = None) -> dict:
    """环境检测总入口：能力清单 + 端口占用 +（可选）各项目缺什么。"""
    if extra_langs is None and projects:
        merged: set[str] = set()
        for p in projects:
            merged |= set((p.get("stack") or {}).get("languages") or ())
        extra_langs = merged
    items = probe_items(extra_langs)
    found = {i["key"] for i in items if i["found"]}
    out: dict = {
        "home": str(settings.home),
        "items": items,
        "ports": probe_ports(),
        "summary": {
            "required_missing": [i["key"] for i in items if i["severity"] == "required" and not i["found"]],
            "optional_missing": [i["key"] for i in items if i["severity"] != "required" and not i["found"]],
        },
    }
    if projects is not None:
        out["projects"] = [
            {**p, "needs": project_needs(p.get("stack") or {}, found)} for p in projects
        ]
    return out
