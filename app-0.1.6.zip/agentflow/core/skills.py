"""Skills 技能包（P2）：可版本化、可开关的「经验包」，按需加载以省上下文。"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import yaml

SKILLS_DIR_NAME = "skills"
SKILL_FILE = "内部文档"
MAX_BODY_CHARS = 12000
MAX_INDEX_ITEMS = 20

_FRONTMATTER = re.compile(r"^---\s*\n(.*?)\n---\s*\n?", re.S)


@dataclass
class Skill:
    name: str
    description: str
    enabled: bool
    scope: str
    body: str
    path: Path


def skills_dir(home) -> Path:
    return Path(home) / SKILLS_DIR_NAME


def parse_skill(text: str, *, fallback_name: str = "", path: Path | None = None) -> Skill:
    """解析 内部文档（frontmatter 可选；解析失败按无元数据处理，不抛）。"""
    m = _FRONTMATTER.match(text or "")
    meta: dict = {}
    body = text or ""
    if m:
        try:
            loaded = yaml.safe_load(m.group(1))
            meta = loaded if isinstance(loaded, dict) else {}
        except Exception:
            meta = {}
        body = (text or "")[m.end():]
    return Skill(
        name=str(meta.get("name") or fallback_name).strip(),
        description=str(meta.get("description") or "").strip(),
        enabled=bool(meta.get("enabled", True)),
        scope=str(meta.get("scope") or "").strip(),
        body=body.strip(),
        path=path or Path(SKILL_FILE),
    )


def list_skills(home, *, project_id: int | None = None, include_disabled: bool = False) -> list[Skill]:
    """列出可用技能。缺 name/description 的坏包**跳过并告警**（技能是增强，不阻塞主链路）。"""
    out: list[Skill] = []
    d = skills_dir(home)
    if not d.is_dir():
        return out
    for p in sorted(d.glob(f"*/{SKILL_FILE}")):
        try:
            sk = parse_skill(p.read_text(encoding="utf-8"), fallback_name=p.parent.name, path=p)
        except OSError:
            continue
        if not sk.name or not sk.description:
            print(f"[skills] 忽略缺少 name/description 的技能包: {p}")
            continue
        if not include_disabled and not sk.enabled:
            continue
        if sk.scope.startswith("project:"):
            try:
                want = int(sk.scope.split(":", 1)[1])
            except ValueError:
                continue
            if project_id is None or want != int(project_id):
                continue
        out.append(sk)
    return out


def load_skill(home, name: str, *, project_id: int | None = None) -> Skill | None:
    """按 name（或目录名）取技能。"""
    key = (name or "").strip()
    if not key:
        return None
    for sk in list_skills(home, project_id=project_id):
        if sk.name == key or sk.path.parent.name == key:
            return sk
    return None


def skill_index_text(skills: list[Skill]) -> str:
    """常驻清单（只列 name + description）——供 system prompt 注入。"""
    if not skills:
        return ""
    lines = ["## 可用技能（按需加载：需要时调用 skill_load 取全文，不要凭记忆猜）"]
    for sk in skills[:MAX_INDEX_ITEMS]:
        lines.append(f"- {sk.name}: {sk.description}")
    if len(skills) > MAX_INDEX_ITEMS:
        lines.append(f"（另有 {len(skills) - MAX_INDEX_ITEMS} 个技能未列出）")
    return "\n".join(lines) + "\n\n"


def skill_template(name: str) -> str:
    """新建技能包的模板（`agentflow skill new <name>` 用）。"""
    return f"""---
name: {name}
description: 一句话说明这个技能解决什么问题、什么时候该用它（这行会常驻注入，务必简短具体）
enabled: true
scope: ""
---

## 何时用

（什么场景该加载这个技能）

## 内容

（做法、约定、踩过的坑。写具体命令/路径/示例，避免空泛）

## 已踩的坑

（可留空；建议把"这样写会坏、要这样写"的对照写清楚）
"""
