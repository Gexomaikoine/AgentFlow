'''轻量 repo map（P4，2026-09-27）：把"仓库里有什么、在哪"一次性摊给 agent。'''
from __future__ import annotations

import os
import re
import threading
import time
from pathlib import Path

_SKIP_DIRS = {
    ".git", "node_modules", ".next", "dist", "build", "out", ".turbo", ".venv",
    "venv", "__pycache__", ".agentflow_tmp", "coverage", ".pytest_cache", ".idea",
}
_SRC_SUFFIXES = {".ts", ".tsx", ".js", ".jsx", ".mjs", ".vue", ".svelte", ".py"}
_MAX_FILES = 600
_MAX_SYMBOLS_PER_FILE = 8
_MAX_TESTIDS_PER_FILE = 6
_MEMO_TTL_S = 300.0
_MEMO_LOCK = threading.Lock()
_MEMO: dict[str, tuple[float, str]] = {}

_EXPORT_PATTERNS = (
    re.compile(r"^\s*export\s+(?:default\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)"),
    re.compile(r"^\s*export\s+(?:default\s+)?class\s+([A-Za-z_$][\w$]*)"),
    re.compile(r"^\s*export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)"),
    re.compile(r"^\s*export\s+(?:interface|type|enum)\s+([A-Za-z_$][\w$]*)"),
    re.compile(r"^\s*export\s+default\s+(?:function\s+)?([A-Za-z_$][\w$]*)"),
    re.compile(r"^\s*(?:def|class)\s+([A-Za-z_][\w]*)"),
)
_TESTID_RE = re.compile(r"""data-testid\s*=\s*["'`]{1}([A-Za-z0-9_:-]+)["'`]""")

_PAGE_MARK = re.compile(r"(?:^|/)(?:app|pages)/(.+?)/page\.(?:tsx|ts|jsx|js)$")
_ROOT_PAGE = re.compile(r"(?:^|/)app/page\.(?:tsx|ts|jsx|js)$", re.I)


def route_of(rel: str) -> str:
    '''页面文件相对路径 → 路由；非页面文件返回 ""（route group 剥除，app 根页面 → "/"）。'''
    norm = "/" + rel.replace("\\", "/")
    m = _PAGE_MARK.search(norm)
    if not m:
        return "/" if _ROOT_PAGE.search(norm) else ""
    seg = m.group(1).replace("/page", "")
    seg = re.sub(r"\([^)]*\)/", "", seg)
    return "/" + seg.strip("/") if seg else "/"


def build_repo_map(root, max_lines: int = 120) -> str:
    """生成紧凑 repo map 文本（无源码 → 返回空串）。结果按 (root, 文件签名) 进程内缓存 5 分钟。"""
    root_p = Path(str(root))
    if not root_p.is_dir():
        return ""
    entries: list[tuple[str, float]] = []
    scanned = 0
    for dirpath, dirnames, filenames in os.walk(root_p):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for fn in filenames:
            if os.path.splitext(fn)[1].lower() not in _SRC_SUFFIXES:
                continue
            fp = Path(dirpath) / fn
            try:
                st = fp.stat()
            except OSError:
                continue
            try:
                rel = str(fp.relative_to(root_p)).replace("\\", "/")
            except ValueError:
                continue
            entries.append((rel, st.st_mtime))
            scanned += 1
            if scanned >= _MAX_FILES:
                break
        if scanned >= _MAX_FILES:
            break
    if not entries:
        return ""
    sig = str(hash(tuple(sorted(entries))))
    key = f"{root_p.resolve()}|{sig}"
    now = time.monotonic()
    with _MEMO_LOCK:
        hit = _MEMO.get(key)
        if hit and now - hit[0] < _MEMO_TTL_S:
            return hit[1]

    lines: list[str] = []
    pages: list[str] = []
    for rel, _mt in sorted(entries):
        try:
            text = (root_p / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        symbols: list[str] = []
        for line in text.splitlines():
            for pat in _EXPORT_PATTERNS:
                m = pat.match(line)
                if m:
                    name = m.group(1)
                    if name not in symbols:
                        symbols.append(name)
                    break
            if len(symbols) >= _MAX_SYMBOLS_PER_FILE:
                break
        testids: list[str] = []
        for m in _TESTID_RE.finditer(text):
            tid = m.group(1)
            if tid not in testids:
                testids.append(tid)
            if len(testids) >= _MAX_TESTIDS_PER_FILE:
                break
        route = route_of(rel)
        if route:
            pages.append(f"{route} -> {rel}")
        if not symbols and not testids:
            continue
        piece = f"{rel}"
        if symbols:
            piece += ": " + ", ".join(symbols)
        if testids:
            piece += f"  [testid: {', '.join(testids)}]"
        lines.append(piece)
        if len(lines) >= max_lines:
            break

    out = ""
    if pages:
        out += "## 页面路由\n" + "\n".join(sorted(pages)[:30]) + "\n"
    if lines:
        out += "## 文件 → 导出符号 / 锚点（按路径序，用于定位改动点）\n" + "\n".join(lines) + "\n"
    out = out.strip()
    if out:
        out += (
            "\n（以上为索引快照，非验证事实：命中文件后用 read_file 看真实内容；"
            "本功能写集内的文件内容已在任务信息里预注）"
        )
    with _MEMO_LOCK:
        _MEMO[key] = (now, out)
        if len(_MEMO) > 32:
            for k in list(_MEMO)[:-16]:
                _MEMO.pop(k, None)
    return out
