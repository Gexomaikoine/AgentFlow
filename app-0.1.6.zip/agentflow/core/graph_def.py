"""拓扑定义（graph_def）：MVP 不使用 ——拓扑由 scheduler 直接驱动"""

from __future__ import annotations




