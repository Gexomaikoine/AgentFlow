"""ask 档审批注册表（P0-2）：进程内 pending 队列 + 线程事件等待人工决议。"""

from __future__ import annotations

import json
import threading
import time
import uuid
from pathlib import Path

DECISIONS = ("allow_once", "allow_prefix", "deny")


class ApprovalRegistry:
    def __init__(self):
        self._lock = threading.Lock()
        self._pending: dict[str, dict] = {}
        self._events: dict[str, threading.Event] = {}
        self._decisions: dict[str, str] = {}
        self._prefixes: dict[int, set[str]] = {}
        self._persist_dir: str | None = None
        self._project_resolver = None

    def create(self, task_id: int, cmd: str, reason: str) -> dict:
        """登记一条待审批命令，返回审批请求（含 approval_id，供事件/UI/API 引用）。"""
        aid = uuid.uuid4().hex[:12]
        req = {
            "approval_id": aid,
            "task_id": task_id,
            "cmd": cmd,
            "reason": reason,
            "created_at": time.time(),
        }
        with self._lock:
            self._pending[aid] = req
            self._events[aid] = threading.Event()
        return dict(req)

    def wait(self, approval_id: str, timeout_s: float) -> str:
        """阻塞等待决议。返回 allow_once/allow_prefix/deny；超时返回 timeout。"""
        ev = self._events.get(approval_id)
        if ev is None:
            return "unknown"
        decided = ev.wait(timeout_s)
        with self._lock:
            decision = self._decisions.pop(approval_id, "deny" if decided else "timeout")
            self._pending.pop(approval_id, None)
            self._events.pop(approval_id, None)
        return decision

    def decide(self, approval_id: str, decision: str) -> tuple[bool, str]:
        """人工决议。allow_prefix 时登记任务级前缀（后续同类命令免审）+ 项目级持久化（跨重启生效）。"""
        decision = (decision or "").strip()
        if decision not in DECISIONS:
            return False, f"非法决议: {decision}（可选: {'/'.join(DECISIONS)}）"
        ev = None
        persist: tuple[int, str] | None = None
        with self._lock:
            req = self._pending.get(approval_id)
            if req is None:
                return False, "审批请求不存在或已过期"
            if decision == "allow_prefix":
                from agentflow.safety.command import cmd_prefix

                prefix = cmd_prefix(req["cmd"])
                if prefix:
                    self._prefixes.setdefault(req["task_id"], set()).add(prefix)
                    persist = (req["task_id"], prefix)
            self._decisions[approval_id] = decision
            ev = self._events.get(approval_id)
        if persist is not None:

            self._persist_prefix(*persist)
        if ev is not None:
            ev.set()
        return True, decision

    def enable_persistence(self, projects_dir, project_resolver) -> None:
        """开启项目级前缀持久化（serve 组装时调用一次；测试未调用则保持纯内存行为）。"""
        self._persist_dir = str(projects_dir)
        self._project_resolver = project_resolver

    def _project_prefixes(self, task_id: int) -> set[str]:
        """项目级持久化前缀（跨任务跨重启）。未启用/读取失败返回空，不影响安全判定主链路。"""
        try:
            resolver = self._project_resolver
            if not self._persist_dir or not resolver:
                return set()
            name = resolver(task_id)
            if not name:
                return set()
            p = Path(self._persist_dir) / name / "approvals.json"
            if not p.exists():
                return set()
            data = json.loads(p.read_text(encoding="utf-8")) or {}
            return {str(x) for x in data.get("allow_prefixes", [])}
        except Exception:
            return set()

    def _persist_prefix(self, task_id: int, prefix: str) -> None:
        """前缀落盘（best-effort：失败不影响审批主链路，内存登记已生效）。"""
        try:
            resolver = self._project_resolver
            if not self._persist_dir or not resolver:
                return
            name = resolver(task_id)
            if not name:
                return
            p = Path(self._persist_dir) / name / "approvals.json"
            p.parent.mkdir(parents=True, exist_ok=True)
            data = {}
            if p.exists():
                data = json.loads(p.read_text(encoding="utf-8")) or {}
            prefixes = {str(x) for x in data.get("allow_prefixes", [])}
            prefixes.add(prefix)
            data["allow_prefixes"] = sorted(prefixes)
            p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def pending_for_task(self, task_id: int) -> dict | None:
        """任务当前待审批命令（刷新还原用；同任务同时至多一条）。"""
        with self._lock:
            for req in self._pending.values():
                if req["task_id"] == task_id:
                    return dict(req)
        return None

    def prefixes_for(self, task_id: int) -> set[str]:
        with self._lock:
            result = set(self._prefixes.get(task_id, set()))

        return result | self._project_prefixes(task_id)



REGISTRY = ApprovalRegistry()
