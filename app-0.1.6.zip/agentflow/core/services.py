"""ServiceManager（UI 机审环境编排）：受控的服务生命周期管理。"""

from __future__ import annotations

import atexit
import json
import os
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path





PORT_PLACEHOLDER = "{port}"
ENV_PORT_VAR = "AF_UI_PORT"


HARNESS_MARK = "[机审环境]"


class ServiceError(RuntimeError):
    """服务编排失败（响亮错：调用方停机/机审失败，绝不静默跳过）。"""


@dataclass
class ServiceHandle:
    proc: subprocess.Popen
    port: int


def parse_ui_review(project_config: str | dict) -> dict | None:
    """解析项目配置里的 ui_review 段；未启用返回 None。缺失必填项响亮报错。"""
    if isinstance(project_config, str):
        try:
            cfg = json.loads(project_config or "{}")
        except Exception:
            return None
    else:
        cfg = project_config or {}
    ui = cfg.get("ui_review") or {}
    if not isinstance(ui, dict) or not ui.get("enabled"):
        return None
    if not ui.get("start_cmd"):
        raise ServiceError("ui_review 已启用但缺少 start_cmd（响亮错：机审无法起服务）")
    ui.setdefault("port", "auto")
    ui.setdefault("channel", "msedge")
    ui.setdefault("health_path", "/")
    ui.setdefault("start_timeout_s", 60)
    ui.setdefault("pages", [])
    ui.setdefault("console_block", True)
    ui.setdefault("http_max_code", 399)
    ui.setdefault("allow_hosts", [])
    return ui


def allocate_free_port(preferred: object = None) -> int:
    """分配机审端口：preferred 为正整数且空闲则复用，否则让 OS 挑一个空闲端口。"""
    try:
        pref = int(preferred)
    except (TypeError, ValueError):
        pref = 0
    if pref > 0 and not _port_open(pref):
        return pref
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sk:
        sk.bind(("127.0.0.1", 0))
        return int(sk.getsockname()[1])


def resolve_ui_port(ui: dict) -> dict:
    """把机审端口解析成具体空闲端口并落到 start_cmd（通用契约，与项目无关）。"""
    cmd = str(ui.get("start_cmd") or "")
    has_ph = PORT_PLACEHOLDER in cmd
    has_env = ENV_PORT_VAR in cmd
    if not (has_ph or has_env):
        raise ServiceError(
            f"ui_review.start_cmd 未声明机审端口契约：请用 {PORT_PLACEHOLDER} 占位符"
            f"（如 `npm run dev -- -p {PORT_PLACEHOLDER}`）或引用环境变量 {ENV_PORT_VAR}，"
            "AgentFlow 会分配空闲端口并注入。"
        )
    port = allocate_free_port(ui.get("port"))
    out = dict(ui)
    out["port"] = port
    if has_ph:
        out["start_cmd"] = cmd.replace(PORT_PLACEHOLDER, str(port))
    return out


def _port_open(port: int, host: str = "127.0.0.1") -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sk:
        sk.settimeout(0.5)
        return sk.connect_ex((host, port)) == 0





_LEADING_CMD = re.compile(r"^\s*cmd(?:\.exe)?\b(?:\s+/[a-z]+)*\s+/c\s+", re.IGNORECASE)


def _normalize_shell_cmd(cmd: str) -> str:
    """剥掉 start_cmd 自带的 `cmd /c` 前缀（只剥一层），避免 shell=True 叠成双层 shell。"""
    return _LEADING_CMD.sub("", cmd or "", count=1)


def _uses_powershell_syntax(cmd: str) -> bool:
    """win32 下判定 start_cmd 是否 PowerShell 风格（引号外有 `;` 命令分隔）。"""
    quote = ""
    prev = ""
    for ch in cmd:
        if quote:
            if ch == quote:
                quote = ""
        elif ch in "\"'":
            quote = ch
        elif ch == ";":
            return True
        elif ch == "&" and prev == "&":
            return False
        prev = ch
    return False


def _ps_semicolons_to_cmd(cmd: str) -> str:
    """把引号外的顶层 `;` 分隔符翻译成 cmd 的 `&&`（仍走 cmd.exe）。"""
    out: list[str] = []
    quote = ""
    for ch in cmd:
        if quote:
            out.append(ch)
            if ch == quote:
                quote = ""
            continue
        if ch in "\"'":
            quote = ch
        elif ch == ";":
            out.append("&&")
            continue
        out.append(ch)
    return "".join(out)


def start_service(ui: dict, cwd: Path) -> ServiceHandle:
    """按登记的 start_cmd 起服务（shell 语义与执行面一致），轮询健康直至可服务。"""
    port = int(ui["port"])
    if _port_open(port):
        raise ServiceError(
            f"{HARNESS_MARK} 端口 {port} 已被占用，无法起机审服务"
            "（AgentFlow 会自动换空闲端口重试；若为本轮机审残留会一并清理）"
        )
    env = {**os.environ, ENV_PORT_VAR: str(port)}



    start_cmd = _normalize_shell_cmd(str(ui["start_cmd"]))


    import tempfile

    log_path = Path(tempfile.gettempdir()) / f"agentflow-ui-svc-{os.getpid()}-{port}.log"


    if sys.platform == "win32" and _uses_powershell_syntax(start_cmd):
        start_cmd = _ps_semicolons_to_cmd(start_cmd)
    with open(log_path, "ab") as lf:
        proc = subprocess.Popen(
            start_cmd, cwd=str(cwd), shell=True, env=env,
            stdout=lf, stderr=subprocess.STDOUT,
        )
    handle = ServiceHandle(proc=proc, port=port)
    deadline = float(ui.get("start_timeout_s") or 60)
    start = time.monotonic()
    health = str(ui.get("health_path") or "")
    while time.monotonic() - start < deadline:
        if proc.poll() is not None:
            raise ServiceError(
                f"{HARNESS_MARK} 机审服务启动即退出（exit={proc.poll()}）：{start_cmd[:200]}\n"
                f"--- 服务输出（{log_path}）---\n{_tail(log_path)}"
            )
        if health:
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}{health}", timeout=2) as r:
                    if r.status == 200:
                        return handle
            except Exception:
                pass
        elif _port_open(port):
            return handle
        time.sleep(0.5)
    stop_service(handle)
    raise ServiceError(
        f"{HARNESS_MARK} 机审服务 {deadline}s 内未就绪（health {health or port}）：{start_cmd[:200]}\n"
        f"--- 服务输出（{log_path}）---\n{_tail(log_path)}"
    )


def _tail(path: Path, limit: int = 1200) -> str:
    """读文件尾部（服务输出诊断用；不存在/读失败返回空）。"""
    try:
        data = path.read_bytes()[-limit:]
        return data.decode("utf-8", errors="replace").strip()
    except Exception:
        return ""


def stop_service(handle: ServiceHandle | None) -> None:
    """清理服务进程树。Windows 用 taskkill /T /F（shell=True 的 pid 是 shell，必须杀树）。"""
    if handle is None or handle.proc.poll() is not None:
        return
    try:
        if sys.platform == "win32":
            subprocess.run(
                ["taskkill", "/T", "/F", "/PID", str(handle.proc.pid)],
                capture_output=True, timeout=10,
            )
        else:
            handle.proc.terminate()
            handle.proc.wait(timeout=10)
    except Exception:
        try:
            handle.proc.kill()
        except Exception:
            pass








_WATCH_HINTS = (
    "next dev", "vite", "npm run dev", "yarn dev", "pnpm dev", "npm start",
    "nodemon", "webpack serve", "--watch", "-w ", "serve -s",
)
WARM_MAX_IDLE_S = float(os.environ.get("AF_UI_WARM_IDLE_S") or 900)
KEEP_WARM_MARK = "[暖服务复用]"


@dataclass
class _WarmEntry:
    handle: ServiceHandle
    last_used: float = field(default_factory=time.monotonic)


_WARM_LOCK = threading.Lock()
_WARM: dict[tuple[str, str], _WarmEntry] = {}
_WARM_REAPER_STARTED = False


def _looks_watch_service(start_cmd: str) -> bool:
    low = (start_cmd or "").lower()
    return any(h in low for h in _WATCH_HINTS)


def _warm_key(ui: dict, cwd: Path) -> tuple[str, str]:
    return (
        str(Path(cwd).resolve()).lower(),
        _normalize_shell_cmd(str(ui.get("start_cmd") or "")).strip().lower(),
    )


def _drop_warm_locked(key: tuple[str, str]) -> None:
    entry = _WARM.pop(key, None)
    if entry is not None:
        stop_service(entry.handle)
        _unregister_warm(entry.handle.proc.pid)


def _reap_idle_warm() -> None:
    now = time.monotonic()
    with _WARM_LOCK:
        for key in [k for k, e in _WARM.items() if now - e.last_used > WARM_MAX_IDLE_S]:
            _drop_warm_locked(key)


def _ensure_reaper() -> None:
    global _WARM_REAPER_STARTED
    if _WARM_REAPER_STARTED:
        return
    _WARM_REAPER_STARTED = True

    def _loop() -> None:
        while True:
            time.sleep(30)
            try:
                _reap_idle_warm()
            except Exception:
                pass

    threading.Thread(target=_loop, name="af-warm-service-reaper", daemon=True).start()
    atexit.register(release_services)


def acquire_service(ui: dict, cwd: Path, home: Path | None = None) -> tuple[ServiceHandle, bool]:
    """起机审服务；watch 型开发服务按 (工作根, start_cmd) 进程内复用。"""
    if home is not None:
        _set_warm_home(home)
    cmd = str(ui.get("start_cmd") or "")
    if not _looks_watch_service(cmd) or not bool(ui.get("warm_reuse", True)):
        return start_service(ui, cwd), False
    key = _warm_key(ui, cwd)
    with _WARM_LOCK:
        entry = _WARM.get(key)
        if entry is not None:
            if entry.handle.proc.poll() is None and _port_open(entry.handle.port):
                entry.last_used = time.monotonic()
                ui["port"] = int(entry.handle.port)
                return entry.handle, True
            _drop_warm_locked(key)
        handle = start_service(ui, cwd)
        _WARM[key] = _WarmEntry(handle=handle)
        _ensure_reaper()
        _register_warm(handle, ui, cwd)
        return handle, True


def touch_warm(handle: ServiceHandle) -> None:
    """续期（调用方跑完一轮机审后调用）。非暖句柄静默忽略。"""
    now = time.monotonic()
    with _WARM_LOCK:
        for entry in _WARM.values():
            if entry.handle is handle:
                entry.last_used = now
                return


def release_services(cwd: Path | None = None) -> int:
    """收口暖服务：cwd 为 None 时清全部；否则清该工作根下的（任务收口/清理 worktree 前必调，"""
    prefix = str(Path(cwd).resolve()).lower() if cwd is not None else None
    with _WARM_LOCK:
        keys = [k for k in _WARM if prefix is None or k[0] == prefix]
        for k in keys:
            _drop_warm_locked(k)
        return len(keys)


def run_project_ui_review(session, settings, bus, task, project, cwd: Path, round_label: str = "") -> str | None:
    """合并队列回归门（机审）：起服务 → UI 机审 → VerifierRun 落库 → 清进程。"""
    from agentflow.verifiers.base import VerifierResult
    from agentflow.verifiers.ui import attach_media, run_ui_checks

    try:
        ui = parse_ui_review(project.config)
        if ui is not None:
            ui = resolve_ui_port(ui)
    except ServiceError as e:
        return f"{HARNESS_MARK} UI 机审无法启动：{e}"
    if ui is None:
        return None
    try:
        import playwright
    except ImportError:
        return f"{HARNESS_MARK} playwright 未安装：pip install -e '.[ui]'（响亮失败，不静默跳过机审）"

    evidence_dir = (
        Path(settings.home) / "screenshots" / str(project.name) / f"task{task.id}"
        / (round_label or "round")
    )
    label = f"[ui-review] pages={len(ui.get('pages') or [])} port={ui['port']} channel={ui.get('channel')}"
    handle: ServiceHandle | None = None
    warm = False
    result: VerifierResult
    report: dict | None = None
    try:
        handle, warm = acquire_service(ui, cwd, home=getattr(settings, "home", None))
    except ServiceError as e:
        result = VerifierResult(verifier="ui", cmd=label, exit_code=1,
                                output=str(e), duration_ms=0, classification="harness")
    else:
        result, report = run_ui_checks(ui, cwd, evidence_dir, label=label, report=True)
    finally:
        if handle is not None:
            if warm:
                touch_warm(handle)
            else:
                stop_service(handle)

    _record_run(session, task, result, report=report, evidence_dir=evidence_dir, settings=settings)
    if bus is not None:
        try:
            bus.publish_task(task.id, "log.appended", {
                "level": "sched",
                "message": f"UI 机审{'通过' if result.exit_code == 0 else '失败'}: {(result.output or '')[:300]}",
            })
        except Exception:
            pass
    if result.exit_code != 0:
        kind = "机审环境问题（非代码问题）" if result.classification == "harness" else "页面断言未过"
        return f"{kind}: {(result.output or '')[:1500]}"
    return None


def _record_run(session, task, result, report: dict | None = None,
                evidence_dir: Path | None = None, settings=None) -> None:
    """落 VerifierRun（feature_id 锚定第一个 feature；无 feature 的任务不落库只发事件）。"""
    from agentflow.storage import models as m

    if report is not None and evidence_dir is not None and settings is not None:

        attach_media(report, evidence_dir, settings.home)



    from agentflow.spec.scope import current_features

    feats = current_features(session, task.id)
    feat = feats[0] if feats else None
    if feat is None:
        return
    detail = None
    if report is not None:
        try:
            detail = json.dumps(report, ensure_ascii=False)[:100_000]
        except Exception:
            detail = None
    run = m.VerifierRun(
        feature_id=int(feat.id), task_id=int(task.id), node_id=None,
        verifier="ui", cmd=(result.cmd or "")[:200], exit_code=result.exit_code,
        duration_ms=int(result.duration_ms or 0),
        output_uri=(result.output or "")[:800],
        classification=result.classification,
        detail=detail,
    )
    if result.exit_code != 0:
        from agentflow.core.evolution import run_fingerprint

        run.fingerprint = run_fingerprint(run.cmd, result.exit_code, result.output)
    session.add(run)
    session.commit()









WARM_TABLE_NAME = "warm_services.json"
_WARM_HOME: Path | None = None


def _set_warm_home(home) -> None:
    global _WARM_HOME
    _WARM_HOME = Path(home)


def _warm_table_path(home=None) -> Path:
    if home is not None:
        base = Path(home)
    elif _WARM_HOME is not None:
        base = _WARM_HOME
    else:
        from agentflow.config import agentflow_home

        base = agentflow_home()
    return base / WARM_TABLE_NAME


def _load_warm_table(home=None) -> list[dict]:
    try:
        raw = json.loads(_warm_table_path(home).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    except Exception:
        return []
    entries = raw.get("entries") if isinstance(raw, dict) else raw
    return [e for e in (entries or []) if isinstance(e, dict) and e.get("pid")]


def _save_warm_table(entries: list[dict], home=None) -> None:
    p = _warm_table_path(home)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(
            json.dumps({"version": 1, "entries": entries}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        os.replace(tmp, p)
    except Exception:
        pass


def _register_warm(handle: ServiceHandle, ui: dict, cwd: Path) -> None:
    from datetime import datetime, timezone

    pid = int(handle.proc.pid)
    entries = [e for e in _load_warm_table() if int(e.get("pid") or 0) != pid]
    entries.append({
        "pid": pid,
        "cwd": str(Path(cwd).resolve()),
        "start_cmd": _normalize_shell_cmd(str(ui.get("start_cmd") or "")),
        "port": int(handle.port),
        "owner_pid": os.getpid(),
        "started_at": datetime.now(timezone.utc).isoformat(),
    })
    _save_warm_table(entries)


def _unregister_warm(pid: int) -> None:
    entries = _load_warm_table()
    keep = [e for e in entries if int(e.get("pid") or 0) != int(pid)]
    if len(keep) != len(entries):
        _save_warm_table(keep)


def _compact(s: str) -> str:
    """匹配用规范化：去空白与引号、统一小写。"""
    return re.sub(r"[\s\"']+", "", s or "").lower()


def _pid_alive(pid: int) -> bool:
    """进程是否存活。**判定不了返回 True**（保守：宁可留着孤儿，也不误杀无关进程）。"""
    pid = int(pid or 0)
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    if sys.platform == "win32":
        try:
            r = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH", "/FO", "CSV"],
                capture_output=True, text=True, timeout=15,
            )
        except Exception:
            return True
        return f'"{pid}"' in (r.stdout or "")
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except OSError:
        return True


def _process_cmdlines(pids: list[int]) -> dict[int, str]:
    """批量取进程命令行。取不到返回空 dict —— 调用方据此**不杀**（保守优先）。"""
    pids = [int(p) for p in pids if int(p or 0) > 0]
    if not pids:
        return {}
    if sys.platform == "win32":
        ids = ",".join(str(p) for p in pids)
        script = (
            f"$ids = @({ids}); "
            "Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | "
            "Where-Object { $ids -contains $_.ProcessId } | "
            "ForEach-Object { $_.ProcessId.ToString() + '|' + [string]$_.CommandLine }"
        )
        try:
            r = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                capture_output=True, text=True, timeout=25,
            )
        except Exception:
            return {}
        out: dict[int, str] = {}
        for line in (r.stdout or "").splitlines():
            pid_s, _, cmd = line.partition("|")
            try:
                out[int(pid_s.strip())] = cmd.strip()
            except ValueError:
                continue
        return out
    out: dict[int, str] = {}
    for p in pids:
        try:
            raw = Path(f"/proc/{p}/cmdline").read_bytes()
            out[p] = raw.replace(b"\0", b" ").decode("utf-8", "replace").strip()
        except Exception:
            continue
    return out


def _kill_tree(pid: int) -> bool:
    pid = int(pid or 0)
    if pid <= 0:
        return False
    try:
        if sys.platform == "win32":
            r = subprocess.run(["taskkill", "/T", "/F", "/PID", str(pid)], capture_output=True, timeout=20)
            return r.returncode == 0
        os.kill(pid, 15)
        return True
    except Exception:
        return False


def sweep_orphan_warm(home: Path | None = None, *, dry_run: bool = False) -> dict:
    """清扫孤儿暖服务：owner 进程已死、但服务进程仍在跑的登记条目。"""
    entries = _load_warm_table(home)
    result: dict = {"scanned": len(entries), "killed": [], "dropped": [], "kept": [], "warnings": [], "dry_run": dry_run}
    if not entries:
        return result

    my_pid = os.getpid()
    cache: dict[int, bool] = {}

    def alive(pid: int) -> bool:
        if pid not in cache:
            cache[pid] = _pid_alive(pid)
        return cache[pid]

    cmdlines = _process_cmdlines([int(e["pid"]) for e in entries])
    kept: list[dict] = []

    for e in entries:
        pid = int(e["pid"])
        owner = int(e.get("owner_pid") or 0)
        if owner == my_pid or (owner and alive(owner)):
            kept.append(e)
            continue
        if not alive(pid):
            result["dropped"].append(e)
            continue
        cmdline = cmdlines.get(pid) or ""
        norm = _normalize_shell_cmd(str(e.get("start_cmd") or "")).strip()
        if not cmdline:
            result["warnings"].append({**e, "reason": "取不到进程命令行，保守不杀（请人工确认）"})
            kept.append(e)
            continue
        if not norm or _compact(norm) not in _compact(cmdline):
            result["warnings"].append({**e, "reason": f"命令行与登记不符（疑似 pid 复用），不杀：{cmdline[:160]}"})
            kept.append(e)
            continue
        if dry_run:
            result["warnings"].append({**e, "reason": f"[dry-run] 将杀：{cmdline[:160]}"})
            kept.append(e)
            continue
        if _kill_tree(pid):
            result["killed"].append({**e, "cmdline": cmdline[:160]})
        else:
            result["warnings"].append({**e, "reason": f"taskkill 失败，保留待人工处理：{cmdline[:160]}"})
            kept.append(e)

    if not dry_run:
        _save_warm_table(kept, home)
    result["kept"] = kept
    return result


def render_sweep_report(res: dict) -> str:
    lines = [f"孤儿暖服务清扫（登记 {res['scanned']} 条{'，dry-run（未执行）' if res['dry_run'] else ''}）"]
    for e in res["killed"]:
        lines.append(f"  已杀 pid={e['pid']} port={e.get('port')} :: {(e.get('cmdline') or '')[:110]}")
    for e in res["dropped"]:
        lines.append(f"  清理死登记 pid={e['pid']}（进程已不在）")
    for e in res["warnings"]:
        lines.append(f"  保留 pid={e['pid']}：{e.get('reason')}")
    if not (res["killed"] or res["dropped"] or res["warnings"]):
        lines.append("  （无孤儿）")
    return "\n".join(lines)
