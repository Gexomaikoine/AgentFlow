"""自举闭环（self-host）：让「平台修改自己」成功落地。"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

from agentflow.storage import models as m
from sqlmodel import select




def self_host_cfg(project) -> dict:
    """项目 config 里的 self_host 块（缺失/损坏一律按"未启用"）。"""
    try:
        cfg = (json.loads(getattr(project, "config", "") or "{}") or {}).get("self_host")
    except Exception:
        cfg = None
    return cfg if isinstance(cfg, dict) else {}


def _hits(paths: list[str], prefixes) -> bool:
    """paths 里是否有文件落在 prefixes（目录前缀，如 "server/"）下。"""
    pres = [str(p).strip().replace("\\", "/").rstrip("/") + "/" for p in (prefixes or []) if str(p).strip()]
    for p in paths:
        np = str(p).strip().replace("\\", "/")
        if any(np.startswith(pre) for pre in pres):
            return True
    return False


def changed_paths(repo_path: str, sha: str) -> list[str]:
    """合并 commit `sha` 相对其首个父提交改动的文件清单（在主 checkout 上查）。"""
    try:
        p = subprocess.run(
            ["git", "-C", str(repo_path), "diff", "--name-only", f"{sha}^", sha],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30,
        )
        return [l.strip() for l in (p.stdout or "").splitlines() if l.strip()]
    except Exception:
        return []


def wt_changed_paths(repo) -> list[str]:
    """合并 worktree 里"工作区 vs HEAD"的改动文件（commit 前的合并结果/解冲突产物）。"""
    try:
        out = repo.repo.git.diff("--name-only", "HEAD") or ""
        return [l.strip() for l in out.splitlines() if l.strip()]
    except Exception:
        return []


def plan_from_paths(paths: list[str], cfg: dict) -> dict:
    """按 diff 文件清单得到合后动作：{"rebuild": bool, "restart": bool}（纯函数，可测）。"""
    return {
        "rebuild": _hits(paths, cfg.get("web_paths")),
        "restart": _hits(paths, cfg.get("server_paths")),
    }


def _run_cmd(cmd: str, cwd: str, timeout: int) -> tuple[bool, str, int]:
    """跑一条命令：走执行面**统一命令链**。"""
    from agentflow.safety.command import run_command

    t0 = time.monotonic()
    try:
        code, out = run_command(cmd, Path(cwd), timeout=timeout)
        return code == 0, (out or "")[-1500:], int((time.monotonic() - t0) * 1000)
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"[:500], int((time.monotonic() - t0) * 1000)


def _ev(bus, task_id: int | None, level: str, message: str) -> None:
    try:
        if task_id:
            bus.publish_task(int(task_id), "log.appended", {"level": level, "message": message})
        else:
            bus.publish_global("log.appended", {"level": level, "message": message})
    except Exception:
        pass




def run_gate_in_merge(session, task, project, repo, bus=None) -> str | None:
    """自举门禁：改动触及 server_paths 时，在合并 worktree 跑平台自身测试套件。"""
    cfg = self_host_cfg(project)
    if not cfg:
        return None
    test_cmd = str(cfg.get("test_cmd") or "").strip()
    if not test_cmd or not (cfg.get("server_paths") or []):
        return None
    paths = wt_changed_paths(repo)
    if not _hits(paths, cfg.get("server_paths")):
        return None


    cmd = test_cmd.replace("{python}", sys.executable)
    timeout = int(cfg.get("test_timeout", 900))
    _ev(bus, task.id, "sched", f"自举门禁：改动触及平台自身代码（{[p for p in paths if _hits([p], cfg.get('server_paths'))][:3]}…），合并门禁追加平台测试套件（预计 2~4 分钟）…")
    ok, out, ms = _run_cmd(cmd, repo.repo_path, timeout)
    if not ok:
        return (
            f"自举门禁未过：平台自身测试套件失败（{ms/1000:.0f}s）——改动会破坏平台，不推进 main。\n"
            f"cmd: {cmd[:220]}\n--- 输出尾部 ---\n{out}"
        )
    _ev(bus, task.id, "sched", f"自举门禁通过：平台测试套件全绿（{ms/1000:.0f}s）· 合并门禁③")
    return None




def post_merge_self_host(engine, bus, project_id: int, repo_path: str,
                         merged_sha: str, task_id: int) -> None:
    """合并落 main 后执行（best-effort：失败响亮记事件，绝不回滚已完成的合并）。"""
    try:
        from sqlmodel import Session

        with Session(engine) as s:
            proj = s.get(m.Project, int(project_id))
        cfg = self_host_cfg(proj) if proj else {}
        if not cfg:
            return
        paths = changed_paths(repo_path, merged_sha) if merged_sha else []
        plan = plan_from_paths(paths, cfg)
        if plan["rebuild"] and str(cfg.get("rebuild_cmd") or "").strip():
            cmd = str(cfg["rebuild_cmd"]).strip()
            ok, out, ms = _run_cmd(cmd, repo_path, int(cfg.get("rebuild_timeout", 600)))
            if ok:
                _ev(bus, task_id, "sched",
                    f"自举重建：控制台产物已重建（{ms/1000:.1f}s）——刷新控制台即可看到新版本")
            else:
                _ev(bus, task_id, "sched",
                    f"自举重建失败（exit≠0）！控制台可能仍是旧产物：{out[-300:]}")
        if plan["restart"] and cfg.get("auto_restart", True):
            request_restart(f"任务#{task_id} 的合并改动触及平台自身 server 代码", task_id)
            _ev(bus, task_id, "sched",
                "自举重启已置位：改动触及平台自身代码，执行面将在**空闲时**自动重启加载新代码（不打断运行中的任务）")
    except Exception as e:
        _ev(bus, task_id, "sched", f"自举钩子异常（不阻塞合并）：{type(e).__name__}: {e}")




_PENDING_LOCK = threading.Lock()
_PENDING: dict | None = None


def request_restart(reason: str, task_id: int | None = None) -> None:
    global _PENDING
    with _PENDING_LOCK:
        _PENDING = {"reason": reason, "task_id": task_id}


def pending_restart() -> dict | None:
    with _PENDING_LOCK:
        return dict(_PENDING) if _PENDING else None


def clear_restart_pending() -> None:
    """测试用：清空挂起态。"""
    global _PENDING
    with _PENDING_LOCK:
        _PENDING = None


def _idle(af) -> bool:
    """执行面是否空闲（可安全重启）：无任务 runner、无 Spec 生成、合并队列无活跃条目。"""
    try:
        if af.runners or af.spec_generating:
            return False
        from sqlmodel import Session

        with Session(af.engine) as s:
            active = s.exec(
                select(m.MergeQueueEntry.id).where(
                    m.MergeQueueEntry.status.in_(["queued", "running", "gated"])
                )
            ).first()
        return active is None
    except Exception:
        return False


async def watch_loop(af) -> None:
    """自举重启看门狗：挂起态 + 空闲 → 执行重启（进程随后退出，由新进程接管端口）。"""
    import asyncio

    while True:
        await asyncio.sleep(3)
        pend = pending_restart()
        if not pend:
            continue
        if not _idle(af):
            continue
        _ev(af.bus, pend.get("task_id"), "sched",
            f"自举重启：执行面空闲，正在重启加载新代码（{pend.get('reason')}）…")
        try:
            port = int((af.settings.data.get("server") or {}).get("port", 8765))
            perform_restart(port)
        except Exception as e:
            _ev(af.bus, None, "sched", f"自举重启拉起失败（{type(e).__name__}: {e}），改为人工重启")
            clear_restart_pending()
            continue
        return



_WATCHER_CODE = r"""
import os, sys, time, urllib.request
port = sys.argv[1]
deadline = time.time() + 30
while time.time() < deadline:
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{port}/api/v1/health", timeout=1).read()
        time.sleep(0.3)  # 旧进程还活着，继续等它退出
    except Exception:
        break  # 端口已释放
time.sleep(0.5)
os.execv(sys.executable, [sys.executable, "-m", "agentflow", "serve"])
"""


def perform_restart(port: int) -> None:
    """拉起看门狗（等端口释放后重启 serve），本进程延迟硬退出。"""
    kwargs: dict = {}
    if sys.platform == "win32":
        kwargs["creationflags"] = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True
    subprocess.Popen(
        [sys.executable, "-c", _WATCHER_CODE, str(port)],
        close_fds=True,
        **kwargs,
    )

    threading.Timer(0.8, lambda: os._exit(0)).start()
