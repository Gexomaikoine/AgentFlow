'''失败语料库 + 闸门阈值校准：把"历史到底怎么坏的"变成可统计的语料。'''

from __future__ import annotations

import json
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from agentflow.config import Settings





@dataclass(frozen=True)
class Category:
    key: str
    label: str
    markers: tuple[str, ...]



CATEGORIES: tuple[Category, ...] = (
    Category("scheduler_error", "调度异常（平台缺陷）", ("调度异常:",)),
    Category("merge_conflict", "解冲突失败", ("解冲突失败",)),
    Category("merge_env", "合并被机审环境挡住", ("合并被机审环境问题挡住",)),
    Category("gate_blocked", "集成校验未过（门禁③）", ("集成校验未过:",)),
    Category("zero_output", "零产出（0 diff）", ("无任何代码改动",)),
    Category("feature_retry_exhausted", "功能重试超限", ("重试超限",)),
    Category("sos_escalation", "SOS 升级人工", ("SOS 升级人工",)),
    Category("budget_hard", "预算硬顶熔断", ("预算硬顶熔断",)),
    Category("budget_soft", "预算软顶告警", ("预算软顶告警",)),
    Category("safety_blocked", "安全档拦截", ("被拦截",)),
    Category("watchdog_timeout", "看门狗超时", ("看门狗超时",)),
)

OTHER = Category("other", "其它/未归类", ())


def classify_reason(reason: str) -> Category:
    """按停机原因原文归类；未知原因归 other（不猜）。"""
    for cat in CATEGORIES:
        if any(mk in reason for mk in cat.markers):
            return cat
    return OTHER





@dataclass
class FailSample:
    task_id: int
    category: str
    label: str
    reason: str
    options: list[str] = field(default_factory=list)


@dataclass
class Corpus:
    created_at: str
    events_dir: str
    tasks_scanned: int
    events_scanned: int
    fails: list[FailSample]
    by_category: dict[str, int]
    distributions: dict[str, list[float]]
    verify: dict[str, int]
    since: str = ""
    ts_range: tuple[str, str] = ("", "")

    def summary(self) -> dict:
        return {
            "created_at": self.created_at,
            "events_dir": self.events_dir,
            "since": self.since or None,
            "ts_range": list(self.ts_range),
            "tasks_scanned": self.tasks_scanned,
            "events_scanned": self.events_scanned,
            "fails_total": len(self.fails),
            "by_category": self.by_category,
            "verify": self.verify,
            "distribution_stats": {k: _stats(v) for k, v in self.distributions.items()},
        }





def _pct(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    xs = sorted(values)
    if len(xs) == 1:
        return float(xs[0])
    pos = q * (len(xs) - 1)
    lo = int(pos)
    hi = min(lo + 1, len(xs) - 1)
    return float(xs[lo] + (xs[hi] - xs[lo]) * (pos - lo))


def _stats(values: list[float]) -> dict:
    if not values:
        return {"count": 0, "p50": 0, "p90": 0, "p99": 0, "max": 0, "mean": 0}
    xs = [float(v) for v in values]
    return {
        "count": len(xs),
        "p50": round(_pct(xs, 0.5), 1),
        "p90": round(_pct(xs, 0.9), 1),
        "p99": round(_pct(xs, 0.99), 1),
        "max": round(max(xs), 1),
        "mean": round(sum(xs) / len(xs), 1),
    }


def _norm_args(raw) -> object:
    """事件流里 args 是 JSON 字符串；代码侧是 dict。解析成 dict 才能对齐指纹。"""
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except (ValueError, TypeError):
            return raw
    return raw if isinstance(raw, dict) else str(raw or "")


def _observation_fp(name: str, args: object, ok: bool, message: str) -> str:
    """对齐 base._StuckDetector.record_observation 的"动作+观察"指纹。"""
    try:
        return json.dumps(
            {"t": name, "a": args, "ok": bool(ok), "m": (message or "")[:160]},
            ensure_ascii=False,
            sort_keys=True,
            default=str,
        )
    except (TypeError, ValueError):
        return f"{name}|{ok}|{(message or '')[:160]}"


def _longest_repeat(fps: list[str]) -> int:
    best = cur = 0
    prev = None
    for fp in fps:
        if fp == prev:
            cur += 1
        else:
            cur = 1
        prev = fp
        best = max(best, cur)
    return best


def _longest_silent(flags: list[bool]) -> int:
    """最长连续"无工具调用"步数（对齐 record_step 的自我对话检测）。"""
    best = cur = 0
    for has_tool in flags:
        cur = 0 if has_tool else cur + 1
        best = max(best, cur)
    return best


def _dispatch_segments(steps: list[int]) -> list[int]:
    """按 step 号回落切分 dispatch，返回每段的步数（段内 max(step)）。"""
    segs: list[int] = []
    prev = 0
    cur: list[int] = []
    for s in steps:
        if s <= prev and cur:
            segs.append(max(cur))
            cur = []
        cur.append(s)
        prev = s
    if cur:
        segs.append(max(cur))
    return segs


def _group_and_max(items: list[tuple[int, object]], fn) -> int:
    """按 dispatch 分组后各组取 fn，再取最大值（per-dispatch 语义的指标）。"""
    groups: dict[int, list] = defaultdict(list)
    for disp, val in items:
        groups[disp].append(val)
    return max((fn(v) for v in groups.values()), default=0)





@dataclass
class _NodeState:
    steps: list[int] = field(default_factory=list)
    silent: list[tuple[int, bool]] = field(default_factory=list)
    pending: list[dict] = field(default_factory=list)
    fps: list[tuple[int, str]] = field(default_factory=list)
    prev_step: int = 0
    dispatch_id: int = 0
    duration_ms: int = 0
    token_in: int = 0
    token_out: int = 0


def _pop_call(pending: list[dict], name: str) -> dict | None:
    """按工具名从待配对队列取调用（缺 result 时不错位）；找不到则 FIFO。"""
    for i, call in enumerate(pending):
        if call.get("name") == name:
            return pending.pop(i)
    return pending.pop(0) if pending else None


def harvest(events_dir: Path, since: str | None = None) -> Corpus:
    """扫事件流，产出失败样本 + 各项观测分布。"""
    created = datetime.now(timezone.utc).isoformat()
    files = sorted(Path(events_dir).glob("task_*.jsonl"))
    if not files:
        raise FileNotFoundError(f"未找到事件流：{Path(events_dir) / 'task_*.jsonl'}")

    fails: list[FailSample] = []
    nodes: dict[tuple[int, int], _NodeState] = defaultdict(_NodeState)
    task_tokens: dict[int, list[float]] = defaultdict(lambda: [0.0, 0.0])
    verify = Counter()
    events_scanned = 0
    tasks_scanned = 0
    ts_min = ts_max = ""

    for path in files:
        tasks_scanned += 1
        try:
            task_id = int(path.stem.split("_", 1)[1])
        except (IndexError, ValueError):
            continue
        with path.open(encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                except ValueError:
                    continue
                ts = str(ev.get("ts") or "")
                if ts:
                    if not ts_min or ts < ts_min:
                        ts_min = ts
                    if ts > ts_max:
                        ts_max = ts
                if since and ts[:10] and ts[:10] < since:
                    continue
                events_scanned += 1
                name = ev.get("event")
                p = ev.get("payload") or {}
                key = (task_id, int(p.get("node_id") or 0))

                if name == "human.required":
                    reason = str(p.get("reason") or "")
                    cat = classify_reason(reason)
                    fails.append(
                        FailSample(
                            task_id=task_id,
                            category=cat.key,
                            label=cat.label,
                            reason=reason,
                            options=[str(o) for o in (p.get("options") or [])],
                        )
                    )
                elif name == "agent.step":
                    st = nodes[key]
                    step_no = int(p.get("step") or 1)
                    if step_no <= st.prev_step:
                        st.dispatch_id += 1
                    st.prev_step = step_no
                    tcs = p.get("tool_calls") or []
                    st.steps.append(step_no)
                    st.silent.append((st.dispatch_id, bool(tcs)))
                    for tc in tcs:
                        if isinstance(tc, dict):
                            st.pending.append(
                                {
                                    "name": str(tc.get("name") or "?"),
                                    "args": _norm_args(tc.get("args")),
                                    "dispatch": st.dispatch_id,
                                }
                            )
                elif name == "tool.result":
                    st = nodes[key]
                    call = _pop_call(st.pending, str(p.get("name") or "?"))
                    if call is None:
                        continue
                    st.fps.append(
                        (call.get("dispatch", 0), _observation_fp(call["name"], call["args"], p.get("ok"), str(p.get("message") or "")))
                    )
                elif name == "node.updated":
                    st = nodes[key]
                    if p.get("status") in ("succeeded", "failed"):
                        st.duration_ms = int(p.get("duration_ms") or 0)
                        st.token_in = int(p.get("token_in") or 0)
                        st.token_out = int(p.get("token_out") or 0)
                elif name == "verify.run":
                    verify["total"] += 1
                    if int(p.get("exit_code") or 0) == 0:
                        verify["passed"] += 1

    for (tid, _nid), st in nodes.items():
        task_tokens[tid][0] += st.token_in
        task_tokens[tid][1] += st.token_out

    segments = [s for st in nodes.values() if st.steps for s in _dispatch_segments(st.steps)]
    distributions = {
        "node_duration_ms": [float(st.duration_ms) for st in nodes.values() if st.duration_ms],
        "dispatch_steps": [float(max(_dispatch_segments(st.steps), default=0)) for st in nodes.values() if st.steps],
        "dispatch_segment_steps": [float(s) for s in segments],
        "node_total_steps": [float(len(st.steps)) for st in nodes.values() if st.steps],
        "stuck_repeat_run": [
            float(_group_and_max(st.fps, _longest_repeat)) for st in nodes.values() if st.fps
        ],
        "silent_run": [
            float(_group_and_max(st.silent, _longest_silent)) for st in nodes.values() if st.silent
        ],
        "task_tokens_in": [v[0] for v in task_tokens.values() if v[0]],
        "task_tokens_out": [v[1] for v in task_tokens.values() if v[1]],
    }
    by_category = Counter(f.category for f in fails)

    return Corpus(
        created_at=created,
        events_dir=str(events_dir),
        tasks_scanned=tasks_scanned,
        events_scanned=events_scanned,
        fails=fails,
        by_category=dict(by_category.most_common()),
        distributions=distributions,
        verify={"total": verify["total"], "passed": verify["passed"], "failed": verify["total"] - verify["passed"]},
        since=since or "",
        ts_range=(ts_min, ts_max),
    )





@dataclass
class ThresholdCheck:
    key: str
    label: str
    current: float
    unit: str
    observed: dict
    verdict: str
    note: str
    caliber: str = ""


def _ceiling(key, label, current, unit, values, caliber, at_limit_note, idle_note, min_n=10) -> ThresholdCheck:
    """上限型阈值：观测触及上限 → at_limit；远离上限 → idle（形同虚设）。"""
    st = _stats(values)
    if st["count"] < min_n:
        return ThresholdCheck(key, label, current, unit, st, "insufficient_data", f"样本 {st['count']} 个，不足以裁决", caliber)
    if st["max"] >= current:
        return ThresholdCheck(key, label, current, unit, st, "at_limit", at_limit_note, caliber)
    if st["max"] <= max(1, current - 2):
        return ThresholdCheck(key, label, current, unit, st, "idle", idle_note, caliber)
    return ThresholdCheck(key, label, current, unit, st, "ok", "观测落在合理区间（未触顶、非闲置）", caliber)


def _incident(key, label, current, unit, hits: int, tasks: int, note) -> ThresholdCheck:
    """事件计数型：只知"撞到上限的实例数"，不知分布（事件流不带该项分布）。"""
    st = {"count": hits, "tasks": tasks}
    return ThresholdCheck(key, label, current, unit, st, "at_limit" if hits else "ok", note)


def calibrate(corpus: Corpus, settings: Settings) -> list[ThresholdCheck]:
    """把当前闸门阈值与实测分布摆在一起，逐项给出裁决（只建议，不改配置）。"""
    sch = settings.data.get("scheduler", {})
    bud = settings.data.get("budget", {})
    sos = settings.data.get("sos", {})
    d = corpus.distributions
    checks: list[ThresholdCheck] = []

    checks.append(
        _ceiling(
            "scheduler.stuck_max_repeat", "轮内连续重复（动作+观察）", int(sch.get("stuck_max_repeat", 3)), "次",
            d.get("stuck_repeat_run", []),
            "对齐 base._StuckDetector.record_observation：工具名+参数+ok+结果前 160 字；"
            "每次 dispatch 计数归零，故按 dispatch 切段后取各段最长",
            "有 dispatch 达到上限（上限在起作用；若这些重复其实是正常轮询，说明该动作该改成后台起+轮询就绪）",
            "观测从未接近上限，阈值形同虚设",
        )
    )
    checks.append(
        _ceiling(
            "scheduler.stuck_max_silent", "轮内连续无工具调用", int(sch.get("stuck_max_silent", 6)), "步",
            d.get("silent_run", []),
            "对齐 base._StuckDetector.record_step：整步无 tool_calls 即计入；同样按 dispatch 切段",
            "有 dispatch 达到上限（自我对话空转确实发生过）",
            "观测从未接近上限，阈值形同虚设",
        )
    )
    limit_steps = int(sch.get("max_steps_per_run", 50))
    seg = d.get("dispatch_segment_steps", [])
    hit = sum(1 for v in seg if v >= limit_steps)
    checks.append(
        _ceiling(
            "scheduler.max_steps_per_run", "单次 dispatch 步数上限", limit_steps, "步",
            d.get("dispatch_steps", []),
            "按 agent.step 的 step 号回落切分 dispatch（对齐 dispatch.max_steps；每节点取其最长段）",
            f"有 dispatch 打到上限（{hit}/{len(seg)} 个段 ≥{limit_steps} 步，会被 StepLimitExhausted 截断，可能截出卡）",
            "观测远低于上限，可下调以更早收敛（省 token）",
        )
    )

    exhausted = [f for f in corpus.fails if f.category == "feature_retry_exhausted"]
    retry_tasks = len({f.task_id for f in exhausted})
    checks.append(
        _incident(
            "budget.max_retries", "功能重试次数上限", int(bud.get("max_retries", 3)), "次",
            len(exhausted), retry_tasks,
            f"事件流不携带 feature.retry_count（只有 DB 有），只能数『重试超限』停机：{len(exhausted)} 次"
            f"（涉及 {retry_tasks} 个任务）"
            + ("——上限确实在起作用" if exhausted else "——该窗口内未撞过上限（阈值可能偏宽）"),
        )
    )

    token_st = _stats(d.get("task_tokens_in", []))
    cur_tokens = float(bud.get("task_max_tokens", 5_000_000))
    if token_st["count"] < 3:
        verdict, note = "insufficient_data", f"样本 {token_st['count']} 个，不足以裁决"
    elif token_st["max"] >= cur_tokens * 0.8:
        verdict, note = "at_limit", f"实测峰值达上限的 {token_st['max'] / cur_tokens:.0%}（历史确有撞顶/接近）"
    elif token_st["max"] <= cur_tokens * 0.4:
        verdict, note = "idle", f"实测峰值仅占上限 {token_st['max'] / cur_tokens:.0%}，阈值偏宽"
    else:
        verdict, note = "ok", f"实测峰值占上限 {token_st['max'] / cur_tokens:.0%}"
    checks.append(
        ThresholdCheck(
            "budget.task_max_tokens", "任务 token 硬顶", cur_tokens, "token", token_st, verdict, note,
            "按 (task,node) 累加 node.updated 的 token_in——仅含带 token 记录的节点，为实际用量下界；"
            "硬顶熔断后可人工确认恢复，故总量可超硬顶",
        )
    )

    per_task_sos = Counter(f.task_id for f in corpus.fails if f.category == "sos_escalation")
    checks.append(
        _incident(
            "sos.task_quota", "每任务熔断决策配额", int(sos.get("task_quota", 2)), "次",
            len(per_task_sos), len(per_task_sos),
            f"按『SOS 升级人工』停机次数反推：{sum(per_task_sos.values())} 次升级、涉及 {len(per_task_sos)} 个任务"
            + (f"（单任务最多 {max(per_task_sos.values())} 次）" if per_task_sos else ""),
        )
    )

    dur_s = [v / 1000 for v in d.get("node_duration_ms", [])]
    st = _stats(dur_s)
    over = sum(1 for v in dur_s if v >= 180)
    checks.append(
        ThresholdCheck(
            "agents.base.long_tail_milestones", "节点长尾里程碑（硬编码 180/420/900s）",
            "180/420/900", "s", st, "reference",
            (
                f"耗时 p50={st['p50']}s p90={st['p90']}s p99={st['p99']}s max={st['max']}s；"
                f"≥180s 的节点占 {over}/{st['count']}（{over / st['count']:.0%}）"
                + f"；Spec 功能超时预算 {int(bud.get('feature_timeout_s', 600))}s——p99 已超，多节点功能必然撞"
            )
            if st["count"] else "无样本",
            "node.updated 终态 duration_ms（节点级；Spec 的 feature_timeout_s 是功能级，此处仅供下界参考）",
        )
    )
    return checks





_VERDICT_MARK = {
    "ok": "OK   ",
    "at_limit": "触顶 ",
    "idle": "闲置 ",
    "insufficient_data": "样本不足",
    "reference": "参考 ",
}


def render_report(corpus: Corpus, checks: list[ThresholdCheck], out_dir: Path | None = None) -> str:
    lines = []
    lines.append("=" * 76)
    lines.append(f"失败语料库 + 阈值校准  ({corpus.created_at})")
    lines.append(
        f"扫描 {corpus.tasks_scanned} 个任务 / {corpus.events_scanned} 条事件"
        f"；停机样本 {len(corpus.fails)} 条；校验 {corpus.verify['passed']}/{corpus.verify['total']} 通过"
    )
    if corpus.ts_range[0]:
        scope = f"事件区间 {corpus.ts_range[0][:10]} ~ {corpus.ts_range[1][:10]}"
        scope += f"（已按 --since {corpus.since} 过滤）" if corpus.since else "（全量）"
        lines.append(scope)
    if not corpus.since:
        lines.append(
            "提示：detector / 阈值 / 模型配置历经多次变更，跨阶段混算会让 stuck、步数类结论失真；"
            "只看近期行为请加 --since（如 --since 2026-09-14 即 stuck detector 上线日）。"
        )
    lines.append("-" * 76)
    lines.append("失败模式分布（按停机次数）:")
    if corpus.by_category:
        for key, n in corpus.by_category.items():
            label = next((c.label for c in CATEGORIES if c.key == key), OTHER.label)
            lines.append(f"  {n:5d}  {label}")
    else:
        lines.append("  （无停机记录）")

    lines.append("-" * 76)
    lines.append("阈值校准（当前值 vs 实测分布）:")
    for c in checks:
        st = c.observed
        if "p50" in st:
            stat = f"n={st['count']} p50={st['p50']} p90={st['p90']} p99={st['p99']} max={st['max']}"
        elif "tasks" in st:
            stat = f"命中 {st['count']} 次 / {st['tasks']} 个任务"
        else:
            stat = f"n={st['count']}"
        cur = c.current
        lines.append(
            f"  [{_VERDICT_MARK.get(c.verdict, c.verdict)}] {c.key}"
            f"  当前={cur}{c.unit}  实测 {stat}"
        )
        lines.append(f"           {c.note}")
        if c.caliber:
            lines.append(f"           口径: {c.caliber}")
    lines.append("-" * 76)
    lines.append("说明：阈值只出建议、不自动生效——改 scheduler/budget/sos 配置由人裁决。")
    if out_dir is not None:
        lines.append(f"语料已写入: {out_dir}")
    lines.append("=" * 76)
    return "\n".join(lines)


def write_corpus(out_root: Path, corpus: Corpus, checks: list[ThresholdCheck]) -> Path:
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    out = Path(out_root) / ts
    out.mkdir(parents=True, exist_ok=True)
    (out / "corpus.json").write_text(
        json.dumps(
            {
                **corpus.summary(),
                "fails": [asdict(f) for f in corpus.fails],
                "distributions": corpus.distributions,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    (out / "calibration.json").write_text(
        json.dumps(
            {"created_at": corpus.created_at, "checks": [asdict(c) for c in checks]},
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return out


def run_corpus(
    events_dir: str | None = None,
    out_dir: str | None = None,
    settings: Settings | None = None,
    since: str | None = None,
) -> dict:
    """采集 + 校准 + 落盘 + 打印；返回语料摘要（供测试/调用方断言）。"""
    import sys

    settings = settings or Settings.load()
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except (ValueError, OSError):
                pass

    events = Path(events_dir) if events_dir else settings.home / "events"
    corpus = harvest(events, since=since)
    checks = calibrate(corpus, settings)
    out = write_corpus(Path(out_dir) if out_dir else settings.home / "replay_corpus", corpus, checks)
    print(render_report(corpus, checks, out))
    return {"corpus": corpus.summary(), "checks": [asdict(c) for c in checks], "out_dir": str(out)}
