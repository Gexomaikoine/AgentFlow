"""修复 Agent（fixer）：独立定位根因 + 最小单文件修复（P4 独立化，不复用 developer 提示词）。"""

from __future__ import annotations

from agentflow.storage import models as m


def build_fixer_system(feature: m.Feature) -> str:
    """fixer 独立 system：定位根因 → 最小单文件修复，杜绝「再开发一次」。"""
    return (
        "你是修复 agent。你的职责：拿到校验失败上下文后，**定位根因、做最小修复**。\n"
        "原则：\n"
        "1. 先 read_file 读失败涉及的文件，弄清哪里错了，再动手。\n"
        "2. 只改真正导致失败的部分，最小化 diff；不要顺手重构、不要扩写功能、不要照搬 Spec 重写实现。\n"
        "3. 修完用校验命令自检（run_cmd 跑失败的那条），通过后再 done。\n"
        "3a. 若失败命令是**关键词存在性/缺席性**检查（`Select-String -Pattern \"xxx\"`、`grep xxx`）："
        "先全文搜这个关键词（含注释、文档字符串）——**注释里留下的字面量会让缺席断言假失败**，"
        "「实现已改对、只是注释里还写着旧词」是最常见的一类假失败（：flex-wrap 已移出 "
        "className，注释却写着「不再 flex-wrap 折行」→ fixer 反复空转）。修法是把注释里的该词换成同义描述。\n"
        "4. 写文件仅限本功能写集（file_scope），通过工具完成，禁止臆造。\n"
        "5. 调用 done 前，先输出结构化修复报告（供系统解析归档，格式严格如下）：\n"
        "[FIX_REPORT]\n"
        "根因: <一句话>\n"
        "改动: <文件:行 简述>\n"
        "置信度: high|medium|low\n"
        "[/FIX_REPORT]\n"
        f"当前功能 seq={feature.seq}「{feature.title}」，写集: {feature.file_scope}\n"
        "你的所有自然语言输出使用简体中文；代码、命令、文件路径、标识符保持原文。"
    )


def build_fixer_prompt(
    task: m.Task,
    feature: m.Feature,
    spec_yaml: str,
    project: m.Project,
    failure_context: str,
    lead_hint: str = "",
) -> str:
    """构造 fixer 提示：明确失败校验器输出 + 要求最小修复，不复用 developer 的 Spec 实现提示。"""
    parts = [
        f"任务标题: {task.title}\n"
        f"PROJECT_PATH: {project.repo_path}\n"
        f"当前功能 seq={feature.seq}「{feature.title}」\n\n"
        "你的单一目标：让以下校验通过。**定位根因并做最小修复**，不做无关改动。\n\n"
        "## 校验失败上下文\n"
        f"{failure_context}\n"
    ]
    if lead_hint:
        parts.append(f"\n## Lead 重策略提示（上轮思路已判无效，请换思路）\n{lead_hint[:1500]}\n")
    parts.append(
        "\n请读取相关文件定位根因，用 write_file/edit_file 做最小修改，"
        "**改源码一律走 edit_file/write_file，不要用 shell 文本往返改文件**"
        "（PowerShell 的 `(Get-Content <文件>) … | Set-Content <同名文件>`、`sed -i`、`cat > 文件` 等都禁止）："
        "PS 5.1 的 Get-Content 默认按 ANSI(GBK) 读、Set-Content 按 utf8 写，中文注释会变乱码，"
        "且这类命令绕过写集租约；确需 shell 处理文本时两端都显式 `-Encoding utf8`。也别 `cd` 到主 checkout 改文件——"
        "工作根只认 PROJECT_PATH（worktree），改主 checkout 会弄脏用户仓库并让后续建任务被 FR6 拒绝。"
        "运行失败的那条校验命令确认通过后调用 done。"
        "**不要用递归删除命令清缓存**（`rm -rf`/`rmdir /s`/`Remove-Item -Recurse -Force` 命中 deny 档 → 任务停机人工）；"
        "要清 `.next`/`out`/`__pycache__` 就改名挪到 `.agentflow_tmp/trash-<时间戳>/`，或用项目自带自救脚本。"
    )
    return "".join(parts)