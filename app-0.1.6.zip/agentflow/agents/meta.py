"""meta agent：失败聚类上下文 → 结构化增强提案（纯文本，无工具、不改代码）。"""

from __future__ import annotations

import re

_KIND_MAP = {"规则": "rule", "verifier": "verifier", "spec": "spec_template"}
_EVIDENCE_RE = re.compile(r"[（(]证据[:：]\s*(.+?)[)）]\s*$")
_EXPECT_RE = re.compile(r"[（(]预期[:：]\s*(.+?)[)）]")


def build_meta_system() -> str:
    return (
        "你是 meta agent（自迭代识别）。系统已由代码把失败校验记录按指纹聚类，"
        "你只负责分析这些聚类证据，指出「本项目 agent 流程可以补上的结构性防线」。\n\n"
        "## 输出要求\n"
        "1. 用简体中文输出 1~3 条提案；每条一行，格式严格如下：\n"
        "   `[提案-<类型>] 标题：具体做法（证据: #run_id1,#run_id2）`\n"
        "   其中 <类型> 只能取：规则 | verifier | spec。\n"
        "   - 规则：一句话行为约束（写进项目规则强制遵守），做法=规则原文本身。\n"
        "   - verifier：一条可判定的验收命令，做法=命令完整原文（单独一条命令，非破坏性，"
        "     能在干净代码树上通过 exit 0；如 lint/单测/静态检查类）。不要写解释文字。\n"
        "   - spec：Spec 模板/不变量补充（如某类功能必须声明某字段），做法=不变量原文。\n"
        "2. 每条提案必须在结尾括号里引用它依据的失败证据（证据: #12,#13 —— run_id 列表，"
        "   来自下方聚类的 run ids）。无证据引用的提案会被代码丢弃。\n"
        "3. 每条提案在证据括号前加一个预估括号：`（预期: <量化预估>）`，"
        "   估算该提案生效后可改善的核心指标（如「重试率降~30%」「同类校验失败归零」）。"
        "   预估会展示在自愈页签并与回放验证的实际提升对照，请基于证据合理估算。\n"
        "4. 聚焦防复发：同类失败 ≥2 次说明现有验收防线有空洞，提案应针对这个空洞；"
        "   不要与「现有规则/验收命令清单」重复。\n"
        "5. 每条建议必须关联观察到的具体失败证据（命令/输出特征），不空谈。\n"
        "6. 不输出代码块，不重复失败描述本身，不输出其他多余文字。"
    )


def build_meta_prompt(task, clusters: list[dict], ctx: dict | None = None) -> str:
    """clusters 来自 evolution.cluster_failures（代码聚类，含 run ids 证据链）。"""
    lines = [
        f"## 任务信息\n任务 #{task.id}「{task.title}」（当前状态 {task.status.value}）\n",
        "## 失败聚类（代码按指纹聚合；同指纹 ≥2 次才列出）",
    ]
    for i, c in enumerate(clusters[:5], 1):
        lines.append(
            f"### 聚类{i}（共 {c['count']} 次，跨任务 {c['task_ids'][:5]}）\n"
            f"- run ids: {','.join(str(r) for r in c['run_ids'][:8])}\n"
            f"- 命令: `{(c['sample_cmd'] or '')[:200]}`\n"
            f"- 退出码: {c['sample_exit']}\n"
            f"- 输出尾部: {(c['sample_output'] or '')[:300]}"
        )
    if ctx:
        if ctx.get("existing_rules"):
            lines.append("## 现有项目规则（勿重复）\n" + "\n".join(f"- {r[:150]}" for r in ctx["existing_rules"][:10]))
        if ctx.get("existing_verifier_cmds"):
            lines.append("## 现有验收命令（勿重复）\n" + "\n".join(f"- {c[:150]}" for c in ctx["existing_verifier_cmds"][:10]))
        sd = ctx.get("stall_digest") or {}
        if sd.get("scanned"):
            lines.append(
                f"## 本项目近期停机模式画像（语料库确定性分类，扫 {sd.get('tasks')} 个任务 / "
                f"{sd.get('scanned')} 次停机）\n"
                + "\n".join(f"- {k}: {v} 次" for k, v in (sd.get("by_category") or {}).items())
                + (("\n样本：\n" + "\n".join(f"- {s}" for s in sd.get("samples") or [])) if sd.get("samples") else "")
                + "\n（若某类停机反复出现且属流程/验收空洞，可据此提规则/spec 类提案；"
                  "平台缺陷类（调度异常）不要用规则掩盖，只需在提案里点明。测试类断言收口的提案仍须引用上方 run id 证据。）"
            )
    lines.append("\n请分析以上失败聚类，输出 1~3 条提案（严格按格式，引用证据 run id）。")
    return "\n".join(lines)


def parse_proposals(advice: str) -> list[dict]:
    """解析 meta 输出为结构化提案（判定权在代码解析，LLM 只产文本）。"""
    out: list[dict] = []
    for line in (advice or "").splitlines():
        line = line.strip()
        match = re.match(r"`?\[提案-(规则|verifier|spec)\]\s*(.+)", line)
        if not match:
            continue
        tag, rest = match.group(1), match.group(2)
        expected_gain = ""
        exp_m = _EXPECT_RE.search(rest)
        if exp_m:
            expected_gain = exp_m.group(1).strip()[:200]
            rest = (rest[:exp_m.start()] + rest[exp_m.end():]).strip()
        evidence_ids: list[int] = []
        ev_m = _EVIDENCE_RE.search(rest)
        if ev_m:
            for tok in re.split(r"[,，\s]+", ev_m.group(1)):
                tok = tok.strip().lstrip("#")
                if tok.isdigit():
                    evidence_ids.append(int(tok))
            rest = rest[:ev_m.start()].strip()
        title, _, detail = rest.partition("：")
        detail = (detail or "").strip()
        if not detail:
            detail = title.strip()
        if not detail or not evidence_ids:
            continue
        kind = _KIND_MAP.get(tag.strip(), "rule")
        payload = {"cmd": detail} if kind == "verifier" else {"content": detail}
        out.append({
            "kind": kind,
            "title": (title or detail)[:120].strip(),
            "detail": detail[:1000],
            "expected_gain": expected_gain,
            "evidence_ids": evidence_ids,
            "payload": payload,
        })
    return out
