"""Web 工具：给 agent 联网能力（web_fetch / web_search）。"""

from __future__ import annotations

import html
import ipaddress
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

_UA = "AgentFlow/1.0 (+web-fetch)"
_SCRIPT_STYLE = re.compile(r"<script[\s\S]*?</script>|<style[\s\S]*?</style>|<!--[\s\S]*?-->", re.I)
_TAG = re.compile(r"<[^>]+>")
_BLANK = re.compile(r"\n{3,}")
_SPACES = re.compile(r"[ \t\u00a0]{2,}")


_METADATA_HOSTS = ("169.254.169.254", "metadata.google.internal", "metadata.goog")


def _host_of(url: str) -> str | None:
    try:
        p = urllib.parse.urlsplit(url)
    except ValueError:
        return None
    if p.scheme not in ("http", "https"):
        return None
    return (p.hostname or "").lower() or None


def _is_private_host(host: str) -> bool:
    """内网 / 回环 / 链路本地 / 元数据地址判定（含 IPv6）。"""
    if host in _METADATA_HOSTS:
        return True
    if host in ("localhost",) or host.endswith(".localhost") or host.endswith(".local"):
        return True
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast


def _domain_allowed(host: str, trusted: list[str]) -> bool:
    """与 safety/command 同一口径：等于信任域或以 `.<信任域>` 结尾。"""
    h = host.lower().rstrip(".")
    for d in trusted:
        d = str(d).strip().lower().lstrip(".")
        if not d:
            continue
        if h == d or h.endswith("." + d):
            return True
    return False


def classify_url(url: str, trusted: list[str]) -> tuple[bool, str]:
    """URL 准入判定。返回 (ok, reason)。"""
    host = _host_of(url)
    if host is None:
        return False, "只允许 http/https URL（且需是完整 URL）"
    if _is_private_host(host):
        return False, f"拒绝访问内网/元数据地址（SSRF 防护）: {host}"
    if not _domain_allowed(host, trusted):
        return False, (
            f"域名 {host} 不在信任名单：请在 设置→安全 的「可信网络域名」中加入它"
            "（与 curl/wget 共用同一份名单），或改用 run_cmd 走审批通道。"
        )
    return True, ""


def html_to_text(raw: str) -> str:
    """HTML → 可读文本：去脚本/样式/注释与标签，解实体，压缩空白。非 HTML 原样返回。"""
    if "<" not in raw:
        return raw
    t = _SCRIPT_STYLE.sub(" ", raw)
    t = re.sub(r"<(br|/p|/div|/li|/tr|/h[1-6])[^>]*>", "\n", t, flags=re.I)
    t = _TAG.sub(" ", t)
    t = html.unescape(t)
    t = _SPACES.sub(" ", t)
    t = "\n".join(line.strip() for line in t.splitlines())
    return _BLANK.sub("\n\n", t).strip()


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """禁用自动跟随：重定向要逐跳校验域名（否则白名单域 302 到内网即绕过 SSRF 防护）。"""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_OPENER = urllib.request.build_opener(_NoRedirect)


def _open(url: str, timeout: float, max_bytes: int, trusted: list[str], max_redirects: int):
    """取 URL（手动处理重定向，每跳校验）。返回 (final_url, bytes, content_type)。"""
    for _ in range(max(0, max_redirects) + 1):
        ok, reason = classify_url(url, trusted)
        if not ok:
            raise PermissionError(reason)
        req = urllib.request.Request(url, headers={"User-Agent": _UA, "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"})
        try:
            resp = _OPENER.open(req, timeout=timeout)
        except urllib.error.HTTPError as e:
            if e.code in (301, 302, 303, 307, 308):
                nxt = e.headers.get("Location") or ""
                if not nxt:
                    raise
                url = urllib.parse.urljoin(url, nxt)
                continue
            raise
        with resp:
            ctype = resp.headers.get_content_type()
            raw = resp.read(max_bytes)
            return resp.geturl(), raw, ctype
    raise PermissionError(f"重定向超过 {max_redirects} 跳，已中止")


def web_fetch(url: str, trusted: list[str], *, timeout: float = 20.0, max_chars: int = 20000, max_redirects: int = 3) -> tuple[bool, str]:
    """抓取 URL 正文并转文本。返回 (ok, text_or_error)。"""
    url = (url or "").strip()
    if not url:
        return False, "web_fetch 需要 url 参数"
    if "://" not in url:
        url = "https://" + url
    try:
        final_url, raw, ctype = _open(url, timeout, max_bytes=max(4096, max_chars * 4), trusted=trusted, max_redirects=max_redirects)
    except PermissionError as e:
        return False, f"[被拒] {e}"
    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code}：{url}（{e.reason}）"
    except Exception as e:
        return False, f"抓取失败（{type(e).__name__}: {e}）：{url}"

    text = raw.decode("utf-8", errors="replace")
    if "html" in (ctype or ""):
        text = html_to_text(text)
    truncated = len(text) > max_chars
    if truncated:
        text = text[:max_chars] + f"\n\n…[已截断，原文超出 {max_chars} 字符]"
    head = f"# {final_url}\n" if final_url != url else ""
    return True, head + text


def web_search(query: str, cfg: dict) -> tuple[bool, str]:
    """调用配置的搜索端点（Tavily 兼容格式：POST {"query": q} → {"results":[{title,url,content}]}）。"""
    query = (query or "").strip()
    if not query:
        return False, "web_search 需要 query 参数"
    endpoint = str(cfg.get("search_url") or "").strip()
    if not endpoint:
        return False, "未配置搜索端点（web.search_url）——本工具本不该出现在工具集里，请检查配置"
    key_env = str(cfg.get("search_key_env") or "").strip()
    payload: dict = {"query": query, "max_results": 5}
    headers = {"Content-Type": "application/json", "User-Agent": _UA}
    if key_env:
        key = os.environ.get(key_env, "").strip()
        if not key:
            return False, f"搜索所需 Key 未配置：请在 ~/.agentflow/.env 设置 {key_env}"
        payload["api_key"] = key
    try:
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(endpoint, data=body, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=float(cfg.get("timeout_s") or 20)) as r:
            data = json.loads(r.read(400_000).decode("utf-8", errors="replace"))
    except Exception as e:
        return False, f"搜索失败（{type(e).__name__}: {e}）"
    results = data.get("results") or data.get("data") or []
    if not isinstance(results, list) or not results:
        return False, f"搜索无结果或响应格式不符（期望 results[]）：{query}"
    lines = [f"搜索「{query}」结果（{len(results)} 条）："]
    for i, item in enumerate(results[:5], 1):
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or "").strip()
        link = str(item.get("url") or item.get("link") or "").strip()
        snippet = str(item.get("content") or item.get("snippet") or "").strip().replace("\n", " ")
        lines.append(f"{i}. {title}\n   {link}\n   {snippet[:300]}")
    return True, "\n".join(lines)
