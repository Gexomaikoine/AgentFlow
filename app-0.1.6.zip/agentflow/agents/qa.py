"""QA Agent（质量验证，原 verifier 升级）：验证执行 + 证据收集 + 失败归因（非判定者）。"""

from __future__ import annotations

import json
import re

from agentflow.llm.gateway import LLMGateway
from agentflow.storage import models as m


def build_qa_system() -> str:
    return (
        "你是 QA（质量验证）agent。职责：运行/解读验证命令与测试构建，收集并整理验证证据，"
        "对失败做根因归因并给出修复建议。\n"
        "原则：\n"
        "1. **不判定通过/失败**：判定权在代码（exit code + 调度器），你只做证据整理与归因解释。\n"
        "2. **输出结构（三段式，供系统解析复用）**：\n"
        "   根因: <一句话，最可能的失败根因>\n"
        "   类别: <env|semantic|command|transient 之一>\n"
        "   建议: <给 fixer 的具体修复建议>\n"
        "3. **只读**：可读失败输出与相关文件，禁止修改代码（修复交给 fixer）。\n"
        "4. 你的所有自然语言输出使用简体中文；命令、报错原文、文件路径保持原样引用。\n"
        "5. **直接给结论，不要输出工具调用/函数调用格式**（本环节没有工具可用）："
        "不要写 `<function_calls>` / `<invoke>` 之类的标记，也不要假装执行命令；"
        "信息不足时就在『建议』里说明需要看什么，而不是输出未执行的调用。\n"
        "6. **UI 机审失败必须逐步读结构化详情**：这类详情含每一步的 op / target（选择器）/ ok / error，"
        "要据此定位到**具体哪一步的哪个选择器**失败，并区分三种常见成因——"
        "① 元素只在某个页签/弹层下渲染而检查声明漏了导航动作；"
        "② 实现真的没渲染该元素；③ 选择器与该 DOM 结构不符。"
        "**不要只凭截图路径推测**（截图你读不到内容），也不要把它笼统归成『页面整体未渲染』。\n"
        "7. **页面可见控件清单是「当前状态快照」，不是「实现清单」**：清单里有页签/筛选类控件而目标"
        "控件不在其中时，默认按 ①（漏了导航动作）判定——清单只说明「在这一步的页面状态下看不见它」，"
        "**不能据此断定控件未实现**。除非需求明确要求「不依赖任何导航就应在页面上渲染」，"
        "否则不要把这类失败归因为实现缺陷（：功能标题里的『常驻渲染』指「切换筛选页签后"
        "仍不消失」，QA 误读成「任何状态下都应出现」，把漏导航动作的声明缺陷判成了实现缺陷）。\n"
        "8. **类别映射（硬规则，：同一份证据 4 次归因 3 种类别，声明缺陷被误判 semantic "
        "把自愈引向错误的修复通道）**：成因为「① 漏了导航动作」或「② 选择器语义错误」（例如用动态"
        "状态选择器 `button[aria-pressed=false]` 同时当点击目标与断言目标——点击后选择器重新命中"
        "另一个元素，断言必假；或选择器与 DOM 结构不符）时，**类别一律写 `command`**——这是检查声明"
        "缺陷，修声明不修实现；只有「实现真的没渲染该元素」（需求明确要求且页面确实没有）才写 "
        "`semantic`。"
    )


def qa_attribute_failure(
    gateway: LLMGateway,
    feature: m.Feature,
    runs: list[m.VerifierRun],
    stage: str | None = None,
    engine=None,
    want_fix_declaration: bool = False,
) -> str:
    """QA 失败归因（增强节点，不判定）：读失败校验输出，产出根因判断 + 修复建议。"""
    failed = [r for r in runs if r.exit_code != 0]
    if not failed:
        return ""
    prompt_lines = [
        f"功能: {feature.title}",
        f"验证阶段: {stage or '全部'}",
        "失败校验器输出:",
    ]
    for r in failed[:3]:
        seg = f"--- {r.verifier} (exit {r.exit_code}) ---\n{r.output_uri[:1500]}"




        detail = (getattr(r, "detail", None) or "").strip()
        if detail:
            seg += f"\n结构化失败详情（逐步）: {detail[:2500]}"
        prompt_lines.append(seg)
    system = build_qa_system()
    if want_fix_declaration:
        system += (
            "\n\n## 本次额外要求：直接产出修正声明（系统会优先采用，跳过转手重写）\n"
            "若你的归因是声明缺陷（类别 command），请在『建议』之后追加一段**完整可执行的修正声明**，"
            "格式严格如下（json 围栏内是完整声明对象）：\n"
            "修正声明:\n```json\n{\"start_cmd\": \"...\", \"port\": \"auto\", \"pages\": [...]}\n```\n"
            "要求：① 结构合法——字符串类键（click/wait 的选择器形态/screenshot/assert_visible/"
            "assert_hidden/expect_selector/expect_url）的值必须是字符串，多个选择器拆成多条动作；"
            "wait 可为数字毫秒或选择器字符串；② 断言某元素前**必须先有导航动作**到达承载它的视图"
            "（如先 click 对应页签）；③ click/断言的 selector 必须**稳定**（data-testid 或文案），"
            "不要用会随交互变化的选择器（如 aria-pressed=false 这类状态相关选择器）；"
            "④ 端口仍写 \"auto\"，不要写死端口号。若归因不是声明缺陷（如 semantic），不要输出修正声明。"
        )
    result = gateway.generate("qa", "\n".join(prompt_lines), system)
    if engine is not None:
        from agentflow.core.llm_usage import record_extra

        record_extra(engine, feature.task_id, "qa", "diagnose", f"qa_attribution_{stage or 'light'}", result)
    return result.text


_FIX_DECL_RE = re.compile(r"修正声明[:：]?\s*```json\s*(\{.*?\})\s*```", re.S)


def parse_fixed_declaration(qa_report: str) -> dict | None:
    """从 QA 归因文本解析修正后的 ui 声明（`修正声明:` + ```json 块）。无/坏 → None。"""
    m = _FIX_DECL_RE.search(qa_report or "")
    if not m:
        return None
    try:
        obj = json.loads(m.group(1))
    except json.JSONDecodeError:
        return None
    return obj if isinstance(obj, dict) else None


def apply_fixed_declaration(session, feature: m.Feature, decl: dict) -> str | None:
    """校验 QA 修正声明并写回 feature.verify_commands（替换其中的 ui 项）。返回错误文本或 None。"""
    import json as _json

    from agentflow.verifiers import probe
    from agentflow.verifiers.strength import gate_ui_rewrite
    from agentflow.verifiers.ui_dsl import declaration_problems

    problems = declaration_problems(decl)
    if problems:
        return "修正声明结构非法: " + "；".join(problems[:3])


    weak = gate_ui_rewrite(feature.verify_commands, decl)
    if weak:
        return "修正声明弱化验收: " + weak
    try:
        cmds = _json.loads(feature.verify_commands or "[]")
    except (json.JSONDecodeError, TypeError):
        return "feature.verify_commands 解析失败"
    if not isinstance(cmds, list):
        return "feature.verify_commands 不是列表"
    hit = False
    for c in cmds:
        if isinstance(c, dict) and c.get("verifier") == "ui":
            c["cmd"] = _json.dumps(decl, ensure_ascii=False)
            hit = True
    if not hit:
        return "feature 无 ui 验证项可替换"
    ok, err = probe.check_command("ui", _json.dumps(decl, ensure_ascii=False), None)
    if not ok:
        return f"修正声明可执行性预检未过: {err[:200]}"
    feature.verify_commands = _json.dumps(cmds, ensure_ascii=False)
    session.add(feature)
    session.commit()
    return None
