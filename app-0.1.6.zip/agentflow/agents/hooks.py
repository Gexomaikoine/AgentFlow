"""确定性 Hooks（P1）：在 agent 生命周期的关键点做**代码级**检查。"""

from __future__ import annotations

import re
from dataclasses import dataclass




_SOURCE_PATH = re.compile(
    r"[\w./\\-]+\.(tsx?|jsx?|py|css|json|md|toml|ya?ml|html|vue)\b", re.IGNORECASE
)
_PS_READ = re.compile(r"\b(Get-Content)\b", re.IGNORECASE)
_PS_WRITE = re.compile(r"\b(Set-Content|Out-File|Add-Content)\b", re.IGNORECASE)


_SLEEP = re.compile(
    r"Start-Sleep\s+(?:-Seconds\s+)?(\d+)|timeout\s+/t\s+(\d+)|(?:^|[^\w])sleep\s+(\d+)",
    re.IGNORECASE,
)
_SLEEP_MIN_S = 10


_RECURSIVE_DEL = re.compile(r"(rmdir\s+/s|rd\s+/s|rm\s+-rf|Remove-Item[^\n]*-Recurse)", re.IGNORECASE)
_CACHE_DIR = re.compile(r"(node_modules|\.next|dist|\.venv|__pycache__|\.pytest_cache)", re.IGNORECASE)


def _check_ps_source_roundtrip(cmd: str) -> str:
    if _PS_READ.search(cmd) and _PS_WRITE.search(cmd) and _SOURCE_PATH.search(cmd):
        return (
            "PowerShell 管道往返改源码会破坏文件编码。"
            "请改用 edit_file 做定点替换（支持 edits 数组一次多处/多文件）。"
        )
    return ""


def _check_long_sleep(cmd: str) -> str:
    for m in _SLEEP.finditer(cmd):
        secs = next((int(g) for g in m.groups() if g), 0)
        if secs >= _SLEEP_MIN_S:
            return (
                f"禁长睡等就绪。"
                "常驻命令请后台起 + 轮询就绪（如后台启动后用短命令反复探测端口/健康接口）。"
            )
    return ""


def _check_recursive_cache_delete(cmd: str) -> str:
    if _RECURSIVE_DEL.search(cmd) and _CACHE_DIR.search(cmd):
        return (
            "递归删除缓存目录属高危操作。"
            "清缓存/重建请走项目自带脚本（如 npm run build 会自行处理），或请人工执行。"
        )
    return ""



_BUILTIN_CHECKS: tuple[tuple[str, object], ...] = (
    ("ps_source_roundtrip", _check_ps_source_roundtrip),
    ("long_sleep", _check_long_sleep),
    ("recursive_cache_delete", _check_recursive_cache_delete),
)





@dataclass
class HookVerdict:
    action: str = "allow"
    reason: str = ""
    replacement: dict | None = None
    rule: str = ""


def _configured_rules(settings) -> list[dict]:
    """读取 settings.hooks.rules（可配置加固规则）；非法项忽略并告警，不影响任务启动。"""
    raw = ((settings.data.get("hooks") or {}).get("rules")) or []
    out: list[dict] = []
    for r in raw:
        if not isinstance(r, dict):
            continue
        pat = str(r.get("pattern") or "")
        if not pat:
            continue
        try:
            rx = re.compile(pat)
        except re.error as e:
            print(f"[hooks] 规则正则非法已忽略: {pat!r}（{e}）")
            continue
        act = str(r.get("action") or "block").strip().lower()
        if act not in ("block", "rewrite"):
            continue
        out.append({
            "tool": str(r.get("tool") or "run_cmd").strip(),
            "rx": rx,
            "action": act,
            "message": str(r.get("message") or "").strip(),
            "replacement": str(r.get("replacement") or ""),
        })
    return out


def pre_tool_use(name: str, args: dict, settings) -> HookVerdict:
    """工具执行前的确定性守卫（内置规则 + settings.hooks.rules 配置规则）。"""
    if name != "run_cmd":
        return HookVerdict()
    cmd = str((args or {}).get("cmd") or "")
    if not cmd.strip():
        return HookVerdict()

    for rule_id, check in _BUILTIN_CHECKS:
        reason = check(cmd)
        if reason:
            return HookVerdict(action="block", reason=reason, rule=rule_id)

    for r in _configured_rules(settings):
        if r["tool"] != name or not r["rx"].search(cmd):
            continue
        msg = r["message"] or f"命中项目自定义守卫规则（{r['rx'].pattern[:60]}）"
        if r["action"] == "rewrite" and r["replacement"]:
            return HookVerdict(
                action="rewrite", reason=msg, replacement={"cmd": r["rx"].sub(r["replacement"], cmd)}, rule="config"
            )
        return HookVerdict(action="block", reason=msg, rule="config")
    return HookVerdict()
