"""Lead Agent（前台统筹，原 planner 并入）：用户唯一对话窗口 + Spec 拆解 + 统筹。"""

from __future__ import annotations

import json
import re
from pathlib import Path

from agentflow.config import detect_exec_env
from agentflow.llm.gateway import LLMGateway
from agentflow.spec.schema import SpecDoc, VerifyCommand, dump_spec, parse_spec
from agentflow.storage import models as m
from agentflow.verifiers.ui_dsl import GRAMMAR_HINT as _UI_GRAMMAR_HINT
from sqlmodel import Session, select

_YAML_RE = re.compile(r"```(?:yaml|yml)?\s*(.*?)```", re.S)


def _verify_cmd_rules(shell: str) -> str:
    """verify_commands 硬约束（Spec 生成与 B-2 重规划共用一处，防两份提示词漂移）。"""
    from agentflow.verifiers.registry import available



    is_bash = (shell or "").strip().lower() == "bash"
    if is_bash:
        ex_http = ('if [ "$(curl -s -o /dev/null -w \'%{http_code}\' http://localhost:3000)" != "200" ]; '
                   "then exit 1; fi")
        ex_exit = 'if [ "$ok" != "true" ]; then exit 1; fi'
        ex_grep = ("if ! grep -q '<关键词>' <文件>; then "
                   "echo 'MISSING-KEYWORD <关键词> in <文件>'; exit 1; fi")
        ex_pattern = "grep -q 'data-testid=\"x\"'"
        ex_start = "cd site && npm run dev -- -p {port}"
    else:
        ex_http = "if ((Invoke-WebRequest http://localhost:3000 -UseBasicParsing).StatusCode -ne 200) { exit 1 }"
        ex_exit = "if (-not $ok) { exit 1 }"
        ex_grep = ("if (-not (Select-String -Path <文件> -Pattern '<关键词>' -Quiet)) "
                   "{ Write-Output 'MISSING-KEYWORD <关键词> in <文件>'; exit 1 }")
        ex_pattern = "-Pattern 'data-testid=\"x\"'"
        ex_start = "cd /d site && npm run dev -- -p {port}"

    return (
        f"verify_commands 硬约束（违反会在 Spec 期被探针拒绝并要求重写）：\n"
        f"1. cmd 必须是能在 {shell} 里直接执行的真命令，**严禁写自然语言或测试步骤描述**。\n"
        f"   反例: cmd: 集成浏览器访问 http://localhost:3000，断言页面加载成功\n"
        f"   正例: cmd: {ex_http}\n"
        f"2. verifier 是展示用标签（存量用过 {', '.join(available())} 等），"
        f"其中 **ui 是唯一有真实实现的浏览器机审校验器**，其余名字一律按 shell 命令执行。\n"
        f"3. 需要真实浏览器 UI 自测（不得仅凭进程存活/构建通过判定）时用 verifier: ui，"
        f"cmd 填 JSON 检查声明而非描述，由 Playwright 执行并断言 console 错误/HTTP 状态码/选择器/动作：\n"
        f"""   cmd: '{{"start_cmd":"{ex_start}","port":"auto","pages":[{{"url":"/","selectors":["h1"]}}]}}'\n"""
        f"   **端口交给 AgentFlow 自管**：port 写 \"auto\"（或省略），start_cmd 用 {{port}} 占位符"
        f"（或引用环境变量 AF_UI_PORT）。AgentFlow 每次机审都会分配一个空闲端口并替换占位符，"
        f"**严禁写死端口号**。\n"
        f"   start_cmd 直接写 shell 命令行即可（AgentFlow 已用 shell 执行，会自动剥掉你多写的 "
        f"`cmd /c` 前缀）；`cd <目录> && <serve>` 这类链式写法是支持的。\n"
        f"   受支持的 page/action 键（写别的会被**响亮拒绝**，不再静默忽略）：\n"
        f"     pages 项 = {{url, selectors, actions, assert_selected_count}}；\n"
        f"     actions 项 = {{click, fill, wait, screenshot, expect_url, expect_selector, "
        f"assert_selected, assert_count, assert_visible, assert_hidden, assert_text}}。\n"
        f"   选中态断言用 aria-pressed：`{{\"click\":\"<sel>\",\"assert_selected\":true}}`、"
        f"`{{\"assert_selected\":[\"<sel>\",false]}}`，或页级 `\"assert_selected_count\":[\"<sel>\",1]`。"
        f"不要发明键（assert_not / selected_count_gt 之类会被拒）。\n"
        f"   选择器必须对**真实存在且会渲染**的元素成立：组件在数据为空时会返回 null 不渲染，"
        f"别挑没有数据的页面做断言。\n"
        f"   selectors 与 actions 有时序语义：页级 selectors 在页面加载后**立即**断言可见（先于任何 "
        f"action）——只放默认渲染就存在的元素；条件渲染的元素（点页签/弹层后才出现）必须放进 "
        f"actions：先 click/wait 导航到位，再对它断言（：筛选栏仅在资讯页签下渲染，"
        f"页级 selectors 直查必超时假失败）。\n"
        f"   选择器要按组件真实 DOM 写（先 read_file 确认标记）：不要臆造 ARIA role 或结构，"
        f"如普通 button 没有 role=tab，`[role=tab]` 必落空；无稳定选择器时可用 "
        f"`button:has-text(\"页签文字\")` 这类 Playwright 选择器。\n"
        f"   **click 的选择器必须稳定定位**：不要用会随交互变化的状态选择器——如 "
        f"`button[aria-pressed=false]` 同时当点击目标与断言目标（点击后它变 true，选择器重新命中"
        f"另一个未选中按钮，断言必假）。用 data-testid / 文案定位点击目标，再用 assert_selected "
        f"断言状态。\n"
        f"   **视觉规格类需求（圆角/尺寸/字号等\"对齐/一致\"）必须用 assert_style 断言计算样式**：\n"
        f"""   {{"assert_style":["[data-testid=category-filter] button",{{"borderRadius":"8px","fontSize":"13px"}}]}}\n"""
        f"   （px 值带 ±1px 渲染容差；基准规格要 read_file 确认或实测，不要凭感觉填；"
        f"/73 实证：类名字符串 grep 验不到 computed 形态，外形改错了机审照样通过，两轮 6.6M token 白烧）\n"
        f"   **窄视口/溢出类需求必须在该页声明 viewport**：机审默认视口 1440×900，"
        f"\"本行塞不下时不要换行、改横向滚动/滚轮横滚\"这类需求在 1440 宽下**塞得下**，"
        f"永远测不出问题。"
        f'写法：`{{"url":"/games","viewport":{{"width":480,"height":900}},"actions":[...]}}`\n'
        f"4. 验收是命令不是形容词：断言不成立必须让命令以非 0 退出（如 {ex_exit}）。\n"
        f"4a-1. **失败分支必须打印证据**：只 `exit 1` 不输出，会让 QA/fixer 拿不到任何线索、只能盲猜"
        f"。"
        f"正确写法：`{ex_grep}`——一句话说清「缺什么、在哪」。\n"
        f"4a-2. **`cmd:` 的值在 YAML 里必须用单引号整条包裹**，且值内**不要出现 `: `（冒号+空格）**、"
        f"不要以 `{{` / `[` 开头。原因：YAML 里未加引号的标量含 `: ` 会被当成嵌套映射，直接 ScannerError；"
        f"——证据文案里写了 `MISSING: xxx`，Spec 生成**两轮都解析失败**，任务回退澄清卡住。"
        f"换用 `MISSING-KEYWORD xxx` 这类无冒号文案。\n"
        f"4b. **字面量断言必须能真正匹配源码的真实写法**（否则必然假失败，还白烧一轮 fixer）：\n"
        f"   - JSX 属性真实写法是 `data-testid=\"x\"`（**带引号**）→ 断言就得写 "
        f"`{ex_pattern}`；写成不带引号的 `data-testid=x` 永远匹配不到"
        f"。\n"
        f"   - 类名断言按实际 class 串写，取其中一个类即可，不要拼一整串、不要拼含空白/顺序敏感的长串。\n"
        f"   - 断言里引用的 data-testid / 类名，必须是**基线上已存在**或**本功能明确说要新增**的；"
        f"引用一个谁都没实现的锚点会被 Spec 期预检判成坏命令、白跑一轮重生成。"
        f"要新增锚点就在 `description` 里写清「本功能新增 data-testid=xxx」。\n"
        f"5. **每个功能至少配一条 stage=light 的秒级快速自检**（如脚本带 -SkipHttp 干跑、"
        f"关键词存在性校验），真起停服务/浏览器机审这类分钟级命令才放 stage=heavy。\n"
        f"   原因：stage=light 过滤后为空时，代码会回退执行**全部**命令（防空集假通过）——"
        f"只有 heavy 命令的功能，开发期每轮校验都会把起停服务与 UI 机审重跑一遍。\n"
        f"6. verifier: ui 的机审命令有两条硬契约：\n"
        f"   键表（页级键 / 动作键 / 断言形状，写未列出的键会**响亮失败**且白跑一轮重生成）：\n"
        f"   {_UI_GRAMMAR_HINT}\n"
        f"   a) start_cmd 必须是**前台阻塞**的服务命令（如 `{ex_start}`）。"
        f"机审结束后代码按进程树清理它；起完就返回的 launcher（如 `sop.ps1 start`、nohup/-d）"
        f"会被判定「机审服务启动即退出」而失败。\n"
        f"   b) start_cmd 必须含 {{port}} 占位符（或引用 AF_UI_PORT）——端口由 AgentFlow 自分配，"
        f"不要写死端口号、也不要为此排 stop 命令：每次机审都会重新挑一个空闲端口。\n"
        f"7. **命令里的文件路径一律写相对项目根**（如 `index.html`、`src/**/*.py`），"
        f"**严禁写主 checkout 的绝对路径**（如 `C:\\my\\code\\<proj>\\index.html`）。\n"
        f"   原因：验收命令的执行工作目录是**任务工作区**（worktree），产出在合入 main 之前只存在于那里；"
        f"主 checkout 里根本没有这些文件。写死绝对路径的断言必然 MISING-FILE，伪装成「代码没写」，"
        f"把 fixer 引向「把文件拷进主 checkout」这种荒谬动作（2026-10-01 ："
        f"单个 fixer 节点烧掉 110 万 token，验收永远失败，最后卡在 Safety 的跨目录写拦截上等人）。\n"
    )


KEY_PROJECT_FILES = [
    "内部文档",
    "内部文档",
    "README.md",
    "package.json",
    "pyproject.toml",
    "requirements.txt",
    "go.mod",
    "Cargo.toml",
    "tsconfig.json",
    "vite.config.ts",
    "next.config.js",
]


def _profile_fingerprint(project: m.Project) -> str:
    """项目关键文件指纹：mtime+size（+stack）。文件没变 → 档案缓存命中。"""
    import hashlib

    root = Path(project.repo_path)
    sig = [project.stack or ""]
    for fname in KEY_PROJECT_FILES:
        fpath = root / fname
        if fpath.exists() and fpath.is_file():
            st = fpath.stat()
            sig.append(f"{fname}:{st.st_mtime_ns}:{st.st_size}")
    return hashlib.md5("|".join(sig).encode()).hexdigest()


def _read_project_context(project: m.Project, session: Session | None = None) -> str:
    """读取项目关键文件，构建上下文。"""
    root = Path(project.repo_path)
    if not root.exists():
        return ""

    try:
        cfg = json.loads(project.config or "{}")
    except (json.JSONDecodeError, TypeError):
        cfg = {}
    cache = cfg.get("profile_cache") or {}
    fp = _profile_fingerprint(project)
    if cache.get("fingerprint") == fp and cache.get("text"):
        return cache["text"]








    parts = [
        f"项目路径: {root}",
        "（注：上路径是主 checkout，仅用于 Spec 期读取基线；任务实际在独立工作区执行，"
        "verify_commands 里的路径一律相对项目根写，不要写上面的绝对路径）",
    ]


    try:
        stack = json.loads(project.stack) if project.stack else {}
        if stack:
            parts.append(f"技术栈探测: {json.dumps(stack, ensure_ascii=False)}")
    except Exception:
        pass


    for fname in KEY_PROJECT_FILES:
        fpath = root / fname
        if fpath.exists() and fpath.is_file():
            try:
                content = fpath.read_text(encoding="utf-8", errors="replace")

                if len(content) > 2000:
                    content = content[:2000] + "\n...[truncated]"
                parts.append(f"\n--- {fname} ---\n{content}")
            except Exception:
                pass

    context = "\n".join(parts)

    if session is not None:
        try:
            cfg["profile_cache"] = {"fingerprint": fp, "text": context}
            project.config = json.dumps(cfg, ensure_ascii=False)
            session.add(project)
            session.commit()
        except Exception:
            pass
    return context


def _task_status_snapshot(session: Session, task: m.Task) -> str:
    """D-1：当前任务执行状态快照（功能进度 + 最近节点 + 分支/合并门禁），供 Lead 对话回复用户。"""
    parts = [f"任务状态: {task.status.value}", f"任务分支: {task.branch or '（未创建）'}"]

    if task.status == m.TaskStatus.paused_human:
        gate = (
            session.query(m.MergeApproval)
            .filter(m.MergeApproval.task_id == task.id)
            .order_by(m.MergeApproval.id.desc())
            .first()
        )
        if gate and gate.status == "pending":
            parts.append(
                "合并门禁: 待人工审批——所有改动都在任务分支（worktree）上，"
                "尚未 merge 进 main，**本地主 checkout / 生产环境看不到 UI 变化是正常现象**，"
                "不是没实现也不是要重启服务；批准合并并部署后才会可见。"
                "用户想提前看效果应去任务 worktree 查看（git worktree list 可查路径）。"
            )
        else:
            parts.append("任务处于暂停等人工状态（SOS 升级/重验失败/审查未过等），改动未合并。")
    try:
        feats = session.query(m.Feature).filter(m.Feature.task_id == task.id).all()
        if feats:
            feat_lines = [
                f"- F{f.seq}「{f.title}」 status={f.status.value} retry={f.retry_count}"
                for f in sorted(feats, key=lambda x: x.seq)
            ]
            parts.append("功能进度:\n" + "\n".join(feat_lines))
    except Exception:
        pass
    try:
        nodes = (
            session.query(m.Node)
            .filter(m.Node.task_id == task.id, m.Node.ended_at.isnot(None))
            .order_by(m.Node.id.desc())
            .limit(5)
            .all()
        )
        if nodes:
            node_lines = [f"- [{n.kind}] {n.status.value}: {(n.summary or '')[:80]}" for n in nodes]
            parts.append("最近节点:\n" + "\n".join(node_lines))
    except Exception:
        pass
    return "\n".join(parts)


def build_parent_context(session: Session, parent: m.Task) -> str:
    """P0 任务树 → 上下文系统：父任务上下文包升级为任务树全貌包（full 版）。"""
    from agentflow.agents import context as ctx

    return ctx.build_tree_overview(session, parent, mode="full")


def build_related_context(session: Session, task: m.Task) -> str:
    """P0 任务树：新任务澄清注入的关联上下文。"""
    parts: list[str] = []

    if task.parent_task_id:
        parent = session.get(m.Task, task.parent_task_id)
        if parent:
            parts.append(build_parent_context(session, parent))


    try:
        from datetime import datetime, timedelta, timezone

        week_ago = (datetime.now(timezone(timedelta(hours=8))) - timedelta(days=7)).isoformat()
        recent = (
            session.query(m.Task)
            .filter(
                m.Task.project_id == task.project_id,
                m.Task.id != task.id,
                m.Task.status.in_([
                    m.TaskStatus.merged, m.TaskStatus.human_review, m.TaskStatus.pending_push,
                    m.TaskStatus.passed, m.TaskStatus.pushed, m.TaskStatus.aborted, m.TaskStatus.paused_human,
                ]),
                m.Task.created_at >= week_ago,
            )
            .order_by(m.Task.id.desc())
            .limit(10)
            .all()
        )
        lines = []
        for t in recent:
            if t.id == task.parent_task_id:
                continue
            has_fail = (
                session.query(m.VerifierRun)
                .filter(m.VerifierRun.task_id == t.id, m.VerifierRun.exit_code != 0)
                .first()
            )
            if not has_fail:
                continue
            lines.append(f"- #{t.id}「{t.title}」[{t.status.value}] {(t.raw_request or '')[:100]}")
        if lines:
            parts.append("近期失败/异常任务（近 7 天，供避坑参考）:\n" + "\n".join(lines[:5]))
    except Exception:
        pass

    return "\n\n".join(parts)[:6000]


def _lead_delta(bus, task: m.Task, phase: str):
    """Lead 阶段的流式节流器（agent.delta，node_id=None 任务级流）。bus 缺省则不流式。"""
    if bus is None:
        return None
    from agentflow.agents.base import DeltaThrottler

    return DeltaThrottler(bus, task.id, None, "lead", phase=phase)


def clarify_round(
    gateway: LLMGateway,
    session: Session,
    task: m.Task,
    user_msg: str,
    user_images: list[str] | None = None,
    bus=None,
) -> str:
    """澄清对话一轮：带完整历史调用 Lead。消息已由调用方落库。"""
    project = session.get(m.Project, task.project_id)
    project_context = _read_project_context(project, session) if project else ""


    history_rows = (
        session.query(m.ClarifyMessage)
        .filter(m.ClarifyMessage.task_id == task.id)
        .order_by(m.ClarifyMessage.id.asc())
        .all()
    )

    def _row_text(r) -> str:
        text = r.content or ""
        try:
            imgs = json.loads(r.images or "[]")
        except (json.JSONDecodeError, TypeError):
            imgs = []
        if imgs:
            text = (text + f" [附图 x{len(imgs)}]").strip()
        return text

    history_text = "\n".join(
        f"{'用户' if r.role == 'user' else 'Lead'}: {_row_text(r)}" for r in history_rows[-20:]
    ) or "（暂无，请根据需求发起首轮澄清）"

    system = (
        "你是团队 Lead（统筹 agent），是用户在整个任务过程中的唯一对话窗口。你的职责：澄清需求、"
        "产出 Spec 并直做开发（单一模式，不派 developer），失败时由代码调度器派 QA/fixer，并随时向用户汇报。\n\n"
        "## 重要原则\n"
        "1. **先读项目信息再提问**：你已经拿到了项目的技术栈和关键文件（内部文档/内部文档/package.json 等），"
        "这些信息你应该已经知道，不要再问用户。\n"
        "2. **只问真正模糊的部分**：比如用户没说清楚的业务逻辑、边界条件、特殊要求等。\n"
        "3. **如果需求已经足够清晰**（有明确目标、验收可判定、无需技术选型决策），"
        "直接回复'需求已清晰，可以进入执行'，不要为了问而问。\n"
        "4. **不要问技术栈/框架/启动命令**：这些从项目文件里能读到的，你自己判断。\n"
        "5. **首轮澄清**：如果没有历史对话，请基于项目和需求直接给出你的理解，并列出真正需要确认的问题（最多 3 个，合并提问）；"
        "若需求描述已完整自洽（如'实现 X 函数并通过测试'这类目标明确的小任务），也可直接宣告清晰。\n"
        "6. **本环节是纯文本对话，没有任何工具可用**：不要输出任何工具调用标记/命令执行请求；"
        "判断需求清晰后只需回复文字'需求已清晰，可以进入执行'，执行交给后续流程。\n"
        "7. **全程使用简体中文与用户交流**，即使项目文档或需求中包含英文。\n"
        "8. **先直接回答用户本轮的问题**：「关联任务上下文」（近期失败任务等）只作避坑参考，"
        "禁止把回答变成历史任务复盘——用户问的是当前任务，就答当前任务。\n"
    )

    from agentflow.agents.base import priority_context_text

    rules = priority_context_text(session, task.project_id, project.repo_path if project else None)
    if rules:
        system = rules + system




    if task.status in (m.TaskStatus.done, m.TaskStatus.aborted, m.TaskStatus.resolved) or task.status in m.MERGED_OK_STATUSES:
        system += (
            "\n## 咨询模式（当前任务已结束，status="
            f"{task.status.value}）\n"
            "用户此时的消息只能是对已执行过程的询问（如某环节为何这样处理、失败原因、改动内容）。\n"
            "1. 依据「当前任务状态」快照与对话历史如实解答，可给出复盘与建议。\n"
            "2. **拒绝在当前任务中发起任何新的修改/开发**：若用户提出新需求，明确说明任务已结束，"
            "引导其新建任务（新任务会重新走澄清与 Spec 流程）。\n"
            "3. 保持简体中文，简洁作答。\n"
        )

    env = detect_exec_env()


    try:
        from agentflow.agents.diagnose import DiagnosisError, latest_diagnosis, parse_diagnosis_card

        _card = None
        _raw = latest_diagnosis(session, task.id)
        if _raw:
            try:
                _card = parse_diagnosis_card(_raw)
            except DiagnosisError:
                _card = None
        if _card and _card.get("verdict") == "ops":
            system += (
                "\n## 运维分流生效中（现场诊断 verdict=ops）\n"
                f"本任务已经只读现场诊断判定为**运维问题，不会进入开发拆解**（不生成 Spec、不启动开发 agent）：\n"
                f"- 根因: {_card.get('root_cause', '')}\n"
                f"- 修复命令: `{_card.get('ops_cmd', '')}` | 验证命令: `{_card.get('verify_cmd', '')}`\n"
                "- 执行方式：系统已自动执行修复并用验证命令确认（**不需要用户点任何按钮**）\n"
                "规则：\n"
                "1. **禁止再说「需求已清晰，可以进入执行」**——用户点「确认 Spec 并运行」只会再走一遍诊断/执行，不产出代码改动。\n"
                "2. 若系统已执行完毕：如实转述结果（✅ 已解决=任务已收口为终态「已解决」，可归档；❌ 未通过=说明卡点与建议，"
                "可引导用户补充信息后重新确认 Spec）。若用户问「为什么没有 AI 执行」，说明执行是系统自动完成的。\n"
                "3. 若用户说明这实际需要改代码/是功能需求，请引导其补充具体需求描述；"
                "用户发新消息后系统会失效旧诊断卡，下次确认 Spec 将重新诊断。\n"
            )
    except Exception:
        pass
    snapshot = _task_status_snapshot(session, task) if session else ""

    related_ctx = ""
    try:
        related_ctx = build_related_context(session, task) if session else ""
    except Exception:
        related_ctx = ""
    related_section = f"\n## 关联任务上下文（父任务/近期失败任务）\n{related_ctx}\n" if related_ctx else ""

    image_note = (
        f"\n\n（本轮用户随消息附了 {len(user_images)} 张图片，已在消息中一并给你，请结合图片内容理解需求。）"
        if user_images
        else ""
    )
    prompt = (
        f"## 项目上下文\n{project_context}\n\n"
        f"## 任务信息\n"
        f"任务标题: {task.title}\n"
        f"原始需求: {task.raw_request}\n"
        f"{related_section}\n"
        f"## 执行环境\n"
        f"OS: {env['os']} | 默认 shell: {env['shell']}（verify 命令必须按此 shell 语法书写）\n\n"
        f"## 当前任务状态\n{snapshot}\n\n"
        f"## 对话历史\n{history_text}\n\n"
        f"请基于以上信息回复（继续澄清或宣告需求清晰；若用户询问进度，依据「当前任务状态」如实回答）。{image_note}"
    )




    for attempt in range(2):
        if attempt == 0:
            throttler = _lead_delta(bus, task, "clarify")
            result = gateway.generate("lead", prompt, system, images=user_images or None, on_delta=throttler.feed if throttler else None)
            if throttler:
                throttler.flush(done=True)
        else:
            result = gateway.generate("lead", prompt, system, images=user_images or None)
        text = _sanitize(result.text)
        if text:
            return text
    if bus is not None:
        try:
            bus.publish_task(task.id, "log.appended", {
                "level": "sched",
                "message": "⚠ 澄清回复为空（模型连续两次未返回正文）——已回兜底提示，请重发消息或直接点「确认 Spec 并运行」",
            })
        except Exception:
            pass
    return "（本轮模型未返回内容——可能是瞬时异常。请重发上一条消息；若需求已清晰，直接点「✓ 确认 Spec 并运行」进入执行。）"


def _sanitize(text: str) -> str:
    """清洗模型泄漏的工具调用标记（DSML/<tool_call> 等），只保留正文。"""
    if not text:
        return text

    for marker in ("<｜DSML｜", "<|DSML|"):
        idx = text.find(marker)
        if idx >= 0:
            text = text[:idx]

    text = re.sub(r"<tool_call>.*?</tool_call>", "", text, flags=re.S)
    return text.strip()


def extract_spec_yaml(text: str) -> str:
    m = _YAML_RE.search(text)
    return m.group(1).strip() if m else text.strip()


def requirement_images(settings, session: Session, task_id: int, limit: int = 2) -> list[str]:
    """任务需求截图 → data URL 列表（澄清期用户上传的图片，供 Spec/开发多模态注入）。"""
    import base64

    home = getattr(settings, "home", None)
    if home is None:
        return []
    try:
        rows = session.exec(
            select(m.ClarifyMessage)
            .where(m.ClarifyMessage.task_id == task_id)
            .order_by(m.ClarifyMessage.id)
        ).all()
    except Exception:
        return []
    names: list[str] = []
    for r in rows:
        if (r.role or "") != "user":
            continue
        try:
            names.extend(json.loads(r.images or "[]"))
        except Exception:
            continue
    out: list[str] = []
    for n in names[-limit:]:
        p = Path(home) / "clarify_images" / str(task_id) / str(n)
        if not p.is_file():
            continue
        ext = p.suffix.lower().lstrip(".") or "png"
        mime = "image/jpeg" if ext in ("jpg", "jpeg") else f"image/{ext}"
        try:
            out.append(f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}")
        except Exception:
            continue
    return out


def generate_spec(
    gateway: LLMGateway,
    session: Session,
    task: m.Task,
    project: m.Project,
    retry_feedback: str = "",
    bus=None,
) -> SpecDoc:
    """调用 Lead 生成 Spec，落库（Spec + Feature 行）。返回 SpecDoc。"""
    invariants = _load_invariants(session, project.id)
    project_context = _read_project_context(project, session)
    env = detect_exec_env()
    shell_example = (
        "例如 Windows 执行面为 Git Bash：用 bash/POSIX 语法（`test -f`、`command -v`、`grep -q`）。\n"
        if env["shell"] == "bash"
        else "例如 Windows 用 PowerShell 语法（`Test-Path`、`Get-Command`），"
        "Linux/macOS 用 bash 语法（`test -d`、`command -v`）。\n"
    )
    system = (
        "你是团队 Lead（统筹 agent）。任务：把需求拆解为功能清单，每个功能标注写集 file_scope、验收命令。\n\n"
        "## 重要原则\n"
        "1. **基于项目上下文拆解**：你已经拿到了项目的技术栈和关键文件，拆解时要考虑项目实际结构。\n"
        "2. **file_scope 要精准**：根据项目实际目录结构标注，不要笼统写 `**/*`。\n"
        "3. **related_files 要具体**：列出实现该功能最相关的现有文件（从项目上下文里找）。\n"
        "4. **验收命令必须匹配执行环境的 shell**：verify_commands 的每条命令按执行环境的 shell 语法书写，"
        "并在每项标注 `shell` 字段（powershell / bash / cmd）。"
        f"{shell_example}"
        "4a. **命令从简**：验收命令禁止复杂括号嵌套与管道对象操作（避开 Where-Object/内联表达式嵌套），"
        "单条 Select-String / test / && 链能表达的就用最短形式；文档类功能只用「关键词存在性」校验。\n"
        "5. **自然语言字段使用简体中文**：title、功能标题等描述性文字一律中文；file_scope、命令、标识符保持原文。\n"
        "6. **不输出 `grouping`**：分组由调度器代码聚类（写集不相交自动并行）裁决，Lead 不干预分组。\n"
        "6a. **拆分粒度：按改动的独立性拆 2~3 个写集不重叠的 feature 并行推进，别拆碎也别揉成一坨**。"
        "调度器按「组」并行、组间串行：拆成 2~3 个不相交 feature 时组内真并行，墙钟按最大组计；"
        "**把 8~10 个文件揉进单个 feature 反而更慢**——一个巨型 developer 节点实测 961s/165 万 token"
        "，而拆开时单节点 44~388s。反过来拆成 5+ 个 feature 也不划算："
        "组数变多、跨 feature 锚点契约变多。判定：同一根因 + 文件高度同构（如五个页面各改一处）"
        "→ 合成 1 个 feature；可独立验证的组件级改动（组件本体 / 页面接入 / 文档）→ 拆 2~3 个。\n"
        "6b. **跨 feature 的锚点命名必须唯一且归属明确**：同一控件（如时间档位条）的 `data-testid` 只能有一个名字，"
        "由**引入它的那个 feature** 在 `description` 里写清「新增 data-testid=xxx」，后续 feature 的 ui 声明只许引用同一个名字。"
        "否则会出现「A 用 `time-range-track`、B 实现时叫 `time-range-filter`」→ 机审选择器超时、白跑 fixer。\n"
        "6c. **并行 feature 的 file_scope 不得重叠**：重叠会让两个执行节点在同一 worktree 互相覆盖，"
        "并刷出「file_scope 外的未提交文件未纳入绿点」告警；写集有交集的两个 feature "
        "还会被调度器**分批串行**（墙钟从 max(组) 退化成 sum(组)），白丢 ~15 分钟。"
        "**落在同一个文件上的改动必须写成同一个 feature**（包括「改代码」和「跑它并同步产物」这种同文件前后步）；"
        "写集重叠且无依赖的 feature 会被生成器自动合并——不要指望靠 depends_on 把它们排成串行，那是同一次改动。\n"
        "7. **评估并输出 complexity 字段**：顶层输出 `complexity: simple | standard`（只有这两个合法值，禁止 medium/complex/高级 等其他值）。"
        "判定标准——simple：单一功能且改动集中在 1-2 个文件、无技术选型决策、验收直接（如实现一个函数+测试）；"
        "standard：多功能/多文件/有架构决策。simple 任务系统会走快路径（跳过调研与合并前审查）省时。\n"
    )

    from agentflow.agents.base import priority_context_text

    rules = priority_context_text(session, project.id, project.repo_path)
    if rules:
        system = rules + system






    history_rows = (
        session.query(m.ClarifyMessage)
        .filter(m.ClarifyMessage.task_id == task.id)
        .order_by(m.ClarifyMessage.id.asc())
        .all()
    )
    user_lines = [f"用户: {(r.content or '')[:600]}" for r in history_rows if r.role == "user"]
    last_lead = next((r for r in reversed(history_rows) if r.role != "user"), None)
    lead_lines = [f"Lead: {(last_lead.content or '')[:400]}"] if last_lead else []
    history_text = "\n".join(user_lines + lead_lines) or "（暂无澄清历史）"
    related_ctx = ""
    try:
        related_ctx = build_related_context(session, task)
    except Exception:
        related_ctx = ""
    related_section = f"\n## 关联任务上下文（父任务/近期失败任务，子任务共享）\n{related_ctx[:2500]}\n" if related_ctx else ""


    diagnosis_text = ""
    try:
        from agentflow.agents.diagnose import latest_diagnosis

        diagnosis_text = latest_diagnosis(session, task.id)
    except Exception:
        diagnosis_text = ""
    if diagnosis_text:
        related_section = (
            f"\n## Lead 现场诊断（探针证据，结论优先于推测；拆解必须与根因/证据一致，不得另起炉灶）\n"
            f"{diagnosis_text[:3000]}\n" + related_section
        )
    if retry_feedback:
        related_section = (
            f"\n## 上轮失败证据（本次生成的验收命令必须规避此类语法错误；含括号嵌套时先脑内配平后再输出）\n{retry_feedback}\n"
            + related_section
        )
    prompt = (
        f"## 项目上下文\n{project_context}\n\n"
        f"## 项目不变量\n" + "\n".join(f"- {i}" for i in invariants) + "\n\n"
        f"## 任务信息\n"
        f"任务标题: {task.title}\n"
        f"原始需求: {task.raw_request or '（空，请以澄清历史与关联上下文为准）'}\n"
        f"{related_section}\n"
        f"## 澄清历史（已确认的结论优先于原始需求）\n{history_text}\n\n"
        f"## 执行环境\n"
        f"OS: {env['os']} | 默认 shell: {env['shell']}\n"
        f"verify_commands 每条必须带 shell 字段且命令按 {env['shell']} 语法书写；"
        f"stage 只允许 light（开发期每次校验都跑，默认填 light）或 heavy（仅集成阶段跑），不要自造其他取值。\n\n"
        f"{_verify_cmd_rules(env['shell'])}\n"
        f"请产出结构化 Spec，格式 YAML，必须包含: title / complexity(simple|standard) / features(seq,title,file_scope,verify_commands(verifier,cmd,timeout,classification_hint,stage,shell),depends_on,related_files) / invariants / budget。\n"
        f"file_scope 用 glob（相对项目根）。related_files 列出实现该功能最相关的现有文件。分组由调度器自动裁决，不要输出 grouping。"
    )


    _req_images = requirement_images(getattr(gateway, "settings", None), session, int(task.id))
    if _req_images:
        prompt += (
            f"\n\n## 需求截图（{len(_req_images)} 张，已随本消息附上）\n"
            "**样式/视觉类要求一律以截图为唯一准绳**，不要仅凭文字推断形状与位置；"
            "请在 Spec 的 verify_commands 里把可机械校验的视觉特征（选择器/类名/结构）写死。"
        )
    throttler = _lead_delta(bus, task, "spec")
    result = gateway.generate("lead", prompt, system, images=_req_images or None,
                              on_delta=throttler.feed if throttler else None)
    if throttler:
        throttler.flush(done=True)
    yaml_text = extract_spec_yaml(result.text)
    _repair_notes: list[str] = []
    doc = parse_spec(yaml_text, repair_note=_repair_notes)
    if _repair_notes and bus is not None:
        try:
            bus.publish_task(task.id, "log.appended", {
                "level": "sched", "message": "；".join(_repair_notes),
            })
        except Exception:
            pass
    doc.title = doc.title or task.title




    from agentflow.core.partition import merge_overlapping_features

    doc, _merge_notes = merge_overlapping_features(doc)
    if _merge_notes:
        yaml_text = dump_spec(doc)
        if bus is not None:
            try:
                bus.publish_task(task.id, "log.appended", {
                    "level": "sched", "message": "；".join(_merge_notes),
                })
            except Exception:
                pass

    spec = m.Spec(task_id=task.id, version=1, yaml_raw=yaml_text, parsed=doc.model_dump_json(), complexity=doc.complexity)
    session.add(spec)
    session.flush()
    for f in doc.features:
        feat = m.Feature(
            task_id=task.id,
            spec_id=spec.id,
            seq=f.seq,
            title=f.title,
            file_scope=json.dumps(f.file_scope),
            verify_commands=json.dumps([vc.model_dump() for vc in f.verify_commands]),
            depends_on=json.dumps(f.depends_on),
            related_files=json.dumps(f.related_files),
        )
        session.add(feat)
    session.commit()
    _log_ui_strength_delta(session, task, spec, bus)
    return doc


def _log_ui_strength_delta(session: Session, task: m.Task, spec: m.Spec, bus) -> None:
    """Spec 重生成时对比上一版 ui 声明强度，有下降/削弱则时间线留痕（**不阻断**）。"""
    if bus is None:
        return
    prev = session.exec(
        select(m.Spec).where(m.Spec.task_id == task.id, m.Spec.id != spec.id)
        .order_by(m.Spec.id.desc())
    ).first()
    if prev is None:
        return
    from agentflow.verifiers.strength import compare_ui, find_ui_decl

    def _ui_of(sp) -> dict | None:
        for feat in session.exec(select(m.Feature).where(m.Feature.spec_id == sp.id)).all():
            d = find_ui_decl(feat.verify_commands)
            if d:
                return d
        return None

    old, new = _ui_of(prev), _ui_of(spec)
    if old is None or new is None:
        return
    bad, adv = compare_ui(old, new)
    if not bad and not adv:
        return
    notes = ([f"强度削弱：{b}" for b in bad] + adv)[:3]
    try:
        bus.publish_task(task.id, "log.appended", {
            "level": "sched",
            "message": "⚠ 本版 Spec 的 ui 验收与上一版相比有削弱——" + "；".join(notes)
                       + "（若为有意放宽验收标准，请确认其仍然充分）",
        })
    except Exception:
        pass


def _load_invariants(session: Session, project_id: int) -> list[str]:
    rows = session.query(m.Invariant).filter(m.Invariant.project_id == project_id).all()
    return [r.text for r in rows]


def replan_verify_commands(
    gateway: LLMGateway,
    session: Session,
    task: m.Task,
    feature: m.Feature,
    failure_ctx: str,
    bus=None,
) -> str | None:
    """B-2 Lead 重规划 verify_commands（spec 缺陷通道：命令级错误不派 fixer）。"""
    import yaml

    env = detect_exec_env()
    system = (
        "你是团队 Lead。当前功能的验证命令写错（shell 语法不匹配/命令不存在/路径错误/把自然语言描述当命令），需要你重写 verify_commands。\n"
        "另一类常见错误：UI 机审（verifier=ui，cmd 为 JSON）的预期与页面实际交互不符——如断言的元素只在某个页签/弹层下渲染，"
        "此时应在 actions 里补导航动作（如先点击页签按钮）再断言，而不是要求页面无条件渲染该元素；"
        "若实现与需求一致而机审预期与之矛盾，修正机审 JSON，不要曲改需求。\n"
        f"执行环境: OS={env['os']}，shell={env['shell']}。命令必须按该 shell 语法书写并在每项标注 shell 字段。\n"
        f"{_verify_cmd_rules(env['shell'])}\n"
        "只输出 YAML 列表，每项含 verifier/cmd/timeout/classification_hint/stage/shell。stage 只允许 light（开发期跑）或 heavy（集成阶段跑），默认 light。不要输出其他内容。"
    )
    prompt = (
        f"功能 seq={feature.seq}「{feature.title}」\n"
        f"当前 verify_commands:\n{feature.verify_commands}\n\n"
        f"失败上下文（含 QA 归因）:\n{failure_ctx[:4000]}\n\n"
        "请重写 verify_commands，修正命令使其能正确执行（按执行环境 shell 语法、补对命令/路径），用 YAML 列表输出。"
    )


    last_err = ""
    for attempt in range(2):
        round_prompt = prompt if not last_err else (
            f"{prompt}\n\n你上一次的输出无法通过代码校验，请修正后重新输出**完整** YAML 列表:\n{last_err}"
        )
        throttler = _lead_delta(bus, task, "replan")
        result = gateway.generate("lead", round_prompt, system, on_delta=throttler.feed if throttler else None)
        if throttler:
            throttler.flush(done=True)
        text = extract_spec_yaml(result.text)
        raw = None
        try:
            raw = yaml.safe_load(text)
        except Exception as e:
            last_err = f"YAML 解析失败: {e}（字符串含冒号/引号等特殊字符时必须加引号）"
            continue
        if isinstance(raw, dict):
            raw = raw.get("verify_commands") or []
        if not isinstance(raw, list) or not raw:
            last_err = "输出不是有效的命令列表（需 YAML 列表，每项含 verifier/cmd/...）"
            continue
        try:
            cmds = [VerifyCommand.model_validate(c) for c in raw]
        except Exception as e:
            last_err = f"命令校验失败: {e}"
            continue
        if not all(c.cmd.strip() for c in cmds):
            last_err = "存在空命令"
            continue



        from agentflow.verifiers import probe as _probe

        _project = session.get(m.Project, task.project_id) if getattr(task, "project_id", None) else None
        _main_root = getattr(_project, "repo_path", None)
        bad: list[str] = []
        for c in cmds:
            ok, err = _probe.check_command(c.verifier, c.cmd, c.shell, _main_root)
            if not ok:
                bad.append(f"[{c.verifier}] {err}")
        if bad:
            last_err = "命令可执行性预检未过: " + "；".join(bad[:3])
            continue
        break
    else:
        return f"重规划输出无法解析: {last_err}"




    if _is_homogeneous_replan(feature.verify_commands, cmds):
        return (
            "重规划与上一轮**同质**：断言手段未发生实质变化（仍是同一类检查）。"
            "这说明问题不在命令写法，而在于**本功能的验收标准本身无法证明该需求**——"
            "继续改写命令只会复现同一失败。请人工重新设计验收方式"
            "（例如补行为断言、补前置动作、或修正需求理解），不要继续自动重规划。"
        )


    from agentflow.verifiers.strength import gate_ui_rewrite

    new_ui_cmd = next((c.cmd for c in cmds if (c.verifier or "").strip().lower() == "ui"), None)
    if new_ui_cmd is not None:
        weak = gate_ui_rewrite(feature.verify_commands, new_ui_cmd)
        if weak:
            return (
                f"重规划弱化了验收强度：{weak}。"
                "若原断言确已证明不可达（如目标控件只在某档位渲染），正确修法是**补前置动作后仍断言原目标**"
                "（或换成等价强度的新锚点），而不是把断言降级为『元素存在即可』。"
                "若确需放宽验收标准，请人工重新设计验收方式，不要继续自动重规划。"
            )
    feature.verify_commands = json.dumps([c.model_dump() for c in cmds])
    session.add(feature)
    session.commit()
    return None


def _cmd_signature(cmd: str) -> str:
    """断言手段签名：按"用什么方式验证"归类，忽略具体关键词/路径。"""
    c = (cmd or "").lower()
    if "select-string" in c or re.search(r"\bgrep\b|\bfindstr\b", c):
        return "literal"
    if re.search(r"\b(pytest|unittest|jest|vitest|mocha)\b", c):
        return "test"
    if "npx tsc" in c or "tsc --noemit" in c:
        return "typecheck"
    if "npm run build" in c or "npm run" in c:
        return "npm"
    return "other"


def _is_homogeneous_replan(old_raw, new_cmds) -> bool:
    """新旧 verify_commands 是否同质（同类断言手段、无实质升级）。"""
    try:
        old = json.loads(old_raw or "[]")
    except Exception:
        return False
    if not old:
        return False

    def sig_set(cmds) -> set[str]:
        out: set[str] = set()
        for v in cmds:
            if isinstance(v, dict):
                verifier = (v.get("verifier") or "").strip().lower()
                raw_cmd = v.get("cmd", "") or ""
            else:
                verifier = getattr(v, "verifier", "") or ""
                raw_cmd = getattr(v, "cmd", "") or ""
            if verifier == "ui":
                out.add("ui")
                continue
            out.add(_cmd_signature(raw_cmd))
        return out

    old_sig = sig_set(old)
    new_sig = sig_set(new_cmds)

    if "ui" in old_sig or "ui" in new_sig:
        return False
    return old_sig == new_sig


_SOS_JSON_RE = re.compile(r"\{.*\}", re.S)


def sos_decide(
    gateway: LLMGateway,
    session: Session,
    task: m.Task,
    feature: m.Feature,
    packet: "m.SosPacket",
    retry_error: str = "",
    bus=None,
) -> dict | None:
    """SOS 决策（自愈系统 P1）：输入 SOS 包，输出四选一决策 JSON。"""
    env = detect_exec_env()
    system = (
        "你是团队 Lead，收到执行 agent 的 SOS 求助包（已熔断，常规修复无效）。请基于症状、已试路径、"
        "剩余预算做四选一决策。你只出建议，代码会严格校验你的输出。\n\n"
        "## 决策分支与 payload 契约（必须严格遵守，否则被拒）\n"
        "1. restrategy（换策略重派）: payload={\"new_hint\": \"给 fixer 的新修复思路，≤500字\"}。\n"
        "   注意：与历史 hint 相似度>0.8 会被拒；每功能最多 2 次。\n"
        "2. research（派调研）: payload={\"focus\": \"调研聚焦点（哪些文件/依赖要查）\"}。\n"
        "   每任务最多 2 次；已有进行中调研会被拒。\n"
        "3. split（拆子任务）: payload={\"subtasks\": [{\"title\", \"description\", \"file_scope\": [glob...]}], "
        "\"deferred_scope\": \"可选，未覆盖部分的归属说明\"}。1-3 条；file_scope 必须是父功能写集的子集；"
        "并集必须覆盖父写集（否则填 deferred_scope）。\n"
        "4. escalate（升级人工）: payload={\"question\": \"≥20字，说明卡在哪、需要人定什么\"}。\n\n"
        "只输出 JSON（可包在 ```json 代码块中）：{\"decision\": \"restrategy|research|split|escalate\", "
        "\"reason\": \"一句话依据\", \"payload\": {...}}\n"
        "选择依据：失败是策略问题→restrategy；信息不足→research；任务过大应拆分→split；"
        "需要业务决策/人工介入→escalate。全程简体中文。"
    )
    prompt = (
        f"任务 #{task.id}「{task.title}」功能 F{feature.seq}「{feature.title}」触发 SOS\n\n"
        f"## 症状\n{packet.symptom[:800]}\n\n"
        f"## 已尝试\n{packet.tried[:800]}\n\n"
        f"## 失败证据\n{packet.evidence[:800]}\n\n"
        f"## 剩余预算\n{packet.budget_left[:200]}\n\n"
        f"## 执行环境\nOS: {env['os']} | shell: {env['shell']}\n\n"
    )
    if retry_error:
        prompt += f"## ⚠ 上轮决策被代码拒绝，原因：{retry_error}\n请调整后重新决策（不要原样重复）。\n\n"
    prompt += "请输出决策 JSON。"
    throttler = _lead_delta(bus, task, "sos")
    result = gateway.generate("lead", prompt, system, on_delta=throttler.feed if throttler else None)
    if throttler:
        throttler.flush(done=True)
    mjson = _SOS_JSON_RE.search(result.text or "")
    if not mjson:
        return None
    try:
        d = json.loads(mjson.group(0))
    except Exception:
        return None
    return d if isinstance(d, dict) else None

