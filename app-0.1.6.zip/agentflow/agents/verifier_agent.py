"""校验 Agent（verifier）：按 Spec 顺序串行跑 Verifier + LLM 失败归因（非判定者）。"""

from __future__ import annotations

import json
import time
from pathlib import Path

from agentflow.config import Settings
from agentflow.storage import models as m, trace as tr
from agentflow.verifiers.base import VerifierResult
from agentflow.verifiers.probe import (
    SPEC_DEFECT_EXIT,
    SPEC_DEFECT_MARK,
    SPEC_DEFECT_PATH_MARK,
    main_checkout_path_reason,
    prose_reason,
    ui_hint,
)
from agentflow.verifiers.registry import get_verifier, is_registered
from sqlmodel import Session


def run_feature_verifiers(
    session: Session,
    settings: Settings,
    task: m.Task,
    feature: m.Feature,
    repo_root: Path,
    node_id: int | None = None,
    bus=None,
    stage: str | None = None,
) -> tuple[bool, list[m.VerifierRun], str | None]:
    """按 Spec 顺序串行跑该功能校验命令（可只跑指定 stage）。返回 (是否全过, runs, blocking_or_None)。"""
    cmds = json.loads(feature.verify_commands) if feature.verify_commands else []
    if stage is not None:
        filtered = [c for c in cmds if c.get("stage", "light") == stage]
        if not filtered and cmds:


            if bus is not None:
                try:
                    bus.publish_task(task.id, "log.appended", {
                        "level": "verify",
                        "message": f"stage={stage} 未命中任何校验命令，回退执行全部 {len(cmds)} 条（防空集假通过）",
                    })
                except Exception:
                    pass
            filtered = cmds
        cmds = filtered
    trace_uri = ""
    if node_id:
        _n = session.get(m.Node, node_id)
        trace_uri = _n.trace_uri if _n else ""


    _project = session.get(m.Project, task.project_id) if getattr(task, "project_id", None) else None
    main_root = getattr(_project, "repo_path", None)

    def one(vc: dict) -> m.VerifierRun:
        name = vc.get("verifier", "noop")
        cmd = vc.get("cmd", "")
        timeout = int(vc.get("timeout", 120))
        shell = vc.get("shell") or None
        start = time.monotonic()





        guard = "" if is_registered(name) else prose_reason(cmd)

        path_guard = main_checkout_path_reason(cmd, main_root)
        if guard or path_guard:
            if guard:
                output = (
                    f"{SPEC_DEFECT_MARK} 校验命令不是可执行命令：{guard}。\n"
                    f"原 cmd: {cmd[:300]}\n"
                    "这是 Spec 缺陷（命令字段写了自然语言），不是被测代码的故障，"
                    "应由 Lead 重写 verify_commands，不要派 fixer 改业务代码。"
                    + (f"\n{ui_hint(name, cmd)}" if ui_hint(name, cmd) else "")
                )
            else:
                output = (
                    f"{SPEC_DEFECT_PATH_MARK} {path_guard}。\n"
                    f"原 cmd: {cmd[:300]}\n"
                    "这是 Spec 缺陷（命令把产出定位到了主 checkout），不是被测代码的故障，"
                    "应由 Lead 重写 verify_commands，不要派 fixer 改业务代码。"
                )
            result = VerifierResult(
                verifier=name,
                cmd=cmd,
                exit_code=SPEC_DEFECT_EXIT,
                output=output,
                duration_ms=0,
                classification="command",
            )
        else:
            result = get_verifier(name).run(cmd, repo_root, timeout, shell=shell)
        run = m.VerifierRun(
            feature_id=feature.id,
            task_id=task.id,
            node_id=node_id,
            verifier=name,
            cmd=cmd,
            exit_code=result.exit_code,
            duration_ms=int((time.monotonic() - start) * 1000),
            output_uri=result.output[:2000],
            detail=getattr(result, "detail", None),
        )
        if result.exit_code != 0:



            run.classification = result.classification or vc.get("classification_hint", "blocking")
            from agentflow.core.evolution import run_fingerprint

            run.fingerprint = run_fingerprint(cmd, result.exit_code, result.output)

        if bus is not None:
            try:
                bus.publish_task(task.id, "verify.run", {
                    "node_id": node_id,
                    "verifier": name,
                    "cmd": cmd,
                    "exit_code": result.exit_code,
                    "duration_ms": run.duration_ms,
                    "output": result.output[:300],
                })
            except Exception:
                pass
        if trace_uri:
            tr.append(
                trace_uri, "verify_run", f"{name} exit={result.exit_code}",
                verifier=name, cmd=cmd, exit_code=result.exit_code,
                duration_ms=run.duration_ms, output=result.output[:2000],
            )
        return run






    if not cmds:
        return False, [one({"verifier": "noop", "cmd": ""})], "command"







    runs = [one(vc) for vc in cmds]

    for r in runs:
        session.add(r)
    session.commit()

    passed = all(r.exit_code == 0 for r in runs)
    blocking = None
    if not passed:
        for r in runs:
            if r.exit_code != 0:
                blocking = r.classification or "blocking"
                break
    return passed, runs, blocking
