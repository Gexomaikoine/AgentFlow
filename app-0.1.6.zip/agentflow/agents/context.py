"""上下文组装层（上下文系统）：集中注入上限与任务树全貌包组装。"""

from __future__ import annotations

from agentflow.storage import models as m


CTX_LIMITS = {
    "tree_full": 6000,
    "tree_brief": 1500,
    "tree_brief_fixer": 1200,
    "parent_request": 1200,
    "parent_clarify": 200,
    "sub_block_full": 700,
    "sub_note": 400,
    "sub_files": 150,
    "brief_max_subs": 8,
    "handoff_item": 600,
    "handoff_block": 3000,
    "query_item": 800,
    "query_block": 4000,
}


def _clip(text: str, limit: int) -> str:
    return (text or "").strip()[:limit]


BRIEF_APPENDIX = (
    "\n（以上为任务树简况：兄弟/父任务的笔记是 agent 生成的参考，非验证事实；"
    "需要兄弟任务细节时用 context.query 调用（scope=\"tree\"）自行查询）"
)


def build_tree_overview(session, task: m.Task, mode: str = "brief") -> str:
    """任务树全貌包：父任务 + 全部兄弟子任务（含自身家族）。"""
    try:
        if task.parent_task_id:
            parent = session.get(m.Task, task.parent_task_id)
            if parent is None:
                return ""
            siblings = session.exec(
                _select_subtasks(parent.id)
            ).all()
            return _render(session, task, parent, siblings, mode)
        subs = session.exec(_select_subtasks(task.id)).all()
        if subs or mode == "full":
            return _render(session, task, task, subs, mode)
        return ""
    except Exception:
        return ""


def _select_subtasks(parent_id: int):
    from sqlmodel import select

    return select(m.Task).where(m.Task.parent_task_id == parent_id).order_by(m.Task.id)


def _render(session, task: m.Task, parent: m.Task, siblings: list[m.Task], mode: str) -> str:
    parts: list[str] = []
    if mode == "full":
        parts.append(
            f"## 任务树全貌（父任务 #{parent.id}「{parent.title}」+ 全部子任务，周边需求据此做全）"
        )
        parts.append(f"父任务原始需求: {_clip(parent.raw_request, CTX_LIMITS['parent_request'])}")
        parts.append(f"父任务状态: {parent.status.value}")
        feats = session.exec(
            _select_feats(parent.id)
        ).all()
        if feats:
            lines = [
                f"- F{f.seq}「{f.title}」status={f.status.value} retry={f.retry_count}"
                for f in sorted(feats, key=lambda x: x.seq)[:12]
            ]
            parts.append("父 Spec 功能清单:\n" + "\n".join(lines))
        _append_clarify(session, parent, parts)
        _append_parent_failures(session, parent, parts)
        for sub in siblings:
            in_scope = sub.id == task.id
            parts.append(_full_sub_block(session, sub, in_scope))
        text = "\n\n".join(parts)
        return text[: CTX_LIMITS["tree_full"]]

    parts.append(f"## 任务树简况（父任务 #{parent.id}「{parent.title}」）")
    parts.append(f"父任务目标: {_clip(parent.raw_request, 300)}")
    lines: list[str] = []
    for sub in siblings:
        note_files = _sub_line(session, sub, task)
        if note_files:
            lines.append(note_files)
        if len(lines) >= CTX_LIMITS["brief_max_subs"]:
            break
    parts.append("兄弟子任务（状态+涉及文件）:\n" + "\n".join(lines) if lines else "（尚无子任务）")
    remaining = len(siblings) - len(lines)
    if remaining > 0:
        parts.append(
            f"其余 {remaining} 个兄弟详见 context.query 调用（scope=\"tree\"），已省略。"
        )
    text = "\n\n".join(parts)
    return text[: CTX_LIMITS["tree_brief"]]


def _full_sub_block(session, sub: m.Task, in_scope: bool) -> str:
    mark = "（本任务）" if in_scope else ""
    lines = [
        f"### 子任务 #{sub.id}「{sub.title}」[{sub.status.value}]{mark} origin={sub.origin}",
        f"需求: {_clip(sub.raw_request, 300)}",
    ]
    note = _latest_note(session, sub.id)
    if note:
        lines.append(f"交接笔记: {_clip(note.content, CTX_LIMITS['sub_note'])}")
        if note.risk:
            lines.append(f"未解决风险: {_clip(note.risk, 200)}")
        if note.files:
            lines.append(f"涉及文件: {_clip(note.files, CTX_LIMITS['sub_files'])}")
    else:
        feat = session.exec(
            _select_feats(sub.id)
        ).first()
        if feat:
            lines.append(f"功能: F{feat.seq}「{feat.title}」status={feat.status.value}")
    fail = _latest_failure(session, sub.id)
    if fail:
        lines.append(f"最近失败: {fail}")
    return "\n".join(lines)[: CTX_LIMITS["sub_block_full"]]


def _sub_line(session, sub: m.Task, task: m.Task) -> str:
    """精简版一行/子任务：状态 + 交接要点 + 涉及文件。"""
    note = _latest_note(session, sub.id)
    brief = _clip(note.content, 160) if note else ""
    risk = _clip(note.risk, 100) if note and note.risk else ""
    feats = session.exec(_select_feats(sub.id)).all()
    files = ""
    if feats:
        globs: list[str] = []
        for f in feats:
            for g in (f.file_scope or "").split(","):
                g = g.strip()
                if g and g not in globs:
                    globs.append(g)
        files = ",".join(globs)[: CTX_LIMITS["sub_files"]]
    if not files and note:
        files = _clip(note.files, CTX_LIMITS["sub_files"])
    mark = "（本任务）" if sub.id == task.id and task.parent_task_id is not None else ""
    text = f"- #{sub.id}「{sub.title}」[{sub.status.value}]{mark}"
    if brief:
        text += f" 笔记: {brief}"
    if risk:
        text += f" 风险: {risk}"
    if files:
        text += f" 文件: {files}"
    return text[:400]


def _append_clarify(session, parent: m.Task, parts: list[str]) -> None:
    try:
        msgs = (
            session.exec(
                _select_clarify(parent.id)
            ).all()
        )
        if msgs:
            lines = [f"- {_clip(r.content, CTX_LIMITS['parent_clarify'])}" for r in msgs]
            parts.append("父任务澄清结论（新→旧）:\n" + "\n".join(lines[:3]))
    except Exception:
        pass


def _append_parent_failures(session, parent: m.Task, parts: list[str]) -> None:
    try:
        runs = session.exec(_select_fail_runs(parent.id)).all()
        if runs:
            lines = [
                f"- 命令 `{(r.cmd or '')[:120]}` 退出码 {r.exit_code}: {(r.output_uri or '')[:400]}"
                for r in runs[:2]
            ]
            parts.append("父任务最近失败证据:\n" + "\n".join(lines))
    except Exception:
        pass


def _select_clarify(task_id: int):
    from sqlmodel import select

    return (
        select(m.ClarifyMessage)
        .where(m.ClarifyMessage.task_id == task_id, m.ClarifyMessage.role == "assistant")
        .order_by(m.ClarifyMessage.id.desc())
    )


def _latest_note(session, task_id: int) -> m.HandoffNote | None:
    return (
        session.exec(
            _select_notes(task_id)
        ).first()
    )


def _select_notes(task_id: int):
    from sqlmodel import select

    return (
        select(m.HandoffNote)
        .where(m.HandoffNote.task_id == task_id)
        .order_by(m.HandoffNote.id.desc())
    )


def _select_feats(task_id: int):
    from sqlmodel import select

    return select(m.Feature).where(m.Feature.task_id == task_id).order_by(m.Feature.seq)


def _latest_failure(session, task_id: int) -> str:
    runs = (
        session.exec(
            _select_fail_runs(task_id)
        ).first()
    )
    if runs is None:
        return ""
    return f"`{(runs.cmd or '')[:120]}` exit={runs.exit_code} {_clip(runs.output_uri, 200)}"


def _select_fail_runs(task_id: int):
    from sqlmodel import select

    return (
        select(m.VerifierRun)
        .where(m.VerifierRun.task_id == task_id, m.VerifierRun.exit_code != 0)
        .order_by(m.VerifierRun.id.desc())
    )


def build_handoff_block(
    session,
    task_id: int,
    feature_id: int | None = None,
    kinds: tuple[str, ...] = ("report", "attribution", "research"),
    item_limit: int | None = None,
    block_limit: int | None = None,
) -> str:
    """交接块：某任务（+可选 feature）最近的结构化交接笔记，带来源标签。"""
    try:
        item_limit = item_limit or CTX_LIMITS["handoff_item"]
        block_limit = block_limit or CTX_LIMITS["handoff_block"]
        from sqlmodel import select

        stmt = (
            select(m.HandoffNote)
            .where(m.HandoffNote.task_id == task_id)
            .order_by(m.HandoffNote.id.desc())
        )
        if feature_id is not None:
            stmt = stmt.where(m.HandoffNote.feature_id == feature_id)
        rows = session.exec(stmt).all()
        filtered = [r for r in rows if r.kind in kinds]
        if not filtered:
            return ""
        keep, summary_rows = [], []
        for r in filtered[:9]:
            label = f"[{r.role}·{r.kind}" + (f"第{r.seq}轮" if r.seq else "") + f"]"
            if len(keep) < 3:
                keep.append(f"{label} {_clip(r.content, item_limit)}")
            else:
                summary_rows.append(f"{label} {_clip(r.content, 150)}")
        parts = ["## 交接笔记（agent 生成参考，非验证事实；关键结论以 verify 命令为准）"]
        if summary_rows:
            parts.append("更早记录摘要:\n" + "\n".join(reversed(summary_rows)))
        parts.extend(reversed(keep))
        return "\n\n".join(parts)[:block_limit]
    except Exception:
        return ""
