"""开发 Agent（developer）：单写者（可多实例）。ReAct 写码。"""

from __future__ import annotations

import json
from pathlib import Path

from agentflow.core.partition import feature_write_set
from agentflow.spec.schema import render_spec_prompt
from agentflow.storage import models as m


def compute_target_file(feature: m.Feature, repo_root: Path) -> str:
    """从 related_files / 写集计算目标实现文件。"""
    rels = json.loads(feature.related_files) if feature.related_files else []
    for r in rels:
        if "__init__" not in r:
            return r
    files = feature_write_set(feature, repo_root)
    if files:
        return sorted(files)[0]
    return ""


def build_developer_prompt(
    task: m.Task,
    feature: m.Feature,
    spec_yaml: str,
    project: m.Project,
    target_file: str,
    failure_context: str = "",
    repo_root: Path | None = None,
) -> str:
    """构造 developer 提示：Spec 契约 + 当前功能 + 目标文件 + 项目结构摘要。"""
    func = _infer_func_name(feature.title)



    work_root = Path(repo_root) if repo_root is not None else Path(project.repo_path)
    parts = [
        f"任务标题: {task.title}",
        "",
        render_spec_prompt(_spec_doc(spec_yaml)),
        "",
        "## 当前功能",
        f"seq: {feature.seq}  标题: {feature.title}",
        f"TARGET_FILE: {target_file}",
        f"目标函数: {func}" if func else "",
        f"PROJECT_PATH: {work_root}",
    ]
    if Path(work_root) != Path(project.repo_path):
        parts.append(
            f"（注意：本任务在独立 worktree 中工作，PROJECT_PATH 就是它；shell 命令请以该路径为工作根，"
            f"**不要往主 checkout {project.repo_path} 写任何东西**——那里的写操作会被安全策略拒绝并弹审批卡。）"
        )
    structure = _project_structure_summary(feature, repo_root)
    if structure:
        parts += ["", "## 项目结构摘要（相关文件现有内容，已截断；无需再 read_file 探索这些文件）", structure]
    if failure_context:
        parts += ["", "## 上次失败上下文（勿重复踩坑）", failure_context]
    from agentflow.safety.path import AGENT_TMP_DIR

    parts += [
        "",
        "## 工作区约定（写文件前先读）",
        "- 实现改动只能写本功能写集（file_scope）内的文件；越区写会被租约拒绝。",
        "- **改源码一律走 `edit_file`/`write_file` 工具**，不要用 PowerShell 的 "
        "`(Get-Content <文件>) … | Set-Content <同名文件>` 往返改文件：PS 5.1 的 Get-Content 默认按 ANSI(GBK) 读、"
        "Set-Content 按 utf8 写，**中文注释会被写成乱码**，而且这类命令绕过写集租约、不进绿点。"
        "确需 shell 处理文本时两端都必须显式 `-Encoding utf8`（：fixer 用该写法写坏 4 个源文件注释，"
        "并写进主 checkout，连锁导致主仓库变脏、后续建任务被 FR6 拒绝）。",
        "- 工作根只认上面给出的 PROJECT_PATH（worktree）。**不要 `cd` 到主 checkout 再去改文件**——"
        "主 checkout 是用户的仓库，任务改动必须落在工作根内。",
        "- **不要用递归删除命令清理构建缓存/产物目录**（`.next`、`out`、`__pycache__`、`.pytest_cache` 等）："
        "`rm -rf` / `rmdir /s` / `Remove-Item -Recurse -Force` 命中安全 **deny 档 → 任务直接停机人工**"
        "。"
        f"要清缓存就**改名让路**：`ren` / `Move-Item` 挪到 `{AGENT_TMP_DIR}/trash-<时间戳>/`（免租约、不进交付、可恢复），"
        "或直接跑项目自带的自救脚本（kk_dash 用 `./sop.ps1 reset`）；确需真删除时写明理由交人工。",
        f"- 需要一次性辅助脚本（UI 自测脚本、临时校验脚本等）时，一律写到 `{AGENT_TMP_DIR}/` 下："
        "该目录免写集租约、不纳入绿点与合并，无需审批。",
        f"- 不要往项目根 / pipeline / site 等真实源码目录塞临时脚本（会被拒），也不要依赖 shell heredoc "
        "或 `python -c` 内联长脚本绕路（可能触发命令审批，白耗步数）。",
        "- 重启/清理服务进程时，只按端口或 PID 定位**你自己启动的进程**"
        "（如 `Get-NetTCPConnection -LocalPort <port>` 查 PID 后 `taskkill /PID <pid> /T /F`）；"
        "**严禁 `taskkill /IM node.exe` 这类按映像名的全局捕杀**——那会把宿主机上所有同名进程"
        "（用户的其他应用、dev 工具链）一起杀掉。",
        "- 验收命令若是**关键词存在性/缺席性**检查（`Select-String -Pattern \"xxx\"`、`grep xxx`），"
        "代码、注释、文档字符串里都**不要保留被移除的那个关键词字面量**："
        "缺席断言会命中注释里的字面量而假失败，把你拖进空转的修复循环"
        "（：`flex-wrap` 已从 className 移除，但注释写着「不再 flex-wrap 折行」"
        "→ `if (Select-String 'flex-wrap') { exit 1 }` 判成残留 → fixer 反复空转）。"
        "写注释时换成同义描述（如「不再折行」）。",
        "- **不要翻平台内部文件**：你的契约来源只有「本功能 Spec + 上面的调研/诊断摘要 + 仓库代码」。"
        "`~/.agentflow/` 下的 `agentflow.db`（含 -wal/-shm）、`projects/**/trace/*.jsonl`、日志是**平台自己的运行状态**，"
        "不是你的工作区——从里面 grep/findstr 找上下文**永远不会带来有效信息**，只会烧光步数预算"
        "（：developer 为找回被截断的调研报告尾部，连发 20+ 条 findstr/grep 去扫 agentflow.db 二进制，"
        "还试了 Copy-Item 该 DB（外部路径 → 审批卡 300s），50 步耗尽仍未写代码，单节点 113 万 token）。"
        "信息缺失时**按未知处理**：自己定命名/锚点并按 Spec 字面实现，或写清假设后交 done。",
        "- **等待就绪不要用长睡**：需要等「服务/端口/产物」就绪时，禁止 `Start-Sleep` 长睡"
        "（一次 60~150 秒纯属白烧墙钟——：单个节点 866s 里有 ~490s 花在连续 "
        "`Start-Sleep -Seconds 60/90/100/120/120` 上，占该节点 57%）。正确姿势：① UI 渲染/交互验证一律交给 "
        "`ui_check`（它自己起停服务并按需等待）；② 确需自己等时用**有界轮询**——每 2~3 秒探一次目标"
        "（`Get-NetTCPConnection -LocalPort <p>` / `curl -s -o NUL -w \"%{http_code}\"` / `Test-Path`），"
        "最多 10 次，并在命令里写明「在等什么、等到什么算就绪」。",
        "- **步数预算是硬约束（默认 50 步）**：先把改动写完，再用 `ui_check` 自证，最后 done。"
        "不要把步数花在「确认现状」的长链探索上——Spec/摘要已给的现状**直接采信**；"
        "同一条命令不要重复跑，跑不通就换思路或如实上报，不要靠堆步数撞答案。"
        "- **一步多做（省的是往返步数）**：互不依赖的多个读取/搜索（read_file / grep / glob）"
        "在**同一次响应里并行调用**，别一步一个来回；跨文件的多处改动用一个 `edit_file` 的 "
        "`edits` 数组一次提交（原子：任一处不合法则整体不写）。",
        "- 本功能若含 ui 机审（verify_commands 里 `verifier=ui` 那条）：**改完直接调 `ui_check` 跑它**——"
        "那与合并门禁是**同一套管线**（起服务 → Playwright 执行声明），开发期就能告诉你声明打不打中控件、"
        "改动到底过不过。**不要用 `run_cmd` 手搓 Playwright 脚本、也不要自己起 dev server**"
        "（找解释器/装依赖/试端口/处理 60s 命令超时会把步数预算烧光，还会残留端口占用）："
        "——developer 为自证 UI 连烧 22 步 + 一次 75s 超时，写临时脚本、开 3211 dev server、"
        "反复查端口与日志，最终仍未收敛，任务在预算软顶附近空转。",
        "- `ui_check` 报「选择器不可见」时先分清是**声明缺陷**还是**实现缺陷**：目标控件常只在某个 tab / "
        "筛选档位下渲染（数据为空时组件也可能整体不渲染）——这时该改的是**声明**（`declaration` 参数可传临时声明），"
        "在 actions 里补前置 click 动作再断言；只有确认选择器在页面上真实存在才去改实现。"
        "**临时声明的 JSON 语法以 `ui_check` 工具描述里给出的键表为准**（页级键 / 动作键 / 列表型断言形状），"
        "不要按直觉造键——凭感觉写 `path`/`op` 一类未列出的键会响亮失败，反复起服务重跑会烧光预算"
        "。",
        "- **本功能 `verify_commands` 是硬契约**：即使你判断「行为上已经实现」，"
        "也必须让每条断言**字面通过**——命名、类名、属性、`data-testid`、文件路径都要与 Spec 描述一致。"
        "**不允许**以「已实现 / 无需改动」为由交 0 改动：那会让 smoke 断言直接失败，并触发熔断 → SOS → 人工升级，"
        "任务停在 paused_human（：feature 要求「复用公共 Hook + 指定 testid」，developer 认定行为已存在交 0 改动，"
        "`Select-String useHorizontalWheelScroll` 断言失败 → CB-2 升人工）。若你确信某条断言本身写错了，"
        "不要用 0 改动「赌它」，而要明确报失败并写清哪条断言错在哪。",
        "",
        *_verify_commands_section(feature),
        "请实现当前功能。使用工具完成文件读写，完成后调用 done。",
    ]
    return "\n".join(p for p in parts if p is not None)


def _verify_commands_section(feature: m.Feature) -> list[str]:
    """本功能验收命令**原文**（必须披露给 developer）。"""
    cmds: list[dict] = []
    try:
        raw = json.loads(feature.verify_commands) if feature.verify_commands else []
        if isinstance(raw, list):
            cmds = [c for c in raw if isinstance(c, dict)]
    except Exception:
        cmds = []
    if not cmds:
        return []
    lines = ["", "## 本功能的验收命令（**逐条必须通过；这就是校验与合并门禁会跑的原文**）"]
    for c in cmds:
        lines.append(f"- [{c.get('verifier', '?')}/{c.get('stage') or '?'}] `{c.get('cmd', '')}`")
    lines.append(
        "对照实现：断言里出现的**每个字面量**（`data-testid` 名、类名、属性名、文件路径、关键词）"
        "都必须**原样**出现在代码里——名字不一致就等于没实现（基线没有的就按这里的名字新增）。"
        "先把改动写完，再把这些命令原文跑一遍，全绿再 done。"
    )
    return lines


def _scope_order(feature: m.Feature) -> list[str]:
    """Spec 声明的 file_scope 原始顺序（含 glob 项；供预注文件的优先级排序用）。"""
    try:
        raw = json.loads(feature.file_scope) if feature.file_scope else []
        return [str(x) for x in raw] if isinstance(raw, list) else []
    except Exception:
        return []


def _project_structure_summary(feature: m.Feature, repo_root: Path | None, per_file_limit: int = 3000, max_files: int = 10) -> str:
    """写集 + 相关文件现有内容摘要（每文件截断，最多 max_files 个）。"""
    if repo_root is None:
        return ""
    rels: list[str] = []
    try:
        _ws = set(feature_write_set(feature, repo_root) or [])
    except Exception:
        _ws = set()


    rels = [r for r in _scope_order(feature) if r in _ws]
    rels += [r for r in sorted(_ws) if r not in rels]
    try:
        for rel in (json.loads(feature.related_files) if feature.related_files else []):
            if rel not in rels:
                rels.append(rel)
    except Exception:
        pass
    if not rels:
        return ""
    blocks: list[str] = []
    for rel in rels[:max_files]:
        p = repo_root / rel
        try:
            if not p.is_file():
                continue
            content = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if len(content) > per_file_limit:
            content = content[:per_file_limit] + "\n…（截断）"
        blocks.append(f"--- {rel} ---\n{content}")
    return "\n\n".join(blocks)


def _spec_doc(spec_yaml: str):
    from agentflow.spec.schema import parse_spec

    try:
        return parse_spec(spec_yaml)
    except Exception:
        from agentflow.spec.schema import SpecDoc

        return SpecDoc()


def _infer_func_name(title: str) -> str:
    import re

    m = re.search(r"(?:实现|implement)\s*[:：]?\s*(\w+)\s*(?:函数|方法|function|method)?", title)
    return m.group(1) if m else ""
