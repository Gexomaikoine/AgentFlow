"""SSE 端点：任务级 + 全局（仪表盘）。断线按 Last-Event-ID 补发。"""

from __future__ import annotations

import json

from agentflow.api.auth import verify_token_query
from sse_starlette.sse import EventSourceResponse


def sse_response(request, af, task_id: int | None):
    """构造 SSE 响应（异步生成器）。"""
    if not verify_token_query(af.settings, request.query_params.get("token", "")):
        return EventSourceResponse(({"event": "error", "data": "unauthorized"} for _ in range(1)))

    q = af.bus.subscribe(task_id)
    last_id = request.headers.get("last-event-id", "0")
    after = int(last_id or 0)

    async def gen():



        if task_id is not None:
            for ev in af.event_log.since(task_id, after):
                yield {"event": ev["event"], "id": str(ev["seq"]), "data": json.dumps(ev["payload"], ensure_ascii=False)}
        try:
            while True:
                item = await q.get()
                yield {
                    "event": item["event"],
                    "id": str(item["seq"]),
                    "data": json.dumps(item["payload"], ensure_ascii=False),
                }
        except Exception:
            pass
        finally:
            af.bus.unsubscribe(task_id, q)

    return EventSourceResponse(gen())
