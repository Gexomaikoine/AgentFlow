"""节点 routes（FR3 展开 / FR7 trace）。"""

from __future__ import annotations

from agentflow.api.auth import require_auth
from agentflow.storage import models as m, trace as tr
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlmodel import Session

router = APIRouter(tags=["nodes"])


@router.get("/nodes/{nid}")
def get_node(nid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        n = s.get(m.Node, nid)
        if not n:
            raise HTTPException(404, "node not found")
        return {
            "id": n.id,
            "task_id": n.task_id,
            "feature_id": n.feature_id,
            "seq": n.seq,
            "kind": n.kind,
            "status": n.status.value,
            "retries": n.retries,
            "duration_ms": n.duration_ms,
            "summary": n.summary,
            "started_at": n.started_at,
            "ended_at": n.ended_at,
            "token_in": n.token_in,
            "token_out": n.token_out,
            "rolled_back": n.rolled_back,
        }


@router.get("/nodes/{nid}/trace")
def get_trace(nid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        n = s.get(m.Node, nid)
        if not n:
            raise HTTPException(404, "node not found")
        return {"node_id": nid, "events": tr.read_trace(n.trace_uri) if n.trace_uri else []}
