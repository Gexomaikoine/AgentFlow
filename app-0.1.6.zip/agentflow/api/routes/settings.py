"""模型配置 routes（FR10）。持久化到 config.toml [llm]。"""

from __future__ import annotations

import os
import sys
import threading
import time
import json
from uuid import uuid4

from datetime import datetime, timezone

from agentflow.api.auth import require_auth
from agentflow.storage import models as m
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlmodel import Session, select

router = APIRouter(tags=["settings"])


class ProfileIn(BaseModel):
    model: str
    vision: bool = False
    thinking: bool = False
    effort: str = ""
    base_url: str = ""
    api_key: str = ""
    context_window: int = 0


class ModelsIn(BaseModel):
    provider: str | None = None
    profiles: dict[str, ProfileIn] | None = None
    roles: dict[str, str] | None = None
    api_key: str | None = None
    base_url: str | None = None
    timeout_s: float | None = None


class ModelTestIn(BaseModel):
    """连通性测试入参：均可选。给 profile_name 时按该档案的网关/专用 Key 解析（草稿字段优先）。"""
    api_key: str | None = None
    base_url: str | None = None
    model: str | None = None
    thinking: bool = False
    effort: str = ""
    profile_name: str = ""


class RuleIn(BaseModel):
    title: str = ""
    content: str = ""
    enabled: bool = True


class RetireIn(BaseModel):
    reason: str = ""



@router.get("/settings/selfheal")
def selfheal_summary(request: Request, _: str = Depends(require_auth)):
    """自愈页签数据源：提案档案（全自动生效/丢弃/退役留档）+ 进化评分曲线 + 统计"""
    af = request.app.state.af
    from agentflow.core.evolution import SCORE_WEIGHTS, production_effect

    with Session(af.engine) as s:
        proposals = s.exec(select(m.SelfHealProposal).order_by(m.SelfHealProposal.id.desc())).all()[:50]
        curve = s.exec(select(m.EvolutionEntry).order_by(m.EvolutionEntry.id.desc())).all()[:50]
        sos = s.exec(select(m.SosPacket).order_by(m.SosPacket.id.desc())).all()[:30]
        fails = s.exec(select(m.FailureQueueEntry).where(m.FailureQueueEntry.status == "open")).all()[:30]
        gates = s.exec(select(m.MergeApproval).order_by(m.MergeApproval.id.desc())).all()[:30]
        tasks = {t.id: t.title for t in s.exec(select(m.Task)).all() if t.id}
        status_count = {"adopted": 0, "discarded": 0, "retired": 0}
        for p in proposals:
            if p.status in status_count:
                status_count[p.status] += 1
        scores = [e.score for e in curve]
        return {
            "proposals": [
                {
                    "id": p.id, "task_id": p.task_id, "project_id": p.project_id, "kind": p.kind,
                    "title": p.title, "detail": p.detail, "status": p.status, "origin": p.origin,
                    "payload": p.payload,
                    "evidence_ids": p.evidence_ids, "preflight": p.preflight,
                    "expected_gain": p.expected_gain, "validation": p.validation,
                    "validation_unread": p.validation_unread,
                    "hit_count": p.hit_count, "retired_at": p.retired_at,
                    "created_at": p.created_at, "decided_at": p.decided_at,

                    "production": production_effect(s, p) if p.status == "adopted" else None,
                } for p in proposals
            ],
            "curve": [
                {
                    "id": e.id, "project_id": e.project_id, "task_id": e.task_id,
                    "generation": e.generation, "score": e.score, "triggered": e.triggered,
                    "signals": e.signals, "created_at": e.created_at,
                } for e in curve
            ],
            "stats": {
                **status_count,
                "avg_score_recent": round(sum(scores) / len(scores), 1) if scores else None,
                "curve_total": len(scores),
            },
            "score_weights": {k: {"weight": w, "cap": cap} for k, (w, cap) in SCORE_WEIGHTS.items()},
            "sos": [
                {
                    "id": x.id, "task_id": x.task_id, "trigger": x.trigger, "decision": x.decision,
                    "symptom": x.symptom[:300], "decision_valid": x.decision_valid, "created_at": x.created_at,
                } for x in sos
            ],
            "failures": [
                {
                    "id": f.id, "task_id": f.task_id, "classification": f.classification,
                    "attempts": f.attempts, "status": f.status,
                } for f in fails
            ],
            "gates": [
                {
                    "id": g.id, "task_id": g.task_id, "status": g.status,
                    "reason": g.reason[:200], "decided_at": g.decided_at, "created_at": g.created_at,
                } for g in gates
            ],
            "_titles": tasks,
        }


@router.post("/selfheal/proposals/{pid}/retire")
def retire_proposal(pid: int, body: RetireIn, request: Request, _: str = Depends(require_auth)):
    """事后停用：全自动闭环不设人审前置，这里是事后干预——清除生效配置并留档。"""
    from agentflow.core import evolution

    af = request.app.state.af
    with Session(af.engine) as s:
        p = s.get(m.SelfHealProposal, pid)
        if p is None:
            raise HTTPException(404, "proposal not found")
        if p.status != "adopted":
            raise HTTPException(409, f"提案状态 {p.status} 不可停用（仅已生效）")
        evolution.retire_proposal(s, p, reason=body.reason or "人工停用")
        s.commit()
        af.bus.publish_task(p.task_id, "selfheal.updated", {"task_id": p.task_id, "project_id": p.project_id})
        af.bus.publish_task(p.task_id, "log.appended", {
            "level": "human",
            "message": f"自愈提案已停用：{p.kind} {p.title[:60]}",
        })
        return {"ok": True, "status": p.status}


class ValidateIn(BaseModel):
    mock: bool = False
    suite: str = ""


_VALIDATE_LOCK = threading.Lock()


@router.post("/selfheal/proposals/{pid}/validate")
def validate_proposal(pid: int, body: ValidateIn, request: Request, _: str = Depends(require_auth)):
    """手动触发提案回放验证：后台线程跑回放集（跑完自动清理项目记录），"""
    af = request.app.state.af
    with Session(af.engine) as s:
        p = s.get(m.SelfHealProposal, pid)
        if p is None:
            raise HTTPException(404, "proposal not found")
        if p.status != "adopted":
            raise HTTPException(409, f"提案状态 {p.status} 不可验证（仅已生效）")
        if not _VALIDATE_LOCK.acquire(blocking=False):
            raise HTTPException(409, "已有回放验证在运行，请等它完成后再触发")
        runs = json.loads(p.validation or "[]")
        ts = datetime.now(timezone.utc).isoformat()
        runs.append({"ts": ts, "status": "running", "mock": body.mock, "suite": body.suite or "default"})
        p.validation = json.dumps(runs[-20:], ensure_ascii=False)
        s.add(p)
        s.commit()
        p_task_id = p.task_id

    def _worker() -> None:
        try:
            from agentflow.replay import runner as _replay_runner

            report = _replay_runner.run_suite(body.suite or None, use_mock=body.mock, cleanup=True)
            entry = {
                "status": "done", "suite": report["suite"], "mock": body.mock,
                "report_file": report.get("report_file", ""),
                "cases_total": report["cases_total"], "cases_passed": report["cases_passed"],
                "success_rate": report["success_rate"],
                "tokens_in": report["tokens_in"], "tokens_out": report["tokens_out"],
                "cost_usd": report["cost_usd"], "duration_s": report["duration_s"],
            }
        except Exception as e:
            entry = {"status": "error", "error": f"{type(e).__name__}: {e}"[:500]}
        try:
            with Session(af.engine) as s:
                p = s.get(m.SelfHealProposal, pid)
                if p is None:
                    return
                runs = json.loads(p.validation or "[]")
                for r in runs:
                    if r.get("ts") == ts:
                        r.clear()
                        r.update(entry)
                        r["ts"] = ts
                        break
                p.validation = json.dumps(runs, ensure_ascii=False)
                p.validation_unread = True
                s.add(p)
                s.commit()
            af.bus.publish_task(p_task_id, "selfheal.updated", {"task_id": p_task_id})
        except Exception:
            import sys
            import traceback
            traceback.print_exc(file=sys.stderr)
        finally:
            _VALIDATE_LOCK.release()

    threading.Thread(target=_worker, daemon=True, name=f"selfheal-validate-{pid}").start()
    return {"ok": True, "ts": ts}


@router.post("/selfheal/proposals/{pid}/validation-read")
def mark_validation_read(pid: int, request: Request, _: str = Depends(require_auth)):
    """清除提案验证结果的未读标记（自愈页签绿点点击后调用）。"""
    af = request.app.state.af
    with Session(af.engine) as s:
        p = s.get(m.SelfHealProposal, pid)
        if p is None:
            raise HTTPException(404, "proposal not found")
        p.validation_unread = False
        s.add(p)
        s.commit()
        return {"ok": True}


@router.get("/selfheal/reports/{fname}")
def get_replay_report(fname: str, request: Request, _: str = Depends(require_auth)):
    """读取回放报表 JSON（自愈页签 Report 详情弹窗）。文件名白名单校验防路径穿越。"""
    import re

    if not re.fullmatch(r"\d{8}-\d{6}-.+\.json", fname):
        raise HTTPException(422, "非法报表文件名")
    path = request.app.state.af.settings.home / "replay_reports" / fname
    if not path.is_file():
        raise HTTPException(404, "report not found")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise HTTPException(500, f"报表解析失败: {e}")


@router.get("/settings/models")
def get_models(request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    out = dict(af.settings.data["llm"])
    out["profiles"] = _profiles_out(af.settings.home, out.get("profiles") or {})
    return {**out, "key_status": _key_status(), "routing": _routing_view(af.settings)}


def _profiles_out(home, profiles: dict) -> dict:
    """档案响应装配：补 has_key（档案专用 Key 是否已配置），绝不回传 Key 本身。"""
    from agentflow.llm.gateway import profile_env_key

    return {
        name: {**p, "has_key": bool(os.environ.get(profile_env_key(name), "").strip())}
        for name, p in profiles.items()
    }


@router.put("/settings/models")
def put_models(body: ModelsIn, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    llm = af.settings.data["llm"]
    if body.provider is not None:
        llm["provider"] = body.provider
    elif str(llm.get("provider") or "") == "mock" and (body.api_key or "").strip():




        llm["provider"] = "openai"
    if body.profiles is not None:
        from agentflow.llm.gateway import norm_base_url, profile_env_key

        new_profiles: dict = {}
        for name, p in body.profiles.items():
            n = name.strip()
            if not n:
                raise HTTPException(422, "模型档案名不能为空")
            if not p.model.strip():
                raise HTTPException(422, f"模型档案 {n!r} 缺少模型名")
            effort = p.effort.strip()
            if len(effort) > 32 or '"' in effort:
                raise HTTPException(422, f"模型档案 {n!r} 思考档位非法：{p.effort!r}（≤32 字符，自由填写如 high/minimal/2）")

            if p.api_key.strip():
                kvar = profile_env_key(n)
                os.environ[kvar] = p.api_key.strip()
                _update_env_file(af.settings.home, {kvar: p.api_key.strip()})
            new_profiles[n] = {
                "model": p.model.strip(),
                "vision": p.vision,
                "thinking": p.thinking,
                "effort": effort,
                "base_url": norm_base_url(p.base_url),
            }
            cw = int(p.context_window or 0)
            if cw:
                if not (1_000 <= cw <= 10_000_000):
                    raise HTTPException(422, f"模型档案 {n!r} 上下文窗口非法：{cw}（token，合理范围 1000~10000000）")
                new_profiles[n]["context_window"] = cw
        llm["profiles"] = new_profiles
    if body.roles is not None:
        merged = dict(llm.get("roles") or {})
        merged.update(body.roles)
        profiles = llm.get("profiles") or {}
        missing = sorted(r for r, v in merged.items() if not str(v).strip())
        unknown = sorted({str(v).strip() for v in merged.values() if str(v).strip() and str(v).strip() not in profiles})
        if missing:

            raise HTTPException(422, f"以下角色未分配模型档案：{', '.join(missing)}（角色必须显式指档，无默认回退）")
        if unknown:
            raise HTTPException(422, f"角色指向了不存在的模型档案：{', '.join(unknown)}")
        llm["roles"] = merged
    if body.base_url is not None or body.timeout_s is not None:
        from agentflow.llm.gateway import norm_base_url

        oa = llm.setdefault("openai", {})
        if body.base_url is not None:
            oa["base_url"] = norm_base_url(body.base_url)
        if body.timeout_s is not None:
            if body.timeout_s <= 0 or body.timeout_s > 3600:
                raise HTTPException(422, "timeout_s 须在 (0, 3600] 秒内")
            oa["timeout_s"] = body.timeout_s



    if body.api_key is not None and body.api_key.strip():
        key = body.api_key.strip()
        os.environ.pop("OPENCODE_API_KEY", None)
        os.environ["OPENAI_API_KEY"] = key
        _update_env_file(af.settings.home, {"OPENCODE_API_KEY": None, "OPENAI_API_KEY": key})
    _write_toml(af.settings.home, af.settings.data)
    af.gateway.rebuild()
    out = dict(llm)
    out["profiles"] = _profiles_out(af.settings.home, out.get("profiles") or {})
    return {**out, "key_status": _key_status()}


def _probe(model: str, base_url: str, key: str, thinking: bool, effort: str,
           timeout_s: float, use_opencode_hdr: bool) -> dict:
    """发一次最小流式请求做连通性探测（不抛异常，返回 {ok,latency_ms,…} 或 {ok:False,error}）。"""
    try:
        from openai import OpenAI

        kwargs: dict = {"api_key": key, "timeout": min(float(timeout_s), 120.0), "max_retries": 0}
        if base_url:
            kwargs["base_url"] = base_url
        if use_opencode_hdr:
            kwargs["default_headers"] = {"X-Opencode-Session": str(uuid4())}
        client = OpenAI(**kwargs)
        create_kwargs: dict = {
            "model": model,
            "messages": [{"role": "user", "content": "只回复两个字：OK"}],
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        eff = (effort or "").strip() if thinking else ""
        if eff:
            create_kwargs["reasoning_effort"] = eff
        t0 = time.monotonic()
        parts: list[str] = []
        usage = None
        for chunk in client.chat.completions.create(**create_kwargs):
            if getattr(chunk, "usage", None):
                usage = chunk.usage
            if chunk.choices:
                d = chunk.choices[0].delta
                if d and d.content:
                    parts.append(d.content)
        return {
            "ok": True,
            "model": model,
            "latency_ms": int((time.monotonic() - t0) * 1000),
            "reply": "".join(parts).strip()[:100],
            "tokens_in": usage.prompt_tokens if usage else 0,
            "tokens_out": usage.completion_tokens if usage else 0,
        }
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"[:500], "model": model}


def _routing_view(settings) -> list[dict]:
    """每个角色 → **实际生效**的档案/模型/网关/Key 来源（设置→模型 页签展示）。"""
    from agentflow.llm.gateway import norm_base_url, profile_env_key

    llm = settings.data["llm"]
    profiles = llm.get("profiles") or {}
    roles = llm.get("roles") or {}
    oa = llm.get("openai") or {}
    global_base = norm_base_url(str(oa.get("base_url") or "")) or os.environ.get("OPENAI_BASE_URL", "").strip()
    global_key = bool(os.environ.get("OPENCODE_API_KEY", "").strip() or os.environ.get("OPENAI_API_KEY", "").strip())
    out: list[dict] = []
    for role in sorted(roles):
        name = str(roles.get(role) or "").strip()
        p = profiles.get(name) or {}
        own_base = norm_base_url(str(p.get("base_url") or ""))
        own_key = bool(os.environ.get(profile_env_key(name), "").strip()) if name else False
        out.append({
            "role": role,
            "profile": name,
            "model": str(p.get("model") or ""),
            "base_url": own_base or global_base,
            "gateway_source": "profile" if own_base else ("global" if global_base else "none"),
            "key_source": "profile" if own_key else ("global" if global_key else "none"),
            "thinking": bool(p.get("thinking")),
            "effort": str(p.get("effort") or ""),
        })
    return out


@router.get("/settings/routing")
def get_routing(request: Request, _: str = Depends(require_auth)):
    """当前路由：角色 → 生效档案/模型/网关/Key 来源。"""
    af = request.app.state.af
    return {"routing": _routing_view(af.settings)}


@router.post("/settings/routing/test")
def test_routing(request: Request, _: str = Depends(require_auth)):
    """逐档案连通性测试（去重角色引用的档案，逐个发最小请求）。"""
    af = request.app.state.af
    llm = af.settings.data["llm"]
    oa = llm.get("openai", {})
    from agentflow.llm.gateway import norm_base_url, profile_env_key

    names: list[str] = []
    for name in (llm.get("roles") or {}).values():
        n = str(name or "").strip()
        if n and n not in names:
            names.append(n)
    results = []
    for name in names:
        p = (llm.get("profiles") or {}).get(name) or {}
        base = norm_base_url(str(p.get("base_url") or "")) or norm_base_url(str(oa.get("base_url") or "")) \
            or os.environ.get("OPENAI_BASE_URL", "").strip()
        key = os.environ.get(profile_env_key(name), "").strip() \
            or os.environ.get("OPENCODE_API_KEY", "").strip() or os.environ.get("OPENAI_API_KEY", "").strip()
        row = {
            "profile": name,
            "model": str(p.get("model") or ""),
            "base_url": base,
            "gateway_source": "profile" if norm_base_url(str(p.get("base_url") or "")) else "global",
        }
        if not key:
            results.append({**row, "ok": False, "error": "无可用 Key"})
            continue
        probe = _probe(
            model=row["model"], base_url=base, key=key, thinking=bool(p.get("thinking")),
            effort=str(p.get("effort") or ""), timeout_s=float(oa.get("timeout_s", 150)),
            use_opencode_hdr=("opencode.ai" in base.lower()),
        )
        results.append({**row, **probe})
    return {"results": results, "ok": all(r.get("ok") for r in results) if results else False}


class GitSettingsIn(BaseModel):
    protocol: str | None = None
    prefer: list[str] | None = None
    use_proxy: bool | None = None
    proxy: str | None = None


@router.get("/settings/git")
def get_git_settings(request: Request, _: str = Depends(require_auth)):
    """远端传输策略（设置→Git 页签）。"""
    af = request.app.state.af
    return {"git": dict(af.settings.data.get("git") or {})}


@router.put("/settings/git")
def put_git_settings(body: GitSettingsIn, request: Request, _: str = Depends(require_auth)):
    """保存远端传输策略：协议（auto/ssh/https）、优先顺序、是否走代理与代理地址。"""
    af = request.app.state.af
    git = dict(af.settings.data.get("git") or {})
    if body.protocol is not None:
        proto = body.protocol.strip().lower()
        if proto not in ("auto", "ssh", "https"):
            raise HTTPException(422, "protocol 只能是 auto / ssh / https")
        git["protocol"] = proto
    if body.prefer is not None:
        prefer = [str(s).strip().lower() for s in body.prefer if str(s).strip().lower() in ("ssh", "https")]
        if not prefer:
            raise HTTPException(422, "prefer 至少包含 ssh / https 之一")
        git["prefer"] = list(dict.fromkeys(prefer))
    if body.use_proxy is not None:
        git["use_proxy"] = bool(body.use_proxy)
    if body.proxy is not None:
        proxy = body.proxy.strip()
        if proxy and not proxy.lower().startswith(("http://", "https://", "socks5://", "socks5h://")):
            raise HTTPException(422, "proxy 需形如 http://127.0.0.1:7890")
        git["proxy"] = proxy
    af.settings.data["git"] = git
    _write_toml(af.settings.home, af.settings.data)
    return {"ok": True, "git": git}


@router.post("/settings/models/test")
def test_models(body: ModelTestIn, request: Request, _: str = Depends(require_auth)):
    '''连通性测试（模型页签"测试"按钮）：用表单草稿（优先）或已保存配置发一次最小流式请求。'''
    af = request.app.state.af
    llm = af.settings.data["llm"]
    oa = llm.get("openai", {})
    from agentflow.llm.gateway import norm_base_url, profile_env_key

    prof = (llm.get("profiles") or {}).get(body.profile_name.strip()) if body.profile_name.strip() else None
    if body.profile_name.strip() and prof is None:
        return {"ok": False, "error": f"档案 {body.profile_name!r} 不存在（请先保存）"}

    draft_base = norm_base_url(body.base_url or "")
    base_url = draft_base or norm_base_url(str((prof or {}).get("base_url") or "")) \
        or norm_base_url(oa.get("base_url", "")) or os.environ.get("OPENAI_BASE_URL", "").strip()

    draft_key = (body.api_key or "").strip()
    if draft_key:
        key = draft_key
    else:
        key = ""
        if prof is not None:
            key = os.environ.get(profile_env_key(body.profile_name.strip()), "").strip()
        key = key or os.environ.get("OPENCODE_API_KEY", "").strip() or os.environ.get("OPENAI_API_KEY", "").strip()
    model = (body.model or "").strip() or str((prof or {}).get("model") or "")
    if not key:
        return {"ok": False, "error": "未配置 API Key：请在上方填入后保存，或先填 Key 再测试"}
    if not model:
        return {"ok": False, "error": "未配置模型名"}
    return _probe(
        model=model, base_url=base_url, key=key, thinking=body.thinking,
        effort=body.effort, timeout_s=float(oa.get("timeout_s", 150)),
        use_opencode_hdr=(
            "opencode.ai" in base_url.lower()
            or bool(not draft_key and not prof and os.environ.get("OPENCODE_API_KEY", "").strip())
        ),
    )


def _key_status() -> dict:
    """当前生效 Key 的脱敏状态（只回前缀/后缀，绝不回完整 Key）。"""
    k = os.environ.get("OPENCODE_API_KEY", "").strip()
    via = "OPENCODE_API_KEY"
    if not k:
        k = os.environ.get("OPENAI_API_KEY", "").strip()
        via = "OPENAI_API_KEY" if k else None
    if not k:
        return {"set": False, "via": None, "masked": None}
    masked = f"{k[:6]}…{k[-4:]}" if len(k) > 14 else f"{k[:6]}…"
    return {"set": True, "via": via, "masked": masked}


def _update_env_file(home, updates: dict) -> None:
    """更新 ~/.agentflow/.env 中的指定变量：存在则原位替换，None 删除该行，缺省追加。"""
    env_file = home / ".env"
    if env_file.exists():
        lines = env_file.read_text(encoding="utf-8").splitlines()
    else:
        lines = ["# AgentFlow API 密钥存储（不提交 git，不入库，仅内存加载）"]
    for key, val in updates.items():
        idx = next((i for i, ln in enumerate(lines) if ln.strip().startswith(f"{key}=")), None)
        if val is None:
            if idx is not None:
                lines.pop(idx)
        elif idx is None:
            lines.append(f"{key}={val}")
        else:
            lines[idx] = f"{key}={val}"
    env_file.write_text("\n".join(lines) + "\n", encoding="utf-8")



@router.get("/settings/global-rules")
def list_global_rules(request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        rows = s.exec(
            select(m.GlobalRule).order_by(m.GlobalRule.sort_order, m.GlobalRule.id)
        ).all()
        return [_rule_dto(r) for r in rows]


@router.post("/settings/global-rules")
def create_global_rule(body: RuleIn, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        max_order = s.exec(
            select(m.GlobalRule.sort_order).order_by(m.GlobalRule.sort_order.desc())
        ).first()
        rule = m.GlobalRule(
            title=body.title.strip()[:60],
            content=body.content.strip()[:2000],
            enabled=body.enabled,
            sort_order=(max_order or 0) + 1,
        )
        s.add(rule)
        s.commit()
        return _rule_dto(rule)


@router.put("/settings/global-rules/{rid}")
def update_global_rule(rid: int, body: RuleIn, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        rule = s.get(m.GlobalRule, rid)
        if not rule:
            raise HTTPException(404, "rule not found")
        rule.title = body.title.strip()[:60]
        rule.content = body.content.strip()[:2000]
        rule.enabled = body.enabled
        s.add(rule)
        s.commit()
        return _rule_dto(rule)


@router.delete("/settings/global-rules/{rid}")
def delete_global_rule(rid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        rule = s.get(m.GlobalRule, rid)
        if not rule:
            raise HTTPException(404, "rule not found")
        s.delete(rule)
        s.commit()
        return {"ok": True}


def _rule_dto(r: m.GlobalRule) -> dict:
    return {
        "id": r.id,
        "title": r.title,
        "content": r.content,
        "enabled": r.enabled,
        "sort_order": r.sort_order,
        "created_at": r.created_at,
    }



@router.post("/settings/restart")
def restart_executor(request: Request, _: str = Depends(require_auth)):
    """一键重启执行面：拉起看门狗（等端口释放后重启 serve），旧进程延迟退出。"""
    af = request.app.state.af
    port = af.settings.data["server"]["port"]
    try:
        from agentflow.core.selfhost import perform_restart

        perform_restart(int(port))
    except Exception as e:
        raise HTTPException(500, f"重启看门狗拉起失败: {e}")
    return {"ok": True, "message": "执行面重启中，预计 3~5 秒后恢复"}


def _toml_key(k: str) -> str:
    """TOML 键：裸键仅允许 A-Za-z0-9_-，其余（如档案名 'glm-5.3-flash' 含点）加引号。"""
    import re

    return k if re.fullmatch(r"[A-Za-z0-9_-]+", k) else f'"{k}"'


def _write_toml(home, data: dict) -> None:
    """简易 TOML 序列化（覆盖 [llm]/[scheduler] 等基础配置，支持三层嵌套如 [llm.profiles.x]）。"""
    lines = []
    for section, sub in data.items():
        if not isinstance(sub, dict):
            continue
        lines.append(f"[{section}]")

        for k, v in sub.items():
            if not isinstance(v, dict):
                lines.append(f"{_toml_key(k)} = {_fmt(v)}")

        for k, v in sub.items():
            if not isinstance(v, dict):
                continue
            if v and all(isinstance(v2, dict) for v2 in v.values()):

                for k2, v2 in v.items():
                    lines.append(f"[{section}.{_toml_key(k)}.{_toml_key(k2)}]")
                    for k3, v3 in v2.items():
                        lines.append(f"{_toml_key(k3)} = {_fmt(v3)}")
            else:
                lines.append(f"[{section}.{_toml_key(k)}]")
                for k2, v2 in v.items():
                    lines.append(f"{_toml_key(k2)} = {_fmt(v2)}")
        lines.append("")
    (home / "config.toml").write_text("\n".join(lines), encoding="utf-8")


def _fmt(v) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, list):
        return "[" + ", ".join(_fmt(x) for x in v) + "]"

    return json.dumps(v, ensure_ascii=False)



@router.get("/settings/env")
def get_env(request: Request, _: str = Depends(require_auth)):
    """本机能力检测：平台自用运行时（Python/git/playwright）+ 项目侧（Node）+ 端口占用"""
    af = request.app.state.af
    from agentflow.core.env_probe import probe_environment

    with Session(af.engine) as s:
        rows = s.exec(select(m.Project).order_by(m.Project.sort_order, m.Project.id)).all()
        projects = [
            {
                "id": p.id,
                "name": p.name,
                "archived": bool(p.archived_at),
                "stack": json.loads(p.stack) if p.stack else {},
            }
            for p in rows
        ]
    return probe_environment(af.settings, projects)



@router.get("/settings/first-run")
def first_run_status(request: Request, _: str = Depends(require_auth)):
    """首次运行判定：**模型没配好（无档案 / 无 Key / 角色未指派）就必须走向导** —— 否则"""
    af = request.app.state.af
    llm = af.settings.data["llm"]
    profiles = llm.get("profiles") or {}
    roles = llm.get("roles") or {}
    key_set = bool(
        os.environ.get("OPENCODE_API_KEY", "").strip() or os.environ.get("OPENAI_API_KEY", "").strip()
    )
    with Session(af.engine) as s:
        project_count = len(s.exec(select(m.Project)).all())

    missing: list[str] = []
    if not key_set:
        missing.append("api_key")
    if not profiles:
        missing.append("profiles")
    unassigned = sorted(r for r, v in roles.items() if not str(v or "").strip())
    if unassigned:
        missing.append("roles")
    if project_count == 0:
        missing.append("project")

    blocking = [x for x in missing if x in ("api_key", "profiles", "roles")]
    return {
        "needs_setup": bool(blocking),
        "missing": missing,
        "blocking": blocking,
        "unassigned_roles": unassigned,
        "api_key_set": key_set,
        "project_count": project_count,
    }



class UpdateConfigIn(BaseModel):
    enabled: bool | None = None
    manifest_url: str | None = None
    api_url: str | None = None
    token_env: str | None = None
    token: str | None = None


@router.get("/settings/update")
def get_update(request: Request, _: str = Depends(require_auth)):
    """检查应用层更新（只读）。仅安装形态可用；源码树/开发态返回 supported=false。"""
    af = request.app.state.af
    from agentflow.core.updater import check_update

    return check_update(af.settings)


@router.put("/settings/update")
def put_update(body: UpdateConfigIn, request: Request, _: str = Depends(require_auth)):
    """更新源配置（地址 / 模式 / 令牌），落 config.toml [update]；令牌只落 .env。"""
    af = request.app.state.af
    cfg = dict(af.settings.data.get("update") or {})
    if body.enabled is not None:
        cfg["enabled"] = bool(body.enabled)
    if body.manifest_url is not None:
        cfg["manifest_url"] = body.manifest_url.strip()
    if body.api_url is not None:
        cfg["api_url"] = body.api_url.strip().rstrip("/")
    if body.token_env is not None:
        cfg["token_env"] = body.token_env.strip()
    if body.token is not None and body.token.strip():
        kvar = str(cfg.get("token_env") or "AGENTFLOW_UPDATE_TOKEN")
        os.environ[kvar] = body.token.strip()
        _update_env_file(af.settings.home, {kvar: body.token.strip()})
    af.settings.data["update"] = cfg
    _write_toml(af.settings.home, af.settings.data)

    from agentflow.core.updater import check_update

    return {"ok": True, "update": cfg, "status": check_update(af.settings)}


@router.post("/settings/update/apply")
def apply_update_ep(request: Request, _: str = Depends(require_auth)):
    """开始下载新 app 层（后台执行，立即返回）：服务稍后重启切到新版（失败自动回滚）。"""
    af = request.app.state.af
    from agentflow.core.updater import apply_update

    return apply_update(af.settings)


@router.get("/settings/update/progress")
def get_update_progress(request: Request, _: str = Depends(require_auth)):
    """更新进度快照（前端轮询）：阶段 / 已下载字节 / 错误；重启后的进程从落盘状态恢复结果。"""
    af = request.app.state.af
    from agentflow.core.updater import update_progress

    return update_progress(af.settings)
