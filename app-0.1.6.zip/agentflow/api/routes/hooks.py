"""外部 webhook 回流：CD 部署事件接收（ghook → AgentFlow）。"""

from __future__ import annotations

import json
import secrets as _secrets
from datetime import datetime, timedelta, timezone

from agentflow.api.auth import ensure_hook_token, require_auth
from agentflow.storage import models as m
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlmodel import Session, select

router = APIRouter(tags=["hooks"])
read_router = APIRouter(prefix="/api/v1", tags=["hooks"])

_RESULT_WHITELIST = {"success", "smoke_fail", "rollback", "fail"}


class CdEventIn(BaseModel):
    project: str
    env: str = "prod"
    trigger: str = "manual"
    prev_sha: str = ""
    new_sha: str = ""
    result: str = "success"
    stages: list[dict] = []
    log_ref: str = ""
    finished_at: str = ""


def _now_cst() -> str:
    return datetime.now(timezone(timedelta(hours=8))).isoformat()


@router.post("/hooks/cd-events")
def receive_cd_event(body: CdEventIn, request: Request):
    af = request.app.state.af
    tok = ensure_hook_token(af.settings)
    auth = request.headers.get("authorization", "")
    if not _secrets.compare_digest(auth.removeprefix("Bearer ").strip(), tok):
        raise HTTPException(status_code=401, detail="invalid hook token")

    if not body.project or body.result not in _RESULT_WHITELIST:
        raise HTTPException(status_code=422, detail="invalid project or result")


    allowed = {"name", "ok", "ms", "skipped", "routes", "json", "tail"}
    stages = [{k: v for k, v in st.items() if k in allowed} for st in body.stages]

    ev = m.CdEvent(
        project_name=body.project,
        env=body.env or "prod",
        trigger=body.trigger,
        prev_sha=body.prev_sha,
        new_sha=body.new_sha,
        result=body.result,
        stages=json.dumps(stages, ensure_ascii=False),
        log_ref=body.log_ref,
        finished_at=body.finished_at or _now_cst(),
    )
    with Session(af.engine) as s:
        s.add(ev)
        s.commit()
        s.refresh(ev)
    return {"ok": True, "event_id": ev.id}


@read_router.get("/hooks/cd-events")
def list_cd_events(
    request: Request,
    project: str = "",
    limit: int = 20,
    task_id: int = 0,
    _: str = Depends(require_auth),
):
    """CD 页签数据源：按项目名倒序列出部署事件。"""
    af = request.app.state.af
    with Session(af.engine) as s:
        q = select(m.CdEvent).where(m.CdEvent.project_name == project)
        merged_sha = ""
        if task_id:
            entry = (
                s.exec(
                    select(m.MergeQueueEntry)
                    .where(m.MergeQueueEntry.task_id == task_id, m.MergeQueueEntry.status == "merged")
                    .order_by(m.MergeQueueEntry.id.desc())
                )
            ).first()
            merged_sha = (entry.merged_sha or "").strip() if entry else ""
            if not merged_sha:
                return []

            q = q.where(m.CdEvent.new_sha == merged_sha)
        rows = s.exec(q).all()
        if task_id and merged_sha:
            rows = rows + _cd_events_containing(s, project, merged_sha, exclude_ids={r.id for r in rows})
    rows.sort(key=lambda r: r.id or 0, reverse=True)
    return [
        {
            "id": r.id,
            "project": r.project_name,
            "env": r.env,
            "trigger": r.trigger,
            "prev_sha": r.prev_sha,
            "new_sha": r.new_sha,
            "result": r.result,
            "stages": json.loads(r.stages or "[]"),
            "log_ref": r.log_ref,
            "finished_at": r.finished_at,
            "received_at": r.received_at,
        }
        for r in rows[: max(1, min(limit, 100))]
    ]


def _cd_events_containing(session, project: str, merged_sha: str, exclude_ids: set | None = None):
    '''找出"部署 tip 包含该任务合并提交"的 CD 事件（new_sha 是 merged_sha 的后代）。'''
    from pathlib import Path

    from agentflow.git_runtime.repo import RepoHandle

    exclude_ids = exclude_ids or set()
    proj = session.exec(select(m.Project).where(m.Project.name == project)).first()
    if proj is None:
        return []
    try:
        repo = RepoHandle(Path(proj.repo_path))
    except Exception:
        return []
    recent = session.exec(
        select(m.CdEvent).where(m.CdEvent.project_name == project).order_by(m.CdEvent.id.desc()).limit(50)
    ).all()
    out = []
    for r in recent:
        if (r.id in exclude_ids) or not (r.new_sha or "").strip():
            continue
        try:
            rc = repo.repo.git.execute(
                ["git", "merge-base", "--is-ancestor", merged_sha, r.new_sha.strip()],
                with_extended_output=True, with_exceptions=False,
            )
            ok = (rc[0] if isinstance(rc, tuple) else rc) == 0
        except Exception:
            ok = False
        if ok:
            out.append(r)
    return out
