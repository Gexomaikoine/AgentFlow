"""本机目录浏览（接入项目时选仓库目录用）。"""

from __future__ import annotations

import os
import stat as stat_mod
from pathlib import Path

from agentflow.api.auth import require_auth
from fastapi import APIRouter, Depends, HTTPException

router = APIRouter(tags=["fs"])


MAX_DIRS = 500


def _window_drives() -> list[dict]:
    """Windows 盘符清单（GetLogicalDrives 位掩码，比逐个 exists() 探测快）。"""
    import ctypes

    mask = ctypes.windll.kernel32.GetLogicalDrives()
    return [
        {"name": f"{chr(65 + i)}:", "path": f"{chr(65 + i)}:\\"}
        for i in range(26)
        if mask & (1 << i)
    ]


def _is_hidden_or_system(entry: os.DirEntry) -> bool:
    """Windows 隐藏/系统属性目录（$RECYCLE.BIN、AppData 等）不进浏览器。"""
    if os.name != "nt":
        return False
    try:
        attrs = entry.stat(follow_symlinks=False).st_file_attributes
    except OSError:
        return False
    return bool(attrs & (stat_mod.FILE_ATTRIBUTE_HIDDEN | stat_mod.FILE_ATTRIBUTE_SYSTEM))


def _resolve(raw: str) -> Path:
    text = (raw or "").strip()
    if not text:
        return Path.home()
    p = Path(text).expanduser()
    if not p.is_absolute():
        p = Path.home() / p
    try:
        return p.resolve()
    except OSError as e:
        raise HTTPException(400, f"路径无效: {e}") from e


def _parent_of(p: Path) -> str | None:
    """上级目录；盘符根（C:\\）与文件系统根无上级，返回 None。"""
    if p.parent == p:
        return None
    return str(p.parent)


@router.get("/fs/dirs")
def list_dirs(path: str = "", _: str = Depends(require_auth)):
    """列出 path 下的子目录 + 上级路径 + 盘符清单（path 空则落到用户主目录）。"""
    target = _resolve(path)
    if not target.is_dir():
        raise HTTPException(400, f"目录不存在: {target}")

    dirs: list[dict] = []
    truncated = False
    try:
        with os.scandir(target) as it:
            entries = sorted(it, key=lambda e: e.name.lower())
    except PermissionError as e:
        raise HTTPException(400, f"无权限访问: {target}") from e

    for entry in entries:
        if not entry.is_dir(follow_symlinks=False):
            continue
        if _is_hidden_or_system(entry):
            continue
        if len(dirs) >= MAX_DIRS:
            truncated = True
            break
        try:
            child = Path(entry.path)
            dirs.append({
                "name": entry.name,
                "path": str(child),
                "is_git": (child / ".git").exists(),
            })
        except OSError:
            continue

    return {
        "path": str(target),
        "parent": _parent_of(target),
        "dirs": dirs,
        "truncated": truncated,
        "roots": _window_drives() if os.name == "nt" else [{"name": "/", "path": "/"}],
    }
