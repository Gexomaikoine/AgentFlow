"""任务 routes（FR1/FR2/FR3/FR6/FR8）。"""

from __future__ import annotations

import asyncio
import json
import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from agentflow.agents.lead import clarify_round, generate_spec
from agentflow.api.auth import require_auth, require_auth_or_query
from agentflow.api.events import sse_response
from agentflow.api.routes.projects import _main_synced_with_origin, _reconcile_all_pending_push
from agentflow.core.budget import budget_snapshot, fmt_tokens
from agentflow.core.scheduler import TaskRunner
from agentflow.core.services import HARNESS_MARK
from agentflow.git_runtime import anchors as anchors_mod, branch, merge as merge_mod
from agentflow.git_runtime.repo import GitError, RepoHandle
from agentflow.spec.schema import parse_spec
from agentflow.storage import models as m
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import func
from sqlmodel import Session, select

router = APIRouter(tags=["tasks"])


def _loads_detail(raw: str | None) -> dict | None:
    """VerifierRun.detail（JSON 文本）→ dict；损坏数据响亮降级为 None（前端回退文本）。"""
    if not raw:
        return None
    try:
        d = json.loads(raw)
        return d if isinstance(d, dict) else None
    except Exception:
        return None


class TaskIn(BaseModel):
    project_id: int
    title: str
    raw_request: str = ""

    images: list[str] = []


class ClarifyIn(BaseModel):
    message: str = ""

    images: list[str] = []


class RollbackIn(BaseModel):
    anchor_id: int


class HumanIn(BaseModel):
    text: str = ""
    option: str = ""

    images: list[str] = []


class ApprovalIn(BaseModel):
    decision: str


class RenameIn(BaseModel):
    title: str = ""


class BudgetIn(BaseModel):
    """任务级预算上限覆盖（不传的一项沿用全局默认，见 set_task_budget）。"""

    task_max_tokens: int | None = None
    task_max_cost_usd: float | None = None


class SubtaskIn(BaseModel):
    """P0 任务树：在父任务底下起子任务（bug 跟进/联动需求）。origin 白名单校验在端点内。"""

    title: str
    raw_request: str = ""
    origin: str = "user_followup"

    images: list[str] = []



def _clarify_status_writeback(af, s, t, tid: int) -> None:
    """首轮澄清完成后的状态写回（竞态保护）：只在任务仍在澄清流（draft/clarifying）时收窄写回。"""
    s.refresh(t)
    if t.status in (m.TaskStatus.draft, m.TaskStatus.clarifying):
        t.status = m.TaskStatus.clarifying
        s.add(t)
        s.commit()
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "clarifying"})


@router.post("/tasks")
def create_task(body: TaskIn, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        proj = s.get(m.Project, body.project_id)
        if not proj:
            raise HTTPException(404, "project not found")

        try:
            repo = RepoHandle(proj.repo_path)
        except Exception as e:
            raise HTTPException(400, str(e))
        if not repo.is_clean():
            raise HTTPException(400, "主 checkout 有未提交改动，拒绝创建任务（FR6）")
        running = s.exec(select(m.Task).where(m.Task.project_id == body.project_id, m.Task.status == m.TaskStatus.running)).all()


        use_wt = bool(af.settings.data["scheduler"].get("per_task_worktree", False))
        if running and not use_wt:
            raise HTTPException(400, "同项目同时仅允许 1 个运行任务（FR6）")
        task = m.Task(project_id=body.project_id, title=body.title, raw_request=body.raw_request)
        s.add(task)
        s.commit()
        tid = task.id


    image_names = _save_clarify_images(af.settings, tid, body.images)
    if body.raw_request or image_names:
        with Session(af.engine) as s:
            um = m.ClarifyMessage(task_id=tid, role="user", content=body.raw_request or "", images=json.dumps(image_names))
            s.add(um)
            s.commit()
            s.refresh(um)
            af.bus.publish_task(
                tid, "clarify.message",
                {"task_id": tid, "id": um.id, "role": "user", "content": body.raw_request or "", "images": image_names},
            )



    def _auto_first_clarify(user_images: list[str]) -> None:
        with Session(af.engine) as s:
            t = s.get(m.Task, tid)
            if t is None:
                return
            try:
                reply = clarify_round(af.gateway, s, t, "", user_images=user_images or None, bus=af.bus)
                am = m.ClarifyMessage(task_id=tid, role="assistant", content=reply)
                s.add(am)
                s.commit()
                s.refresh(am)




                _clarify_status_writeback(af, s, t, tid)
                af.bus.publish_task(tid, "clarify.message", {"task_id": tid, "id": am.id, "role": "assistant", "content": reply})
            except Exception as e:

                fallback = f"（自动澄清失败：{e}，请手动发送消息重试）"
                am = m.ClarifyMessage(task_id=tid, role="assistant", content=fallback)
                s.add(am)
                s.commit()
                af.bus.publish_task(tid, "clarify.message", {"task_id": tid, "id": am.id, "role": "assistant", "content": fallback})

    threading.Thread(target=_auto_first_clarify, args=(body.images,), daemon=True, name=f"clarify-{tid}").start()

    return {"id": tid, "title": body.title, "status": "clarifying"}


@router.post("/tasks/{tid}/subtask")
def create_subtask(tid: int, body: SubtaskIn, request: Request, _: str = Depends(require_auth)):
    """P0 任务树：在父任务（主任务）底下创建子任务（origin=user_followup/lead_variant）。"""
    af = request.app.state.af
    if body.origin not in ("user_followup", "lead_variant"):
        raise HTTPException(400, f"origin 非法（允许 user_followup|lead_variant，sos_split 由系统创建）")
    if not body.title.strip():
        raise HTTPException(400, "title 不能为空")
    with Session(af.engine) as s:
        parent = s.get(m.Task, tid)
        if not parent:
            raise HTTPException(404, "parent task not found")
        if parent.origin:
            raise HTTPException(400, "任务树最多两层：子任务不可再派生子任务（请在主任务下发起追问）")
        if parent.archived_at:
            raise HTTPException(400, "父任务已归档：父子任务是共同体，请先在「设置→归档」恢复该任务再发起追问")
        if parent.status in (m.TaskStatus.running, m.TaskStatus.merging, m.TaskStatus.waiting_subtasks):
            raise HTTPException(400, "父任务运行/合并/等待子任务中，暂不能派生子任务")

        raw_req = body.raw_request.strip()
        if not raw_req and parent.raw_request.strip():
            latest = (
                s.query(m.ClarifyMessage)
                .filter(m.ClarifyMessage.task_id == parent.id, m.ClarifyMessage.role == "assistant")
                .order_by(m.ClarifyMessage.id.desc())
                .limit(3)
                .all()
            )
            inherit = "\n".join(f"- {c.content[:200]}" for c in reversed(latest))
            raw_req = f"（继承父任务 #{parent.id} 需求）{parent.raw_request[:800]}" + (f"\n父任务澄清结论:\n{inherit[:800]}" if inherit else "")
        task = m.Task(
            project_id=parent.project_id,
            title=body.title.strip(),
            raw_request=raw_req,
            parent_task_id=tid,
            origin=body.origin,
        )
        s.add(task)
        s.commit()
        sub_id = task.id



    image_names = _save_clarify_images(af.settings, sub_id, body.images)
    sub_desc = body.raw_request.strip()
    if sub_desc or image_names:
        with Session(af.engine) as s:
            um = m.ClarifyMessage(task_id=sub_id, role="user", content=sub_desc, images=json.dumps(image_names))
            s.add(um)
            s.commit()
            s.refresh(um)
            af.bus.publish_task(
                sub_id, "clarify.message",
                {"task_id": sub_id, "id": um.id, "role": "user", "content": sub_desc, "images": image_names},
            )


    def _auto_first_clarify_sub(user_images: list[str]) -> None:
        with Session(af.engine) as s:
            t = s.get(m.Task, sub_id)
            if t is None:
                return
            try:
                reply = clarify_round(af.gateway, s, t, "", user_images=user_images or None, bus=af.bus)
                am = m.ClarifyMessage(task_id=sub_id, role="assistant", content=reply)
                s.add(am)
                t.status = m.TaskStatus.clarifying
                s.add(t)
                s.commit()
                s.refresh(am)
                af.bus.publish_task(sub_id, "task.updated", {"task_id": sub_id, "status": "clarifying"})
                af.bus.publish_task(sub_id, "clarify.message", {"task_id": sub_id, "id": am.id, "role": "assistant", "content": reply})
            except Exception as e:
                fallback = f"（自动澄清失败：{e}，请手动发送消息重试）"
                am = m.ClarifyMessage(task_id=sub_id, role="assistant", content=fallback)
                s.add(am)
                s.commit()
                af.bus.publish_task(sub_id, "clarify.message", {"task_id": sub_id, "id": am.id, "role": "assistant", "content": fallback})

    threading.Thread(target=_auto_first_clarify_sub, args=(body.images,), daemon=True, name=f"clarify-{sub_id}").start()
    af.bus.publish_task(tid, "log.appended", {"level": "human", "message": f"派生子任务 #{sub_id}「{body.title.strip()}」（origin={body.origin}）"})
    return {"id": sub_id, "title": body.title, "parent_task_id": tid, "origin": body.origin, "status": "clarifying"}


@router.get("/tasks")
def list_tasks(request: Request, project_id: int | None = None, archived: int = 0, _: str = Depends(require_auth)):
    af = request.app.state.af


    _reconcile_all_pending_push(af)
    with Session(af.engine) as s:
        q = select(m.Task)
        if project_id:
            q = q.where(m.Task.project_id == project_id)
        q = q.where(m.Task.archived_at.is_not(None)) if archived else q.where(m.Task.archived_at.is_(None))
        rows = s.exec(q.order_by(m.Task.id.desc())).all()
        ids = [t.id for t in rows]

        user_msg: set[int] = set()
        if ids:
            for tid in s.exec(
                select(m.ClarifyMessage.task_id)
                .where(m.ClarifyMessage.task_id.in_(ids), m.ClarifyMessage.role == "user")
                .distinct()
            ):
                user_msg.add(tid)

        feat_by_task: dict[int, tuple[int, int]] = {}
        if ids:
            for task_id, status, cnt in s.exec(
                select(m.Feature.task_id, m.Feature.status, func.count())
                .where(m.Feature.task_id.in_(ids))
                .group_by(m.Feature.task_id, m.Feature.status)
            ):
                passed, total = feat_by_task.get(task_id, (0, 0))
                total += cnt
                if status == m.FeatureStatus.passed:
                    passed += cnt
                feat_by_task[task_id] = (passed, total)


        remote_by_proj: dict[int, bool] = {}

        def _cached_has_remote(pid: int) -> bool:
            if pid not in remote_by_proj:
                remote_by_proj[pid] = _project_has_remote(s, pid)
            return remote_by_proj[pid]

        return [
            _task_dto(
                t,
                has_user_message=t.id in user_msg,
                progress=feat_by_task.get(t.id),
                has_remote=_cached_has_remote(t.project_id),
            )
            for t in rows
        ]



def _task_family(s: Session, task: m.Task) -> list[m.Task]:
    """任务族 = 父任务 + 其全部子任务。"""
    root = task
    if task.parent_task_id:
        parent = s.get(m.Task, task.parent_task_id)
        if parent:
            root = parent
    kids = s.exec(select(m.Task).where(m.Task.parent_task_id == root.id)).all()
    return [root, *kids]


def _cleanup_aborted_task_branch(af, task: m.Task) -> None:
    """废弃任务删除前的 git 分支残留清理（响亮错）。"""
    if not task.branch:
        return
    proj = None
    with Session(af.engine) as s:
        proj = s.get(m.Project, task.project_id)
    if not proj:
        return
    repo = RepoHandle(Path(proj.repo_path))
    if task.branch not in repo.repo.branches:
        return
    try:
        branch.delete_task_branch(repo, task.id)
    except Exception as e:
        raise HTTPException(500, f"任务分支 {task.branch} 清理失败（先解决占用再删，不留无主残留）: {e}")


@router.post("/tasks/{tid}/archive")
def archive_task(tid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")

        family = _task_family(s, task)
        running = [t for t in family if t.status == m.TaskStatus.running]
        if running:
            raise HTTPException(400, f"任务 #{running[0].id} 运行中：父任务与子任务需一起归档，暂不能归档")
        archived_ids: list[int] = []
        deleted_ids: list[int] = []
        for t in family:


            if t.status == m.TaskStatus.aborted:
                _cleanup_aborted_task_branch(af, t)
                from agentflow.storage.cleanup import delete_task_records


                af.bus.publish_task(t.id, "task.deleted", {"task_id": t.id})
                delete_task_records(af.engine, af.settings.home, t.id)
                deleted_ids.append(t.id)
                continue
            t.archived_at = _utcnow()
            s.add(t)
            archived_ids.append(t.id)
        s.commit()
        return {"ok": True, "archived": archived_ids, "deleted": deleted_ids}


@router.post("/tasks/{tid}/delete")
def delete_task(tid: int, request: Request, _: str = Depends(require_auth)):
    """彻底删除任务族：整族（父 + 全部子任务）一起删——DB 关联行 + 事件流/trace/澄清图片。"""
    af = request.app.state.af
    from agentflow.storage.cleanup import delete_task_records

    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")

        family = _task_family(s, task)
        busy = [
            t for t in family
            if t.status in (m.TaskStatus.running, m.TaskStatus.merging, m.TaskStatus.spec_generating)
        ]
        if busy:
            raise HTTPException(400, f"任务 #{busy[0].id} 状态 {busy[0].status.value}：父任务与子任务需一起删除，暂不能删")
        not_archived = [t for t in family if t.status != m.TaskStatus.aborted and not t.archived_at]
        if not_archived:
            raise HTTPException(400, f"任务 #{not_archived[0].id} 未归档：父任务与子任务需一起归档后再删")
        gone_ids = [t.id for t in family]
        for t in family:

            if t.status == m.TaskStatus.aborted:
                _cleanup_aborted_task_branch(af, t)

    deleted_tasks = 0
    deleted_files = 0
    for gid in gone_ids:
        af.bus.publish_task(gid, "task.deleted", {"task_id": gid})
        detail = delete_task_records(af.engine, af.settings.home, gid)
        deleted_tasks += detail.get("tasks", 0)
        deleted_files += detail.get("files", 0)
    return {"ok": True, "tasks": deleted_tasks, "files": deleted_files, "deleted": gone_ids}


@router.post("/tasks/{tid}/unarchive")
def unarchive_task(tid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")

        unarchived_ids: list[int] = []
        for t in _task_family(s, task):
            t.archived_at = None
            s.add(t)
            unarchived_ids.append(t.id)
        s.commit()
        return {"ok": True, "unarchived": unarchived_ids}


@router.post("/tasks/{tid}/pin")
def pin_task(tid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        task.pinned = True
        s.add(task)
        s.commit()
        return {"ok": True}


@router.post("/tasks/{tid}/unpin")
def unpin_task(tid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        task.pinned = False
        s.add(task)
        s.commit()
        return {"ok": True}


@router.post("/tasks/{tid}/rename")
def rename_task(tid: int, body: RenameIn, request: Request, _: str = Depends(require_auth)):
    """重命名任务（title 非状态字段，无状态迁移，不违反"状态走调度器"）。"""
    title = (body.title or "").strip()
    if not title:
        raise HTTPException(400, "标题不能为空")
    if len(title) > 200:
        raise HTTPException(400, "标题过长（上限 200 字）")
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        task.title = title
        s.add(task)
        s.commit()
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "title": title})
        return {"ok": True}


@router.post("/tasks/{tid}/budget")
def set_task_budget(tid: int, body: BudgetIn, request: Request, _: str = Depends(require_auth)):
    '''设定本任务的预算上限（停机卡片写着"决策=提高上限"，此前却没有这个入口）。'''
    if body.task_max_tokens is None and body.task_max_cost_usd is None:
        raise HTTPException(400, "至少要设一项上限：task_max_tokens / task_max_cost_usd")
    if body.task_max_tokens is not None and body.task_max_tokens <= 0:
        raise HTTPException(400, "task_max_tokens 须为正整数（上限语义里 0 等于不限，不接受）")
    if body.task_max_cost_usd is not None and body.task_max_cost_usd <= 0:
        raise HTTPException(400, "task_max_cost_usd 须为正数（上限语义里 0 等于不限，不接受）")

    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        try:
            total = json.loads(task.total_budget) if task.total_budget else {}
        except Exception:
            total = {}
        if not isinstance(total, dict) or not total:

            total = dict(af.settings.data["budget"])
        if body.task_max_tokens is not None:
            total["task_max_tokens"] = int(body.task_max_tokens)
        if body.task_max_cost_usd is not None:
            total["task_max_cost_usd"] = float(body.task_max_cost_usd)
        task.total_budget = json.dumps(total, ensure_ascii=False)
        s.add(task)
        s.commit()

        used = json.loads(task.used_budget) if task.used_budget else {}
        tok = int(used.get("tokens_in", 0)) + int(used.get("tokens_out", 0) or 0)
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "total_budget": total})
        af.bus.publish_task(tid, "log.appended", {
            "level": "human",
            "message": (
                f"预算上限已设为 {fmt_tokens(total.get('task_max_tokens') or 0)} tokens / "
                f"${total.get('task_max_cost_usd')}（已用 {fmt_tokens(tok)} tokens）"
            ),
        })
        return {"ok": True, "total_budget": total}




_IMAGE_MIME_EXT = {"image/png": "png", "image/jpeg": "jpg", "image/gif": "gif", "image/webp": "webp"}
_IMAGE_MAX_BYTES = 5 * 1024 * 1024
_IMAGE_MAX_COUNT = 4


def _save_clarify_images(settings, tid: int, images: list[str]) -> list[str]:
    """把 data URL 图片落盘到 <home>/clarify_images/{tid}/，返回文件名列表。"""
    import base64
    import re
    import uuid

    if not images:
        return []
    if len(images) > _IMAGE_MAX_COUNT:
        raise HTTPException(400, f"单条消息最多 {_IMAGE_MAX_COUNT} 张图片")
    names: list[str] = []
    for data_url in images:
        mm = re.match(r"^data:(image/(?:png|jpeg|gif|webp));base64,([A-Za-z0-9+/=]+)$", data_url or "")
        if not mm:
            raise HTTPException(400, "图片格式不合法（仅支持 data URL 形式的 png/jpeg/gif/webp）")
        mime, b64 = mm.group(1), mm.group(2)
        try:
            raw = base64.b64decode(b64, validate=True)
        except Exception:
            raise HTTPException(400, "图片 base64 解码失败")
        if len(raw) > _IMAGE_MAX_BYTES:
            raise HTTPException(400, f"单张图片不得超过 {_IMAGE_MAX_BYTES // (1024 * 1024)}MB")
        folder = settings.home / "clarify_images" / str(tid)
        folder.mkdir(parents=True, exist_ok=True)
        name = f"{uuid.uuid4().hex}.{_IMAGE_MIME_EXT[mime]}"
        (folder / name).write_bytes(raw)
        names.append(name)
    return names


@router.post("/tasks/{tid}/clarify")
def clarify(tid: int, body: ClarifyIn, request: Request, _: str = Depends(require_auth)):
    """澄清对话一轮（状态分流）："""
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        msg = (body.message or "").strip()
        image_names = _save_clarify_images(af.settings, tid, body.images)
        um: m.ClarifyMessage | None = None
        if msg or image_names:
            um = m.ClarifyMessage(task_id=tid, role="user", content=msg, images=json.dumps(image_names))
            s.add(um)
            s.commit()
            s.refresh(um)
            af.bus.publish_task(
                tid, "clarify.message",
                {"task_id": tid, "id": um.id, "role": "user", "content": msg, "images": image_names},
            )
        if task.status == m.TaskStatus.draft:
            task.status = m.TaskStatus.clarifying
            s.add(task)
            s.commit()
            af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "clarifying"})
            s.refresh(task)
        if task.status in (m.TaskStatus.running, m.TaskStatus.merging):

            af.bus.publish_task(tid, "log.appended", {"level": "sched", "message": "已收到用户消息：当前执行 agent 将在下一步立即插队处理"})
            return {"reply": "", "queued": True}
        try:
            reply = clarify_round(af.gateway, s, task, msg, user_images=body.images, bus=af.bus)
        except Exception as e:




            if um is not None:
                um.consumed_at = datetime.now(timezone.utc).isoformat()
                s.add(um)
                s.commit()
            af.bus.publish_task(tid, "log.appended", {
                "level": "human",
                "message": f"Lead 回复失败（{type(e).__name__}）：{str(e)[:300]}",
            })
            raise HTTPException(503, f"Lead 回复失败：{str(e)[:400]}") from e


        if um is not None and _load_ops_card(s, tid):
            note = s.exec(
                select(m.HandoffNote).where(
                    m.HandoffNote.task_id == tid, m.HandoffNote.kind == "diagnosis"
                ).order_by(m.HandoffNote.id.desc())
            ).first()
            if note:
                s.delete(note)
                s.commit()
                af.bus.publish_task(tid, "log.appended", {
                    "level": "sched",
                    "message": "用户补充了新信息，已失效旧诊断卡（ops）；下次确认 Spec 将重新现场诊断",
                })
        am = m.ClarifyMessage(task_id=tid, role="assistant", content=reply)
        s.add(am)
        if um is not None:
            um.consumed_at = datetime.now(timezone.utc).isoformat()
            s.add(um)
        s.commit()
        s.refresh(am)
        af.bus.publish_task(tid, "clarify.message", {"task_id": tid, "id": am.id, "role": "assistant", "content": reply})
        return {"reply": reply}


@router.get("/tasks/{tid}/clarify")
def get_clarify_history(tid: int, request: Request, _: str = Depends(require_auth)):
    """澄清对话历史（持久化，切页/刷新不丢）。"""
    af = request.app.state.af
    with Session(af.engine) as s:
        rows = s.exec(
            select(m.ClarifyMessage).where(m.ClarifyMessage.task_id == tid).order_by(m.ClarifyMessage.id.asc())
        ).all()
        return {
            "messages": [
                {
                    "id": r.id,
                    "role": r.role,
                    "content": r.content,
                    "images": json.loads(r.images or "[]"),
                    "created_at": r.created_at,
                }
                for r in rows
            ]
        }


@router.get("/tasks/{tid}/clarify/images/{name}")
def get_clarify_image(tid: int, name: str, request: Request, _auth: str = Depends(require_auth_or_query)):
    """对话图片文件（<img> 标签无法带 Authorization header，走 query token 认证，同 SSE）。"""
    import re as _re

    from fastapi.responses import FileResponse

    af = request.app.state.af

    if not _re.match(r"^[0-9a-f]{32}\.(png|jpg|gif|webp)$", name):
        raise HTTPException(400, "invalid image name")
    path = af.settings.home / "clarify_images" / str(tid) / name
    if not path.is_file():
        raise HTTPException(404, "image not found")
    return FileResponse(path)


@router.get("/tasks/{tid}/spec")
def get_spec(tid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        spec = s.exec(select(m.Spec).where(m.Spec.task_id == tid).order_by(m.Spec.id.desc())).first()
        if not spec:
            raise HTTPException(404, "spec not found")
        feats = s.exec(select(m.Feature).where(m.Feature.spec_id == spec.id).order_by(m.Feature.seq)).all()
        return {
            "yaml": spec.yaml_raw,
            "parsed": json.loads(spec.parsed),
            "features": [_feature_dto(f) for f in feats],
            "confirmed_at": spec.confirmed_at,
        }


SPEC_RETRY_DELAY_S = 30.0


def _back_to_clarifying(af, s, task, tid: int) -> None:
    """把生成流中的任务退回 clarifying（ops 未通过时等人补充信息）。"""
    s.expire(task)
    if task.status in (m.TaskStatus.spec_generating, m.TaskStatus.running):
        task.status = m.TaskStatus.clarifying
        s.add(task)
        s.commit()
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "clarifying"})


def _ops_code_landed(s: Session, tid: int) -> bool:
    """本任务最新运维执行结论是否**真实改动了 main**。"""
    from agentflow.agents.diagnose import latest_ops_exec

    note = latest_ops_exec(s, tid) or {}
    return bool(note.get("code_changed")) and not note.get("superseded")


def _to_ops_review(af, s, task, tid: int, code_landed: bool = False) -> None:
    """运维指令执行完毕 → 推送人审：spec_generating → human_review。"""
    s.expire(task)
    if task.status not in (m.TaskStatus.spec_generating, m.TaskStatus.running):
        return
    task.status = m.TaskStatus.human_review
    if not task.completed_at:
        task.completed_at = _utcnow()
    s.add(task)
    s.commit()
    af.bus.publish_task(tid, "task.updated", {
        "task_id": tid, "status": "human_review",
        "code_landed": bool(code_landed),
    })


def _handle_ops_flow(af, s, task, tid: int, card: dict, approved_side_effects: bool = False) -> None:
    """ops 分流的 AI 自主执行（用户拍板 2026-09-19：去掉「执行运维命令并验证」按钮）。"""
    from agentflow.agents import diagnose as diagnose_mod

    if not approved_side_effects:
        from agentflow.safety.command import has_outbound_side_effect

        if has_outbound_side_effect(str(card.get("ops_cmd", ""))):
            _to_ops_pending_approval(af, s, task, tid, card)
            return

    af.bus.publish_task(tid, "log.appended", {
        "level": "lead",
        "message": (
            f"Lead 现场诊断判定：运维问题，无需拆解开发。根因: {str(card.get('root_cause', ''))[:200]} | "
            f"建议: {str(card.get('suggestion', ''))[:200]}"
        ),
    })
    prev = diagnose_mod.latest_ops_exec(s, tid)
    if prev and prev.get("ok") and not prev.get("superseded"):



        _to_ops_review(af, s, task, tid, bool(prev.get("code_changed")))
        landed = bool(prev.get("code_changed"))
        af.bus.publish_task(tid, "log.appended", {
            "level": "human",
            "message": (
                f"该运维问题此前已执行解决（{str(prev.get('ts', ''))[:19]}）：{str(prev.get('summary', ''))[:300]}\n"
                + (
                    "已推送人审（不重复执行，防 restart 类命令重复副作用）。该轮运维**真实改动了 main**"
                    "（git 事实）——通过 → 按远端状态转「待推送」/「已推送」；重做 → 带说明重新诊断执行。"
                    if landed else
                    "已推送人审（不重复执行，防 restart 类命令重复副作用）。通过 → 收口「已解决」；"
                    "重做 → 带说明重新诊断执行；若其实需要改代码，重做时说明即可，新诊断会判 single/complex 转开发链。"
                )
            ),
        })
        return

    af.bus.publish_task(tid, "log.appended", {
        "level": "lead",
        "message": (
            f"Lead 开始自主执行运维修复（失败自行调整）：`{str(card.get('ops_cmd', ''))[:160]}` → "
            f"验证 `{str(card.get('verify_cmd', ''))[:160]}`"
        ),
    })
    res = diagnose_mod.run_ops_execution(af.engine, af.gateway, af.bus, af.settings, tid, card)
    if res.get("ok"):
        landed = bool(res.get("code_changed"))
        _to_ops_review(af, s, task, tid, landed)
        af.bus.publish_task(tid, "log.appended", {
            "level": "human",
            "message": (
                (
                    f"✅ 运维执行已合入 main（{str(res.get('main_before', ''))[:8]} → "
                    f"{str(res.get('main_after', ''))[:8]}，真实代码变更），已推送人审。\n"
                    if landed else
                    "✅ 运维问题已解决（验证命令 exit 0），已推送人审（无代码改动，不进 CI/合并链路）。\n"
                )
                + f"执行摘要: {str(res.get('summary', ''))[:500]}\n"
                + f"验证输出: {str(res.get('verify_output', ''))[:300]}\n"
                + (
                    "请在中栏人审：通过 → 按 git 事实转「待推送」/「已推送」；重做 → 带说明重新诊断执行。"
                    if landed else
                    "请在中栏人审：通过 → 收口「已解决」；重做 → 带说明重新诊断执行。"
                )
            ),
        })
    else:
        _back_to_clarifying(af, s, task, tid)
        af.bus.publish_task(tid, "log.appended", {
            "level": "sched",
            "message": (
                f"❌ 运维执行未通过（验证命令 exit {res.get('verify_exit')}）。\n"
                f"执行摘要: {str(res.get('summary', ''))[:600]}\n"
                f"验证输出: {str(res.get('verify_output', ''))[:300]}\n"
                "请在对话中补充信息（现象/换个思路）后重新确认 Spec；系统会重新诊断并执行。"
            ),
        })


def _to_ops_pending_approval(af, s, task, tid: int, card: dict) -> None:
    """含推送类命令的运维卡 → 不自动执行，整卡转人工批准。"""
    s.expire(task)
    if task.status not in (m.TaskStatus.spec_generating, m.TaskStatus.running):
        return
    task.status = m.TaskStatus.paused_human
    s.add(task)
    s.commit()
    af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "paused_human"})
    af.bus.publish_task(tid, "log.appended", {
        "level": "human",
        "message": (
            "运维卡含推送类命令，按策略**不自动执行**（推送不可回滚，闸门设在执行前）：\n"
            f"修复命令：`{str(card.get('ops_cmd', ''))[:300]}`\n"
            f"验证命令：`{str(card.get('verify_cmd', ''))[:200]}`\n"
            "点「批准并执行」→ 平台执行（保留执行记录与收口）；「重做」→ 失效旧卡重新诊断。"
        ),
    })
    af.bus.publish_task(tid, "human.required", {
        "reason": (
            "运维卡含推送类命令（按策略不自动执行，需人工批准）："
            f"`{str(card.get('ops_cmd', ''))[:200]}`"
        ),
        "options": ["批准并执行", "重做"],
    })


def _is_pending_ops_approval(engine, tid: int) -> bool:
    """当前是否处于「运维卡待人工批准执行」态（paused_human + 有最新诊断卡）。"""
    with Session(engine) as s:
        task = s.get(m.Task, tid)
        if task is None or task.status != m.TaskStatus.paused_human:
            return False
        return _load_ops_card(s, tid) is not None


def _human_approve_ops_exec(tid: int, af) -> dict:
    """人工批准含推送类命令的运维卡：平台执行 → 走既有收口。"""
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if task is None:
            raise HTTPException(404, "task not found")
        if task.status != m.TaskStatus.paused_human:

            return {"ok": True, "started": False, "reason": f"当前状态 {task.status.value} 无需批准执行"}
        card = _load_ops_card(s, tid)
        if not card:
            raise HTTPException(400, "未找到可执行的运维卡（可能已被重做失效）")
        task.status = m.TaskStatus.spec_generating
        s.add(task)
        s.commit()
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "spec_generating"})
        af.bus.publish_task(tid, "log.appended", {
            "level": "human",
            "message": "人工已批准执行（含推送类命令）：平台开始执行运维卡",
        })
        _handle_ops_flow(af, s, task, tid, card, approved_side_effects=True)
    return {"ok": True, "started": True, "action": "ops_approved"}


def _human_ops_pending_requeue(tid: int, af, note: str = "", images: list[str] | None = None) -> dict:
    """待批准态下的「重做」/补充说明：失效旧诊断卡 → 回 clarifying。"""
    image_names = _save_clarify_images(af.settings, tid, images or [])
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if task is None:
            raise HTTPException(404, "task not found")
        if task.status != m.TaskStatus.paused_human or _load_ops_card(s, tid) is None:
            return {"ok": True, "started": False, "reason": "非待批准运维卡，未处理"}
        text = (note or "").strip()
        if text or image_names:
            um = m.ClarifyMessage(task_id=tid, role="user", content=text, images=json.dumps(image_names))
            s.add(um)
            s.commit()
            s.refresh(um)
            af.bus.publish_task(
                tid, "clarify.message",
                {"task_id": tid, "id": um.id, "role": "user", "content": text, "images": image_names},
            )
        diag = s.exec(
            select(m.HandoffNote).where(
                m.HandoffNote.task_id == tid, m.HandoffNote.kind == "diagnosis"
            ).order_by(m.HandoffNote.id.desc())
        ).first()
        if diag:
            s.delete(diag)
            s.commit()
        task.status = m.TaskStatus.clarifying
        s.add(task)
        s.commit()
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "clarifying"})
        af.bus.publish_task(tid, "log.appended", {
            "level": "human",
            "message": "已按人工要求撤销本张运维卡（旧诊断卡失效）——补充说明后重新确认 Spec 会重新诊断。",
        })
    return {"ok": True, "action": "ops_requeue"}




_PREFLIGHT_WT_ID_BASE = 900_000_000


def _prepare_preflight_root(af, s: Session, proj) -> tuple[Path | None, str]:
    """准备 ui 实测预检的**隔离工作根**（项目专用 preflight worktree）。"""
    from agentflow.git_runtime import worktree as wt_mod
    from agentflow.git_runtime.repo import RepoHandle
    from agentflow.projects.registry import project_dep_strategy, project_runtime_data_dirs

    main_root = Path(str(proj.repo_path))
    wid = _PREFLIGHT_WT_ID_BASE + proj.id
    try:
        wt = wt_mod.ensure_dev_worktree(af.settings, main_root, wid)

        RepoHandle(wt).repo.git.reset("--hard", "main")
    except Exception as e:
        return None, f"隔离工作根准备失败（{type(e).__name__}: {e}）"
    try:
        if project_dep_strategy(s, proj.id) == "junction_node_modules":
            wt_mod.link_node_deps(main_root, wt)
        data_dirs = project_runtime_data_dirs(s, proj.id)
        if data_dirs:
            wt_mod.link_runtime_data(main_root, wt, data_dirs)
    except Exception as e:
        return None, f"隔离工作根依赖/数据链接失败（{type(e).__name__}: {e}）"
    return wt, ""


def _ui_decl_empirical_evidence(af, s: Session, task_id: int, proj, max_len: int = 1600) -> str:
    """Spec 期把 ui 声明**实测跑一遍**，把真实失败与页面控件快照回灌给 Spec 作者。"""
    spec, decl = _ui_decl_of_spec(s, task_id)
    if spec is None or proj is None or not getattr(proj, "repo_path", None) or not decl:
        return ""
    rep = _ui_preflight_run(af, s, task_id, proj, spec_id=spec.id)
    if rep is None:
        return ""
    _persist_ui_preflight(af, task_id, rep)
    if rep.get("harness"):
        return f"（ui 声明实测预检未能执行：{str(rep.get('output') or '')[:300]}。请人工确认声明能否命中目标控件。）"
    if rep.get("ok"):
        return ""
    from agentflow.verifiers import ui_preflight as uip

    return uip.format_feedback(rep, max_len=max_len)


def _ui_decl_of_spec(s: Session, task_id: int, spec_id: int | None = None) -> tuple[object | None, str]:
    """取（Spec, 该 Spec 里第一条 verifier=ui 的声明）。spec_id 为空取最新一份。"""
    spec = None
    if spec_id is not None:
        spec = s.exec(select(m.Spec).where(m.Spec.task_id == task_id, m.Spec.id == spec_id)).first()
    if spec is None:
        spec = s.exec(select(m.Spec).where(m.Spec.task_id == task_id).order_by(m.Spec.id.desc())).first()
    if spec is None:
        return None, ""
    for f in s.exec(select(m.Feature).where(m.Feature.spec_id == spec.id)).all():
        try:
            cmds = json.loads(f.verify_commands or "[]")
        except (json.JSONDecodeError, TypeError):
            continue
        for v in cmds:
            if isinstance(v, dict) and (v.get("verifier") or "").strip().lower() == "ui":
                return spec, (v.get("cmd") or "")
    return spec, ""


def _ui_preflight_run(af, s: Session, task_id: int, proj, spec_id: int | None = None) -> dict | None:
    """对指定 Spec 的 ui 声明**实测**跑一遍（隔离工作根），返回结构化报告；无 ui 声明 → None。"""
    import time as _time

    from agentflow.verifiers import ui_preflight as uip
    from agentflow.verifiers.ui import UiVerifier

    spec, decl = _ui_decl_of_spec(s, task_id, spec_id)
    if spec is None or not decl:
        return None
    root, why = _prepare_preflight_root(af, s, proj)
    if root is None:
        return {"spec_id": spec.id, "decl": decl, "ok": False, "harness": True,
                "output": f"{HARNESS_MARK} 实测预检已跳过：{why}", "fail_targets": [], "snapshot": []}
    t0 = _time.monotonic()
    try:
        res = UiVerifier().run(decl, root, timeout=300)
    except Exception as e:
        return {"spec_id": spec.id, "decl": decl, "ok": False, "harness": True,
                "output": f"实测预检未能执行：{type(e).__name__}: {e}", "fail_targets": [], "snapshot": []}
    fail_targets, snapshot, fail_items = uip.parse_verifier_report(res)
    return {
        "spec_id": spec.id, "decl": decl, "ok": res.exit_code == 0,
        "harness": (getattr(res, "classification", "") or "") == "harness",
        "output": (res.output or "")[:4000], "fail_targets": fail_targets, "snapshot": snapshot,
        "fail_items": fail_items,
        "root": str(root), "elapsed_s": round(_time.monotonic() - t0, 1),
    }


def _persist_ui_preflight(af, task_id: int, rep: dict) -> None:
    try:
        from agentflow.verifiers import ui_preflight as uip

        uip.save_report(af.settings.home, task_id, int(rep.get("spec_id") or 0), rep)
    except Exception:
        pass


def _preflight_rewrite_tip(fail_targets: list, root: str) -> str:
    '''预检未过时的提示语：区分"基线已存在"（确认时会带证据改写声明）与"本次新增元素"。'''
    from agentflow.verifiers.probe import _hosts_of_testid

    ids = list(
        dict.fromkeys(re.findall(r"data-testid\s*=\s*[\"']?([A-Za-z0-9_-]+)", "；".join(fail_targets or [])))
    )
    existing: list[str] = []
    new: list[str] = []
    for i in ids:
        try:
            (existing if _hosts_of_testid(i, root) else new).append(i)
        except Exception:
            existing.append(i)
    if existing:
        return f"确认运行时会自动带证据重写声明（{', '.join(existing[:3])} 在基线源码里存在＝可达性问题）"
    if new:
        return f"{', '.join(new[:3])} 是本次新增元素、基线本就不存在＝预期不可达，**不会**改写声明"
    return "确认时按确定性规则判定是否重写（失败目标里没有可判的 data-testid 锚点）"


def _spawn_ui_preflight(af, tid: int, spec_id: int) -> None:
    """**用户审 Spec 卡期间**后台实测预检（P0，2026-09-27）。"""
    import threading

    def _bg() -> None:
        try:
            with Session(af.engine) as s:
                task = s.get(m.Task, tid)
                proj = s.get(m.Project, task.project_id) if task else None
                rep = _ui_preflight_run(af, s, tid, proj, spec_id=spec_id)
            if rep is None:
                return
            _persist_ui_preflight(af, tid, rep)
            if rep.get("harness"):
                af.bus.publish_task(tid, "log.appended", {
                    "level": "sched",
                    "message": f"ui 实测预检未能执行（{str(rep.get('output') or '')[:160]}）——不影响确认与运行",
                })
                return
            if rep.get("ok"):
                af.bus.publish_task(tid, "log.appended", {
                    "level": "sched",
                    "message": f"ui 声明实测预检通过 ✓（基线可达，用时 {rep.get('elapsed_s')}s）",
                })
                return




            _tip = _preflight_rewrite_tip(rep.get("fail_targets") or [], rep.get("root") or "")
            af.bus.publish_task(tid, "log.appended", {
                "level": "sched",
                "message": (
                    f"ui 声明实测预检**未过**（用时 {rep.get('elapsed_s')}s）："
                    + "；".join(rep.get("fail_targets") or [])[:220]
                    + f" —— 证据已留档；{_tip}；也可人工直接指定 ui 声明"
                ),
            })
            _remember_ui_preflight_fact(af, tid, rep)
        except Exception as e:
            try:
                af.bus.publish_task(tid, "log.appended", {
                    "level": "sched", "message": f"ui 实测预检异常（忽略）：{type(e).__name__}: {e}",
                })
            except Exception:
                pass

    threading.Thread(target=_bg, daemon=True, name=f"ui-preflight-{tid}").start()


_UI_MEMORY_TITLE = "[自动记忆] ui 断言可达性"


def _remember_ui_preflight_fact(af, tid: int, rep: dict) -> None:
    """把实测预检发现的**环境事实**沉淀为一条项目规则。"""
    from agentflow.verifiers import ui_preflight as _uip


    reach = _uip.reachability_failures(rep.get("fail_items") or [])
    if not reach:
        return
    targets = reach[:3]
    fact = (
        "ui 机审断言不得依赖「默认筛选档 / 默认分页 / 列表非空」的渲染：实测出现过声明里的控件"
        f"（{', '.join(targets[:2])}）在默认状态下不可达（数据陈旧 → 列表被筛空 → 条件渲染为 null）。"
        "写声明时先 click 到有数据的稳定档位，或改断言在该上下文恒定渲染的锚点。"
    )
    try:
        with Session(af.engine) as s:
            task = s.get(m.Task, tid)
            if not task:
                return
            rows = s.exec(select(m.ProjectRule).where(m.ProjectRule.project_id == task.project_id)).all()
            if any((r.title or "").strip() == _UI_MEMORY_TITLE for r in rows):
                return
            s.add(m.ProjectRule(project_id=task.project_id, title=_UI_MEMORY_TITLE,
                                content=fact[:400], enabled=True, sort_order=999))
            s.commit()
        af.bus.publish_task(tid, "log.appended", {
            "level": "sched",
            "message": "已沉淀一条项目规则（自动记忆）：ui 断言勿依赖默认档位渲染（防同类缺陷复发）",
        })
    except Exception:
        pass


def _ui_preflight_confirm_feedback(af, tid: int) -> str:
    """确认运行时的**确定性**自动修复：实测预检失败 + 失败目标在基线源码里真实存在"""
    from agentflow.verifiers import ui_preflight as uip
    from agentflow.verifiers.probe import _hosts_of_testid

    rep = uip.load_report(af.settings.home, tid)
    if not rep or rep.get("ok") or rep.get("harness"):
        return ""
    root = rep.get("root") or ""
    if not root:
        return ""

    ids: list[str] = []
    for t in uip.reachability_failures(rep.get("fail_items") or []):
        ids += re.findall(r"data-testid\s*=\s*[\"']?([A-Za-z0-9_-]+)", str(t))
    existing: list[str] = []
    for i in dict.fromkeys(ids):
        try:
            if _hosts_of_testid(i, root):
                existing.append(i)
        except Exception:
            continue
    if not existing:
        return ""
    return uip.format_feedback(rep)


def _apply_ui_decl_override(s: Session, task_id: int, decl: str) -> bool:
    """把最新 Spec 里本功能的 ui 机审命令替换为人工指定的声明（其余命令不动）。"""
    spec = s.exec(select(m.Spec).where(m.Spec.task_id == task_id).order_by(m.Spec.id.desc())).first()
    if spec is None:
        return False
    hit = False
    for f in s.exec(select(m.Feature).where(m.Feature.spec_id == spec.id)).all():
        try:
            cmds = json.loads(f.verify_commands or "[]")
        except (json.JSONDecodeError, TypeError):
            continue
        changed = False
        for v in cmds:
            if isinstance(v, dict) and (v.get("verifier") or "").strip().lower() == "ui":
                v["cmd"] = decl
                changed = True
        if changed:
            f.verify_commands = json.dumps(cmds, ensure_ascii=False)
            s.add(f)
            hit = True
    if hit:
        s.commit()
    return hit


def _run_spec_generation(af, tid: int, first_feedback: str = "", ui_decl: str = ""):
    """后台线程：生成 Spec（LLM 长调用，可能 2 分钟+）。成功 → spec_pending，失败 → 回退 clarifying。"""
    try:
        retry_delay = float(af.settings.data.get("llm", {}).get("spec_retry_s", SPEC_RETRY_DELAY_S))
    except (AttributeError, TypeError, ValueError):
        retry_delay = SPEC_RETRY_DELAY_S
    max_attempts = 2
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            return
        for attempt in range(1, max_attempts + 1):
            try:
                proj = s.get(m.Project, task.project_id)


                if af.settings.data.get("lead", {}).get("diagnose_before_spec", True):
                    from agentflow.agents import diagnose as diagnose_mod

                    card = diagnose_mod.run_pre_spec_diagnosis(af.engine, af.gateway, af.bus, af.settings, tid)
                    if card.get("verdict") == "ops":
                        _handle_ops_flow(af, s, task, tid, card)
                        return
                generate_spec(af.gateway, s, task, proj, retry_feedback=first_feedback, bus=af.bus)

                from agentflow.verifiers.probe import split_probe_results, probe_spec_verify_commands

                _all = probe_spec_verify_commands(s, tid)



                bad, advisories = split_probe_results(_all)
                if advisories:
                    af.bus.publish_task(tid, "log.appended", {
                        "level": "sched",
                        "message": "Spec 期提示（不阻断）: " + " | ".join(
                            f"F{a['feature']}《{a['title']}》{a['error'][:200]}" for a in advisories[:4]
                        ),
                    })
                if bad:
                    feedback = "\n".join(
                        f"F{b['feature']}《{b['title']}》第{b['index']+1}条: `{b['cmd'][:120]}` → {b['error'][:150]}"
                        for b in bad
                    )



                    if af.settings.data.get("lead", {}).get("ui_decl_preflight", True) and any(
                        "data-testid" in (b.get("error") or "") or "ui 声明" in (b.get("error") or "")
                        for b in bad
                    ):
                        evidence = _ui_decl_empirical_evidence(af, s, tid, proj)
                        if evidence:
                            feedback += "\n\n" + evidence
                            af.bus.publish_task(tid, "log.appended", {
                                "level": "sched",
                                "message": "Spec 期 ui 声明实测预检已执行：真实失败与页面控件快照已回灌重生成",
                            })
                    try:
                        generate_spec(af.gateway, s, task, proj, retry_feedback=feedback, bus=af.bus)
                    except Exception as regen_err:
                        af.bus.publish_task(tid, "log.appended", {
                            "level": "sched", "message": f"Spec 重生成失败（保留第 1 轮 Spec）: {type(regen_err).__name__}: {regen_err}",
                        })
                    bad2, _adv2 = split_probe_results(probe_spec_verify_commands(s, tid))
                    note = (
                        f"Spec 语法自检第 1 轮检出 {len(bad)} 条坏命令 → 已带证据重生成 → "
                        + ("第 2 轮全过 ✓" if not bad2 else f"第 2 轮仍有 {len(bad2)} 条坏命令（响亮留证，可修 Spec 后重新确认）")
                    )
                    af.bus.publish_task(tid, "log.appended", {"level": "sched", "message": note})





                if ui_decl:
                    if _apply_ui_decl_override(s, tid, ui_decl):
                        af.bus.publish_task(tid, "log.appended", {
                            "level": "human",
                            "message": f"已按人工指定的 ui 机审声明覆盖本功能声明（{len(ui_decl)} 字）",
                        })
                        _ovr_bad, ovr_adv = split_probe_results(probe_spec_verify_commands(s, tid))
                        if _ovr_bad:
                            af.bus.publish_task(tid, "log.appended", {
                                "level": "sched",
                                "message": "人工指定的 ui 声明仍有护栏告警（响亮留证）: "
                                           + " | ".join(f"F{b['feature']} {b['error'][:160]}" for b in _ovr_bad[:3]),
                            })
                    else:
                        af.bus.publish_task(tid, "log.appended", {
                            "level": "sched", "message": "人工 ui 声明未能覆盖：未找到本功能可覆盖的 ui 机审命令",
                        })
                spec = s.exec(select(m.Spec).where(m.Spec.task_id == tid).order_by(m.Spec.id.desc())).first()
                if spec:
                    spec.confirmed_at = datetime.now(timezone.utc).isoformat()
                    s.add(spec)

                s.expire(task)
                if task.status != m.TaskStatus.spec_generating:
                    af.bus.publish_task(tid, "log.appended", {
                        "level": "sched",
                        "message": f"Spec 已生成，但任务状态已变为 {task.status.value}，不再接续运行",
                    })
                    return
                task.status = m.TaskStatus.spec_pending
                s.add(task)
                s.commit()
                af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "spec_pending"})



                if spec is not None and af.settings.data.get("lead", {}).get("ui_decl_preflight", True):
                    _spawn_ui_preflight(af, tid, spec.id)
                return True
            except Exception as e:
                s.rollback()
                if attempt < max_attempts:

                    task = s.get(m.Task, tid)
                    if not task or task.status != m.TaskStatus.spec_generating:
                        return
                    af.bus.publish_task(tid, "log.appended", {
                        "level": "sched",
                        "message": f"Spec 生成失败（第 {attempt} 轮）：{type(e).__name__}: {e}；{retry_delay:.0f}s 后自动重试…",
                    })



                    _err = f"{type(e).__name__}: {e}"
                    if "scannererror" in _err.lower() or "mapping values" in _err.lower():
                        first_feedback = (
                            f"上一轮 Spec 解析失败：{_err[:400]}\n"
                            "请重新输出**完整且合法**的 YAML：每条 `cmd:` 的值必须用单引号整条包裹，"
                            "值内不要出现 `: `（冒号+空格）、不要以 `{` / `[` 开头（YAML 会当成嵌套映射而报错）。"
                            "其余字段格式保持不变。"
                        )
                    else:
                        first_feedback = f"上一轮 Spec 生成失败：{_err[:400]}\n请修正后重新输出完整、合法的 Spec YAML。"
                    time.sleep(retry_delay)
                    task = s.get(m.Task, tid)
                    if not task or task.status != m.TaskStatus.spec_generating:
                        return
                    continue

                task = s.get(m.Task, tid)
                if task and task.status == m.TaskStatus.spec_generating:
                    task.status = m.TaskStatus.clarifying
                    s.add(task)
                    s.commit()
                    af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "clarifying"})
                af.bus.publish_task(tid, "log.appended", {
                    "level": "sched",
                    "message": f"Spec 生成失败（已自动重试 {max_attempts - 1} 轮），回退澄清状态，可手动重试：{type(e).__name__}: {e}",
                })
                return


class SpecConfirmIn(BaseModel):
    feedback: str = ""


    ui_declaration: str = ""



    auto_run: bool = False


@router.post("/tasks/{tid}/spec/confirm")
async def confirm_spec(tid: int, request: Request, body: SpecConfirmIn | None = None, _: str = Depends(require_auth)):
    """签署 Spec（异步）：立即置 spec_generating 并返回，LLM 生成在后台跑。"""
    af = request.app.state.af
    if tid in af.spec_generating:
        return {"ok": True, "started": False, "reason": "Spec 生成中，请稍候"}
    note = ((body.feedback if body else "") or "").strip()
    ui_decl = ((body.ui_declaration if body else "") or "").strip()


    if not note and not ui_decl:
        _pf_feedback = _ui_preflight_confirm_feedback(af, tid)
        if _pf_feedback:
            note = _pf_feedback
            af.bus.publish_task(tid, "log.appended", {
                "level": "sched",
                "message": "确认运行时：Spec 期 ui 实测预检指认的可达性问题已自动带证据重写声明（无需人工介入）",
            })
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        if task.status not in (m.TaskStatus.draft, m.TaskStatus.clarifying, m.TaskStatus.spec_pending):
            raise HTTPException(400, f"当前状态 {task.status.value} 不可确认 Spec")
        task.status = m.TaskStatus.spec_generating
        s.add(task)
        s.commit()

    _spawn_spec_generation(af, tid, note, ui_decl, auto_run=bool(body.auto_run) if body else False)
    return {
        "ok": True,
        "started": True,

        "auto_run": bool(body.auto_run) if body else False,
        "next": "" if (body and body.auto_run) else f"生成完成后如需运行：POST /tasks/{tid}/run",
    }


def _spawn_spec_generation(af, tid: int, note: str = "", ui_decl: str = "", lead_log: str = "Lead 开始生成 Spec（模型调用中，约需 1~3 分钟）…", auto_run: bool = False) -> None:
    """状态已置 spec_generating 并落库后调用：标记生成中 + 广播事件 + 后台跑生成。"""
    af.spec_generating.add(tid)
    af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "spec_generating"})
    af.bus.publish_task(tid, "log.appended", {"level": "lead", "message": lead_log})
    if note:
        af.bus.publish_task(tid, "log.appended", {
            "level": "human",
            "message": f"已随本次 Spec 生成注入人工指引（{len(note)} 字）：{note[:300]}",
        })

    async def _bg():
        try:
            ok = await asyncio.to_thread(_run_spec_generation, af, tid, note, ui_decl)



            if auto_run and ok:
                try:
                    r = await _start_run(af, tid)
                    af.bus.publish_task(tid, "log.appended", {
                        "level": "sched",
                        "message": (
                            "auto_run：Spec 已生成，自动接续运行（免去二次点按）"
                            if r.get("started") else f"auto_run：{r.get('reason')}"
                        ),
                    })
                except Exception as e:
                    af.bus.publish_task(tid, "log.appended", {
                        "level": "sched",
                        "message": f"auto_run 拉起运行失败（{type(e).__name__}: {e}），请在界面点「运行」接续",
                    })
        finally:
            af.spec_generating.discard(tid)

    asyncio.create_task(_bg())


def _load_ops_card(session: Session, tid: int) -> dict | None:
    """读本任务最新诊断卡；仅 verdict=ops（且带 ops_cmd）返回，其余（无卡/损坏/single/complex）返回 None。"""
    from agentflow.agents.diagnose import DiagnosisError, latest_diagnosis, parse_diagnosis_card

    raw = latest_diagnosis(session, tid)
    if not raw:
        return None
    try:
        card = parse_diagnosis_card(raw)
    except DiagnosisError:
        return None
    if card.get("verdict") != "ops" or not (card.get("ops_cmd") or "").strip():
        return None
    return card



def start_task_runner(af, tid: int) -> None:
    """公共任务 runner 启动（run_task 端点与 SOS 子任务/父恢复共用）。"""
    if tid in af.runners:
        return
    with Session(af.engine) as lock_s:
        ptask = lock_s.get(m.Task, tid)
        plock = af.project_lock(ptask.project_id) if ptask else None
    runner = TaskRunner(
        af.engine, af.gateway, af.bus, af.settings, tid, project_lock=plock,
        spawn_runner=lambda sid: start_task_runner(af, sid),
    )
    af.runners[tid] = runner

    async def _wrap():
        try:
            await runner.run()
        finally:
            af.runners.pop(tid, None)

    try:
        asyncio.create_task(_wrap())
    except RuntimeError:



        af.runners.pop(tid, None)
        raise


async def _start_run(af, tid: int) -> dict:
    """置 running + 陈旧残锁自愈 + 拉起 runner（run 端点与 auto_run 共用）。"""
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")

        if task.status not in (m.TaskStatus.spec_pending, m.TaskStatus.running, m.TaskStatus.paused_human, m.TaskStatus.rework):
            raise HTTPException(400, f"当前状态 {task.status.value} 不可运行")
        spec = s.exec(select(m.Spec).where(m.Spec.task_id == tid).order_by(m.Spec.id.desc())).first()
        if not spec or not spec.confirmed_at:
            raise HTTPException(400, "请先确认 Spec")
        task.status = m.TaskStatus.running
        s.add(task)
        s.commit()
        proj_for_lock = s.get(m.Project, task.project_id) if task.project_id else None
        repo_path_for_lock = proj_for_lock.repo_path if proj_for_lock else None






    if repo_path_for_lock:
        try:
            from agentflow.git_runtime import worktree as wt_mod

            cleared = await asyncio.to_thread(wt_mod.clear_stale_index_lock, repo_path_for_lock)
            for p in cleared:
                af.bus.publish_task(tid, "log.appended", {
                    "level": "sched",
                    "message": f"已清理陈旧 git 残锁（无进程持有且超时）: {p} —— 否则本任务所有 git 操作都会被它挡死",
                })
        except Exception as e:
            af.bus.publish_task(tid, "log.appended", {
                "level": "sched",
                "message": f"残锁检测异常（不阻塞恢复）: {type(e).__name__}: {e}",
            })


    af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "running"})

    if tid in af.runners:
        return {"started": False, "reason": "已在运行"}
    start_task_runner(af, tid)
    return {"started": True, "task_id": tid}


@router.post("/tasks/{tid}/run")
async def run_task(tid: int, request: Request, _: str = Depends(require_auth)):
    return await _start_run(request.app.state.af, tid)


@router.post("/tasks/{tid}/pause")
def pause_task(tid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)


        if task and task.status in (m.TaskStatus.running, m.TaskStatus.spec_generating):
            task.status = m.TaskStatus.paused_human
            s.add(task)
            s.commit()
            af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "paused_human"})
        return {"ok": True}


@router.post("/tasks/{tid}/resume")
async def resume_task(tid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af

    _human_resume_verify(tid, af)
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)

        if task and task.status in (m.TaskStatus.paused_human, m.TaskStatus.failed):
            task.status = m.TaskStatus.running
            s.add(task)
            s.commit()
            af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "running"})
    return await run_task(tid, request, _)


def _human_resume_verify(tid: int, af) -> None:
    """C-4：恢复前重验。worktree 存在未提交改动（可能用户手动改过），命中的已绿 feature 标 stale。"""
    from agentflow.core.partition import feature_write_set
    from agentflow.git_runtime import worktree as wt_mod
    from agentflow.git_runtime.repo import RepoHandle

    try:
        with Session(af.engine) as s:
            task = s.get(m.Task, tid)
            if not task:
                return
            proj = s.get(m.Project, task.project_id)
            if not proj:
                return
            wt = wt_mod.dev_worktree_path(af.settings, tid)
            if not wt.exists():
                return
            repo = RepoHandle(wt)
            dirty = (repo.repo.git.status("--porcelain") or "").splitlines()
            changed: set[str] = set()
            for line in dirty:
                p = line[3:].strip()
                if "->" in p:
                    p = p.split("->")[-1].strip()
                changed.add(p.replace("\\", "/"))
            if not changed:
                return
            passed = s.exec(
                select(m.Feature).where(m.Feature.task_id == tid, m.Feature.status == m.FeatureStatus.passed)
            ).all()
            hit = False
            for f in passed:
                if feature_write_set(f, wt) & changed:
                    f.status = m.FeatureStatus.stale
                    s.add(f)
                    hit = True
            if hit:
                s.commit()
                af.bus.publish_task(tid, "log.appended", {"level": "human", "message": "恢复前检测到已绿功能被改动，已标记重新验证"})
    except Exception:

        pass


@router.post("/tasks/{tid}/human-input")
async def human_input(tid: int, body: HumanIn, request: Request, _: str = Depends(require_auth)):
    """停机后人工决策：按选项真实分流（C-2）。判定权在代码，LLM 不参与。"""
    af = request.app.state.af
    opt = (body.option or "").strip()



    if "批准并执行" in opt:
        return await asyncio.to_thread(_human_approve_ops_exec, tid, af)
    if _is_pending_ops_approval(af.engine, tid) and ("重做" in opt or not opt):
        return await asyncio.to_thread(_human_ops_pending_requeue, tid, af, body.text or "", body.images)
    if "回滚" in opt:
        return await asyncio.to_thread(_human_rollback, tid, af)
    if "放弃" in opt:
        return await asyncio.to_thread(_human_skip_feature, tid, af)
    if "重规划" in opt:
        return await asyncio.to_thread(_human_replan, tid, af)
    if "确认无产出" in opt:
        return await asyncio.to_thread(_human_confirm_noop, tid, af)
    if "退回修复" in opt or "重新开发" in opt:
        return await asyncio.to_thread(_human_rework, tid, af)



    image_names = await asyncio.to_thread(_save_clarify_images, af.settings, tid, body.images)
    with Session(af.engine) as s:
        if image_names:
            um = m.ClarifyMessage(task_id=tid, role="user", content=body.text or "", images=json.dumps(image_names))
            s.add(um)
            s.commit()
            s.refresh(um)
            af.bus.publish_task(
                tid, "clarify.message",
                {"task_id": tid, "id": um.id, "role": "user", "content": body.text or "", "images": image_names},
            )
        af.bus.publish_task(tid, "log.appended", {"level": "human", "message": body.text or body.option})
    return await resume_task(tid, request, _)


class CoverageGapIn(BaseModel):
    text: str = ""


@router.post("/tasks/{tid}/coverage-gap")
def mark_coverage_gap(tid: int, body: CoverageGapIn, request: Request, _: str = Depends(require_auth)):
    '''人审「标记漏验」（P2，2026-09-29）：把"人发现的验收缺口"落成一条项目规则。'''
    af = request.app.state.af
    return _human_mark_coverage_gap(tid, af, body.text)


def _human_mark_coverage_gap(tid: int, af, text: str) -> dict:
    from agentflow.verifiers import probe

    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if task is None:
            raise HTTPException(404, "task not found")
        spec = s.exec(select(m.Spec).where(m.Spec.task_id == tid).order_by(m.Spec.id.desc())).first()
        feats = s.exec(select(m.Feature).where(m.Feature.spec_id == spec.id)).all() if spec else []
        summary = probe.ui_coverage_summary(feats)
        desc = (text or "").strip() or "本次验收覆盖不完整，同类需求须补齐覆盖。"
        title = f"[人审漏验] {(task.title or '')[:40]}"
        parts = [f"人审标记的验收缺口：{desc}", f"（来自任务#{tid}「{task.title or ''}」）"]
        if summary:
            parts.append(summary)
        parts.append(
            "要求：涉及相同页面/组件的同类需求，Spec 阶段必须把这些页面/维度纳入 ui 声明与验收命令，"
            "不得只验代表页。"
        )
        rule = m.ProjectRule(project_id=int(task.project_id), title=title[:120],
                             content="\n".join(parts)[:2000])
        s.add(rule)
        s.commit()
        s.refresh(rule)
        rid = int(rule.id)
    af.bus.publish_task(tid, "log.appended", {
        "level": "human",
        "message": f"已按人审漏验标记落一条项目规则（#{rid}）：「{title}」——后续同类 Spec 生成会自动带上",
    })
    return {"ok": True, "rule_id": rid, "title": title, "summary": summary}


@router.post("/tasks/{tid}/approval/{approval_id}")
def decide_approval(tid: int, approval_id: str, body: ApprovalIn, request: Request, _: str = Depends(require_auth)):
    """ask 档命令审批决议（P0-2）。allow_prefix 登记任务级前缀，同类命令后续免审。"""
    from agentflow.core.approvals import REGISTRY

    af = request.app.state.af
    ok, detail = REGISTRY.decide(approval_id, body.decision)
    if ok:
        af.bus.publish_task(tid, "approval.resolved", {
            "approval_id": approval_id, "task_id": tid, "decision": body.decision,
        })
        af.bus.publish_task(tid, "log.appended", {
            "level": "human", "message": f"命令审批决议: {body.decision}（{approval_id}）",
        })
    return {"ok": ok, "detail": detail}


@router.get("/tasks/{tid}/pending-approval")
def get_pending_approval(tid: int, request: Request, _: str = Depends(require_auth)):
    """刷新还原：任务当前待审批命令（内存态，approval.required 事件只推一次）。"""
    from agentflow.core.approvals import REGISTRY

    p = REGISTRY.pending_for_task(tid)
    return p if p else {"approval_id": None}


def _failing_feature(session: Session, tid: int):
    """取任务中当前失败/卡住的功能（回滚/放弃/重规划的目标）。"""
    rows = session.exec(
        select(m.Feature)
        .where(m.Feature.task_id == tid, m.Feature.status.in_([m.FeatureStatus.verifying, m.FeatureStatus.failed]))
        .order_by(m.Feature.retry_count.desc())
    ).all()
    if rows:
        return rows[0]





    task = session.get(m.Task, tid)
    if task is None or task.status in (
        m.TaskStatus.running,
        m.TaskStatus.merging,
        m.TaskStatus.merged,
        m.TaskStatus.pushed,
    ):
        return None
    run = session.exec(
        select(m.VerifierRun)
        .where(
            m.VerifierRun.task_id == tid,
            m.VerifierRun.exit_code != 0,
            m.VerifierRun.feature_id.is_not(None),
        )
        .order_by(m.VerifierRun.id.desc())
    ).first()
    return session.get(m.Feature, run.feature_id) if run else None


def _dev_worktree_scope(af, tid: int, proj) -> "Path | None":
    """回滚时允许清理未跟踪文件的范围：**仅任务 dev worktree**（平台自管的临时工作区）。"""
    try:
        wt = (Path(af.settings.home) / "dev_worktrees" / f"dev-{tid}").resolve()
        repo_p = Path(proj.repo_path).resolve()
    except Exception:
        return None
    return wt if wt.is_dir() and repo_p == wt else None


def _human_rollback(tid: int, af):
    """回滚到最近绿点（真实回滚，走 anchors）。"""
    from agentflow.git_runtime import anchors as anchors_mod
    from agentflow.git_runtime.repo import RepoHandle

    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        anchor = s.exec(
            select(m.GreenAnchor).where(
                m.GreenAnchor.task_id == tid, m.GreenAnchor.invalidated_at.is_(None)
            ).order_by(m.GreenAnchor.id.desc())
        ).first()
        if not anchor:
            raise HTTPException(400, "无可用绿点可回滚")
        proj = s.get(m.Project, task.project_id)
        repo = RepoHandle(proj.repo_path)
        try:
            repo.checkout(task.branch)
        except Exception:
            pass
        cleaned = anchors_mod.rollback_task(s, repo, task, anchor, _dev_worktree_scope(af, tid, proj))
        task.status = m.TaskStatus.spec_pending
        s.add(task)
        s.commit()
        af.bus.publish_task(tid, "anchor.invalidated", {"anchor_id": anchor.id})
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "spec_pending"})
        af.bus.publish_task(tid, "log.appended", {"level": "human", "message": "已回滚到最近绿点，需重新运行"})
        if cleaned:
            af.bus.publish_task(tid, "log.appended", {
                "level": "human",
                "message": f"回滚同时清理 {len(cleaned)} 个未跟踪文件（dev worktree 内）: "
                + ", ".join(cleaned[:5]) + ("…" if len(cleaned) > 5 else ""),
            })
    return {"ok": True, "action": "rollback"}


def _human_skip_feature(tid: int, af):
    """放弃当前失败功能（标 skipped，续跑其余）。"""
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        f = _failing_feature(s, tid)
        if f is None:
            raise HTTPException(400, "无失败功能可放弃")
        f.status = m.FeatureStatus.skipped
        s.add(f)
        task.status = m.TaskStatus.spec_pending
        s.add(task)
        s.commit()
        af.bus.publish_task(tid, "feature.updated", {"feature_id": f.id, "status": "skipped"})
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "spec_pending"})
        af.bus.publish_task(tid, "log.appended", {"level": "human", "message": f"已放弃功能 F{f.seq}「{f.title}」，其余续跑"})
    return {"ok": True, "action": "skip"}


def _human_replan(tid: int, af):
    """Lead 重规划失败功能的 verify_commands（B-2 通道，人工触发）。"""
    from agentflow.agents.lead import replan_verify_commands

    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        f = _failing_feature(s, tid)
        if f is None:
            raise HTTPException(400, "无失败功能可重规划")
        runs = s.exec(select(m.VerifierRun).where(m.VerifierRun.feature_id == f.id).order_by(m.VerifierRun.id.desc()).limit(3)).all()



        ctx_parts: list[str] = []
        for r in runs:
            if r.exit_code == 0:
                continue
            ctx_parts.append(f"--- {r.verifier} (exit {r.exit_code}) ---\n{r.output_uri[:1200]}")
            d = (getattr(r, "detail", "") or "").strip()
            if d:
                ctx_parts.append(f"结构化失败详情（含页面 DOM 证据）:\n{d[:2500]}")
        ctx = "\n\n".join(ctx_parts) or "（无失败输出记录）"


        try:
            qa_lines = [
                str((ev.get("payload") or {}).get("message") or "")
                for ev in af.event_log.since(tid, 0, limit=2000)
                if ev.get("event") == "log.appended" and (ev.get("payload") or {}).get("level") == "qa"
            ]
        except Exception:
            qa_lines = []
        if qa_lines:
            ctx += "\n\nQA 归因（最新在前）:\n" + "\n\n".join(q[:800] for q in qa_lines[:2])
        err = replan_verify_commands(af.gateway, s, task, f, ctx, bus=af.bus)
        if err:
            raise HTTPException(400, f"重规划失败: {err}")
        task.status = m.TaskStatus.spec_pending
        s.add(task)
        s.commit()
        af.bus.publish_task(tid, "log.appended", {"level": "lead", "message": f"功能 F{f.seq} 验证命令已由 Lead 重规划"})
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "spec_pending"})
    return {"ok": True, "action": "replan"}


def _human_confirm_noop(tid: int, af):
    """no-op 裁决·确认无产出：人工确认任务确实无事可做 → 直接置 done。"""
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        task.status = m.TaskStatus.done
        if not task.completed_at:
            task.completed_at = datetime.now(timezone.utc).isoformat()
        s.add(task)
        s.commit()
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "done"})
        af.bus.publish_task(tid, "log.appended", {"level": "human", "message": "人工确认：任务确无代码产出，直接完成（0 diff 裁决）"})

        TaskRunner(af.engine, af.gateway, af.bus, af.settings, tid)._evolve_async(tid)
    return {"ok": True, "action": "confirm_noop"}


def _human_rework(tid: int, af):
    """no-op 裁决·退回修复：人工判定应有产出但 agent 未实现 → 已通过功能全部标回 pending 重派开发。"""
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        feats = s.exec(
            select(m.Feature).where(
                m.Feature.task_id == tid,
                m.Feature.status.in_([m.FeatureStatus.passed, m.FeatureStatus.failed]),
            )
        ).all()
        if not feats:
            raise HTTPException(400, "无已通过/已失败功能可退回")
        for f in feats:
            f.status = m.FeatureStatus.pending
            f.retry_count = 0
            s.add(f)
        task.status = m.TaskStatus.spec_pending
        s.add(task)
        s.commit()
        for f in feats:
            af.bus.publish_task(tid, "feature.updated", {"feature_id": f.id, "status": "pending"})
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "spec_pending"})
        af.bus.publish_task(tid, "log.appended", {"level": "human", "message": f"人工退回修复：{len(feats)} 个已通过功能标回 pending，重新派发开发"})
    return {"ok": True, "action": "rework"}


@router.post("/tasks/{tid}/abort")
def abort_task(tid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    residuals: list[str] = []
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        proj = s.get(m.Project, task.project_id)


        if proj:
            try:
                from agentflow.git_runtime import worktree as wt_mod

                wt_mod.remove_dev_worktree(af.settings, Path(proj.repo_path), tid)
            except Exception as e:
                residuals.append(f"dev worktree 清理失败: {e}")
            if task.branch:
                try:
                    branch.delete_task_branch(RepoHandle(Path(proj.repo_path)), tid)
                except Exception as e:

                    residuals.append(f"分支 {task.branch} 删除失败: {e}")

            try:
                from agentflow.core.scheduler import sweep_agent_temp_files

                swept = sweep_agent_temp_files(RepoHandle(Path(proj.repo_path)), Path(proj.repo_path))
                if swept:
                    af.bus.publish_task(tid, "log.appended", {
                        "level": "sched", "message": f"已清扫 agent 临时文件: {', '.join(swept[:5])}",
                    })
            except Exception:
                pass
        task.status = m.TaskStatus.aborted
        task.completed_at = _utcnow() if not task.completed_at else task.completed_at
        s.add(task)



        cancelled = s.exec(
            select(m.MergeQueueEntry).where(
                m.MergeQueueEntry.task_id == tid,
                m.MergeQueueEntry.status.in_(["queued", "merging"]),
            )
        ).all()
        for q in cancelled:
            q.status = "aborted"
            q.error = "任务被用户废弃：合并取消"
            s.add(q)

        from agentflow.core.scheduler import _node_payload

        dead_merges = s.exec(
            select(m.Node).where(
                m.Node.task_id == tid,
                m.Node.kind == "merge",
                m.Node.status == m.NodeStatus.running,
            )
        ).all()
        for node in dead_merges:
            node.status = m.NodeStatus.failed
            node.ended_at = _utcnow()
            node.summary = (node.summary or "")[:200] + "（任务已废弃，合并中断）"
            s.add(node)
        s.commit()
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "aborted"})
        if cancelled:
            af.bus.publish_task(tid, "merge.updated", {"status": "aborted", "error": "任务被用户废弃：合并取消"})
        for node in dead_merges:
            af.bus.publish_task(tid, "node.updated", _node_payload(node))
        for r in residuals:
            af.bus.publish_task(tid, "log.appended", {"level": "sched", "message": f"废弃清理残留: {r}"})

        TaskRunner(af.engine, af.gateway, af.bus, af.settings, tid)._evolve_async(tid)
        return {"ok": True, "residuals": residuals}



@router.get("/tasks/{tid}/branch-stats")
def branch_stats(tid: int, request: Request, _: str = Depends(require_auth)):
    """分支大小（B2）：领先 main 的 commit 数 + 改动文件数。前端点击才查。"""
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task or not task.branch:
            return {"branch": None, "commits_ahead": None, "files_changed": None}
        proj = s.get(m.Project, task.project_id)
        if not proj:
            return {"branch": None, "commits_ahead": None, "files_changed": None}
    try:
        repo = RepoHandle(proj.repo_path)
        ahead = int(repo.repo.git.rev_list("--count", f"main..{task.branch}").strip() or "0")
        files = len(repo.repo.git.diff("--name-only", f"main...{task.branch}").splitlines())
        return {"branch": task.branch, "commits_ahead": ahead, "files_changed": files}
    except Exception as e:
        return {"branch": task.branch, "commits_ahead": None, "files_changed": None, "error": str(e)}


@router.get("/tasks/{tid}/diff")
def task_diff(tid: int, request: Request, path: str | None = None, _: str = Depends(require_auth)):
    """任务分支 vs main 的 diff（只读，合并前审阅用）。"""
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task or not task.branch:
            return {"branch": None, "files": []}
        proj = s.get(m.Project, task.project_id)
        if not proj:
            return {"branch": None, "files": []}
    try:
        repo = RepoHandle(proj.repo_path)
        rng = f"main...{task.branch}"





        if task.status in m.MERGED_OK_STATUSES:
            rng = _merged_diff_range(repo, task.branch) or rng
        if path:
            return _diff_patch(repo, task.branch, rng, path)

        stats: dict[str, tuple[str | None, str | None]] = {}
        for line in repo.repo.git.diff("--ignore-cr-at-eol", "-M", "--numstat", rng).splitlines():
            parts = line.split("\t")
            if len(parts) != 3:
                continue
            ins, dele, fp = parts
            stats[fp] = (ins if ins != "-" else None, dele if dele != "-" else None)
        statuses: dict[str, str] = {}
        for line in repo.repo.git.diff("--ignore-cr-at-eol", "-M", "--name-status", rng).splitlines():
            parts = line.split("\t")
            if len(parts) < 2:
                continue
            statuses[parts[-1]] = parts[0][:1]
        files = [
            {
                "path": fp,
                "status": statuses.get(fp, "M"),
                "insertions": int(ins) if ins else None,
                "deletions": int(dele) if dele else None,
            }
            for fp, (ins, dele) in stats.items()
        ]
        files.sort(key=lambda f: f["path"])
        return {"branch": task.branch, "files": files}
    except Exception as e:
        return {"branch": task.branch, "files": [], "error": str(e)}


def _merged_diff_range(repo: RepoHandle, branch: str, main_ref: str = "main") -> str | None:
    """merged 任务的 diff 范围：找 main 上第二父=分支头的合并 commit → `{c}^1...{c}`。"""
    try:
        tip = repo.repo.git.rev_parse(branch).strip()
        cands = (repo.repo.git.rev_list("--merges", "--ancestry-path", f"{branch}..{main_ref}") or "").split()
        if not cands:
            cands = (repo.repo.git.rev_list("--merges", f"{branch}..{main_ref}") or "").split()
        for mc in cands:
            try:
                if repo.repo.git.rev_parse(f"{mc}^2").strip() == tip:
                    return f"{mc}^1...{mc}"
            except Exception:
                continue
    except Exception:
        pass
    return None


def _diff_patch(repo: RepoHandle, branch: str, rng: str, path: str, limit: int = 200_000) -> dict:
    """单文件 patch：二进制检测 + 截断保护。"""
    out = repo.repo.git.diff("--ignore-cr-at-eol", "-M", f"{rng}", "--", path)
    binary = "Binary files" in out
    truncated = len(out) > limit
    if truncated:
        out = out[:limit]
    return {"branch": branch, "path": path, "patch": out, "binary": binary, "truncated": truncated}


@router.get("/tasks/{tid}/summary")
def get_summary(tid: int, request: Request, _: str = Depends(require_auth)):
    """任务总结（#14）：终态关键信息聚合——成败/失败原因/总耗时/commit 清单/分功能明细。"""
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        feats = s.exec(select(m.Feature).where(m.Feature.task_id == tid).order_by(m.Feature.seq)).all()
        nodes = s.exec(select(m.Node).where(m.Node.task_id == tid).order_by(m.Node.seq)).all()
        anchors = s.exec(select(m.GreenAnchor).where(m.GreenAnchor.task_id == tid).order_by(m.GreenAnchor.id)).all()
        mq = s.exec(select(m.MergeQueueEntry).where(m.MergeQueueEntry.task_id == tid).order_by(m.MergeQueueEntry.id.desc())).first()
        feat_map = {f.id: f for f in feats}


        features = [
            {
                "seq": f.seq,
                "title": f.title,
                "status": f.status.value,
                "retry_count": f.retry_count,
            }
            for f in feats
        ]
        passed = sum(1 for f in feats if f.status in (m.FeatureStatus.passed, m.FeatureStatus.skipped))
        pass_rate = round(passed / len(feats), 3) if feats else None


        failure_reasons: list[str] = []
        for f in feats:
            if f.status in (m.FeatureStatus.failed, m.FeatureStatus.stale):
                failure_reasons.append(f"F{f.seq}「{f.title}」{f.status.value}（重试 {f.retry_count} 次）")
        for n in nodes:
            if n.status == m.NodeStatus.failed and n.summary:
                failure_reasons.append(f"[{n.kind}] {n.summary[:200]}")
        if mq and mq.status in ("failed", "aborted") and mq.error:
            failure_reasons.append(f"合并失败: {mq.error[:300]}")


        duration_ms = 0
        if task.completed_at:
            try:
                duration_ms = max(
                    0,
                    int((datetime.fromisoformat(task.completed_at) - datetime.fromisoformat(task.created_at)).total_seconds() * 1000),
                )
            except Exception:
                duration_ms = 0
        nodes_duration_ms = sum(n.duration_ms or 0 for n in nodes)


        commits = [
            {
                "kind": "green",
                "hash": a.commit_hash,
                "short": a.commit_hash[:8],
                "feature_seq": feat_map[a.feature_id].seq if a.feature_id and a.feature_id in feat_map else None,
                "feature_title": feat_map[a.feature_id].title if a.feature_id and a.feature_id in feat_map else None,
                "created_at": a.created_at,
                "invalidated": bool(a.invalidated_at),
            }
            for a in anchors
        ]
        merge_commit = None
        if task.branch:
            try:
                proj = s.get(m.Project, task.project_id)
                repo = RepoHandle(proj.repo_path)
                out = repo.repo.git.log("--merges", "-1", "--pretty=format:%H|%s", "--grep", f"合并任务：{task.title}").strip()
                if "|" in out:
                    h, msg = out.split("|", 1)
                    merge_commit = {"hash": h, "short": h[:8], "message": msg}
                    commits.append({"kind": "merge", "hash": h, "short": h[:8], "feature_seq": None,
                                    "feature_title": None, "created_at": "", "invalidated": False})
            except Exception:
                pass


        return {
            "task": {
                "id": task.id,
                "title": task.title,
                "status": task.status.value,
                "branch": task.branch,

                "code_landed": _ops_code_landed(s, task.id),

                "has_remote": _project_has_remote(s, task.project_id),
                "created_at": task.created_at,
                "completed_at": task.completed_at,
            },
            "duration_ms": duration_ms,
            "nodes_duration_ms": nodes_duration_ms,
            "nodes_total": len(nodes),
            "nodes_failed": sum(1 for n in nodes if n.status == m.NodeStatus.failed),
            "features": features,
            "features_pass_rate": pass_rate,
            "commits": commits,
            "merge": {
                "status": mq.status if mq else None,
                "error": mq.error if mq else None,
                "attempts": mq.attempts if mq else None,
                "queued_at": mq.created_at if mq else None,
                "updated_at": mq.updated_at if mq else None,
                "commit": merge_commit,
            },
            "failure_reasons": failure_reasons[:10],
            "selfheal": _task_selfheal(s, task),
        }


def _task_selfheal(s: Session, task: m.Task) -> dict:
    """任务自愈区块数据：进化账本评分/信号 + 本任务提案档案。"""
    entry = s.exec(
        select(m.EvolutionEntry).where(m.EvolutionEntry.task_id == task.id)
    ).first()
    proposals = s.exec(
        select(m.SelfHealProposal)
        .where(m.SelfHealProposal.task_id == task.id)
        .order_by(m.SelfHealProposal.id.desc())
    ).all()
    import json as _json

    def _load(raw: str, default):
        try:
            return _json.loads(raw) if raw else default
        except Exception:
            return default

    return {
        "score": entry.score if entry else None,
        "generation": entry.generation if entry else None,
        "signals": _load(entry.signals if entry else "", {}),
        "proposals": [
            {
                "id": p.id, "kind": p.kind, "title": p.title, "detail": p.detail,
                "status": p.status, "origin": p.origin, "evidence_ids": _load(p.evidence_ids, []),
                "preflight": _load(p.preflight, {}), "hit_count": p.hit_count,
                "adopted_at": p.adopted_at, "retired_at": p.retired_at, "created_at": p.created_at,
            }
            for p in proposals
        ],
    }


@router.get("/tasks/{tid}/ci-summary")
def get_ci_summary(tid: int, request: Request, _: str = Depends(require_auth)):
    """CI 页签数据源（客观证据层）：验收命令时间线 + 绿点 + 租约对账 + 合并门禁状态。"""
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        feats = s.exec(select(m.Feature).where(m.Feature.task_id == tid)).all()
        feat_map = {f.id: f for f in feats}



        from agentflow.spec.scope import current_features

        cur_feats = current_features(s, tid)
        nodes = {n.id: n for n in s.exec(select(m.Node).where(m.Node.task_id == tid)).all()}
        runs = s.exec(
            select(m.VerifierRun).where(m.VerifierRun.task_id == tid).order_by(m.VerifierRun.id)
        ).all()
        anchors = s.exec(
            select(m.GreenAnchor).where(m.GreenAnchor.task_id == tid).order_by(m.GreenAnchor.id)
        ).all()
        leases = s.exec(select(m.Lease).where(m.Lease.task_id == tid)).all()
        mq = s.exec(
            select(m.MergeQueueEntry).where(m.MergeQueueEntry.task_id == tid)
            .order_by(m.MergeQueueEntry.id.desc())
        ).first()
        entries = s.exec(
            select(m.MergeQueueEntry).where(m.MergeQueueEntry.task_id == tid)
            .order_by(m.MergeQueueEntry.id.desc())
        ).all()

        run_items = []
        for r in runs:
            f = feat_map.get(r.feature_id)
            node = nodes.get(r.node_id) if r.node_id else None
            run_items.append({
                "id": r.id,
                "feature_title": (f.title if f else "") or "",
                "verifier": r.verifier,
                "cmd": (r.cmd or "")[:200],
                "exit_code": r.exit_code,
                "duration_ms": r.duration_ms,
                "output_tail": (r.output_uri or "")[-800:],
                "classification": r.classification,
                "started_at": (node.started_at if node else None),
                "ok": r.exit_code == 0 and r.output_uri is not None,
                "detail": _loads_detail(getattr(r, "detail", None)),
            })
        run_items.reverse()


        by_role: dict[str, dict[str, int]] = {}

        by_kind: dict[str, dict[str, int]] = {}
        total_in = total_out = total_cached = 0
        for n in nodes.values():
            if not (n.token_in or n.token_out):
                continue
            r = n.role or n.kind or "agent"
            cached = getattr(n, "token_in_cached", 0) or 0
            agg = by_role.setdefault(r, {"calls": 0, "tokens_in": 0, "tokens_out": 0, "tokens_in_cached": 0})
            agg["calls"] += 1
            agg["tokens_in"] += n.token_in or 0
            agg["tokens_out"] += n.token_out or 0
            agg["tokens_in_cached"] += cached
            kagg = by_kind.setdefault(n.kind or "agent", {"calls": 0, "tokens_in": 0, "tokens_out": 0, "tokens_in_cached": 0})
            kagg["calls"] += 1
            kagg["tokens_in"] += n.token_in or 0
            kagg["tokens_out"] += n.token_out or 0
            kagg["tokens_in_cached"] += cached
            total_in += n.token_in or 0
            total_out += n.token_out or 0
            total_cached += cached



        extra_calls = s.exec(
            select(m.LLMExtraCall).where(m.LLMExtraCall.task_id == tid)
        ).all()
        for x in extra_calls:
            xcached = getattr(x, "tokens_in_cached", 0) or 0
            agg = by_role.setdefault(x.role or "agent", {"calls": 0, "tokens_in": 0, "tokens_out": 0, "tokens_in_cached": 0})
            agg["calls"] += 1
            agg["tokens_in"] += x.tokens_in or 0
            agg["tokens_out"] += x.tokens_out or 0
            agg["tokens_in_cached"] += xcached
            kagg = by_kind.setdefault(x.kind or "agent", {"calls": 0, "tokens_in": 0, "tokens_out": 0, "tokens_in_cached": 0})
            kagg["calls"] += 1
            kagg["tokens_in"] += x.tokens_in or 0
            kagg["tokens_out"] += x.tokens_out or 0
            kagg["tokens_in_cached"] += xcached
            total_in += x.tokens_in or 0
            total_out += x.tokens_out or 0
            total_cached += xcached


        lease_items = [
            {"file_path": l.file_path, "state": l.state.value, "feature_title": (feat_map.get(l.feature_id).title if l.feature_id in feat_map else "") or ""}
            for l in leases
        ]

        return {
            "task_id": tid,
            "features_total": len([f for f in cur_feats if f.status != m.FeatureStatus.skipped]),
            "features_passed": sum(1 for f in cur_feats if f.status == m.FeatureStatus.passed),

            "budget": budget_snapshot(s, task, af.settings),
            "runs": run_items[:100],
            "greens": [
                {"commit_hash": a.commit_hash, "created_at": a.created_at, "invalidated_at": a.invalidated_at, "feature_title": feat_map.get(a.feature_id).title if a.feature_id and a.feature_id in feat_map else None}
                for a in anchors
            ],
            "leases": lease_items,
            "merge": {
                "status": mq.status, "attempts": mq.attempts, "error": mq.error,
                "round_no": mq.round_no, "redo_of": mq.redo_of, "hold": mq.hold,
                "merged_sha": mq.merged_sha,
            } if mq else None,
            "merge_history": [
                {
                    "id": e.id, "status": e.status, "round_no": e.round_no,
                    "attempts": e.attempts, "merged_sha": e.merged_sha,
                    "redo_of": e.redo_of, "hold": e.hold, "error": e.error,
                    "updated_at": e.updated_at,
                }
                for e in entries
            ],
            "tokens": {
                "by_role": by_role, "by_kind": by_kind, "total_in": total_in, "total_out": total_out,
                "total_in_cached": total_cached,
                "extra_calls": len(extra_calls),
                "extra_detail": [
                    {"role": x.role, "kind": x.kind, "purpose": x.purpose,
                     "tokens_in": x.tokens_in, "tokens_out": x.tokens_out, "created_at": x.created_at}
                    for x in extra_calls
                ],
            },
        }


@router.get("/tasks/{tid}/gate")
def get_gate(tid: int, request: Request, _: str = Depends(require_auth)):
    """合并门禁当前状态（待审/已批/已驳回），供 UI 刷新回放。"""
    af = request.app.state.af
    with Session(af.engine) as s:
        ap = s.exec(
            select(m.MergeApproval).where(m.MergeApproval.task_id == tid)
            .order_by(m.MergeApproval.id.desc())
        ).first()
        if ap is None:
            return {"approval_id": None}
        return {
            "approval_id": ap.id, "task_id": ap.task_id, "status": ap.status,
            "reason": ap.reason, "created_at": ap.created_at, "decided_at": ap.decided_at,
        }


class GateDecisionIn(BaseModel):
    decision: str
    reason: str = ""

    images: list[str] = []


@router.post("/tasks/{tid}/gate")
def decide_gate(tid: int, body: GateDecisionIn, request: Request, _: str = Depends(require_auth)):
    """人工裁决合并门禁：批准 → 合并条目出队继续合并；驳回 → 原因落黑板（审计事件）。"""
    af = request.app.state.af
    if body.decision not in ("approve", "reject"):
        raise HTTPException(422, "decision 必须是 approve|reject")
    if body.decision == "reject" and not body.reason.strip():
        raise HTTPException(422, "驳回必须填写原因（原因回注给任务作为修复输入）")
    with Session(af.engine) as s:
        ap = s.exec(
            select(m.MergeApproval).where(m.MergeApproval.task_id == tid)
            .order_by(m.MergeApproval.id.desc())
        ).first()
        if ap is None or ap.status != "pending":
            raise HTTPException(409, "no pending gate for this task")
        ap.status = "approved" if body.decision == "approve" else "rejected"
        ap.reason = body.reason.strip()
        ap.decided_at = datetime.now(timezone.utc).isoformat()
        s.add(ap)
        entry = s.exec(
            select(m.MergeQueueEntry).where(m.MergeQueueEntry.task_id == tid)
            .order_by(m.MergeQueueEntry.id.desc())
        ).first()
        if body.decision == "approve":
            if entry is not None and entry.status == "gated":
                entry.status = "queued"
                entry.updated_at = datetime.now(timezone.utc).isoformat()
                s.add(entry)
            t = s.get(m.Task, tid)
            if t is not None and t.status == m.TaskStatus.paused_human:
                t.status = m.TaskStatus.running
                s.add(t)
            s.commit()
            af.bus.publish_task(tid, "gate.resolved", {"approval_id": ap.id, "status": ap.status})
            af.bus.publish_task(tid, "log.appended", {
                "level": "human", "message": f"合并门禁已批准（{ap.decided_at}），合并队列继续消费",
            })
            return {"ok": True, "status": "approved"}

        if entry is not None and entry.status == "gated":
            entry.status = "aborted"
            entry.error = f"门禁驳回: {body.reason.strip()[:200]}"
            entry.updated_at = datetime.now(timezone.utc).isoformat()
            s.add(entry)
        s.commit()


    image_names = _save_clarify_images(af.settings, tid, body.images)
    if image_names:
        with Session(af.engine) as s:
            um = m.ClarifyMessage(task_id=tid, role="user", content=body.reason.strip(), images=json.dumps(image_names))
            s.add(um)
            s.commit()
            s.refresh(um)
            af.bus.publish_task(
                tid, "clarify.message",
                {"task_id": tid, "id": um.id, "role": "user", "content": body.reason.strip(), "images": image_names},
            )
    af.bus.publish_task(tid, "gate.resolved", {"approval_id": None, "status": "rejected", "reason": body.reason.strip()[:300]})
    af.bus.publish_task(tid, "human.required", {
        "reason": f"合并门禁驳回：{body.reason.strip()[:200]}（任务已暂停；修复后可恢复运行或另开子任务）",
        "options": ["查看 Report"],
    })
    af.bus.publish_task(tid, "log.appended", {
        "level": "human", "message": f"合并门禁驳回：{body.reason.strip()[:500]}",
    })
    return {"ok": True, "status": "rejected"}


class ReviewRedoIn(BaseModel):
    instruction: str

    images: list[str] = []


@router.post("/tasks/{tid}/review/pass")
def review_pass(tid: int, request: Request, _: str = Depends(require_auth)):
    """人审·通过（队列化）：验收确认 → **待推送**（提交已由自动合并完成）。"""
    af = request.app.state.af
    synced: bool | None = None
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        if task.status != m.TaskStatus.human_review:
            raise HTTPException(409, f"当前状态 {task.status.value} 不可确认通过（仅人审中）")
        if not task.branch:

            raise HTTPException(400, "该任务无分支（运维人审），请走运维人审（ops-review/pass）")
        proj = s.get(m.Project, task.project_id)
        synced = _main_synced_with_origin(proj.repo_path if proj else "")
        task.status = m.TaskStatus.pushed if synced is True else m.TaskStatus.pending_push
        s.add(task)
        s.commit()
    if synced is True:
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "pushed"})
        af.bus.publish_task(tid, "merge.review_passed", {"task_id": tid})
        af.bus.publish_task(tid, "log.appended", {
            "level": "human",
            "message": "人审通过：本地 main 已与 origin/main 同步（此前已推送）——任务直接收口「已推送」终态，无需再推",
        })
    else:
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "pending_push"})
        af.bus.publish_task(tid, "merge.review_passed", {"task_id": tid})
        af.bus.publish_task(tid, "log.appended", {
            "level": "human",
            "message": "人审通过：进入「待推送」——在 设置→Git 页签推送当前分支后自动转「已推送」",
        })

    TaskRunner(af.engine, af.gateway, af.bus, af.settings, tid)._evolve_async(tid)
    return {"ok": True, "status": "pushed" if synced is True else "pending_push"}


@router.post("/tasks/{tid}/review/redo")
async def review_redo(tid: int, body: ReviewRedoIn, request: Request, _: str = Depends(require_auth)):
    """人审·重做（队列化）：revert 该任务的合并 commit → 功能重开 → 自动续跑修复。"""
    instruction = (body.instruction or "").strip()
    if not instruction:
        raise HTTPException(422, "重做必须填写问题描述（将打回 worktree 作为修复输入）")
    af = request.app.state.af

    image_names = await asyncio.to_thread(_save_clarify_images, af.settings, tid, body.images)
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        if task.status != m.TaskStatus.human_review:
            raise HTTPException(409, f"当前状态 {task.status.value} 不可重做（仅人审中）")
        if not task.branch:

            raise HTTPException(400, "该任务无分支（运维人审），请走运维人审（ops-review/redo）")
        proj = s.get(m.Project, task.project_id)
        if not proj:
            raise HTTPException(404, "project not found")
        mq = s.exec(
            select(m.MergeQueueEntry)
            .where(m.MergeQueueEntry.task_id == tid, m.MergeQueueEntry.merged_sha.is_not(None))
            .order_by(m.MergeQueueEntry.id.desc())
        ).first()
    repo = RepoHandle(proj.repo_path)
    reverted = False
    if mq is not None and mq.merged_sha:






        if not await asyncio.to_thread(merge_mod.merge_changes_present, repo, mq.merged_sha):
            af.bus.publish_task(tid, "log.appended", {
                "level": "human",
                "message": f"重做：合并 {mq.merged_sha[:8]} 的改动已不在 main 上（此前已撤销），跳过 revert 直接重开功能",
            })
        else:
            try:
                conflicts = await asyncio.to_thread(merge_mod.revert_merge_commit, repo, mq.merged_sha, instruction)
            except GitError as e:
                raise HTTPException(409, f"revert 失败，需人工处理 main: {e}")
            if conflicts:
                await asyncio.to_thread(merge_mod.abort_revert, repo)
                af.bus.publish_task(tid, "human.required", {
                    "reason": f"重做 revert 冲突（{len(conflicts)} 个文件），已中止，需人工处理 main",
                    "options": ["查看 Report"],
                })
                raise HTTPException(409, f"revert 冲突 {len(conflicts)} 个文件，已中止: {conflicts[:5]}")
            reverted = True
    with Session(af.engine) as s:

        feats = s.exec(
            select(m.Feature).where(
                m.Feature.task_id == tid,
                m.Feature.status.in_([m.FeatureStatus.passed, m.FeatureStatus.failed]),
            )
        ).all()
        for f in feats:
            f.status = m.FeatureStatus.pending
            f.retry_count = 0
            s.add(f)
        task.status = m.TaskStatus.rework
        s.add(task)
        s.commit()
        s.add(m.HandoffNote(
            task_id=tid, role="user", kind="rework",
            content=f"[用户重做指令] main 已撤销该任务合并，请修复以下问题后重新走合并流程：{instruction}",
        ))
        s.commit()

        if image_names:
            um = m.ClarifyMessage(task_id=tid, role="user", content=instruction, images=json.dumps(image_names))
            s.add(um)
            s.commit()
            s.refresh(um)
            af.bus.publish_task(
                tid, "clarify.message",
                {"task_id": tid, "id": um.id, "role": "user", "content": instruction, "images": image_names},
            )
        for f in feats:
            af.bus.publish_task(tid, "feature.updated", {"feature_id": f.id, "status": "pending"})
    af.bus.publish_task(tid, "merge.review_redo", {"task_id": tid, "reverted": reverted})
    af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "rework"})
    af.bus.publish_task(tid, "log.appended", {
        "level": "human",
        "message": f"人审重做：main 已{'撤销合并' if reverted else '无需 revert（无内容差异）'}，功能重开修复。指令：{instruction[:300]}",
    })

    return await run_task(tid, request, _)



class OpsReviewRedoIn(BaseModel):
    instruction: str = ""

    images: list[str] = []


def _assert_ops_review_task(s: Session, tid: int) -> m.Task:
    """运维人审前置：任务必须处于人审中且**无分支**（ops 任务从不建分支/不产 commit）。"""
    task = s.get(m.Task, tid)
    if not task:
        raise HTTPException(404, "task not found")
    if task.status != m.TaskStatus.human_review:
        raise HTTPException(409, f"当前状态 {task.status.value} 不可人审（仅人审中）")
    if task.branch:
        raise HTTPException(400, "该任务有分支（合并人审），请走合并人审（review/pass|redo）")
    return task


@router.get("/tasks/{tid}/ops-exec")
def get_ops_exec(tid: int, request: Request, _: str = Depends(require_auth)):
    """本任务最新运维执行结论（人审卡证据源：命令 + 验证 exit code + 输出）。"""
    from agentflow.agents.diagnose import latest_ops_exec

    af = request.app.state.af
    with Session(af.engine) as s:
        if not s.get(m.Task, tid):
            raise HTTPException(404, "task not found")
        return {"exec": latest_ops_exec(s, tid)}


@router.post("/tasks/{tid}/ops-review/pass")
def ops_review_pass(tid: int, request: Request, _: str = Depends(require_auth)):
    """运维人审·通过。按**执行结论里的 git 事实**分流："""
    af = request.app.state.af
    with Session(af.engine) as s:
        task = _assert_ops_review_task(s, tid)
        code_landed = _ops_code_landed(s, tid)
        synced: bool | None = None
        if code_landed:
            proj = s.get(m.Project, task.project_id)
            synced = _main_synced_with_origin(proj.repo_path if proj else "")
        if code_landed:
            task.status = m.TaskStatus.pushed if synced is True else m.TaskStatus.pending_push
        else:
            task.status = m.TaskStatus.resolved
        if not task.completed_at:
            task.completed_at = _utcnow()
        s.add(task)
        s.commit()
    if code_landed:
        if synced is True:
            af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "pushed"})
            af.bus.publish_task(tid, "log.appended", {
                "level": "human",
                "message": "人审通过：运维执行合入的代码已在 origin/main（已推送）——任务收口「已推送」终态。",
            })
        else:
            af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "pending_push"})
            af.bus.publish_task(tid, "log.appended", {
                "level": "human",
                "message": "人审通过：进入「待推送」——本次运维把代码合入了本地 main，请到 设置→Git 页签推送 main 后自动转「已推送」。",
            })
    else:
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "resolved"})
        af.bus.publish_task(tid, "log.appended", {
            "level": "human",
            "message": "人审通过：运维问题已解决，任务收口「已解决」（无代码改动、无需推送）。",
        })

    TaskRunner(af.engine, af.gateway, af.bus, af.settings, tid)._evolve_async(tid)
    return {"ok": True, "status": "pushed" if (code_landed and synced is True) else ("pending_push" if code_landed else "resolved")}


@router.post("/tasks/{tid}/ops-review/redo")
async def ops_review_redo(tid: int, body: OpsReviewRedoIn, request: Request, _: str = Depends(require_auth)):
    """运维人审·重做：带人工说明**重新诊断执行**，完成后再回人审。"""
    af = request.app.state.af
    instruction = (body.instruction or "").strip()
    image_names = await asyncio.to_thread(_save_clarify_images, af.settings, tid, body.images)
    with Session(af.engine) as s:
        task = _assert_ops_review_task(s, tid)
        if instruction or image_names:
            um = m.ClarifyMessage(task_id=tid, role="user", content=instruction, images=json.dumps(image_names))
            s.add(um)
            s.commit()
            s.refresh(um)
            af.bus.publish_task(
                tid, "clarify.message",
                {"task_id": tid, "id": um.id, "role": "user", "content": instruction, "images": image_names},
            )

        diag = s.exec(
            select(m.HandoffNote).where(
                m.HandoffNote.task_id == tid, m.HandoffNote.kind == "diagnosis"
            ).order_by(m.HandoffNote.id.desc())
        ).first()
        if diag:
            s.delete(diag)

        prev = s.exec(
            select(m.HandoffNote).where(
                m.HandoffNote.task_id == tid, m.HandoffNote.kind == "ops_exec"
            ).order_by(m.HandoffNote.id.desc())
        ).first()
        if prev:
            try:
                data = json.loads(prev.content or "{}")
            except json.JSONDecodeError:
                data = {}
            if isinstance(data, dict):
                data["superseded"] = True
                prev.content = json.dumps(data, ensure_ascii=False)
                s.add(prev)
        task.status = m.TaskStatus.spec_generating
        s.add(task)
        s.commit()
    af.bus.publish_task(tid, "log.appended", {
        "level": "human",
        "message": f"人审重做：重新诊断并执行运维{('。说明：' + instruction[:300]) if instruction else '（未填说明）'}",
    })
    _spawn_spec_generation(af, tid, lead_log="Lead 重新现场诊断中（人审重做）…")
    return {"ok": True, "started": True}


@router.get("/tasks/{tid}/graph")
def get_graph(tid: int, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        nodes = s.exec(select(m.Node).where(m.Node.task_id == tid).order_by(m.Node.seq)).all()
        feats = s.exec(select(m.Feature).where(m.Feature.task_id == tid).order_by(m.Feature.seq)).all()
        anchors = s.exec(select(m.GreenAnchor).where(m.GreenAnchor.task_id == tid).order_by(m.GreenAnchor.id)).all()
        task = s.get(m.Task, tid)

        agents = {a.id: a.role for a in s.exec(select(m.AgentInstance).where(m.AgentInstance.task_id == tid)).all()}

        lease_files: dict[int, list[str]] = {}
        for l in s.exec(select(m.Lease).where(m.Lease.task_id == tid)).all():
            if l.feature_id and l.file_path and l.file_path not in lease_files.setdefault(l.feature_id, []):
                lease_files[l.feature_id].append(l.file_path)

        groups: dict[str, dict] = {}
        try:
            for ev in af.event_log.since(tid, 0):
                if ev.get("event") == "group.updated":
                    p = ev.get("payload") or {}
                    gid = p.get("group_id")
                    if gid:
                        groups[gid] = {"group_id": gid, "feature_ids": p.get("member_feature_ids", []), "phase": p.get("phase", "writing")}
        except Exception:
            pass
        task_dto = _task_dto(task, has_remote=_project_has_remote(s, task.project_id)) if task else None
        if task_dto is not None:

            task_dto["code_landed"] = _ops_code_landed(s, task.id)
        return {
            "task": task_dto,
            "nodes": [_node_dto(n, n.role or agents.get(n.agent_id, ""), lease_files.get(n.feature_id)) for n in nodes],
            "edges": _synthesize_edges(nodes),
            "features": [_feature_dto(f) for f in feats],
            "anchors": [_anchor_dto(a) for a in anchors],
            "groups": list(groups.values()),
        }


@router.get("/tasks/{tid}/events")
async def task_events(tid: int, request: Request):
    af = request.app.state.af
    return sse_response(request, af, task_id=tid)


@router.get("/tasks/{tid}/decisions")
def get_decisions(tid: int, request: Request, _: str = Depends(require_auth)):
    """决策时间线（多 agent 协作可视化）：从事件日志回放提取决策流。"""
    af = request.app.state.af
    out: list[dict] = []
    try:
        events = af.event_log.since(tid, 0, limit=5000)
    except Exception:
        events = []
    for ev in events:
        name = ev.get("event")
        p = ev.get("payload") or {}
        seq = ev.get("seq", 0)
        ts = ev.get("ts", "")
        if name == "log.appended":
            level = p.get("level") or "info"
            if level in ("lead", "qa", "pm", "sched", "human", "auto"):
                msg = str(p.get("message") or "")
                out.append({"seq": seq, "ts": ts, "agent": level, "kind": "decision",
                            "title": msg[:80], "detail": msg})
        elif name == "human.required":
            out.append({"seq": seq, "ts": ts, "agent": "human", "kind": "decision",
                        "title": str(p.get("reason") or "")[:120],
                        "detail": "；".join(p.get("options") or [])})
        elif name == "group.updated":
            members = p.get("member_feature_ids") or []
            out.append({"seq": seq, "ts": ts, "agent": "sched", "kind": "decision",
                        "title": f"并行组 {p.get('group_id')} → {p.get('phase')}",
                        "detail": f"成员功能: {members}"})
        elif name == "agent.step":
            if p.get("step") == 1 and p.get("text"):
                out.append({"seq": seq, "ts": ts, "agent": str(p.get("role") or "agent"), "kind": "thought",
                            "title": str(p.get("text"))[:80], "detail": str(p.get("text")),
                            "node_id": p.get("node_id")})
        elif name == "anchor.created":
            out.append({"seq": seq, "ts": ts, "agent": "sched", "kind": "event",
                        "title": f"绿点 {str(p.get('commit') or '')[:8]}"})
        elif name == "merge.updated":
            out.append({"seq": seq, "ts": ts, "agent": "pm", "kind": "event",
                        "title": f"合并队列: {p.get('status')}"})
        elif name == "task.updated":
            if p.get("status") in ("done", "merged", "aborted"):
                out.append({"seq": seq, "ts": ts, "agent": "sched", "kind": "event",
                            "title": f"任务终态: {p.get('status')}"})
        elif name == "clarify.message":
            if p.get("role") == "assistant":
                content = str(p.get("content") or "")
                out.append({"seq": seq, "ts": ts, "agent": "lead", "kind": "thought",
                            "title": content[:80], "detail": content})
    return {"decisions": out}


@router.get("/tasks/{tid}/pending-decision")
def get_pending_decision(tid: int, request: Request, _: str = Depends(require_auth)):
    """停机待决状态还原：任务处于 paused_human 时，从事件日志回放最近一次 human.required（刷新不丢）。"""
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)

        if not task or task.status not in (m.TaskStatus.paused_human, m.TaskStatus.failed):
            return {"reason": None, "options": []}
    for ev in reversed(af.event_log.since(tid, 0)):
        if ev.get("event") == "human.required":
            payload = ev.get("payload") or {}
            return {"reason": payload.get("reason"), "options": payload.get("options", [])}
    return {"reason": None, "options": []}


@router.get("/events")
async def global_events(request: Request):
    af = request.app.state.af
    return sse_response(request, af, task_id=None)



@router.post("/tasks/{tid}/rollback")
def rollback(tid: int, body: RollbackIn, request: Request, _: str = Depends(require_auth)):
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        anchor = s.get(m.GreenAnchor, body.anchor_id)
        if not anchor or anchor.task_id != tid:
            raise HTTPException(404, "anchor not found")
        proj = s.get(m.Project, task.project_id)
        repo = RepoHandle(proj.repo_path)

        try:
            repo.checkout(task.branch)
        except Exception:
            pass
        cleaned = anchors_mod.rollback_task(s, repo, task, anchor, _dev_worktree_scope(af, tid, proj))
        task.status = m.TaskStatus.spec_pending
        s.add(task)
        s.commit()
        af.bus.publish_task(tid, "anchor.invalidated", {"anchor_id": anchor.id})
        af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": "spec_pending"})
        if cleaned:
            af.bus.publish_task(tid, "log.appended", {
                "level": "human",
                "message": f"回滚同时清理 {len(cleaned)} 个未跟踪文件（dev worktree 内）: "
                + ", ".join(cleaned[:5]) + ("…" if len(cleaned) > 5 else ""),
            })
        return {"ok": True}


@router.post("/tasks/{tid}/merge")
def merge(tid: int, request: Request, _: str = Depends(require_auth)):
    """手动合并（B1）：入串行合并队列，由 MergeConsumer 在专用 worktree 上执行。"""
    af = request.app.state.af
    with Session(af.engine) as s:
        task = s.get(m.Task, tid)
        if not task:
            raise HTTPException(404, "task not found")
        if task.status in m.MERGED_OK_STATUSES or task.status == m.TaskStatus.merging:
            raise HTTPException(400, "任务已合入或合并中")
        if not task.branch:
            raise HTTPException(400, "任务无分支，无法合并")

        existing = s.exec(
            select(m.MergeQueueEntry).where(
                m.MergeQueueEntry.task_id == tid,
                m.MergeQueueEntry.status.in_(["queued", "merging"]),
            )
        ).first()
        if existing:
            af.bus.publish_task(tid, "task.updated", {"task_id": tid, "status": task.status.value})
            return {"ok": True, "queued": True}
        proj = s.get(m.Project, task.project_id)

        stale = s.exec(
            select(m.Feature).where(
                m.Feature.task_id == tid,
                m.Feature.status == m.FeatureStatus.stale,
            )
        ).all()
        if stale:
            raise HTTPException(
                400,
                f"存在待重验功能（{', '.join(f'F{f.seq} {f.title[:40]}' for f in stale[:5])}），请先恢复任务让调度器重验通过后再合并",
            )
        if not task.status == m.TaskStatus.done:

            task.status = m.TaskStatus.done
            s.add(task)
        q = m.MergeQueueEntry(project_id=proj.id, task_id=tid, status="queued")
        s.add(q)
        s.commit()
        af.bus.publish_task(tid, "merge.updated", {"status": "queued"})
        return {"ok": True, "queued": True}



def _project_has_remote(s: Session, project_id: int) -> bool:
    """项目是否配置了 git 远端（无远端 = 本地自建仓库，没有可推目标）。"""
    try:
        proj = s.get(m.Project, project_id)
        if not proj or not proj.repo_path:
            return False
        from agentflow.git_runtime.repo import RepoHandle

        return bool(RepoHandle(proj.repo_path).repo.remotes)
    except Exception:
        return False


def _task_dto(
    t: m.Task,
    has_user_message: bool = False,
    progress: tuple[int, int] | None = None,
    has_remote: bool | None = None,
) -> dict:
    prog = None
    if progress and progress[1] > 0:
        prog = round(progress[0] / progress[1], 3)
    return {
        "id": t.id,
        "project_id": t.project_id,
        "title": t.title,
        "status": t.status.value,
        "branch": t.branch,
        "created_at": t.created_at,
        "updated_at": t.updated_at,
        "used_budget": json.loads(t.used_budget) if t.used_budget else {},
        "has_user_message": has_user_message,

        "has_remote": has_remote,
        "archived_at": t.archived_at,
        "pinned": t.pinned,
        "completed_at": t.completed_at,
        "progress": prog,
        "parent_task_id": t.parent_task_id,
        "origin": t.origin,
    }


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _feature_dto(f: m.Feature) -> dict:
    return {
        "id": f.id,
        "spec_id": f.spec_id,
        "seq": f.seq,
        "title": f.title,
        "file_scope": json.loads(f.file_scope) if f.file_scope else [],
        "verify_commands": json.loads(f.verify_commands) if f.verify_commands else [],
        "depends_on": json.loads(f.depends_on) if f.depends_on else [],
        "related_files": json.loads(f.related_files) if f.related_files else [],
        "status": f.status.value,
        "retry_count": f.retry_count,
    }


def _node_dto(n: m.Node, role: str = "", files: list[str] | None = None) -> dict:
    return {
        "id": n.id,
        "feature_id": n.feature_id,
        "seq": n.seq,
        "kind": n.kind,
        "role": role,
        "status": n.status.value,
        "retries": n.retries,
        "duration_ms": n.duration_ms,
        "token_in": n.token_in,
        "token_out": n.token_out,
        "files": files or [],
        "summary": n.summary,
        "started_at": n.started_at,
        "ended_at": n.ended_at,
        "rolled_back": n.rolled_back,
    }


def _anchor_dto(a: m.GreenAnchor) -> dict:
    return {
        "id": a.id,
        "feature_id": a.feature_id,
        "commit_hash": a.commit_hash,
        "created_at": a.created_at,
        "invalidated_at": a.invalidated_at,
    }


def _synthesize_edges(nodes: list[m.Node]) -> list[dict]:
    """动态合成边：相邻 seq 顺序边 + fix→后续节点打回边。"""
    edges = []
    ordered = sorted(nodes, key=lambda n: n.seq)
    for i in range(len(ordered) - 1):
        edges.append({"from": ordered[i].id, "to": ordered[i + 1].id, "kind": "sequence"})
    for n in ordered:
        if n.kind == "fix":
            nxt = next((x for x in ordered if x.seq > n.seq and x.feature_id == n.feature_id), None)
            if nxt:
                edges.append({"from": n.id, "to": nxt.id, "kind": "kickback"})
    return edges
