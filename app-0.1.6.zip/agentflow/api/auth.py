"""认证：Bearer token（FR11/§4.1）。"""

from __future__ import annotations

import os
import secrets

from agentflow.config import Settings
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

_bearer = HTTPBearer(auto_error=False)


def ensure_token(settings: Settings) -> str:
    """返回/生成 token，持久化 ~/.agentflow/token。"""
    token_file = settings.home / "token"
    if token_file.exists():
        tok = token_file.read_text(encoding="utf-8").strip()
        if tok:
            return tok
    tok = secrets.token_urlsafe(32)
    token_file.write_text(tok, encoding="utf-8")
    try:
        os.chmod(token_file, 0o600)
    except OSError:
        pass
    return tok


def verify_token(settings: Settings, creds: HTTPAuthorizationCredentials | None) -> str:
    tok = ensure_token(settings)
    provided = creds.credentials if creds else ""
    if not secrets.compare_digest(provided, tok):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid token")
    return provided


def verify_token_query(settings: Settings, token: str) -> bool:
    """SSE 用 query 参数认证（EventSource 无法带 header）。"""
    tok = ensure_token(settings)
    return secrets.compare_digest(token or "", tok)


def ensure_hook_token(settings: Settings) -> str:
    """外部 webhook 回流专用 token（~/.agentflow/hook_token），与控制面 Bearer token 分离。"""
    tok_file = settings.home / "hook_token"
    if tok_file.exists():
        tok = tok_file.read_text(encoding="utf-8").strip()
        if tok:
            return tok
    tok = secrets.token_urlsafe(32)
    tok_file.write_text(tok, encoding="utf-8")
    try:
        os.chmod(tok_file, 0o600)
    except OSError:
        pass
    return tok


async def require_auth(request: Request, creds: HTTPAuthorizationCredentials | None = Depends(_bearer)) -> str:
    """FastAPI 依赖：从 request 读取 settings 并校验 Bearer token。"""
    settings = request.app.state.af.settings
    return verify_token(settings, creds)


async def require_auth_or_query(
    request: Request,
    token: str = "",
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> str:
    """`<img>` / EventSource 类请求鉴权：query token 优先，Authorization 头回退。"""
    settings = request.app.state.af.settings
    if token and verify_token_query(settings, token):
        return token
    return verify_token(settings, creds)
