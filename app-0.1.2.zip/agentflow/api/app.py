"""FastAPI 应用组装 + 运行时依赖（AppState）。"""

from __future__ import annotations

import sys
import threading
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import Depends, FastAPI, Request, Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from agentflow.api.auth import require_auth_or_query
from agentflow.api.routes import nodes, projects, settings as settings_router, tasks
from agentflow.api.routes import hooks as hooks_router
from agentflow.config import Settings
from agentflow.core import win_silent
from agentflow.core.events_bus import EventBus
from agentflow.llm.gateway import LLMGateway
from agentflow.safety import command as safety_command
from agentflow.storage import models as m
from agentflow.storage.db import create_db_engine
from agentflow.storage.events_log import EventLog
from sqlmodel import Session

win_silent.install()


class AppState:
    def __init__(self, settings: Settings):
        self.settings = settings

        safety_command.ENV_POLICY = settings.data.get("safety", {}).get("env_policy", "sanitize")
        self.engine = create_db_engine(settings)
        self.event_log = EventLog(settings)
        self.bus = EventBus(self.event_log)
        self.gateway = LLMGateway(settings)


        from agentflow.core.approvals import REGISTRY

        REGISTRY.enable_persistence(settings.home / "projects", self._approval_project_name)
        self.runners: dict[int, object] = {}
        self.spec_generating: set[int] = set()

        self._project_locks: dict[int, threading.Lock] = {}

        self.merge_consumer = None
        self._merge_task = None

        self._tunnel = None

    def start_tunnel_supervisor(self) -> None:
        cfg = self.settings.data.get("cd_tunnel") or {}
        if not cfg.get("enabled") or not cfg.get("ssh_host"):
            return
        from agentflow.core.cd_tunnel import TunnelSupervisor

        self._tunnel = TunnelSupervisor(cfg, notify=self._notify_global)
        self._tunnel.start()

    def stop_tunnel_supervisor(self) -> None:
        if self._tunnel is not None:
            self._tunnel.stop()

    def _notify_global(self, msg: str) -> None:
        """隧道状态变化上报事件流（全局可见，不占用任务通道）。"""
        try:
            self.bus.publish_global("log.appended", {"level": "sched", "message": msg})
        except Exception:
            pass

    def project_lock(self, project_id: int) -> threading.Lock:
        """按项目取一把跨线程互斥锁（惰性创建，进程内唯一）。"""
        if project_id not in self._project_locks:
            self._project_locks[project_id] = threading.Lock()
        return self._project_locks[project_id]

    def _approval_project_name(self, task_id: int) -> str:
        """task_id → 项目名（审批前缀落盘定位用）；查不到返回空，调用方跳过持久化。"""
        try:
            with Session(self.engine) as s:
                t = s.get(m.Task, task_id)
                if t is None:
                    return ""
                p = s.get(m.Project, t.project_id)
                return p.name if p else ""
        except Exception:
            return ""

    def start_merge_consumer(self) -> None:
        """启动合并队列消费者（P1）。幂等：已启动不再重复。"""
        if self._merge_task is not None and not self._merge_task.done():
            return
        from sqlmodel import Session

        from agentflow.core import merger as merger_mod
        from agentflow.core.scheduler import build_merge_handlers, resume_parent_after_subtasks

        resolver, validator = build_merge_handlers(self.engine, self.gateway, self.bus, self.settings)

        def _on_merged(task_id: int) -> None:
            """P1 SOS：merged 回调——若为 sos_split 子任务则尝试恢复父任务（全子任务终态才恢复）。"""
            import asyncio

            from sqlmodel import Session as _S

            from agentflow.core.scheduler import resume_parent_after_subtasks as _resume
            from agentflow.storage import models as _m

            try:
                with _S(self.engine) as s:
                    t = s.get(_m.Task, task_id)
                    if t is None or t.origin != "sos_split" or not t.parent_task_id:
                        return
                    parent_id = t.parent_task_id

                asyncio.get_event_loop().call_soon(
                    lambda: _resume(self.engine, self.gateway, self.bus, self.settings, parent_id,
                                    spawn_runner=None)
                )
            except Exception:
                pass

        def _on_gate_rework(task_id: int) -> None:
            """门禁回灌：validator 已把功能重开 + 任务置回 running，这里拉起任务 runner 继续开发。"""
            from agentflow.api.routes.tasks import start_task_runner

            try:
                start_task_runner(self, task_id)
            except Exception as e:
                try:
                    self.bus.publish_task(task_id, "log.appended", {
                        "level": "sched",
                        "message": f"门禁回灌后拉起 runner 失败（{type(e).__name__}: {e}），可人工「恢复运行」接续",
                    })
                except Exception:
                    pass

        self.merge_consumer = merger_mod.MergeConsumer(
            engine=self.engine,
            settings=self.settings,
            bus=self.bus,
            settings_dict=self.settings.data,
            session_factory=lambda: Session(self.engine),
            resolver=resolver,
            validator=validator,
            on_merged=_on_merged,
            on_gate_rework=_on_gate_rework,
        )
        self._merge_task = self.merge_consumer.async_run()

    def stop_merge_consumer(self) -> None:
        if self.merge_consumer is not None:
            self.merge_consumer.stop()


_bearer = HTTPBearer(auto_error=False)


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings.load()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.af = AppState(settings)
        app.state.af.start_merge_consumer()
        app.state.af.start_tunnel_supervisor()
        _recover_orphan_tasks(app.state.af)
        _sweep_orphan_warm(settings)
        try:
            yield
        finally:
            app.state.af.stop_tunnel_supervisor()
            app.state.af.stop_merge_consumer()

    app = FastAPI(title="AgentFlow Executor", version="0.1.0", lifespan=lifespan)

    for r in (projects.router, tasks.router, nodes.router, settings_router.router):
        app.include_router(r, prefix="/api/v1")

    app.include_router(hooks_router.router)
    app.include_router(hooks_router.read_router)

    @app.get("/api/v1/health")
    def health():
        return {"ok": True}

    @app.get("/api/v1/session")
    def session(_auth: str = Depends(require_auth_or_query)):
        """鉴权探针（需 token）：前端判断「是否已连接执行面」用它，别用无鉴权的 /health。"""
        return {"ok": True}

    @app.get("/api/v1/media/{path:path}")
    def media(path: str, _auth: str = Depends(require_auth_or_query)):
        """UI 机审截图取证（img 标签无法带 Authorization header，query token 优先）。"""
        from fastapi import HTTPException
        from fastapi.responses import FileResponse

        media_root = (settings.home / "screenshots").resolve()
        target = (settings.home / path).resolve()
        if not target.is_relative_to(media_root) or target == media_root:
            raise HTTPException(status_code=404, detail="not found")
        if target.suffix.lower() not in (".png", ".jpg", ".jpeg", ".webp"):
            raise HTTPException(status_code=404, detail="not found")
        if not target.is_file():
            raise HTTPException(status_code=404, detail="not found")
        return FileResponse(target)

    _mount_web_ui(app, settings)

    return app


def _web_dist_dir(app_file: Path | None = None) -> Path | None:
    """定位预构建的 Web 控制台产物（web/dist）。"""
    import os

    here = Path(app_file or __file__).resolve()
    cands: list[Path] = []
    env = os.environ.get("AGENTFLOW_WEB_DIST", "").strip()
    if env:
        cands.append(Path(env))
    if len(here.parents) > 2:
        cands.append(here.parents[2] / "web" / "dist")
    if len(here.parents) > 3:
        cands.append(here.parents[3] / "web" / "dist")
    cands.append(Path(sys.executable).resolve().parent / "web" / "dist")
    cands.append(Path.cwd() / "web" / "dist")
    for c in cands:
        if (c / "index.html").is_file():
            return c
    return None


def _mount_web_ui(app: FastAPI, settings: Settings) -> None:
    """由执行面同源托管 Web 控制台（原由 vite preview 独占一个端口 + 一个 Node 进程）。"""
    dist = _web_dist_dir()
    if dist is None:
        return

    from fastapi.responses import FileResponse, HTMLResponse
    from fastapi.staticfiles import StaticFiles

    assets = dist / "assets"
    if assets.is_dir():

        app.mount("/assets", StaticFiles(directory=str(assets)), name="web-assets")

    index = dist / "index.html"
    base_html = index.read_text(encoding="utf-8")

    def spa_index(request: Request) -> Response:
        """SPA 入口：本机请求注入 token 实现自动登录；HTML 交给 React Router 接管。"""
        if _is_loopback_client(request):
            from agentflow.api.auth import ensure_token

            return HTMLResponse(_inject_boot_token(base_html, ensure_token(settings)))
        return FileResponse(index)




    app.add_api_route("/", spa_index, methods=["GET"], include_in_schema=False)
    for route_prefix in ("tasks",):
        app.add_api_route(
            f"/{route_prefix}/{{rest:path}}", spa_index, methods=["GET"], include_in_schema=False
        )


def _is_loopback_client(request: Request) -> bool:
    """请求是否来自本机。"""
    client = request.client
    host = (client.host if client else "") or ""
    return host == "localhost" or host == "::1" or host.startswith("127.")


def _inject_boot_token(html: str, token: str) -> str:
    """把 token 以同步脚本注入 <head>，让同源托管的任意浏览器打开即自动登录。"""
    import json

    literal = (
        json.dumps(token)
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("&", "\\u0026")
    )
    script = (
        "<script>try{localStorage.setItem('agentflow_token',"
        + literal
        + ")}catch(e){}</script>"
    )
    for anchor in ("<head>", "<HEAD>"):
        if anchor in html:
            return html.replace(anchor, anchor + script, 1)
    return script + html


def _sweep_orphan_warm(settings) -> None:
    """启动清扫：上一代 serve 被强杀后遗留的孤儿暖服务（next dev/vite 常驻会锁住 worktree 目录）。"""
    try:
        from agentflow.core.services import render_sweep_report, sweep_orphan_warm

        res = sweep_orphan_warm(settings.home)
        if res["killed"] or res["dropped"] or res["warnings"]:
            print(render_sweep_report(res))
    except Exception as e:
        print(f"[warn] 孤儿暖服务清扫失败: {type(e).__name__}: {e}")


def _recover_orphan_tasks(af: AppState) -> None:
    """重启恢复：上次异常退出残留的孤儿状态改为可续跑。"""
    from sqlmodel import Session, select

    from agentflow.storage import models as m

    try:
        with Session(af.engine) as s:



            dead_nodes = s.exec(
                select(m.Node).where(
                    m.Node.status == m.NodeStatus.running,
                    m.Node.ended_at.is_(None),
                )
            ).all()
            for node in dead_nodes:
                node.status = m.NodeStatus.failed
                node.ended_at = datetime.now(timezone.utc).isoformat()
                node.summary = (node.summary or "")[:200] + "（执行面重启中断）"
                s.add(node)
            orphans = s.exec(select(m.Task).where(m.Task.status == m.TaskStatus.running)).all()
            for t in orphans:
                t.status = m.TaskStatus.paused_human
                s.add(t)
                af.bus.publish_task(t.id, "task.updated", {"task_id": t.id, "status": "paused_human"})
                af.bus.publish_task(t.id, "log.appended", {
                    "level": "sched",
                    "message": "执行面重启：任务已暂停，可「恢复运行」续上（已绿点跳过，未完成重做）",
                })

            gen_orphans = s.exec(select(m.Task).where(m.Task.status == m.TaskStatus.spec_generating)).all()
            for t in gen_orphans:
                t.status = m.TaskStatus.clarifying
                s.add(t)
                af.bus.publish_task(t.id, "task.updated", {"task_id": t.id, "status": "clarifying"})
                af.bus.publish_task(t.id, "log.appended", {
                    "level": "sched",
                    "message": "执行面重启：Spec 生成中断，请重新点「确认 Spec 并运行」",
                })
            mq = s.exec(
                select(m.MergeQueueEntry).where(m.MergeQueueEntry.status == "merging")
            ).all()
            for q in mq:
                t = s.get(m.Task, q.task_id)



                if t is not None and t.status == m.TaskStatus.aborted:
                    q.status = "aborted"
                    q.error = "执行面重启：任务已废弃，合并不再消费"
                elif t is not None and t.status in m.MERGED_OK_STATUSES:
                    q.status = "merged"
                    q.error = q.error or "执行面重启：任务已在人审/已合入，残留条目按已完成收口"
                else:
                    q.status = "queued"
                s.add(q)
            if orphans or mq or gen_orphans:
                s.commit()
    except Exception as e:

        import traceback

        print(f"[recover] 执行面启动恢复失败（不阻塞启动，请人工检查）: {type(e).__name__}: {e}", flush=True)
        traceback.print_exc()
