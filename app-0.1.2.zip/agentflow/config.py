"""全局配置：~/.agentflow/config.toml（含默认值）。"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path


def agentflow_home() -> Path:
    """数据目录：默认 `~/.agentflow`；可用环境变量 `AGENTFLOW_HOME` 覆盖。"""
    import os

    override = os.environ.get("AGENTFLOW_HOME", "").strip()
    return Path(override).expanduser() if override else Path.home() / ".agentflow"


DEFAULT_CONFIG: dict = {
    "server": {"host": "127.0.0.1", "port": 8765},
    "llm": {
        "provider": "mock",


        "profiles": {},
        "roles": {"lead": "", "developer": "", "qa": "", "fixer": "", "reviewer": "", "researcher": ""},


        "cross_review": True,
    },
    "scheduler": {
        "group_size": 100,
        "failure_debt_k": 2,
        "max_steps_per_run": 50,
        "per_task_worktree": True,
        "noop_short_circuit": "confirm",


        "stuck_max_repeat": 3,
        "stuck_max_silent": 6,
    },

    "git": {
        "protocol": "auto",
        "prefer": ["ssh", "https"],
        "use_proxy": False,
        "proxy": "",
    },
    "lead": {
        "researcher_min_features": 3,
        "review_before_merge": True,
        "diagnose_before_spec": True,
        "diagnose_max_steps": 40,





        "force_direct": False,
    },
    "merge": {
        "worktree_base_dir": "",
        "ai_conflict_max_files": 3,
        "heavy_verify_port": 5747,
        "max_ai_retries": 1,
    },
    "safety": {
        "blocked_commands": ["rm -rf", "sudo", "push --force", "force-push", "git clean -fd"],
        "allowed_commands": [],
        "trusted_network_domains": [],
        "env_policy": "sanitize",
        "approval_timeout_s": 300,
        "auto_approve": False,
        "grace_kill_s": 5,
    },



    "hooks": {"rules": []},


    "web": {
        "enabled": True,
        "timeout_s": 20,
        "max_chars": 20000,
        "max_redirects": 3,
        "search_url": "",
        "search_key_env": "",
    },
    "budget": {"max_retries": 3, "feature_timeout_s": 600, "task_max_tokens": 5000000, "task_max_cost_usd": 5.0},


    "cd_tunnel": {"enabled": False, "ssh_host": "", "remote_port": 18265, "local_port": 8765, "check_interval_s": 60},
    "watchdog": {"idle_timeout_s": 1800},



    "update": {
        "enabled": True,




        "manifest_url": (
            "https://ghproxy.net/https://raw.githubusercontent.com"
            "/Gexomaikoine/AgentFlow/main/manifest.json"
        ),

        "api_url": "",
        "token_env": "AGENTFLOW_UPDATE_TOKEN",
    },
    "sos": {

        "task_quota": 2,
        "agent_ask_per_feature": 2,
        "restrategy_max": 2,
        "research_max": 2,
        "redecide_max": 1,
    },
}


@dataclass
class Settings:
    home: Path = field(default_factory=agentflow_home)



    data: dict = field(default_factory=lambda: _deep_copy(DEFAULT_CONFIG))

    @classmethod
    def load(cls) -> "Settings":
        home = agentflow_home()
        _load_env(home)
        data = _deep_copy(DEFAULT_CONFIG)
        cfg_file = home / "config.toml"
        if cfg_file.exists():
            try:
                with cfg_file.open("rb") as f:
                    user = tomllib.load(f)
                _deep_merge(data, user)
            except (tomllib.TOMLDecodeError, OSError) as e:



                import sys

                print(
                    f"[config] {cfg_file} 解析失败，已回退出厂默认：{type(e).__name__}: {e}",
                    file=sys.stderr,
                    flush=True,
                )
        _normalize_llm(data)
        _normalize_safety(data)
        return cls(home=home, data=data)


    def __getitem__(self, key: str):
        return self.data[key]

    def ensure_dirs(self) -> None:
        for sub in ("", "blobs", "projects", "mock_scripts", "clarify_images"):
            (self.home / sub).mkdir(parents=True, exist_ok=True)


def _deep_copy(d: dict) -> dict:
    import copy

    return copy.deepcopy(d)


def _deep_merge(base: dict, override: dict) -> None:
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v


def _normalize_llm(data: dict) -> None:
    """模型配置归一化（2026-09-10 档案制改造，load 时一次性执行）："""
    llm = data.get("llm")
    if not isinstance(llm, dict):
        return
    profiles = llm.get("profiles")
    if not isinstance(profiles, dict):
        profiles = {}
    if not profiles:
        legacy_effort = str(llm.get("reasoning_effort") or "").strip()
        names: list[str] = []
        for v in (llm.get("roles") or {}).values():
            if isinstance(v, str) and v.strip() and v.strip() not in names:
                names.append(v.strip())
        legacy_default = str(llm.get("default_model") or "").strip()
        if legacy_default and legacy_default not in names:
            names.append(legacy_default)
        for n in names:
            profiles[n] = {"model": n, "vision": False, "thinking": bool(legacy_effort), "effort": legacy_effort}
        llm["profiles"] = profiles
    llm.pop("default_model", None)
    llm.pop("reasoning_effort", None)


def _normalize_safety(data: dict) -> None:
    """safety 列表字段恢复：老版本 _write_toml 曾把"""
    import ast

    safety = data.get("safety")
    if not isinstance(safety, dict):
        return
    for k in ("blocked_commands", "allowed_commands", "trusted_network_domains"):
        v = safety.get(k)
        if isinstance(v, list):
            continue
        if isinstance(v, str):
            try:
                parsed = ast.literal_eval(v)
            except (ValueError, SyntaxError):
                parsed = None
            if isinstance(parsed, list):
                safety[k] = parsed
                continue
        safety[k] = list(DEFAULT_CONFIG["safety"].get(k, []))


def _load_env(home: Path) -> None:
    """从 ~/.agentflow/.env 加载环境变量进 os.environ（已在环境中的不覆盖）。"""
    import os

    env_file = home / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v


def detect_exec_env() -> dict:
    """执行面环境检测：OS + 默认 shell（Lead 生成 verify 命令、verifier 选 shell 的依据）。"""
    import platform

    os_name = platform.system().lower()
    return {"os": os_name, "shell": "powershell" if os_name == "windows" else "bash"}
