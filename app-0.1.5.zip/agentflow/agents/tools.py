"""Agent 工具集（P0）：read/write/edit/delete_file/grep/glob/run_cmd/done。"""

from __future__ import annotations

import fnmatch
import json
import re
from dataclasses import dataclass
from pathlib import Path

from agentflow.core import leases
from agentflow.core.approvals import DECISIONS, REGISTRY
from agentflow.safety import path as spath
from agentflow.safety.command import Safety, run_command
from agentflow.spec.schema import expand_file_scope
from agentflow.storage import models as m
from agentflow.verifiers.ui_dsl import GRAMMAR_HINT as _UI_GRAMMAR_HINT


@dataclass
class ToolContext:
    repo_root: Path
    task_id: int
    feature_id: int | None
    session: object
    safety: Safety
    settings: object
    trace_uri: str = ""
    project_invariants: list[str] = None
    bus: object = None
    role: str = ""

    def __post_init__(self):
        if self.project_invariants is None:
            self.project_invariants = []


def _p(ctx: ToolContext, path: str) -> Path:
    return spath.resolve_inside(ctx.repo_root, path)


def tool_read_file(
    ctx: ToolContext, path: str, max_bytes: int = 20000,
    offset_line: int = 1, max_lines: int = 0,
) -> tuple[bool, str]:
    """读文件，支持行号窗口（offset_line 起、max_lines 行）。"""
    p = _p(ctx, path)
    if not p.exists():
        return False, f"文件不存在: {path}。可用 glob 工具确认实际路径（路径相对项目根，勿带盘符/前导斜杠）"
    if p.is_dir():
        return False, f"是目录: {path}。请给出具体文件路径（可先用 glob 列出目录下文件）"
    content = p.read_text(encoding="utf-8", errors="replace")
    if offset_line > 1 or max_lines > 0:
        lines = content.splitlines()
        total = len(lines)
        start = max(1, offset_line) - 1
        end = start + max_lines if max_lines > 0 else total
        end = min(end, total)
        shown = lines[start:end]
        header = f"[{path} 行 {start + 1}-{end} / 共 {total} 行]"
        content = header + "\n" + "\n".join(f"{start + 1 + i}: {line}" for i, line in enumerate(shown))
    if len(content) > max_bytes:
        content = content[:max_bytes] + f"\n...[truncated {len(content) - max_bytes} chars]"
    if ctx.feature_id is not None:

        leases.refresh_base_on_read(ctx.session, ctx.feature_id, path.replace("\\", "/"), ctx.repo_root)
    return True, content


def _ensure_write_auth(ctx: ToolContext, path: str, p: Path) -> tuple[bool, str]:

    if ctx.feature_id is None:
        return True, "ok"


    if spath.is_agent_tmp(path):
        return True, "ok"
    ok, reason = leases.check_write(ctx.session, ctx.feature_id, path.replace("\\", "/"), ctx.repo_root)
    if not ok:
        return False, reason

    if "动态补授写集" in reason and ctx.bus is not None:
        ctx.bus.publish_task(ctx.task_id, "log.appended", {
            "level": "sched",
            "message": (
                f"写集动态补授：{path} —— Spec 的 related_files 已声明该文件，自动扩入本功能写集"
                "（原 file_scope 漏配，若不改会越区写死锁）"
            ),
        })
    return True, "ok"


def tool_write_file(ctx: ToolContext, path: str, content: str) -> tuple[bool, str]:
    try:
        p = _p(ctx, path)
    except spath.PathViolation as e:
        return False, str(e)
    ok, reason = _ensure_write_auth(ctx, path, p)
    if not ok:
        return False, reason
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    if ctx.feature_id is not None:
        leases.record_write(ctx.session, ctx.feature_id, path.replace("\\", "/"), ctx.repo_root)
    return True, f"已写入 {path} ({len(content)} chars)"


def tool_edit_file(ctx: ToolContext, path: str | None = None, old: str | None = None,
                   new: str | None = None, edits=None) -> tuple[bool, str]:
    """精确替换（old→new）。支持**一次批量多处/多文件**（P3，2026-09-27）。"""
    items: list[tuple[str, str, str]] = []
    if edits:
        if not isinstance(edits, list):
            return False, 'edits 需为数组：[{"path": "...", "old": "...", "new": "..."}, …]'
        if path or old is not None or new is not None:
            return False, "批量请只给 edits；单处请只给 path/old/new，两者不要混用"
        for i, e in enumerate(edits):
            if not isinstance(e, dict) or not all(k in e for k in ("path", "old", "new")):
                return False, f'edits[{i}] 需含 path/old/new 三个字段（形如 {{"path": "a.tsx", "old": "…", "new": "…"}}）'
            items.append((str(e["path"]), str(e["old"]), str(e["new"])))
        if not items:
            return False, "edits 数组为空"
    else:
        if not path or old is None or new is None:
            return False, "缺参数：单处编辑需 path/old/new；批量编辑用 edits 数组（一次多处/多文件）"
        items.append((str(path), str(old), str(new)))

    plans: dict[str, str] = {}
    orig: dict[str, str] = {}
    order: list[str] = []
    for i, (pth, o, n) in enumerate(items):
        tag = f"edits[{i}] " if edits else ""
        try:
            p = _p(ctx, pth)
        except spath.PathViolation as e:
            return False, f"{tag}{e}"
        if not p.exists():
            return False, f"{tag}文件不存在: {pth}"
        ok, reason = _ensure_write_auth(ctx, pth, p)
        if not ok:
            return False, f"{tag}{reason}" if edits else reason
        key = pth.replace("\\", "/")
        if key not in plans:
            plans[key] = p.read_text(encoding="utf-8", errors="replace")
            orig[key] = plans[key]
            order.append(key)
        content = plans[key]
        if o not in content:
            return False, (
                f"{tag}未找到待替换片段: {pth}。文件内容可能已变化，请先 read_file 重读该文件，"
                "再按当前实际内容构造 old（注意空格/缩进/换行需逐字符一致）"
            )
        if content.count(o) > 1:
            return False, (
                f"{tag}待替换片段在 {pth} 中出现 {content.count(o)} 次，替换位置有歧义已拒绝。"
                "请扩大 old 的上下文（多带几行邻近代码）使其在文件中唯一"
            )
        plans[key] = content.replace(o, n, 1)

    for key in order:
        _p(ctx, key).write_text(plans[key], encoding="utf-8")
        if ctx.feature_id is not None:
            leases.record_write(ctx.session, ctx.feature_id, key, ctx.repo_root)
    if len(order) == 1:
        return True, f"已编辑 {order[0]}" + (f"（{len(items)} 处）" if len(items) > 1 else "")
    return True, f"已编辑 {len(order)} 个文件 / {len(items)} 处: " + ", ".join(order)



_DELETE_PROTECTED_PARTS = {".git"}
_DELETE_PROTECTED_FILES = {"内部文档"}


def tool_delete_file(ctx: ToolContext, path: str) -> tuple[bool, str]:
    """受控删除：仅限 repo 内、未被 git 跟踪的单个临时文件。"""
    try:
        p = _p(ctx, path)
    except spath.PathViolation as e:
        return False, str(e)
    root = Path(ctx.repo_root).resolve()
    rel = p.relative_to(root)
    rel_posix = rel.as_posix()
    if any(part.lower() in _DELETE_PROTECTED_PARTS for part in rel.parts):
        return False, f"受保护路径禁止删除: {path}"
    if rel.parts and rel.parts[0] in _DELETE_PROTECTED_FILES:
        return False, f"受保护文件禁止删除: {path}"
    if p.is_dir():
        return False, f"delete_file 仅支持单个文件，不支持目录: {path}"
    if not p.exists() and not p.is_symlink():
        return False, f"文件不存在: {path}"
    try:
        from agentflow.git_runtime.repo import RepoHandle

        tracked = RepoHandle(root).repo.git.ls_files("--", rel_posix).strip()
    except Exception as e:
        return False, f"git 状态检查失败，拒绝删除: {e}"
    if tracked:
        return False, f"文件已被 git 跟踪（已提交/已暂存），禁止删除，应走 git 操作: {path}"
    ok, reason = _ensure_write_auth(ctx, rel_posix, p)
    if not ok:
        return False, f"删除被拒（写集外）: {reason}"
    try:
        p.unlink()
    except OSError as e:
        return False, f"删除失败: {e}"
    return True, f"已删除未跟踪临时文件: {rel_posix}"






_SCAN_EXCLUDED_DIRS = {
    ".git", "node_modules", ".next", "dist", "build", "out",
    "__pycache__", ".venv", "venv", ".pytest_cache", ".mypy_cache",
}


def _excluded_for_scan(p: Path, base: Path) -> bool:
    """p 是否落在 base 下的默认排除目录里（base 自身在被排除目录内则不过滤）。"""
    try:
        rel_parts = p.relative_to(base).parts[:-1]
    except ValueError:
        return False
    return any(part in _SCAN_EXCLUDED_DIRS for part in rel_parts)


def tool_grep(ctx: ToolContext, pattern: str, path: str = "", include: str = "*") -> tuple[bool, str]:
    base = _p(ctx, path) if path else ctx.repo_root
    if not base.exists():
        return False, f"路径不存在: {path}"
    try:
        rx = re.compile(pattern)
    except re.error as e:
        return False, f"正则错误: {e}。请检查特殊字符转义（如括号/加号需转义），或先用更简单的字面量子串重试"
    hits = []
    if base.is_file():


        files = [base]
    else:
        files = [p for p in base.rglob("*") if p.is_file() and not _excluded_for_scan(p, base)]
    for p in files:
        rel = p.relative_to(ctx.repo_root).as_posix()
        if not fnmatch.fnmatch(p.name, include):
            continue
        try:
            for i, line in enumerate(p.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                if rx.search(line):
                    hits.append(f"{rel}:{i}: {line[:160]}")
                    if len(hits) >= 50:
                        break
        except OSError:
            continue
        if len(hits) >= 50:
            break
    if not hits:
        return True, (
            "无匹配（include 过滤或内容确实不含该模式）。"
            "排查建议：去掉 path 限定全仓搜、检查 include glob 拼写、或用 glob 工具确认文件是否存在"
        )
    return True, "\n".join(hits)


def tool_glob(ctx: ToolContext, pattern: str) -> tuple[bool, str]:
    norm_pat = pattern.replace("\\", "/")

    explicit = any(part in _SCAN_EXCLUDED_DIRS for part in norm_pat.split("/"))
    matches = sorted(
        str(p.relative_to(ctx.repo_root)).replace("\\", "/")
        for p in ctx.repo_root.glob(norm_pat)
        if p.is_file() and (explicit or not _excluded_for_scan(p, ctx.repo_root))
    )
    if not matches:
        return True, "无匹配文件。请检查 glob 语法与路径（相对项目根；如 src/**/*.py），或先用 grep 按内容找文件"
    return True, "\n".join(matches[:100])


def tool_web_fetch(ctx: ToolContext, url: str) -> tuple[bool, str]:
    """抓取网页正文（P1）。准入复用 `safety.trusted_network_domains`（与 curl/wget 同一份名单）。"""
    from agentflow.agents.webtools import web_fetch

    web = ctx.settings.data.get("web") or {}
    trusted = list((ctx.settings.data.get("safety") or {}).get("trusted_network_domains") or [])
    return web_fetch(
        url, trusted,
        timeout=float(web.get("timeout_s") or 20),
        max_chars=int(web.get("max_chars") or 20000),
        max_redirects=int(web.get("max_redirects") or 3),
    )


def tool_web_search(ctx: ToolContext, query: str) -> tuple[bool, str]:
    """联网检索（P1）。未配置 web.search_url 时该工具会被从工具集里剔除（不出现即不误调）。"""
    from agentflow.agents.webtools import web_search

    return web_search(query, ctx.settings.data.get("web") or {})


def tool_skill_load(ctx: ToolContext, name: str) -> tuple[bool, str]:
    """加载技能全文（P2）：清单常驻、正文按需——常驻全量会把上下文烧在本次用不上的经验上。"""
    from agentflow.core.skills import MAX_BODY_CHARS, list_skills, load_skill

    proj_id = None
    try:
        t = ctx.session.get(m.Task, ctx.task_id)
        proj_id = t.project_id if t else None
    except Exception:
        proj_id = None
    sk = load_skill(ctx.settings.home, name, project_id=proj_id)
    if sk is None:
        avail = ", ".join(s.name for s in list_skills(ctx.settings.home, project_id=proj_id)) or "（无）"
        return False, f"技能 {name!r} 不存在或不可用。可用技能：{avail}"
    body = sk.body
    if len(body) > MAX_BODY_CHARS:
        body = body[:MAX_BODY_CHARS] + f"\n\n…[技能正文已截断，超出 {MAX_BODY_CHARS} 字符]"
    return True, f"# 技能：{sk.name}\n{sk.description}\n\n{body}"


def tool_run_cmd(ctx: ToolContext, cmd: str, timeout: int = 120) -> tuple[bool, str]:


    from agentflow.agents.hooks import pre_tool_use

    hk = pre_tool_use("run_cmd", {"cmd": cmd, "timeout": timeout}, ctx.settings)
    if hk.action == "block":
        return False, f"[确定性守卫] {hk.reason}"
    if hk.action == "rewrite" and hk.replacement:
        cmd = str(hk.replacement.get("cmd") or cmd)

    verdict, reason = ctx.safety.check(
        cmd, approved_prefixes=REGISTRY.prefixes_for(ctx.task_id), repo_root=ctx.repo_root,
    )
    if verdict == "deny":

        try:
            task = ctx.session.get(m.Task, ctx.task_id)
            if task is not None and task.status == m.TaskStatus.running:
                task.status = m.TaskStatus.paused_human
                ctx.session.add(task)
                ctx.session.commit()
                if ctx.bus is not None:
                    ctx.bus.publish_task(ctx.task_id, "task.updated", {"task_id": ctx.task_id, "status": "paused_human"})
                    ctx.bus.publish_task(
                        ctx.task_id, "human.required",
                        {"reason": f"高危命令被拦截: {reason}", "options": ["人工修复后恢复", "回滚"]},
                    )
        except Exception:
            pass
        return False, f"高危命令已拦截并停机人工: {reason}"
    if verdict == "ask":



        from agentflow.safety.command import PATH_BOUNDARY_MARK

        boundary = PATH_BOUNDARY_MARK in reason
        auto = bool(ctx.settings.data.get("safety", {}).get("auto_approve", False)) and not boundary
        if not auto:

            if ctx.bus is None:
                return False, f"命令需人工审批（{reason}），当前无审批通道，已拒绝"
            req = REGISTRY.create(ctx.task_id, cmd, reason)
            try:
                ctx.bus.publish_task(ctx.task_id, "approval.required", {
                    "approval_id": req["approval_id"],
                    "task_id": ctx.task_id,
                    "cmd": cmd,
                    "reason": reason,
                    "options": list(DECISIONS),
                })
            except Exception:
                REGISTRY.decide(req["approval_id"], "deny")
                return False, f"审批事件推送失败，已拒绝: {reason}"
            timeout_s = float(ctx.settings.data.get("safety", {}).get("approval_timeout_s", 300))
            decision = REGISTRY.wait(req["approval_id"], timeout_s)
            if decision not in ("allow_once", "allow_prefix"):


                if decision == "timeout" and ctx.bus is not None:
                    try:
                        ctx.bus.publish_task(ctx.task_id, "approval.resolved", {
                            "approval_id": req["approval_id"],
                            "task_id": ctx.task_id,
                            "decision": "timeout",
                            "level": "human",
                            "message": f"命令审批超时自动失效（{timeout_s:.0f}s 无人决议）：{cmd[:120]}",
                        })
                    except Exception:
                        pass
                return False, (
                    f"命令未获批准（{decision}）: {reason}\n"
                    "请换一种方式完成任务（如改用 write_file/edit_file 写文件、避免该命令）。"
                )
        elif ctx.bus is not None:
            try:
                ctx.bus.publish_task(ctx.task_id, "log.appended", {
                    "level": "auto",
                    "message": f"命令自动放行（auto_approve）: {cmd}（原因: {reason}）",
                })
            except Exception:
                pass
    code, out = run_command(cmd, ctx.repo_root, timeout)
    head = f"[exit {code}]"
    return True, f"{head}\n{out[:4000]}"


def tool_done(ctx: ToolContext, summary: str = "") -> tuple[bool, str]:
    return True, summary or "done"


def tool_ask_lead(ctx: ToolContext, question: str) -> tuple[bool, str]:
    """agent 主动求助 Lead（自愈系统 P1）：落库 SosPacket(trigger=agent_ask) 留痕。"""
    from agentflow.core import sos as sos_mod

    if ctx.feature_id is None:
        return False, "当前无功能上下文，无法求助"
    if not question.strip():
        return False, "question 不能为空"
    limit = int(ctx.settings.data.get("sos", {}).get("agent_ask_per_feature", 2))
    if sos_mod.agent_ask_count(ctx.session, ctx.feature_id) >= limit:
        return False, f"求助已达上限（{limit} 次），请自行决断：继续尝试或调用 done 并说明障碍"
    symptom = json.dumps(
        {"role": ctx.role or "agent", "question": question[:800]}, ensure_ascii=False
    )
    packet = m.SosPacket(
        task_id=ctx.task_id,
        feature_id=ctx.feature_id,
        trigger="agent_ask",
        symptom=symptom,
    )
    ctx.session.add(packet)
    ctx.session.commit()
    if ctx.bus is not None:
        try:
            ctx.bus.publish_task(ctx.task_id, "log.appended", {
                "level": "sos",
                "message": f"agent 求助（{ctx.role or 'agent'}）: {question[:200]}",
            })
        except Exception:
            pass
    return True, f"已上报 Lead（SOS #{packet.id}），请继续尽力尝试或调用 done 并说明障碍。"


def tool_context_query(
    ctx: ToolContext,
    scope: str = "task",
    kind: str = "",
    feature_id: int = 0,
    q: str = "",
    limit: int = 5,
) -> tuple[bool, str]:
    """任务树内只读检索（上下文系统 ）：按需取回结构化历史。"""
    from agentflow.agents.context import CTX_LIMITS

    if scope not in ("task", "tree"):
        return False, "scope 只能是 task 或 tree"
    limit = max(1, min(int(limit or 5), 10))
    try:
        task = ctx.session.get(m.Task, ctx.task_id)
        if task is None:
            return False, "任务不存在"
        if scope == "tree" and task.parent_task_id:
            task_ids = [task.parent_task_id]
            subs = ctx.session.exec(
                _select_tree_tasks(task.parent_task_id)
            ).all()
            task_ids.extend(t.id for t in subs)
        else:
            task_ids = [ctx.task_id]
        parts: list[str] = []
        wants = {k.strip() for k in (kind or "").split(",") if k.strip()} or {
            "run", "clarify", "note", "report", "attribution", "research",
        }
        fid = int(feature_id) if feature_id else None

        def _ok(text: str) -> bool:
            return not q or q.lower() in (text or "").lower()

        from sqlmodel import select as _sel

        if "run" in wants:
            stmt = (
                _sel(m.VerifierRun)
                .where(m.VerifierRun.task_id.in_(task_ids), m.VerifierRun.exit_code != 0)
                .order_by(m.VerifierRun.id.desc())
            )
            for r in ctx.session.exec(stmt).all():
                if fid and r.feature_id != fid:
                    continue
                if not _ok(r.output_uri or ""):
                    continue
                parts.append(
                    f"[VerifierRun#%d 失败 task#%d feature#%s]" % (r.id, r.task_id, r.feature_id)
                    + f" `{(r.cmd or '')[:150]}` exit={r.exit_code}\n{(r.output_uri or '(无输出记录)')[: CTX_LIMITS['query_item']]}"
                )
                if len(parts) >= limit:
                    break
        if len(parts) < limit and "clarify" in wants:
            stmt = (
                _sel(m.ClarifyMessage)
                .where(m.ClarifyMessage.task_id.in_(task_ids))
                .order_by(m.ClarifyMessage.id.desc())
            )
            for r in ctx.session.exec(stmt).all():
                if not _ok(r.content or ""):
                    continue
                parts.append(
                    f"[澄清#{r.id} task#{r.task_id} {r.role}] "
                    + _clip_q(r.content)[: CTX_LIMITS["query_item"]]
                )
                if len(parts) >= limit:
                    break
        if len(parts) < limit:
            want_notes = wants & {"note", "report", "attribution", "research", "summary"}
            stmt = (
                _sel(m.HandoffNote)
                .where(m.HandoffNote.task_id.in_(task_ids))
                .order_by(m.HandoffNote.id.desc())
            )
            for r in ctx.session.exec(stmt).all():
                if want_notes and r.kind not in want_notes:
                    continue
                if fid and r.feature_id != fid:
                    continue
                if not _ok(r.content or ""):
                    continue
                seq_tag = f"第{r.seq}轮" if r.seq else ""
                parts.append(
                    f"[{r.role}·{r.kind}{seq_tag} note#{r.id} task#{r.task_id}] "
                    + (r.content or "")[: CTX_LIMITS["query_item"]]
                )
                if len(parts) >= limit:
                    break
        if not parts:
            return True, "（无匹配记录；scope=tree 可扩到父/兄弟任务）"
        body = "\n\n".join(parts)[: CTX_LIMITS["query_block"]]
        return True, (
            "## 任务树内检索结果（笔记是 agent 生成的参考，非验证事实）\n" + body
        )
    except Exception as e:
        return False, f"context_query 失败: {e}"


def _select_tree_tasks(parent_id: int):
    from sqlmodel import select

    return select(m.Task).where(m.Task.parent_task_id == parent_id).order_by(m.Task.id)


def _clip_q(text: str) -> str:
    return (text or "").replace("\n", " ")



TOOL_SCHEMAS: dict[str, dict] = {
    "read_file": {
        "description": "读取文件内容（受限大小）。用于查看现有代码/配置。大文件用 offset_line/max_lines 分段读。",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "相对项目根的路径"},
                "max_bytes": {"type": "integer", "description": "最大读取字节，可选"},
                "offset_line": {"type": "integer", "description": "从第几行开始读（从 1 起，默认 1），可选"},
                "max_lines": {"type": "integer", "description": "最多读多少行（0=读到文件尾），可选"},
            },
            "required": ["path"],
        },
    },
    "write_file": {
        "description": "写入/覆盖一个文件的全部内容。必须只写本功能写集内的文件。",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "相对项目根的路径"},
                "content": {"type": "string", "description": "文件完整内容"},
            },
            "required": ["path", "content"],
        },
    },
    "edit_file": {
        "description": "精确替换文件中的文本（old→new）。**一次可改多处/多文件**：用 edits 数组"
        '（[{"path":"a.tsx","old":"…","new":"…"}, …]）一次提交，省往返步数；改单处时用 path/old/new。'
        "原子：任一处不合法（越界/无租约/片段未找到或有歧义）则整体不写。",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "单处编辑：文件路径（相对项目根）"},
                "old": {"type": "string", "description": "待替换的原文片段"},
                "new": {"type": "string", "description": "替换后的新文本"},
                "edits": {
                    "type": "array",
                    "description": "批量编辑：一次多处/多文件的替换清单（与 path/old/new 二选一）",
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string"},
                            "old": {"type": "string"},
                            "new": {"type": "string"},
                        },
                    },
                },
            },
        },
    },
    "delete_file": {
        "description": "删除一个文件（受控）。仅限清理自己创建、未被 git 跟踪（未提交/未暂存）"
        "且在本功能写集内的临时文件（如测试脚本）；不能删目录，不能删 .git、内部文档 或任何已提交/已暂存文件。",
        "parameters": {
            "type": "object",
            "properties": {"path": {"type": "string", "description": "相对项目根的路径"}},
            "required": ["path"],
        },
    },
    "grep": {
        "description": "在项目内按正则搜索文本，返回 文件:行号: 内容。",
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "正则表达式"},
                "path": {"type": "string", "description": "可选，限定搜索目录"},
                "include": {"type": "string", "description": "可选，匹配文件名 glob"},
            },
            "required": ["pattern"],
        },
    },
    "glob": {
        "description": "列出匹配 glob 模式的文件（相对项目根）。",
        "parameters": {
            "type": "object",
            "properties": {"pattern": {"type": "string", "description": "glob，如 src/**/*.py"}},
            "required": ["pattern"],
        },
    },
    "run_cmd": {
        "description": "在项目根执行一条 shell 命令（过安全拦截），用于测试/校验/构建。Windows 执行面为 Git Bash：按 bash/POSIX 方言书写（.ps1 脚本调用与 $env: 引用平台会自动改走 PowerShell）。注意：查看/检索代码一律用 read_file/grep/glob 工具（read_file 支持 offset_line/max_lines 分段读，grep 结果自带 行号:行内容，可定位）；python -c、node -e 等内联脚本会触发人工审批，避免使用。",
        "parameters": {
            "type": "object",
            "properties": {
                "cmd": {"type": "string", "description": "要执行的命令"},
                "timeout": {"type": "integer", "description": "超时秒，可选"},
            },
            "required": ["cmd"],
        },
    },
    "web_fetch": {
        "description": "抓取网页正文（HTML 自动转文本）。仅限平台「可信网络域名」名单内的站点——不在名单会被拒并提示如何添加；内网与云元数据地址一律拒绝。查官方文档/API 用法时用它，不要凭记忆猜。",
        "parameters": {
            "type": "object",
            "properties": {"url": {"type": "string", "description": "完整 URL（http/https），如 https://nextjs.org/docs/app/api-reference"}},
            "required": ["url"],
        },
    },
    "web_search": {
        "description": "联网检索（平台配置了搜索端点后才可用）。用于定位文档/报错信息的出处，再用 web_fetch 读正文。",
        "parameters": {
            "type": "object",
            "properties": {"query": {"type": "string", "description": "检索词"}},
            "required": ["query"],
        },
    },
    "skill_load": {
        "description": "加载一个技能的全文（可用技能清单已常驻在 system prompt 的「可用技能」段）。只在你确实需要该经验时加载，并按其中的做法执行。",
        "parameters": {
            "type": "object",
            "properties": {"name": {"type": "string", "description": "技能名（清单里的 name）"}},
            "required": ["name"],
        },
    },
    "done": {
        "description": "当前功能/任务已完成，结束本次执行。也可附带一句总结。",
        "parameters": {
            "type": "object",
            "properties": {"summary": {"type": "string", "description": "可选，完成总结"}},
            "required": [],
        },
    },
    "ask_lead": {
        "description": "向 Lead 求助（仅当确实无法推进时使用，每功能最多 2 次）。"
        "question 须包含：卡在哪、已尝试过什么。求助后请继续尽力尝试，不要停下等待。",
        "parameters": {
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "求助问题（含卡点与已试方案）"},
            },
            "required": ["question"],
        },
    },
    "delegate_subtask": {
        "description": "委派一个无历史包袱的子代理独立解决单一子问题并返回其结论。"
        "用途：需要隔离验证的独立小问题（如复现一个异常、查清某依赖的行为、评估方案的副作用），"
        "或主线程上下文已太杂、换个干净上下文重试更可能成功时。"
        "question 须单一、具体、含预期输出；不能让子代理替你完成主任务；不可嵌套再委派。",
        "parameters": {
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "要解决的单一子问题（含预期产出形式）"},
                "context": {"type": "string", "description": "可选，必要背景：当前进展/已知事实/相关文件路径"},
            },
            "required": ["question"],
        },
    },
    "ui_check": {
        "description": "真浏览器自测（Playwright，与合并门禁同一套机审管线）：起项目服务 → 跑 UI 检查声明 → "
        "返回逐步结果（每步 op/选择器/成败/错误）与页面可见控件清单。改动涉及页面渲染/交互时用它自证，"
        "别只凭 tsc/build 通过就宣称完成。不传 declaration 就跑本功能 Spec 里声明的 ui 机审命令（即合并门禁会跑的那份）；"
        "要临时验证别的交互路径时传 declaration（JSON 声明）。"
        "单次 30~90 秒，别反复空跑；选择器打不到先看返回的控件清单再改。"
        + _UI_GRAMMAR_HINT,
        "parameters": {
            "type": "object",
            "properties": {
                "declaration": {
                    "type": "string",
                    "description": "可选，临时 UI 检查声明（JSON 字符串）；留空则跑 Spec 声明的 ui 机审命令",
                },
            },
            "required": [],
        },
    },
    "context_query": {
        "description": "任务树内只读检索（上下文系统）：按需取回父/兄弟任务与本任务的历史——"
        "失败 VerifierRun 原始输出（kind=run）、澄清原文（kind=clarify）、交接笔记/修复报告/QA 归因/调研（kind=note,report,attribution,research）。"
        "笔记是 agent 生成的参考，非验证事实，关键结论仍需用 run_cmd/verify 复核；项目级跨任务历史不走这里。"
        "查询前先想清楚要查什么，不要重复发同样的 kind+q（每结果 800 字，总量受限）。",
        "parameters": {
            "type": "object",
            "properties": {
                "scope": {
                    "type": "string",
                    "enum": ["task", "tree"],
                    "description": "task=仅本任务；tree=父任务+全部兄弟+本任务",
                },
                "kind": {
                    "type": "string",
                    "description": "查询类型，逗号分隔，可选 run/clarify/note/report/attribution/research；留空查全部",
                },
                "feature_id": {"type": "integer", "description": "可选，限定某功能"},
                "q": {"type": "string", "description": "可选，关键词粗筛"},
                "limit": {"type": "integer", "description": "最多返回条数（默认5，最多10）"},
            },
            "required": [],
        },
    },
}


def build_openai_tools(drop: set[str] | None = None) -> list[dict]:
    """返回 OpenAI function calling 原生 tools 声明列表。"""
    names = [n for n in TOOL_SCHEMAS if not drop or n not in drop]
    return [
        {
            "type": "function",
            "function": {
                "name": name,
                "description": TOOL_SCHEMAS[name]["description"],
                "parameters": TOOL_SCHEMAS[name]["parameters"],
            },
        }
        for name in names
    ]


def build_tools(ctx: ToolContext) -> dict:
    return {
        "read_file": lambda path="", max_bytes=20000, offset_line=1, max_lines=0: tool_read_file(
            ctx, path, max_bytes, offset_line, max_lines
        ),
        "write_file": lambda path, content: tool_write_file(ctx, path, content),
        "edit_file": lambda path=None, old=None, new=None, edits=None: tool_edit_file(ctx, path, old, new, edits),
        "delete_file": lambda path: tool_delete_file(ctx, path),
        "grep": lambda pattern, path="", include="*": tool_grep(ctx, pattern, path, include),
        "glob": lambda pattern: tool_glob(ctx, pattern),
        "run_cmd": lambda cmd, timeout=120: tool_run_cmd(ctx, cmd, timeout),
        "web_fetch": lambda url: tool_web_fetch(ctx, url),
        "web_search": lambda query: tool_web_search(ctx, query),
        "skill_load": lambda name: tool_skill_load(ctx, name),
        "done": lambda summary="": tool_done(ctx, summary),
        "ask_lead": lambda question: tool_ask_lead(ctx, question),
        "context_query": lambda scope="task", kind="", feature_id=0, q="", limit=5: tool_context_query(
            ctx, scope, kind, feature_id, q, limit
        ),
    }


def extract_tool_call(text: str) -> dict | None:
    """从 LLM 输出提取第一个 <tool_call>...</tool_call>。"""
    m = re.search(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", text, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except json.JSONDecodeError:
        return None
