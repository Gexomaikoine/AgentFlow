"""Agent 运行时：ReAct 循环（LLM 决策 + 工具调用迭代）。"""

from __future__ import annotations

import asyncio
import json
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from agentflow.agents.tools import ToolContext, build_openai_tools, build_tools, extract_tool_call
from agentflow.core import events_bus
from agentflow.llm.gateway import LLMGateway
from agentflow.safety.command import Safety
from agentflow.storage import models as m, trace as tr
from sqlmodel import Session, select


def global_rules_text(session: Session) -> str:
    """渲染全局规则段（#6）：跨项目生效，先于项目规则注入。"""
    try:
        rows = session.exec(
            select(m.GlobalRule)
            .where(m.GlobalRule.enabled == True)
            .order_by(m.GlobalRule.sort_order, m.GlobalRule.id)
        ).all()
    except Exception:
        return ""
    if not rows:
        return ""
    lines = ["## 全局规则（跨项目生效，必须首先遵守；优先于项目规则与项目记忆，低于项目 内部文档）"]
    for i, r in enumerate(rows, 1):
        title = (r.title or "").strip()
        lines.append(f"{i}. 《{title}》：{r.content}" if title else f"{i}. {r.content}")
    return "\n".join(lines) + "\n\n"


def project_rules_text(session: Session, project_id: int) -> str:
    """渲染规则段（#3/#6）：全局规则在前、项目规则在后，对每个任务具有最高优先级，"""
    text = global_rules_text(session)
    try:
        rows = session.exec(
            select(m.ProjectRule)
            .where(m.ProjectRule.project_id == project_id, m.ProjectRule.enabled == True)
            .order_by(m.ProjectRule.sort_order, m.ProjectRule.id)
        ).all()
    except Exception:
        return text
    if rows:
        lines = ["## 项目规则（本项目生效，必须首先遵守；优先于项目记忆）"]
        for i, r in enumerate(rows, 1):
            title = (r.title or "").strip()
            lines.append(f"{i}. 《{title}》：{r.content}" if title else f"{i}. {r.content}")
        text += "\n".join(lines) + "\n\n"
    return text


_AGENTS_MD_LIMIT = 4000
_RULES_LIMIT = 8000

_SUBAGENT_SYSTEM = (
    "你是被委派解决单一子问题的子代理。只解决 prompt 给出的具体子问题，不扩大范围，"
    "不改与主目标无关的文件。完成后调用 done，简短输出关键结论（事实/证据/下一步建议）。"
)


_CONTEXT_OVERFLOW_MARKERS = (
    "context_length_exceeded", "context length", "context window",
    "maximum context", "prompt is too long", "request too large",
    "input tokens exceed", "input length exceeds",
)


def _is_context_overflow(e: Exception) -> bool:
    s = f"{type(e).__name__}: {e}".lower()
    return any(m in s for m in _CONTEXT_OVERFLOW_MARKERS)


def truncate_messages(messages: list[dict]) -> list[dict]:
    """历史截断：溢出时历史截半。"""
    n = len(messages)
    if n <= 4:
        return messages
    cut = None
    for i in range(2, n // 2 + 1):
        if messages[i].get("role") == "user":
            cut = i
    if cut is None:
        return messages
    kept = messages[:2] + messages[cut:]
    for msg in kept:
        if msg.get("role") == "tool" and len(msg.get("content") or "") > 800:
            msg["content"] = msg["content"][:800] + "…[已截断]"
    return kept





_REACT_TRIM_AFTER_STEP = 10





_CONTEXT_TRIM_CHARS = 150_000


_TRIM_WINDOW_RATIO = 0.7
_CHARS_PER_TOKEN = 2.5
_TRIM_CHARS_FLOOR = 20_000


def _trim_chars_for_context_window(context_window: int) -> int:
    """上下文窗口（token）→ 压缩触发阈值（字符）。未声明（≤0）回退固定默认值。"""
    cw = int(context_window or 0)
    if cw <= 0:
        return _CONTEXT_TRIM_CHARS
    return max(_TRIM_CHARS_FLOOR, int(cw * _TRIM_WINDOW_RATIO * _CHARS_PER_TOKEN))


def _context_window_of(settings, role: str) -> int:
    """取角色当前档案声明的 context_window；未声明或配置异常 → 0（调用方回退固定阈值）。"""
    try:
        from agentflow.llm.gateway import profile_for

        return int(profile_for(settings, role).get("context_window") or 0)
    except Exception:
        return 0
_TOOL_RESULT_KEEP_RECENT = 3
_TOOL_RESULT_KEEP_CHARS = 800
_TOOL_RESULT_TRIM_MARK = "…[早期工具结果已压缩，需要全文请重新读取]"


_TOOL_ARG_KEEP_CHARS = 400
_TOOL_ARG_KEEP_RECENT = 2
_TOOL_ARG_TRIM_MARK = "…[早期写入参数已压缩，需要原文请重新读取该文件]"



_STEP_NUDGE_REMAINING = (12, 8, 4)


def _messages_chars(messages: list[dict]) -> int:
    """messages 总字符数（粗估上下文体积，用于决定是否触发一次性压缩）。"""
    total = 0
    for m in messages:
        c = m.get("content")
        if isinstance(c, str):
            total += len(c)
        for call in m.get("tool_calls") or []:
            fn = call.get("function") or {}
            args = fn.get("arguments")
            if isinstance(args, str):
                total += len(args)
    return total


def _trim_old_tool_results(messages: list[dict]) -> int:
    """压缩较早的 tool 消息（保留最近 _TOOL_RESULT_KEEP_RECENT 条完整），返回本次压缩条数。幂等。"""
    tool_idx = [i for i, msg in enumerate(messages) if msg.get("role") == "tool"]
    trimmed = 0
    for i in tool_idx[:-_TOOL_RESULT_KEEP_RECENT] if len(tool_idx) > _TOOL_RESULT_KEEP_RECENT else []:
        c = messages[i].get("content") or ""
        if len(c) > _TOOL_RESULT_KEEP_CHARS and not c.endswith(_TOOL_RESULT_TRIM_MARK):
            messages[i]["content"] = c[:_TOOL_RESULT_KEEP_CHARS] + _TOOL_RESULT_TRIM_MARK
            trimmed += 1
    return trimmed


def _trim_old_assistant_tool_args(messages: list[dict]) -> int:
    """压缩较早 assistant 消息里的**大体积工具参数**（write_file 的 content、edit_file 的 old/new 等）。"""
    asst_idx = [i for i, m in enumerate(messages) if m.get("role") == "assistant" and m.get("tool_calls")]
    trimmed = 0
    for i in asst_idx[:-_TOOL_ARG_KEEP_RECENT] if len(asst_idx) > _TOOL_ARG_KEEP_RECENT else []:
        for call in messages[i].get("tool_calls") or []:
            fn = call.get("function") or {}
            args = fn.get("arguments")
            if not isinstance(args, str) or len(args) <= _TOOL_ARG_KEEP_CHARS:
                continue
            try:
                obj = json.loads(args)
            except Exception:
                continue
            if not isinstance(obj, dict):
                continue
            hit = False
            for k in ("content", "old", "new", "declaration"):
                v = obj.get(k)
                if isinstance(v, str) and len(v) > _TOOL_ARG_KEEP_CHARS:
                    obj[k] = v[:_TOOL_ARG_KEEP_CHARS] + _TOOL_ARG_TRIM_MARK
                    hit = True
            if hit:
                fn["arguments"] = json.dumps(obj, ensure_ascii=False)
                trimmed += 1
    return trimmed



_ROLE_DROP_TOOLS: dict[str, set[str]] = {}


_CHECKPOINT_MARK = "【进度检查点】"


def _context_checkpoint(messages: list[dict], steps: int, max_steps: int) -> str:
    """历史压缩后补的**进度检查点**。"""
    touched: list[str] = []
    for msg in messages:
        for call in msg.get("tool_calls") or []:
            fn = call.get("function") or {}
            if fn.get("name") not in ("write_file", "edit_file"):
                continue
            try:
                obj = json.loads(fn.get("arguments") or "{}")
            except Exception:
                continue
            if not isinstance(obj, dict):
                continue
            if obj.get("path"):
                touched.append(str(obj["path"]).replace("\\", "/"))
            for e in obj.get("edits") or []:
                if isinstance(e, dict) and e.get("path"):
                    touched.append(str(e["path"]).replace("\\", "/"))
    uniq = list(dict.fromkeys(touched))
    return (
        f"{_CHECKPOINT_MARK}（本节点历史已压缩，早前工具结果只保留摘要；以下是不可丢的硬事实）\n"
        "- 交付契约：**本会话首条消息**里本功能的 verify_commands 原文，收尾前必须逐条真跑通过"
        "（不要凭记忆复述断言）。\n"
        f"- 本节点写入过的文件（按时间序）：{', '.join(uniq[-12:]) if uniq else '（暂无写入）'}\n"
        f"- 进度：第 {steps}/{max_steps} 步。需要某文件当前内容时**重新 read_file**（勿凭记忆猜）；"
        "改动完成且契约通过后立即 done。\n"
    )


class DeltaThrottler:
    """LLM delta 流的限频发布器（agent.delta 事件，内存直通不落 EventLog）。"""

    _INTERVAL = 0.25
    _MIN_BYTES = 32
    _MAX_BYTES = 256

    def __init__(self, bus, task_id: int, node_id: int | None, role: str, phase: str = ""):
        self._bus = bus
        self._task_id = task_id
        self._node_id = node_id
        self._role = role
        self._phase = phase
        self._buf: list[str] = []
        self._last = 0.0

    def feed(self, text: str) -> None:
        if not text:
            return
        self._buf.append(text)
        now = time.monotonic()
        size = sum(len(s) for s in self._buf)
        if (now - self._last >= self._INTERVAL and size >= self._MIN_BYTES) or size > self._MAX_BYTES:
            self.flush()

    def flush(self, done: bool = False) -> None:
        try:
            text = "".join(self._buf)
            if text or done:
                self._bus.publish_ephemeral(self._task_id, "agent.delta", {
                    "node_id": self._node_id,
                    "role": self._role,
                    "phase": self._phase,
                    "text": text,
                    "done": done,
                })
            self._buf.clear()
            self._last = time.monotonic()
        except Exception:
            self._buf.clear()


def agents_md_text(repo_root: Path | str | None, fallback_root: Path | str | None = None) -> str:
    """渲染项目 内部文档 段（记忆系统 ）：项目宪法，优先级最高。"""
    for root in (repo_root, fallback_root):
        try:
            p = Path(root) / "内部文档" if root else None
            if not p or not p.exists() or not p.is_file():
                continue
            content = p.read_text(encoding="utf-8", errors="replace").strip()
            if not content:
                continue
            if len(content) > _AGENTS_MD_LIMIT:
                content = content[:_AGENTS_MD_LIMIT] + "\n…[内部文档 过长已截断，完整版请用 read_file 读取]"
            return (
                "## 项目 内部文档（项目宪法，最高优先级；与下方任何规则冲突时，以本文件为准）\n"
                f"{content}\n\n"
            )
        except Exception:
            continue
    return ""


def priority_context_text(
    session: Session, project_id: int, repo_root: Path | str | None, fallback_root: Path | str | None = None
) -> str:
    """统一优先级注入链（单点定义）：内部文档（项目宪法，最高） > 全局规则 > 项目规则。"""
    return agents_md_text(repo_root, fallback_root) + project_rules_text(session, project_id)[:_RULES_LIMIT]


@dataclass
class Dispatch:
    task: m.Task
    role: str
    feature: m.Feature | None
    system: str
    prompt: str




    images: list[str] = field(default_factory=list)
    node_kind: str = "think"
    node_id: int | None = None
    report: str = ""
    max_steps: int | None = None
    stop_reason: str = ""

    requires_done: bool = False





    usage_in: int = 0
    usage_out: int = 0
    usage_cached: int = 0
    usage_settled: bool = False


class StuckLoopError(RuntimeError):
    """轮内 stuck（死循环指纹命中）：响亮错中断本次 dispatch。"""


class StepLimitExhausted(RuntimeError):
    """步数耗尽仍未调用 done：响亮错。"""


class _StuckDetector:
    """轮内死循环检测。"""

    def __init__(self, settings, dispatch: "Dispatch"):
        sched = settings.data.get("scheduler", {}) if settings else {}
        self.max_repeat = int(sched.get("stuck_max_repeat", 3))
        self.max_silent = int(sched.get("stuck_max_silent", 6))
        self._dispatch = dispatch
        self._last_fp = ""
        self._repeat = 0
        self._silent = 0

    def record_step(self, has_calls: bool) -> None:
        """每步循环头调用：无工具调用步计数（自我对话检测）。"""
        if has_calls:
            self._silent = 0
        else:
            self._silent += 1
            if self._silent >= self.max_silent:
                raise StuckLoopError(
                    f"轮内 stuck：连续 {self._silent} 步无工具调用（自我对话空转），超出阈值 {self.max_silent}"
                )

    def record_observation(self, name: str, args: dict, ok: bool, message: str) -> None:
        """每次真实工具执行后调用：相同"动作+观察"指纹连续重复检测。"""
        try:
            fp = json.dumps(
                {"t": name, "a": args, "ok": bool(ok), "m": (message or "")[:160]},
                ensure_ascii=False, sort_keys=True, default=str,
            )
        except Exception:
            fp = f"{name}|{ok}|{(message or '')[:160]}"
        if fp == self._last_fp:
            self._repeat += 1
        else:
            self._last_fp = fp
            self._repeat = 1
        if self._repeat >= self.max_repeat:
            preview = (message or "")[:120]
            raise StuckLoopError(
                f"轮内 stuck：工具 {name} 以相同参数与相同结果连续重复 {self._repeat} 次（阈值 {self.max_repeat}），最近结果: {preview}"
            )


class AgentRuntime:
    """ReAct 执行运行时。每次 dispatch 在独立线程中运行（支持多写并行）。"""

    def __init__(
        self,
        engine,
        gateway: LLMGateway,
        bus: events_bus.EventBus,
        settings,
        repo_root: Path,
        project_invariants: list[str] | None = None,
        drop_tools: set[str] | None = None,
        intervention_fetch=None,
        project_root: Path | None = None,
    ):
        self.engine = engine
        self.gateway = gateway
        self.bus = bus
        self.settings = settings
        self.repo_root = repo_root
        self.project_root = project_root
        self.project_invariants = project_invariants or []
        self.drop_tools = drop_tools or set()
        self.intervention_fetch = intervention_fetch
        self._last_activity = 0.0

    def _task_status(self, task_id: int) -> str:
        """任务状态实时读（跨线程，独立短 session 防 caller session 缓存脏值）。异常返回空（不误停）。"""
        try:
            with Session(self.engine) as s:
                t = s.get(m.Task, task_id)
                return t.status.value if t else ""
        except Exception:
            return ""

    def _drain_interventions(self) -> list[str]:
        """拉取用户插队消息（拉取器内部负责标记消费）。失败静默返回空：插队是增强，不阻塞主流程。"""
        if not self.intervention_fetch:
            return []
        try:
            return self.intervention_fetch() or []
        except Exception:
            return []

    def _echo_intervention_reply(self, dispatch: Dispatch, text: str) -> None:
        """插队回复落对话窗：持久化 ClarifyMessage(role=assistant) + SSE 推送。"""
        content = f"**插队回复（{dispatch.role}）**\n\n{(text or '').strip()[:4000]}"
        payload = {"task_id": dispatch.task.id, "role": "assistant", "content": content}
        try:
            with Session(self.engine) as s:
                am = m.ClarifyMessage(task_id=dispatch.task.id, role="assistant", content=content)
                s.add(am)
                s.commit()
                s.refresh(am)
                payload["id"] = am.id
        except Exception:
            pass
        try:
            self.bus.publish_task(dispatch.task.id, "clarify.message", payload)
        except Exception:
            pass

    def run(self, dispatch: Dispatch, session: Session, safety: Safety) -> str:
        """同步执行一次 dispatch（ReAct），返回最终文本。在调用方线程内跑。"""
        self._last_activity = time.monotonic()
        wd_stop = self._watchdog_arm(dispatch)
        try:
            return self._run_react(dispatch, session, safety)
        finally:



            self._settle_usage(dispatch)
            wd_stop.set()

    def _settle_usage(self, dispatch: Dispatch) -> None:
        """dispatch 结束统一结算：node 落 usage + 任务预算累加（best-effort、幂等）。"""
        if dispatch.usage_settled:
            return
        dispatch.usage_settled = True
        if not dispatch.node_id or dispatch.usage_in + dispatch.usage_out <= 0:
            return
        try:
            from agentflow.core.budget import add_usage

            with Session(self.engine) as bs:
                n = bs.get(m.Node, dispatch.node_id)
                if n is not None:
                    n.token_in = (n.token_in or 0) + dispatch.usage_in
                    n.token_out = (n.token_out or 0) + dispatch.usage_out
                    if hasattr(n, "token_in_cached"):
                        n.token_in_cached = (n.token_in_cached or 0) + dispatch.usage_cached
                    bs.add(n)
                t = bs.get(m.Task, dispatch.task.id)
                if t is not None:
                    add_usage(bs, t, dispatch.usage_in, dispatch.usage_out, tokens_in_cached=dispatch.usage_cached)
                    bs.commit()
        except Exception:
            pass

    def _run_react(self, dispatch: Dispatch, session: Session, safety: Safety) -> str:
        node = session.get(m.Node, dispatch.node_id) if dispatch.node_id else None
        trace_uri = node.trace_uri if node else ""
        ctx = ToolContext(
            repo_root=self.repo_root,
            task_id=dispatch.task.id,
            feature_id=dispatch.feature.id if dispatch.feature else None,
            session=session,
            safety=safety,
            settings=self.settings,
            trace_uri=trace_uri,
            project_invariants=self.project_invariants,
            bus=self.bus,
            role=dispatch.role,
        )
        tools = build_tools(ctx)

        self.drop_tools = set(self.drop_tools or set()) | _ROLE_DROP_TOOLS.get(dispatch.role, set())

        _web = self.settings.data.get("web") or {}
        if not bool(_web.get("enabled", True)):
            self.drop_tools |= {"web_fetch", "web_search"}
        elif not str(_web.get("search_url") or "").strip():
            self.drop_tools.add("web_search")
        for k in self.drop_tools:
            tools.pop(k, None)
        tools_schema = build_openai_tools(drop=self.drop_tools)

        _delegable = dispatch.role in ("fixer",) and dispatch.node_kind != "delegate"





        _executes = dispatch.requires_done and dispatch.node_kind != "delegate"
        if _delegable:
            tools["delegate_subtask"] = lambda question, context="": self._delegate_subtask(
                dispatch, session, safety, question, context
            )
        if _executes:
            tools["ui_check"] = lambda declaration="": self._ui_check(dispatch, session, declaration)
        else:
            tools_schema = [
                t for t in tools_schema if t["function"]["name"] != "ui_check"
            ]
        if not _delegable:
            tools_schema = [
                t for t in tools_schema if t["function"]["name"] != "delegate_subtask"
            ]

        max_steps = dispatch.max_steps or self.settings.data["scheduler"]["max_steps_per_run"]
        stuck = _StuckDetector(self.settings, dispatch)




        system = dispatch.system or ""
        rules = priority_context_text(session, dispatch.task.project_id, self.repo_root, self.project_root)


        try:
            from agentflow.core.skills import list_skills, skill_index_text

            skill_idx = skill_index_text(list_skills(self.settings.home, project_id=dispatch.task.project_id))
        except Exception:
            skill_idx = ""
        if rules or skill_idx:
            system = rules + skill_idx + system
        messages: list[dict] = []
        if system:
            messages.append({"role": "system", "content": system})
        if dispatch.images:


            _note = (
                f"（本消息随附 {len(dispatch.images)} 张需求截图，**样式/视觉类要求以图为准**，"
                "不要仅凭文字推断形状、位置与尺寸）\n\n"
            )
            _first: list[dict] = [{"type": "text", "text": _note + dispatch.prompt}]
            _first += [{"type": "image_url", "image_url": {"url": u}} for u in dispatch.images]
            messages.append({"role": "user", "content": _first})
        else:
            messages.append({"role": "user", "content": dispatch.prompt})
        steps = 0
        final = ""
        done = False



        _node_start = time.monotonic()
        _slow_reported: set[int] = set()

        pending_reply = 0
        stuck_reason = ""
        interrupted = False
        zero_diff_rejects = 0
        read_cache: dict[str, tuple[int, str]] = {}
        while steps < max_steps:
            steps += 1





            st = self._task_status(dispatch.task.id)
            if st and st not in ("running", "merging", "spec_generating"):
                self._trace(trace_uri, "interrupt", f"任务状态变为 {st}，agent 停止执行")
                interrupted = True
                break

            if self._budget_hit(dispatch):
                self._trace(trace_uri, "interrupt", "预算超限（硬顶），agent 停止执行")
                interrupted = True
                break
            notes = self._drain_interventions()
            pending_reply += len(notes)
            for note in notes:
                messages.append({"role": "user", "content": f"【用户插队指令，最高优先级】{note}\n请先响应此指令/按其调整工作方向，再继续原任务。"})

            _remaining = max_steps - steps
            if dispatch.requires_done and _remaining in _STEP_NUDGE_REMAINING:
                if dispatch.node_kind == "diagnose":



                    _tail = (
                        "**诊断节点的产出契约是 ```` ```json ```` 诊断卡（verdict/根因/涉及文件）+ 调用 done**："
                        "请立刻收敛，把已查到的证据整理成合规卡片输出，不要再开新的探索分支。"
                    )
                else:
                    _tail = (
                        "**若改动已完成、本功能 verify_commands 已跑过并通过，请立刻调用 done**——"
                        "重复自证 / 重复读同一批文件不会让结果更好；步数耗尽后本节点按失败结算，"
                        "会被重派重跑并可能撞预算硬顶。若仍有未完成的关键改动，只做最关键的一步，随即 done。"
                        if _remaining <= 8 else
                        "请开始收敛：先确认改动是否已写完并跑过本功能 verify_commands，尽快 done；"
                        "不要再做与交付无关的探索（重复 grep/读文件不产生交付价值）。"
                    )
                messages.append({"role": "user", "content": (
                    f"【步数预算提示】本节点上限 {max_steps} 步，已用 {steps}，剩余 {_remaining}。" + _tail
                )})

            _elapsed = time.monotonic() - _node_start
            for _th in (180, 420, 900):
                if _elapsed >= _th and _th not in _slow_reported:
                    _slow_reported.add(_th)
                    self._ev(dispatch, "log.appended", {
                        "level": "sched",
                        "message": (
                            f"「长跑提示」节点仍在运行：已 {int(_elapsed)}s（第 {steps}/{max_steps} 步，"
                            f"角色 {dispatch.role}）。长尾多来自反复自测/环境探索；"
                            "若确认无进展，可在任务操作里暂停或终止。"
                        ),
                    })



            _trim_chars = _trim_chars_for_context_window(_context_window_of(self.settings, dispatch.role))
            if _messages_chars(messages) > _trim_chars:
                trimmed = _trim_old_tool_results(messages)
                if trimmed:
                    self._trace(trace_uri, "context_trim", f"第 {steps} 轮：压缩 {trimmed} 条早期工具结果")
                trimmed_args = _trim_old_assistant_tool_args(messages)
                if trimmed_args:
                    self._trace(trace_uri, "context_trim", f"第 {steps} 轮：压缩 {trimmed_args} 条早期写入参数")




                if not any(_CHECKPOINT_MARK in str(m.get("content") or "") for m in messages):
                    messages.append({"role": "user", "content": _context_checkpoint(messages, steps, max_steps)})
                    self._trace(trace_uri, "context_checkpoint", "已插入进度检查点")
            try:
                throttler = DeltaThrottler(self.bus, dispatch.task.id, dispatch.node_id, dispatch.role)
                result = self.gateway.generate(dispatch.role, messages=messages, tools=tools_schema, on_delta=throttler.feed)
                throttler.flush(done=True)
            except Exception as e:
                if not _is_context_overflow(e):

                    self._trace(trace_uri, "llm_error", f"{type(e).__name__}: {e}")
                    raise

                truncated = truncate_messages(messages)
                if len(truncated) == len(messages):
                    self._trace(trace_uri, "llm_error", f"上下文溢出且无可截断历史: {type(e).__name__}: {e}")
                    raise
                messages = truncated
                self._trace(trace_uri, "context_truncated", f"上下文溢出，历史截至 {len(messages)} 条后重试: {e}")
                try:
                    throttler = DeltaThrottler(self.bus, dispatch.task.id, dispatch.node_id, dispatch.role)
                    result = self.gateway.generate(dispatch.role, messages=messages, tools=tools_schema, on_delta=throttler.feed)
                    throttler.flush(done=True)
                except Exception as e2:
                    self._trace(trace_uri, "llm_error", f"截断后仍失败: {type(e2).__name__}: {e2}")
                    raise

            dispatch.usage_in += result.tokens_in
            dispatch.usage_out += result.tokens_out
            dispatch.usage_cached += getattr(result, "tokens_in_cached", 0) or 0
            self._trace(trace_uri, "response", result.text, tokens=result.tokens_out, tool_calls=result.tool_calls)


            calls = list(result.tool_calls) if result.tool_calls else []
            text_call = extract_tool_call(result.text) if not calls else None
            if text_call:
                calls = [text_call]


            self._ev(dispatch, "agent.step", {
                "role": dispatch.role,
                "step": steps,
                "text": (result.text or "")[:200],
                "tool_calls": [{"name": c.get("name"), "args": _preview(c.get("arguments") or c.get("args") or {}, 120)} for c in calls],
                "tokens": result.tokens_out,
            })



            if pending_reply > 0 and (result.text or "").strip():
                pending_reply = 0
                try:
                    self._echo_intervention_reply(dispatch, result.text)
                except Exception:
                    pass

            if not calls:

                try:
                    stuck.record_step(False)
                except StuckLoopError as e:
                    self._stuck_hit(dispatch, trace_uri, str(e))
                    stuck_reason = str(e)
                    break
                final = result.text
                messages.append({"role": "assistant", "content": result.text or ""})
                messages.append({"role": "user", "content": "（无工具调用。请直接用工具完成任务，或调用 done 结束）"})
                continue
            stuck.record_step(True)


            assistant_msg: dict = {"role": "assistant", "content": result.text or ""}
            tc_structs = []
            for i, c in enumerate(calls):
                tc_id = c.get("id") or f"call_{steps}_{i}"
                c["id"] = tc_id
                tc_structs.append({
                    "id": tc_id,
                    "type": "function",
                    "function": {
                        "name": c.get("name"),
                        "arguments": json.dumps(c.get("arguments") or c.get("args") or {}, ensure_ascii=False),
                    },
                })
            if result.tool_calls:
                assistant_msg["tool_calls"] = tc_structs
            messages.append(assistant_msg)

            done = False
            done_call_id = ""
            for call in calls:
                name = call.get("name")
                args = call.get("arguments") or call.get("args") or {}
                if name == "done":



                    if (
                        dispatch.role == "fixer"
                        and dispatch.node_kind != "delegate"
                        and zero_diff_rejects < 2
                        and self._workdir_diff_empty()
                    ):
                        zero_diff_rejects += 1
                        msg = (
                            "写集无任何改动（git status 为空），拒绝零改动上报完成。"
                            "请实际修改代码使校验通过后再调 done；若根因不在代码（环境/依赖），"
                            "先用 run_cmd 补装/修复环境再试。"
                        )
                        self._ev(dispatch, "tool.result", {"role": dispatch.role, "name": "done", "ok": False, "message": msg, "duration_ms": 0})
                        self._trace(trace_uri, "tool_call", "done", args={}, ok=False, message=msg)
                        if result.tool_calls:
                            messages.append({"role": "tool", "tool_call_id": call.get("id") or f"call_{steps}_done", "content": msg})
                        else:
                            messages.append({"role": "user", "content": f"（{msg}）"})
                        continue
                    self._ev(dispatch, "tool.result", {"role": dispatch.role, "name": "done", "ok": True, "message": "agent 声明完成", "duration_ms": 0})


                    t = result.text or ""
                    if t and t != "done":
                        final = t
                    elif not final:
                        final = "done"
                    done_call_id = call.get("id") or f"call_{steps}_{calls.index(call)}"
                    done = True
                    break
                fn = tools.get(name)
                t0 = time.monotonic()
                self._ev(dispatch, "tool.call", {"role": dispatch.role, "name": name, "args": _preview(args)})
                if fn is None:
                    outcome = (False, f"未知工具: {name}。可用工具见本轮工具列表；如需类似能力请检查工具名拼写")
                else:
                    try:
                        outcome = fn(**args)
                    except TypeError as e:
                        outcome = (False, f"工具 {name} 参数不匹配: {e}。请对照工具 schema 检查参数名与类型")
                    except Exception as e:
                        outcome = (False, f"工具 {name} 执行异常 {type(e).__name__}: {e}")
                self._ev(dispatch, "tool.result", {
                    "role": dispatch.role,
                    "name": name,
                    "ok": bool(outcome[0]),
                    "message": str(outcome[1])[:300],
                    "duration_ms": int((time.monotonic() - t0) * 1000),
                })
                self._trace(trace_uri, "tool_call", name, args=args, ok=outcome[0], message=outcome[1][:500])
                try:
                    stuck.record_observation(name, args, bool(outcome[0]), str(outcome[1]))
                except StuckLoopError as e:
                    self._stuck_hit(dispatch, trace_uri, str(e))
                    stuck_reason = str(e)
                    break

                out_msg = str(outcome[1])


                if name == "read_file" and outcome[0]:
                    try:
                        key = json.dumps(args, ensure_ascii=False, sort_keys=True, default=str)
                        prev = read_cache.get(key)
                        if prev is not None:
                            out_msg = (
                                f"[重复读取] 与第 {prev[0]} 步请求的同一文件窗口完全相同，内容已在历史中"
                                "（早期结果可能已被压缩，此处附尾部原文）。直接基于已有信息行动；"
                                "确需重看请换 offset/max_lines 窗口。\n"
                                f"--- 内容尾部 ---\n{prev[1][-800:]}"
                            )
                        read_cache[key] = (steps, str(outcome[1]))
                    except Exception:
                        pass
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.get("id") or f"call_{steps}_{calls.index(call)}",
                    "content": out_msg[:2000],
                })

            if stuck_reason:
                break
            if done:
                notes = self._drain_interventions()
                if notes:

                    pending_reply += len(notes)
                    if result.tool_calls:
                        messages.append({"role": "tool", "tool_call_id": done_call_id, "content": "用户发来新指令，暂缓结束，先处理插队消息"})
                    else:
                        messages.append({"role": "user", "content": "（用户发来新指令，暂缓结束）"})
                    for note in notes:
                        messages.append({"role": "user", "content": f"【用户插队指令，最高优先级】{note}\n请先响应此指令，再完成原任务后调用 done。"})
                    done = False
                    continue
                break

        if stuck_reason:
            raise StuckLoopError(stuck_reason)



        if (
            not done
            and not interrupted
            and dispatch.requires_done
            and dispatch.node_kind != "delegate"
        ):
            raise StepLimitExhausted(
                f"步数耗尽（{max_steps} 步）仍未调用 done：不按成功结算，转校验/重派路径"
            )

        dispatch.stop_reason = (
            "done" if done else "stuck" if stuck_reason else "interrupted" if interrupted else "step_limit"
        )



        tag = "DEV_REPORT" if dispatch.role in ("developer", "lead") else "FIX_REPORT" if dispatch.role == "fixer" else ""
        if tag:
            dispatch.report = extract_report(final, tag)

        self._settle_usage(dispatch)
        return final

    def _ev(self, dispatch: Dispatch, event: str, payload: dict) -> None:
        """推送节点级细粒度事件（SSE 实时进度）。失败不影响执行，trace 仍有原始证据。"""
        if dispatch.node_id is None:
            return
        try:
            self.bus.publish_task(dispatch.task.id, event, {"node_id": dispatch.node_id, **payload})
        except Exception:
            pass

    def _ui_check(self, dispatch: Dispatch, session: Session, declaration: str = "") -> tuple[bool, str]:
        """开发期真浏览器自测（与合并门禁同一套 ui 机审管线）。"""
        from agentflow.verifiers.ui import UiVerifier

        cmd = (declaration or "").strip()
        if not cmd:
            cmd = self._feature_ui_declaration(session, dispatch)
            if not cmd:
                return (
                    False,
                    "本功能 Spec 未声明 ui 机审命令（verifier=ui + stage=heavy）。"
                    "可传 declaration 参数做临时检查，或让 Lead 重规划补上机审声明。",
                )
        try:
            res = UiVerifier().run(cmd, Path(self.repo_root), timeout=300)
        except Exception as e:
            return (False, f"UI 自测执行异常：{type(e).__name__}: {e}")
        ok = res.exit_code == 0





        parts = [
            ("UI 自测通过（exit 0）" if ok else f"UI 自测未通过（exit {res.exit_code}）"),
            (res.output or "")[:1200],
        ]


        try:
            import json as _json

            rep = _json.loads(res.detail or "{}")
            for pg in (rep.get("pages") or [])[:2]:
                for st in (pg.get("steps") or [])[:24]:
                    mark = "✓" if st.get("ok") else "✗"
                    line = f"  {mark} {st.get('op')} · {st.get('target')}"
                    if st.get("err"):
                        line += f" · {str(st['err'])[:120]}"
                    parts.append(line)
                if pg.get("dom"):
                    parts.append(f"  页面可见控件: {' | '.join(pg['dom'])}")
        except Exception:
            pass
        return (ok, "\n".join(parts)[:3000])

    def _feature_ui_declaration(self, session: Session, dispatch: Dispatch) -> str:
        """本功能 Spec 声明的 ui 机审命令（stage=heavy 优先；没有则取任意 ui 命令）。"""
        try:
            if dispatch.feature is None:
                return ""
            cmds = json.loads(dispatch.feature.verify_commands or "[]")
        except Exception:
            return ""
        ui_cmds = [c for c in cmds if str(c.get("verifier", "")).strip().lower() == "ui"]
        if not ui_cmds:
            return ""
        heavy = [c for c in ui_cmds if str(c.get("stage", "")).strip().lower() == "heavy"]
        return str((heavy or ui_cmds)[0].get("cmd") or "")

    def _delegate_subtask(self, parent: Dispatch, session: Session, safety: Safety, question: str, context: str) -> tuple[bool, str]:
        """一级子代理委派（B 破僵局）：全新上下文只解单一子问题，结论作为工具观察返回。"""
        question = (question or "").strip()
        if not question:
            return (False, "缺少 question：请写明要解决的单一子问题与预期产出")
        sub = Dispatch(
            task=parent.task,
            role=parent.role,
            feature=parent.feature,
            system=_SUBAGENT_SYSTEM,
            node_kind="delegate",
            node_id=parent.node_id,
            prompt=(
                f"## 主代理的问题\n{question[:2000]}\n\n"
                f"## 主代理提供的背景\n{(context or '').strip()[:4000] or '（无）'}\n\n"
                "解决该子问题后调用 done，输出关键结论。"
            ),
            max_steps=12,
        )
        self._ev(parent, "log.appended", {"level": "sched", "message": f"[{parent.role}] 委派子代理解决子问题：{question[:80]}"})
        try:
            answer = self._run_react(sub, session, safety)
        except StuckLoopError as e:
            self._settle_usage(sub)
            return (False, f"子代理自身陷入 stuck，未得出结论：{e}")
        except Exception as e:
            self._settle_usage(sub)
            return (False, f"子代理执行异常：{type(e).__name__}: {e}")
        why = {"step_limit": "步数耗尽（12 步）仍未调用 done", "interrupted": "任务状态/预算中断", "stuck": "轮内 stuck"}.get(
            sub.stop_reason, ""
        )
        text = (answer or "").strip()
        if text == "done":
            text = ""
        if not text:
            msg = (
                f"子代理未产出结论（{why or '未调用 done'}）：本次委派无有效产出。"
                "不要重复同样的委派——请换路径：自己用 run_cmd 直接验证，或基于已有证据推进/上报。"
            )
            self._ev(parent, "log.appended", {"level": "sched", "message": f"[{parent.role}] 子代理委派失败：{why or '无有效产出'}"})
            return (False, msg)
        if why:

            text = f"（子代理{why}；以下为其中途产出，结论可能不完整）\n{text}"
        self._ev(parent, "log.appended", {"level": "sched", "message": f"[{parent.role}] 子代理返回（{len(text)} 字）"})
        return (True, text[:4000])

    def _stuck_hit(self, dispatch: Dispatch, trace_uri: str, reason: str) -> None:
        """stuck 命中留证：trace + 事件（stuck.detected + 日志行），随后由调用方抛 StuckLoopError。"""
        try:
            self._trace(trace_uri, "stuck", reason)
        except Exception:
            pass
        self._ev(dispatch, "stuck.detected", {"role": dispatch.role, "reason": reason[:300]})
        self._ev(dispatch, "log.appended", {"level": "sched", "message": f"[{dispatch.role}] {reason}"})

    def _workdir_diff_empty(self) -> bool:
        """fixer 完成门（零 diff 谎报拦截）：当前工作区是否无任何未提交改动。"""
        import subprocess as _sp

        try:
            r = _sp.run(
                ["git", "status", "--porcelain"],
                cwd=str(self.repo_root),
                capture_output=True, text=True, timeout=30,
                encoding="utf-8", errors="replace",
            )
            if r.returncode != 0:
                return False
            return not (r.stdout or "").strip()
        except Exception:
            return False

    def _budget_hit(self, dispatch: Dispatch) -> bool:
        """预算硬顶检查（FR8）：读 DB 用于预算 + 判定；超限停机事件一并发出。异常视为未超（不误停）。"""
        try:
            from agentflow.core.budget import budget_exceeded, budget_soft_exceeded

            with Session(self.engine) as s:
                t = s.get(m.Task, dispatch.task.id)
                if t is None:
                    return False
                hit, reason = budget_exceeded(s, t, self.settings)
                if hit:
                    self.bus.publish_task(dispatch.task.id, "human.required", {
                        "reason": f"预算硬顶熔断（{dispatch.role}）：{reason}。费用看板见 CI 页签；可确认后恢复（决策=提高上限）或废弃。",
                        "options": ["查看 CI 证据", "恢复运行", "废弃"],
                    })
                    self._pause_if_running(dispatch)
                    return True
                tool_soft = (used := json.loads(t.used_budget or "{}")) .get("soft_warned", False)
                soft_hit, soft_reason = budget_soft_exceeded(s, t, self.settings)
                if soft_hit and not tool_soft:
                    used["soft_warned"] = True
                    t.used_budget = json.dumps(used, ensure_ascii=False)
                    s.add(t)
                    s.commit()
                    self.bus.publish_task(dispatch.task.id, "human.required", {
                        "reason": f"预算软顶告警（{dispatch.role}）：{soft_reason}。任务将默认继续；如需止损请点中止或输入调整指令。",
                        "options": [],
                    })
                    self._ev(dispatch, "task.updated", {"task_id": dispatch.task.id, "status": t.status.value})
        except Exception:
            return False
        return False

    def _pause_if_running(self, dispatch: Dispatch) -> None:
        with Session(self.engine) as bs:
            t2 = bs.get(m.Task, dispatch.task.id)
            if t2 is not None and t2.status == m.TaskStatus.running:
                t2.status = m.TaskStatus.paused_human
                bs.add(t2)
                bs.commit()
        self._ev(dispatch, "task.updated", {"task_id": dispatch.task.id, "status": "paused_human"})

    def _trace(self, uri: str, kind: str, content=None, **kw):
        self._last_activity = time.monotonic()
        if uri:
            tr.append(uri, kind, content, **kw)



    def _watchdog_arm(self, dispatch: Dispatch) -> threading.Event:
        """起 daemon 监视线程：无 trace 产出超过 watchdog.idle_timeout_s 且无 pending 审批 → 判死。"""
        stop_ev = threading.Event()

        def _watch():
            try:
                idle_s = float(self.settings.data.get("watchdog", {}).get("idle_timeout_s", 1800))
            except Exception:
                idle_s = 1800.0
            poll = min(30.0, max(5.0, idle_s / 10))
            from agentflow.core.approvals import REGISTRY

            while not stop_ev.wait(poll):
                if time.monotonic() - self._last_activity < idle_s:
                    continue

                try:
                    if REGISTRY.pending_for_task(dispatch.task.id):
                        self._last_activity = time.monotonic()
                        continue
                except Exception:
                    pass
                self._watchdog_stop(dispatch)
                return

        threading.Thread(target=_watch, daemon=True, name=f"watchdog-task{dispatch.task.id}").start()
        return stop_ev

    def _watchdog_stop(self, dispatch: Dispatch) -> None:
        """看门狗判死动作：置 paused_human（仅当仍 running，避免与人工停机/调度器兜底打架）"""
        idle_min = int((time.monotonic() - self._last_activity) / 60)
        reason = f"agent 节点执行看门狗超时（约 {idle_min} 分钟无事件产出，且无待审批命令）"
        try:
            with Session(self.engine) as s:
                t = s.get(m.Task, dispatch.task.id)
                if t is None or t.status != m.TaskStatus.running:
                    return
                t.status = m.TaskStatus.paused_human
                s.add(t)
                s.commit()
                node = s.get(m.Node, dispatch.node_id) if dispatch.node_id else None
                if node is not None and node.trace_uri:
                    tr.append(node.trace_uri, "watchdog", reason)
        except Exception:
            return
        self._ev(dispatch, "log.appended", {"level": "sched", "message": reason})
        self._ev(dispatch, "human.required", {"reason": reason, "options": ["重试", "回滚"]})


def _preview(obj, limit: int = 300) -> str:
    """参数/文本预览（事件与展示用，截断防爆炸）。"""
    try:
        s = obj if isinstance(obj, str) else json.dumps(obj, ensure_ascii=False)
    except Exception:
        s = str(obj)
    return s[:limit]


def extract_report(text: str, tag: str) -> str:
    """提取 agent 输出中的结构化报告块。"""
    if not text:
        return ""
    import re

    m = re.search(rf"\[{tag}\]\s*(.*?)\s*\[/{tag}\]", text, re.S)
    return m.group(1).strip() if m else ""
