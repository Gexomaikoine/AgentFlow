"""应用层增量更新（双轨：`runtime/` 与 `app/` 分开，只替换 `app/`）。"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import urllib.request
import zipfile
from pathlib import Path



_WATCHDOG_CODE = r'''
import json, os, shutil, subprocess, sys, time, urllib.request

root, port, newver = sys.argv[1], sys.argv[2], sys.argv[3]
app = os.path.join(root, "app")
new = os.path.join(root, "app.new")
bak = os.path.join(root, "app.bak")

deadline = time.time() + 90
while time.time() < deadline:
    try:
        urllib.request.urlopen("http://127.0.0.1:%s/api/v1/health" % port, timeout=1).read()
        time.sleep(0.3)
    except Exception:
        break
time.sleep(1.5)

try:
    if os.path.isdir(bak):
        shutil.rmtree(bak, ignore_errors=True)
    if os.path.isdir(app):
        os.rename(app, bak)
    os.rename(new, app)
except Exception:
    try:
        if not os.path.isdir(app) and os.path.isdir(bak):
            os.rename(bak, app)   # 回滚：把备份换回来
    except Exception:
        pass
    sys.exit(1)

# 写回安装根的版本记录：否则 current_version 永远停在"安装时"的版本，
# 下次检查会一直认为有新版本 → 反复提示更新（实测踩到）
try:
    mp = os.path.join(root, "manifest.json")
    with open(mp, encoding="utf-8") as f:
        man = json.load(f)
    man["version"] = newver
    with open(mp, "w", encoding="utf-8") as f:
        json.dump(man, f, ensure_ascii=False, indent=2)
except Exception:
    pass

subprocess.Popen([sys.executable, "-m", "agentflow", "serve", "--no-open", "--port", port], cwd=root, close_fds=True)
'''


def install_root(exe: Path | None = None) -> Path | None:
    """安装根（含 `manifest.json` + `app/` + `runtime/`）。源码树/开发态返回 None。"""
    path = Path(exe or sys.executable).resolve()
    if len(path.parents) < 3:
        return None
    root = path.parents[2]
    if (root / "manifest.json").is_file() and (root / "app").is_dir():
        return root
    return None


def _local_manifest(root: Path) -> dict:
    """读安装根的 manifest.json（记录当前版本与 runtime_id）；读不到给空 dict。"""
    try:
        return json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def local_runtime_id(root: Path) -> str:
    """本机安装的运行时标识（Python 版本 + 依赖声明集哈希）。"""
    return str(_local_manifest(root).get("runtime_id") or "")


def current_version(root: Path) -> str:
    return str(_local_manifest(root).get("version") or "")


def _version_tuple(v: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", v or "")
    return tuple(int(x) for x in parts) if parts else (0,)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _update_token(cfg: dict) -> str:
    """更新源令牌（private 仓库用）：从配置指定的环境变量读（该变量存 ~/.agentflow/.env）。"""
    name = str(cfg.get("token_env") or "").strip()
    return os.environ.get(name, "").strip() if name else ""


def _headers(token: str, accept: str = "application/vnd.github+json") -> dict:
    h = {"Accept": accept, "X-GitHub-Api-Version": "2022-11-28"}
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h


def _fetch(url: str, headers: dict, timeout: float = 30.0) -> bytes:
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _fetch_json(url: str, headers: dict, timeout: float = 30.0) -> dict:
    return json.loads(_fetch(url, headers, timeout).decode("utf-8"))


def _download(url: str, dest: Path, headers: dict, timeout: float = 300.0) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r, tmp.open("wb") as f:
        shutil.copyfileobj(r, f)
    tmp.replace(dest)


def _resolve_release(cfg: dict) -> tuple[dict, str, dict]:
    """取「最新发布」的清单与 app.zip 下载信息。"""
    token = _update_token(cfg)
    api_url = str(cfg.get("api_url") or "").strip().rstrip("/")

    if api_url:
        auth = _headers(token)
        rel = _fetch_json(f"{api_url}/releases/latest", auth)
        assets = {a.get("name"): a for a in (rel.get("assets") or [])}
        m_asset = assets.get("manifest.json")
        if not m_asset or not m_asset.get("url"):
            raise RuntimeError("release 资产里没有 manifest.json")
        manifest = _fetch_json(
            m_asset["url"], _headers(token, "application/octet-stream")
        )
        z = manifest.get("app_zip") or {}
        name = str(z.get("name") or "").strip()
        target = assets.get(name) if name else None
        if not target or not target.get("url"):
            raise RuntimeError(f"release 资产里没有 {name or 'app.zip'}")
        return manifest, str(target["url"]), _headers(token, "application/octet-stream")


    manifest = _fetch_json(str(cfg.get("manifest_url") or ""), {})
    return manifest, str((manifest.get("app_zip") or {}).get("url") or ""), {}


def check_update(settings) -> dict:
    """查更新（只读，不下载 zip）。任何失败都归到 error 字段，不抛异常。"""
    cfg = settings.data.get("update") or {}
    root = install_root()
    token = _update_token(cfg)
    out: dict = {
        "supported": root is not None,
        "install_root": str(root) if root else "",
        "current": current_version(root) if root else "",
        "enabled": bool(cfg.get("enabled")),
        "mode": "github_api" if str(cfg.get("api_url") or "").strip() else "direct",
        "manifest_url": str(cfg.get("manifest_url") or ""),
        "api_url": str(cfg.get("api_url") or ""),
        "token_env": str(cfg.get("token_env") or ""),
        "token_set": bool(token),
        "runtime_id": local_runtime_id(root) if root else "",
        "requires_runtime": "",
        "need_reinstall": False,
        "has_update": False,
        "latest": "",
        "app_zip": {},
        "notes": [],
        "error": "",
    }
    if root is None:
        out["error"] = "当前不是安装形态（源码树/开发态不支持在线更新）"
        return out
    if not out["enabled"]:
        out["error"] = "更新已关闭（设置里可开启）"
        return out
    if out["mode"] == "direct" and not out["manifest_url"]:
        out["error"] = "未配置更新源地址"
        return out
    if out["mode"] == "github_api" and not token:
        out["error"] = f"private 源需要令牌：请在 {out['token_env']} 里配置（存 ~/.agentflow/.env）"
        return out
    try:
        manifest, zip_url, _ = _resolve_release(cfg)
    except Exception as e:
        out["error"] = f"取更新清单失败：{type(e).__name__}: {e}"
        return out
    out["latest"] = str(manifest.get("version") or "")
    out["app_zip"] = {**(manifest.get("app_zip") or {}), "url": zip_url}
    out["requires_runtime"] = str(manifest.get("requires_runtime") or "")

    out["notes"] = [
        {"hash": str(n.get("hash") or ""), "date": str(n.get("date") or ""), "text": str(n.get("text") or "")}
        for n in (manifest.get("notes") or [])
        if isinstance(n, dict)
    ]
    newer = _version_tuple(out["latest"]) > _version_tuple(out["current"])


    if newer and out["requires_runtime"] and out["runtime_id"] and out["requires_runtime"] != out["runtime_id"]:
        out["need_reinstall"] = True
        out["error"] = "这版内置依赖有变化，app 层更新不够用 —— 请下载新版安装包重装（你的配置与数据不受影响）"
    else:
        out["has_update"] = newer
    return out


def apply_update(settings, *, spawn_watchdog: bool = True) -> dict:
    """下载新 app 层并安排替换（真正的目录替换由进程外看门狗在旧服务退出后执行）。"""
    status = check_update(settings)
    if not status.get("supported"):
        return {"ok": False, "error": status.get("error") or "不支持在线更新"}
    if status.get("need_reinstall"):
        return {"ok": False, "error": status.get("error") or "这版需要重装安装包"}
    if not status.get("has_update"):
        return {"ok": False, "error": status.get("error") or "没有可用的新版本"}

    root = Path(status["install_root"])
    cfg = settings.data.get("update") or {}
    try:
        _, zip_url, headers = _resolve_release(cfg)
    except Exception as e:
        return {"ok": False, "error": f"解析更新源失败：{type(e).__name__}: {e}"}
    if not zip_url:
        return {"ok": False, "error": "更新清单缺少 app.zip 下载地址"}

    tmp_zip = root / "app.new.zip"
    try:
        _download(zip_url, tmp_zip, headers)
    except Exception as e:
        return {"ok": False, "error": f"下载失败：{type(e).__name__}: {e}"}

    expect = str((status.get("app_zip") or {}).get("sha256") or "")
    if expect and _sha256(tmp_zip) != expect:
        tmp_zip.unlink(missing_ok=True)
        return {"ok": False, "error": "sha256 校验不通过（下载损坏或清单过期），已丢弃"}

    new_dir = root / "app.new"
    if new_dir.exists():
        shutil.rmtree(new_dir, ignore_errors=True)
    try:
        with zipfile.ZipFile(tmp_zip) as z:
            z.extractall(new_dir)
    except Exception as e:
        return {"ok": False, "error": f"解压失败：{type(e).__name__}: {e}"}


    if not (new_dir / "agentflow" / "__init__.py").is_file():
        shutil.rmtree(new_dir, ignore_errors=True)
        return {"ok": False, "error": "更新包结构不对（缺少 agentflow/），已丢弃"}
    tmp_zip.unlink(missing_ok=True)

    if not spawn_watchdog:
        return {"ok": True, "applied": status["latest"], "message": "新版本已就位（未启动看门狗）"}

    port = settings.data["server"]["port"]
    kwargs: dict = {}
    if sys.platform == "win32":
        kwargs["creationflags"] = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True
    try:
        subprocess.Popen(
            [sys.executable, "-c", _WATCHDOG_CODE, str(root), str(port), str(status["latest"])],
            close_fds=True, **kwargs,
        )
    except Exception as e:
        return {"ok": False, "error": f"拉起更新看门狗失败：{e}"}





    threading.Timer(1.0, lambda: os._exit(0)).start()
    return {
        "ok": True,
        "applied": status["latest"],
        "message": "新版本已下载，服务即将重启并切换（替换失败会自动回滚到旧版）",
    }
